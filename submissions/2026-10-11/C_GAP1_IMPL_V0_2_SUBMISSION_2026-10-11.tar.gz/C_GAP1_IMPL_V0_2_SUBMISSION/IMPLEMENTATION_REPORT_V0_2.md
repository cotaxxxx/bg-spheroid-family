# IMPLEMENTATION_REPORT_V0_2 — C 空白① 実装 v0.2（Code、2026-10-11）

## 0. 位置づけと立場

**拘束文書：** Code 宛指示書 v0.2（Judge 発行、chat 起草）。Judge が会話に貼り付けた本文を受け取った。
- この時点で bg-spheroid-family の main は `d9457b2a` のままで、Code は次のものを main から読めていない。SHA-256 も照合していない（OPEN_QUESTIONS A1）。
  - v0.2 の指示書そのもの
  - 根拠の `audits/CHAT_DIFF_AUDIT_C_GAP1_IMPL_V0_1_2026-10-11.md`（§8）
  - ChatGPT の監査（`f1ffe1f8`）
- v0.2 の内容は、貼り付けられた本文だけに基づいている。

**出発点と差分：**
- 出発点は v0.1 の提出物（`df2a6915…0077`）の新しい7本。
- v0.1 の生成スクリプトに v0.2 の edit を加え、baseline に当てて作った。
- 変えていないもの：baseline の7本、import 17本、読むだけの pin 1本、allowlist、保護対象の本体。両 kernel と入口2本は、v0.1 と byte 一致である。

**Code の立場：** 実装者であり、監査者ではない。静的 control と提出前の自己点検は、自己確認にすぎない。

**やっていないこと：**
- 数値の実行
- producer、checker、driver、スタブ control の実行
- g_box、gt_box、interval kernel の呼び出し
- 証明書や receipt の生成
- commit、push、既存ファイルの変更、FREEZE

リポジトリに対しては、`git fetch`（bg-spheroid-family のリモート追跡 ref）と `git show`／`git cat-file` だけを行った。提出時点で、bg-oblate-spheroid、bg-spheroid-family、basepoint-geometry のどれも、`git status --short --untracked-files=all` が空である。

## 1. pin の表（v0.1 → v0.2）

| path | v0.1 blob | v0.2 SHA-256 | v0.2 blob | 行数 | v0.1→v0.2 |
|---|---|---|---|---|---|
| `gap1_producer/global_axial_c1b_kernel.py` | d341ee12… | 89b275a657a22a3d3880201c862b5b8bfcb9e002a4411d4e30837368f17dba99 | d341ee1214393c20dd551ce0fac2deacadabe563 | 2336 | 変更なし |
| `gap1_producer/global_axial_c1b_gating.py` | 3009cf03… | a8ed0e9265b22b880aed7699f3f39ce8257fc3b38a6fcfc798ea0467961ddc24 | 7a96afdc42e3de4422888c2c23d47f1976c004ef | 1010 | −14/+94 |
| `gap1_producer/global_axial_c1b_producer.py` | 34ef3758… | 952caa157e8017cf519a28fce1109f52bab37666442038d3eb3aa1949db83da7 | 34ef3758382de5993116c49d511b5b68e4e87bfa | 6 | 変更なし |
| `gap1_analysis/c1b_resumable_driver.py` | f9a8e993… | 27296ab468619ab76ae2e5bca291e459d81172a244da024292afc7a2cc11a6ea | f381ae6849670f02f2c1b4d86442e3df6c6a299d | 392 | −2/+3 |
| `gap1_checker/global_axial_c1b_kernel.py` | 8dc5fb3c… | dcf2dc0af80d88ad1f862745f16b00faabdd9d786a197ca7ecfb7b629739513e | 8dc5fb3c261e8865d0c84401daaf04591674a097 | 2328 | 変更なし |
| `gap1_checker/global_axial_c1b_gating.py` | 1e4e8ee5… | 1eb24c61f8fc7236f973535407182e115933c302abb4be55d830930b61abae0e | 284ec74e06ac9abfa9f5a9999b7d42dd3f4cd305 | 1012 | −15/+93 |
| `gap1_checker/global_axial_c1b_checker.py` | 5b526ddc… | 705c86eb853aa29bc127e43a06e45813995eea6315b2227a1536e2c38470245e | 5b526ddc4f48dc01d3f95eafb44f3d638e2e35ed | 6 | 変更なし |

- baseline の blob（67dda838、a93ca173、0616fbd7、5fd308bb、4eaca55d、03df2620、0760764e）と import 17本は、control 1 で一致を確認した。
- 7本とも、AST の parse と compile-only を通る。
- baseline から作り直すと、byte 一致で再現する。

## 2. F4：L の記録を実際の証明方法と一致させる（DIFF-E）

- `gap1_negative_block_closure`（両 gating に同じテキスト）が、試行中に記録された guard を、段ごとに数える。数えるのは、direct の評価数と閉じた数、mono を試した数と閉じた数である。
  - L は baseline の `eval_exterior` の guard を数える。baseline の関数は変更していない。
  - X は `x_negative_eval` の guard を数える。
- 結果は `result.gap1.negative_block_closure` に書く。`method` は `DIRECT_G_BOX_ONLY` か `DIRECT_G_BOX_AND_MONO_CLOSURE_G0_E1_V3` のどちらかで、`root_count.method` にも写す。
- L の `root_count.rule` は、`method` に応じて `GAP1_L_RULES` の2通りの文言のどちらかになる（direct だけ／direct と mono 閉包。後者は G0/E1 v3 を明記）。証明書が不成立の試行では `rule` は null。
- X は v0.1 のとおり direct だけ。X で mono の guard が数えられたら、`CONTRACT_MISMATCH:X_MONO_CLOSURE` で止める。
- 数え方の詳細は schema §2.6 にある。

## 3. F5：ABORT した slab で受け入れの件数を増やさない（DIFF-E）

**producer：**
- 試行が成立した経路では、候補値 `cap_test_accepted_count = accepted_count + 1`、`cap_test_accepted_work = accepted_work + attempt_work` で上限を判定する。
- ABORT なら、確定値（`accepted_count`、`accepted_work`）と `previous_root` を変えない。ACCEPT のときだけ、候補値を確定値にし、`previous_root` を更新する。
- 候補値は payload の `cap_test_accepted_count`／`cap_test_accepted_work` に記録する。
- 試行が成立しない経路と、global を超えた経路では、候補値は確定値と同じである。

**checker：** 同じ方式にした。
- plan の ACCEPT では、候補値で判定し、cap が無いときだけ確定する。
- plan の ABORT で checker の試行が成立したときは、候補値で判定し、確定はしない。

**resume と replay：**
- `gap1_terminal_abort` は `cap_test_*` で cap を計算し直す。生成時と同じ値を使うので、同じ分類になる。
- 新しい `gap1_ledger_count_audit` は、resume と replay のたびに呼ばれる。ledger から、attempted、global work、受け入れの件数と work を組み立て直し、すべての slab_record の保存値と照合する。`root_count.accepted` と `checker_decision` の値も照合する。
- driver の `resume_state` は、checker が止まった record を受け入れに数えないようにした（OPEN_QUESTIONS A5）。

**`accepted_count` が数えているもの（schema §2.7）：**
- producer：`decision = ACCEPT` の record の数。
- checker：`decision = ACCEPT` かつ `checker_decision ≠ ABORT` の record の数。

## 4. B2：読み方の規則（schema §0 に固定）

- `decision` は plan の決定、`checker_decision` は checker 自身の状態（`REPLAYED`／`ABORT`）を表す。
- 受け入れの判定（`gap1_counts_accepted`）、`root_count.accepted`、driver の `resume_state` は、すべてこの規則による同じ一つの式で決まる。

## 5. 同じ record の中の組み合わせ（コードを読んで導いた全表。実行による確認ではない）

| 系統 | 状況 | decision | checker_decision | result.reason | failure_class | abort_cause | resource_cap | accepted | 確定値 | 候補値 |
|---|---|---|---|---|---|---|---|---|---|---|
| P | 成立、cap なし | ACCEPT | — | PASS | null | null | null | true | +1／+work | 確定値と同じ |
| P | 不成立、depth<3 | REFINE | — | 試行の理由 | 試行の分類 | null | null | false | 不変 | 確定値と同じ |
| P | global 超過 | ABORT | — | RESOURCE_CAP:GLOBAL… | RESOURCE_CAP | RESOURCE_CAP | GLOBAL_ATTEMPT_WORK_CEILING | false | 不変 | 確定値と同じ |
| P | 成立、候補値で accepted の cap | ABORT | — | RESOURCE_CAP:… | RESOURCE_CAP | RESOURCE_CAP | MAX_ACCEPTED／ACCEPTED_WORK_CEILING | false | 不変 | +1／+work |
| P | 不成立、depth=3 | ABORT | — | 試行の理由 | 試行の分類 | MAX_DEPTH_EXHAUSTED | null | false | 不変 | 確定値と同じ |
| C | plan ACCEPT、受け入れ | ACCEPT | REPLAYED | PASS | null | null | null | true | +1／+work | 確定値と同じ |
| C | plan ACCEPT、global 超過 | ACCEPT | ABORT | RESOURCE_CAP:GLOBAL… | RESOURCE_CAP | RESOURCE_CAP | GLOBAL… | false | 不変 | 確定値と同じ |
| C | plan ACCEPT、候補値で cap | ACCEPT | ABORT | RESOURCE_CAP:… | RESOURCE_CAP | RESOURCE_CAP | MAX_ACCEPTED／ACCEPTED_WORK… | false | 不変 | +1／+work |
| C | plan REFINE | REFINE | REPLAYED | 試行の理由 | 試行の分類 | null | null | false | 不変 | 確定値と同じ |
| C | plan ABORT、global 超過 | ABORT | ABORT | RESOURCE_CAP:GLOBAL… | RESOURCE_CAP | RESOURCE_CAP | GLOBAL… | false | 不変 | 確定値と同じ |
| C | plan ABORT、成立、候補値で cap | ABORT | ABORT | RESOURCE_CAP:… | RESOURCE_CAP | RESOURCE_CAP | MAX_ACCEPTED／… | false | 不変 | +1／+work |
| C | plan ABORT、成立、cap なし | ABORT | ABORT | CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED | CONTRACT_MISMATCH | PRODUCER_PLAN_ABORT | null | false | 不変 | +1／+work |
| C | plan ABORT、不成立、depth=3 | ABORT | ABORT | 試行の理由 | 試行の分類 | MAX_DEPTH_EXHAUSTED | null | false | 不変 | 確定値と同じ |
| C | plan ABORT、不成立、depth<3 | ABORT | ABORT | 試行の理由 | 試行の分類 | PRODUCER_PLAN_ABORT | null | false | 不変 | 確定値と同じ |

- P は producer、C は checker。「試行の理由」と「試行の分類」は `attempt_reason`／`attempt_failure_class` と同じ値（どの行でも、この2つの項目は試行そのものの値を持つ）。
- どの行でも、`reason=PASS` と ABORT（`decision` または `checker_decision`）は並ばない。
- どの ABORT の行でも、`gap1_terminal_abort` が record の値から計算し直す分類は、表と一致する。cap は `cumulative_work_after` と `cap_test_*` から計算する。
- どの行でも、`gap1_ledger_count_audit` が組み立て直す件数と work は、確定値と一致する。

## 6. 提出前の自己点検

Code とは別の読むだけのサブエージェントに、静的レビューを1回させた（監査ではない）。
- v0.2 の変更について、重大な誤りは見つからなかった。
- 指摘のうち2点は直した（OPEN_QUESTIONS A8）。
- baseline から引き継いだ問題を1点、記録した（A7：checker の `attempt_sequence` が、中断の後で plan とずれる）。
- 他の軽い指摘は A9 にまとめた。

## 7. 提出物の一覧（tar.gz の中身。全ファイルを `MANIFEST.sha256` に載せた）

| path | 内容 |
|---|---|
| `IMPLEMENTATION_REPORT_V0_2.md` | この報告 |
| `new_files/gap1_*/*.py` | v0.2 の新しい7本 |
| `diffs_baseline_to_v0_2/` | baseline → v0.2 の全文の diff。各 `@@` に DIFF の分類 |
| `diffs_v0_1_to_v0_2/` | v0.1 → v0.2 の diff |
| `STATIC_CONTROL_REPORT_V0_2.md` | control 0–17 と hunk の分類表 |
| `static_controls/` | static_controls.py、hunk_classify.py、pairs.json、出力、実行前に記録した SHA、hunk_table.tsv/.md、authority_sha256.txt |
| `build/` | build_gap1.py、make_diffs.py、build_log.txt（EDITS 77）、gap1_edit_log.json |
| `LEDGER_AND_REPLAY_SCHEMA_V0_2.md` | 更新した schema（§0 に読み方の規則、§2.6 に F4、§2.7 に F5） |
| `OPEN_QUESTIONS_V0_2.md` | 更新した OPEN_QUESTIONS |

## 8. 最終行

IMPLEMENTATION_READY_FOR_CHAT_DIFF_AUDIT
