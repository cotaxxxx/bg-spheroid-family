# OPEN_QUESTIONS_V0_2 — C 空白① 実装 v0.2（Code、2026-10-11）

v0.2 の実装で Judge の確認が要る点を §A に、v0.1 の OPEN_QUESTIONS（B1–B12）が v0.2 でどうなったかを §B に、NOT_VERIFIED の項目と後で行うテストの案を §C に書いた。テストはどれも実行していない。

**前提：** Code が受け取った指示書 v0.2 は、Judge が会話に貼り付けた本文である。この報告を書いた時点で、bg-spheroid-family の main は `d9457b2a` のままだった。そのため次の3つを Code は main から読めていない。SHA-256 も照合していない。
- v0.2 の指示書
- `audits/CHAT_DIFF_AUDIT_C_GAP1_IMPL_V0_1_2026-10-11.md`（§8 の Judge 裁定）
- ChatGPT の監査（`f1ffe1f8`）

v0.2 の内容は、貼り付けられた本文だけに基づいている。

## A. v0.2 で確認してほしい事項

**A1. 指示書 v0.2 と v0.1 監査の authority pin を、コードにまだ入れていない。**
- `GAP1_AUTHORITY_SHA256` は v0.1 の11件のまま。
- 保存されたファイルを Code が読めないので、SHA-256 を書けない。存在を確かめられない値は書かない方針である。
- main に保存された後、次の版でこの2件（できれば ChatGPT 監査 `f1ffe1f8` も）を追加することを提案する。そのときは control 1 が実測値で照合する。

**A2. F4 の数え方。**
- 箱の数は、exterior の仕組みが試行中に書いた guard から数えている（schema §2.6）。数えているもの：段ごとの direct の評価数と、そのうち閉じた数、mono を試した数と、そのうち閉じた数。
- `MONO_WORK_CAP` で mono を飛ばした箱には guard が無いので、どの数にも入らない。その箱は「閉じなかった箱」（評価数 − direct で閉じた数 − mono で閉じた数）として残り、次の段で分割される。
- この読み方でよいか確認してほしい。
- 試行が不成立の L でも、到達した段までの数と `method` を記録する（label は `UNRESOLVED`）。

**A3. L の `rule` の文言は2通り。**
- 文言は `GAP1_L_RULES` に固定した。`method` が `DIRECT_G_BOX_ONLY` なら direct だけの文言、`DIRECT_G_BOX_AND_MONO_CLOSURE_G0_E1_V3` なら mono 閉包と G0/E1 v3 を明記した文言になる。
- 文言そのものを Judge の用語に合わせる必要があれば、指示してほしい。

**A4. F5 で加えた候補値のフィールド。**
- 両系統の slab_record に `cap_test_accepted_count`／`cap_test_accepted_work` を加えた。
- resume と replay では、`gap1_terminal_abort` がこの値で cap を計算し直す。確定値（`accepted_count`／`accepted_work`）は、ABORT の slab で増えない。
- その結果、accepted の上限による ABORT の record の確定値は、一つ前の ACCEPT の record と同じになる。

**A5. driver の `resume_state` を変えた（DIFF-E）。**
- checker が止まった record（`checker_decision=ABORT`）を、受け入れの件数に数えないようにした。
- この変更が無いと、checker が plan の ACCEPT の slab を cap で止めた場合に、ledger から組み立て直した件数と、record の確定値が食い違う。
- 変えたのは非数値の persistence の部分だけである。producer の record には `checker_decision` が無いので、producer での挙動は baseline と同じ。

**A6. 件数の照合（`gap1_ledger_count_audit`）を、resume と replay のたびに ledger 全体に対して行う。**
- 計算量は ledger の長さに比例する（最大でも数千件の record）。
- 一つでも食い違えば `CONTRACT_MISMATCH:LEDGER_COUNT_AUDIT:<attempt_sequence>` で止まる。

**A7. checker の `attempt_sequence` は、中断があると plan とずれる。これは baseline から引き継いだ挙動で、v0.2 では直していない。**
- checker の live のループは `attempt_sequence = attempted`（checker 自身の試行の通し番号）を使う。一方 `replay_state` は、保存された番号が plan の item の `attempt_sequence` と等しいことを要求する（`A1_REPLAY_ATTEMPT_SEQUENCE_MISMATCH`）。
- どちらも baseline 85eca228 の checker gating のまま（L359、L526）。
- 起こり得る場合は二つある。
  - producer が一度中断していると、plan の番号に欠けが出る。中断なしで走った checker が resume すると、番号が合わず止まる。
  - checker 自身が中断して、同じ item をやり直す場合も同じである。
- 証明の内容には影響しない（止まるだけで、誤って受け入れることはない）。ただし、中断を挟む本走では resume ができなくなる可能性がある。
- 修正案：checker の record に `plan_attempt_sequence = item["attempt_sequence"]` を別に持たせ、`replay_state` はその項目を照合する。あるいは、plan の位置（index）で照合する。v0.2 の指示の範囲外なので、裁定を待つ。

**A8. v0.2 の提出前の自己点検で直した小さな点。**
- 証明書が不成立の L で、`rule` に g<0 の文言が入っていた。→ null にした（`method` は残す）。
- `checker_decision` の値を照合していなかった。→ 件数の照合で `REPLAYED`／`ABORT` 以外を `CONTRACT_MISMATCH` にした。
- 自己点検は、Code が起動した読むだけのサブエージェントによる静的レビューで、監査ではない。

**A9. 自己点検で指摘されたが、記録だけにした点。**
- mono の上限で飛ばした箱の数は、guard からは「評価数 − direct で閉じた数 − mono を試した数」でしか分からない。明示の数は trace の `C1B_EXTERIOR_MONO` 行（`skipped_cap`）にだけある。
- `X_MONO_CLOSURE` の停止は record を書く前に起こる。resume では中断として扱われる。現在の X のコードでは起こり得ない。
- plan の REFINE を checker が成立させた場合（producer の失敗を checker が再現しない場合）に、印を付けていない。baseline からの挙動で、F5 の範囲外。
- v0.1 以前の ledger には `cap_test_*` が無い。ただし header が変わっているので、resume の時点で `RESUME_HEADER_CONTRACT_MISMATCH` で止まる。

## B. v0.1 の B1–B12 の扱い

v0.1 監査 §8 の裁定文を Code は読めていない（前提を参照）。v0.2 の指示書が明示している B2 だけを処理した。それ以外は v0.1 の実装のまま残し、裁定を待つ。

| v0.1 | 内容 | v0.2 |
|---|---|---|
| B1 | depth = 3 の不成立は RESOURCE_CAP にしない（`MAX_DEPTH_EXHAUSTED`） | v0.1 のまま |
| B2 | checker の `decision` は plan の決定 | **済。** 読み方の規則として schema §0 に固定した。受け入れの判定規則（`gap1_counts_accepted`）と driver の `resume_state` もこれに合わせた |
| B3 | resume の開始時にすべての cap を調べる | v0.1 のまま |
| B4 | `certified` と `accepted` を分ける | v0.1 のまま。v0.2 で `accepted` を ledger の照合の対象にした |
| B5 | depth で止まったときの終了文字列は baseline のまま | v0.1 のまま |
| B6 | cap の segment_end の後で例外で止まる | v0.1 のまま |
| B7 | スタブ control は本走の preflight でも実行される | v0.1 のまま（v0.2 ではスタブ control を変えていない） |
| B8 | `gap1_root_outcome` は producer の gating にもある | v0.1 のまま |
| B9 | slab_record の後、segment_end の前に落ちた場合 | v0.1 のまま。v0.2 では、resume の最初に件数の照合も行う |
| B10 | checker は plan の ABORT の slab を記録した後で止まる | v0.1 のまま。plan の ABORT で件数を加えない点は F5 で直した |
| B11 | checker で cap を ACCEPT の照合より先に判定する | v0.1 のまま |
| B12 | X の負値ブロックの trace | v0.1 のまま。証明に関わる内容は v0.2 の `negative_block_closure` にも集計される |

v0 から持ち越した Q1（pin manifest は実行準備の段階に延期）と、受理済みの Q2/Q4/Q5/Q6 は変わらない。

## C. NOT_VERIFIED と、後で行うテストの案（どれも実行していない）

| 項目 | 理由 | 後で行うテストの案 |
|---|---|---|
| namespace package と動的 gating import が実行時に正しく解決されること | `sys.path` に依存する | `importlib.util.find_spec` で `gap1_*` と17本の origin を出力する（非数値。許可が要る） |
| preflight 全体が PASS すること（スタブ control の11件を含む） | 数値評価を含む | 両系統で `--ledger-only`。`GAP1_STUB_CONTROL … PASS` が11行出ること |
| F3 と F5 の分類と件数（生成時、resume、replay で一致すること） | 実行時の挙動。今回は静的な読解と control 13、16、17 だけ | 分類の helper（`gap1_cap_exceeded`、`gap1_mark_decision`、`gap1_terminal_abort`）と、`gap1_ledger_count_audit` と driver の `resume_state` だけを、偽の kernel 定数（小さな上限）と手で作った ledger で呼ぶ非数値の単体テスト。cap 4種、depth の消尽、ACCEPT、REFINE、checker の plan ABORT 5通り、中断課金を挟む場合のそれぞれで、record の確定値、候補値、組み立て直した値が一致すること |
| F4 の数が実際の閉じ方と一致すること | 実行時の挙動。今回は静的な読解（control 16） | スタブ control（direct だけで閉じる場合、mono だけで閉じる場合）の結果を `gap1_serialize_record` に通し、`negative_block_closure` の段ごとの数と `method`、`rule` を確かめる非数値のテスト |
| L/X/R のそれぞれで証明書が閉じるかどうか | 数値結果そのもの | 本走でしか確かめられない（Judge の実行許可が要る） |
| producer と checker が同じ木を作ること | 実行時の挙動 | 本走後に checker の `GAP1_PLAN_ORDER_AUDIT PASS` を確認する |

NONE 以外の項目は以上である。
