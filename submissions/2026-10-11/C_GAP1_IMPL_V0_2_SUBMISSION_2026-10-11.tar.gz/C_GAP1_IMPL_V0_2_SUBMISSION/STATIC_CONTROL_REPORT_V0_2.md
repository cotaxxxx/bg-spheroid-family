# STATIC_CONTROL_REPORT_V0_2 — C 空白① 実装 v0.2（Code、2026-10-11）

指示書 v0.2 に対する静的 control の結果。
- v0.1 の control 0–15 はそのまま走らせた。v0.2 で文言が変わった箇所に合わせて、control 12、13 の照合文字列だけを更新した。
- v0.2 §3 の追加分として、control 16（同じ record の中の整合）と control 17（台帳と組み立て直した結果の整合）を加えた。

どの control も、ソースの文字列、SHA-256 と git blob、AST と symtable、リテラル定数の厳密な Fraction 計算だけを使う。リポジトリのモジュールは import も実行もしていない。

## 0. 総括

`SUMMARY C0=PASS C1=PASS C2=PASS C3=PASS C4=PASS C5=PASS C6=PASS C7=PASS C8=PASS C9=PASS C10=PASS C11=PASS C12=PASS C13=PASS C14=PASS C15=PASS C16=PASS C17=PASS`

最終版で FAIL は0件。NOT_VERIFIED の項目は OPEN_QUESTIONS_V0_2 §C にある。

## 1. コマンド（作業領域は Code の scratchpad。リポジトリには書いていない）

```
# 入力：baseline（bg-oblate-spheroid 85eca228 の producer/ checker/ analysis/）= tree/
#       v0.1 の新しい7本（v0.1 提出物 df2a6915 の new_files/）= v01/
#       authority/（v0.1 と同じ11件。bg-spheroid-family d9457b2a から git show）
cp -r tree out
python3 -I build/build_gap1.py tree out > build/build_log.txt                       # 末尾 "EDITS 77"
python3 -I static_controls/hunk_classify.py out "$(cat static_controls/pairs.json)" out/gap1_edit_log.json > static_controls/hunk_table.tsv
python3 -I static_controls/static_controls.py out authority static_controls/hunk_table.tsv > static_controls/static_controls.stdout
python3 -I build/make_diffs.py out v01 static_controls/pairs.json static_controls/hunk_table.tsv out/gap1_edit_log.json .
python3 -I -c "import sys; [compile(open(p).read(), p, 'exec', dont_inherit=True) for p in sys.argv[1:]]" out/gap1_*/*.py   # compile-only
```

**再現性：** 提出の直前に、空のディレクトリで baseline から作り直した。build_log、edit log、7本、hunk_table.tsv、static_controls.stdout は、すべて byte 一致した。

**最終版のスクリプト**（`static_scripts_sha256_pre_run.txt` の `v0_2_final_pre_run_2` の行）

| script | SHA-256 |
|---|---|
| `build/build_gap1.py` | 95eac470dee5dca01cfa7a0f1953dd9384a116c6402aa34f9f12112f4c6da067 |
| `build/make_diffs.py` | 46faae0a5ec542c3f897bd8d0a799a2668f85635b5a9e3a5141d52c02bc09e7d |
| `static_controls/hunk_classify.py` | de82a47c39fd489acbaf1a1ec6031baa639743a243988de6151f71c8e119f7d4（v0 から同一） |
| `static_controls/static_controls.py` | 71a14eee4bf841168016391f1fcdd59b51b4592fb99099916b92427567e34b81 |

## 2. 結果

control 0–15 の内容は v0.1 の STATIC_CONTROL_REPORT_V0_1 §2 と同じで、すべて PASS。v0.2 で変わった点と、追加した control は次のとおり。

| # | 内容 | 判定 | 根拠 |
|---|---|---|---|
| 3 | hunk の分類 | PASS | 63 hunk、未分類と混在は0。K 22、A 5、B 2、C 2、D 2、E 30。v0.2 の変更はすべて DIFF-E。DIFF-A/B/C/D/K の hunk は v0.1 と同じ |
| 4 | 保護対象の本体 | PASS | 両 kernel は v0.1 と byte 一致（blob は producer `d341ee12`、checker `8dc5fb3c`） |
| 12 | 【F2】の照合（v0.2 で照合文字列を更新） | PASS | `gap1_root_count_record(kernel, region, result, closure)` |
| 13 | 【F3】の照合（v0.2 で照合文字列を更新） | PASS | producer は `cap_test_*` で cap を計算し直す。checker は候補値で2回判定する |
| **16a** | 同じ record の中：`accepted` と件数・work | PASS | 両 gating の run_full に、`accepted_count`／`accepted_work` への `+=` は0件。確定は `accepted_count, accepted_work = cap_test_accepted_count, cap_test_accepted_work` の1文だけ。それがあるのは、受け入れの分岐の中だけ（producer は `decision = "ACCEPT"` の else、checker は `if cap is None:`）。`previous_root = root` も1か所。`root_count.accepted = (decision == "ACCEPT")`。候補値は payload に記録される |
| **16b** | 同じ record の中：`rule` と実際に使った guard | PASS | L の `rule` は、certified のときだけ `GAP1_L_RULES[method]`。`method` は、記録された guard から `gap1_negative_block_closure` が決める（`_MONO` の guard が真なら mono）。X で mono の guard があれば `CONTRACT_MISMATCH:X_MONO_CLOSURE`。kernel 側の guard の形（sign は `box.side`、mono は `box.side + "_MONO"`、X は `X_DIRECT_G`）がこの数え方と合うことも、ソースで確かめた |
| **16c** | 同じ record の中：`reason`／`failure_class`／`abort_cause`／`resource_cap` | PASS | `gap1_mark_decision` で、`failure_class` と `reason` を書く場所はそれぞれ2か所だけ。① cap のブロック（4つの値を同時に書く）。② checker の `PRODUCER_PLAN_ABORT` で試行が PASS のとき（`CONTRACT_MISMATCH` と `CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED`）。cap 以外の `abort_cause` は `GAP1_NON_CAP_ABORT_CAUSES` = (`MAX_DEPTH_EXHAUSTED`, `PRODUCER_PLAN_ABORT`) に限る。組み合わせの全表は IMPLEMENTATION_REPORT §5 |
| **17** | 台帳と組み立て直した結果 | PASS | driver の `resume_state` の受け入れの規則は、両 gating の `gap1_counts_accepted` と同じ式（`decision == "ACCEPT" and checker_decision != "ABORT"`）。`gap1_ledger_count_audit` は、slab_record ごとに `attempted_count`、`cumulative_work_after`、`accepted_count`、`accepted_work` を、組み立て直した値（attempt_begin の数、charged_work と work_total の和、受け入れの件数と work）と比べる。`root_count.accepted` と、`checker_decision` の値も照合する。audit は producer の `replay` と checker の `replay_state` で、`gap1_terminal_abort` より先に呼ばれる。terminal abort の再計算は `cap_test_*` を使う。live のループは `resume_state` の値から始まり、`work_total` を加える |

## 3. 途中の経過（記録）

- 最初の v0.2 の生成では、control 12 と 13 が FAIL になった。v0.1 の照合文字列が、v0.2 で書き換えた行を探していたためである。実装の誤りではない。照合文字列を v0.2 の行に合わせて更新し、v0.2 で新しく入った要件（候補値での判定など）も確かめるようにした。この最初の出力は残していない。
- 提出前の自己点検（Code が起動した読むだけのサブエージェントによる静的レビュー。監査ではない）では、v0.2 の変更に重大な誤りは見つからなかった。
  - 指摘のうち2点は直した。証明書が不成立の L の `rule` を null にした。`checker_decision` の値を照合するようにした。それに合わせて、control 16b と 17 の照合も強めた。
  - baseline から引き継いだ checker の `attempt_sequence` の問題は、直さずに OPEN_QUESTIONS A7 に記録した。

## 4. hunk の表（baseline → v0.2）

分類の列は `hunk_classify.py` が出したもので、これが正である。edit の label の列は参考の値。

| # | new file | hunk | baseline lines | new lines | −/+ lines | category | edit label(s) |
|---|---|---|---|---|---|---|---|
| 1 | `gap1_producer/global_axial_c1b_kernel.py` | 1 | 29–35 | 29–35 | −1/+1 | DIFF-K | caps |
| 2 | `gap1_producer/global_axial_c1b_kernel.py` | 2 | 49–56 | 49–56 | −2/+2 | DIFF-K | work ceilings |
| 3 | `gap1_producer/global_axial_c1b_kernel.py` | 3 | 59–64 | 59–181 | −0/+117 | DIFF-K | constants/domain |
| 4 | `gap1_producer/global_axial_c1b_kernel.py` | 4 | 84–94 | 201–209 | −5/+3 | DIFF-A | descending queue |
| 5 | `gap1_producer/global_axial_c1b_kernel.py` | 5 | 883–888 | 998–1141 | −0/+138 | DIFF-K | U1 controls |
| 6 | `gap1_producer/global_axial_c1b_kernel.py` | 6 | 1206–1211 | 1459–1573 | −0/+109 | DIFF-B | X fixed path |
| 7 | `gap1_producer/global_axial_c1b_kernel.py` | 7 | 1426–1431 | 1788–1879 | −0/+86 | DIFF-D | endpoint gate |
| 8 | `gap1_producer/global_axial_c1b_kernel.py` | 8 | 1586–1591 | 2034–2052 | −0/+13 | DIFF-C | L negative path |
| 9 | `gap1_producer/global_axial_c1b_kernel.py` | 9 | 1644–1649 | 2105–2131 | −0/+21 | DIFF-E | region dispatcher |
| 10 | `gap1_producer/global_axial_c1b_kernel.py` | 10 | 1814–1820 | 2296–2304 | −1/+3 | DIFF-K | preflight banner |
| 11 | `gap1_producer/global_axial_c1b_kernel.py` | 11 | 1837–1842 | 2321–2327 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 12 | `gap1_producer/global_axial_c1b_kernel.py` | 12 | 1845–1848 | 2330–2336 | −0/+3 | DIFF-K | preflight controls |
| 13 | `gap1_producer/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 14 | `gap1_producer/global_axial_c1b_gating.py` | 2 | 142–147 | 142–456 | −0/+309 | DIFF-E | ledger/overlap/union helpers |
| 15 | `gap1_producer/global_axial_c1b_gating.py` | 3 | 317–322 | 626–633 | −0/+2 | DIFF-E | resume re-classifies a terminal ABORT |
| 16 | `gap1_producer/global_axial_c1b_gating.py` | 4 | 328–337 | 639–648 | −2/+2 | DIFF-A | live right-child-first; resume replay right-child-first |
| 17 | `gap1_producer/global_axial_c1b_gating.py` | 5 | 341–347 | 652–658 | −1/+1 | DIFF-E | replay schema label |
| 18 | `gap1_producer/global_axial_c1b_gating.py` | 6 | 389–400 | 700–711 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 19 | `gap1_producer/global_axial_c1b_gating.py` | 7 | 402–407 | 713–753 | −0/+35 | DIFF-K | U1 header metadata block |
| 20 | `gap1_producer/global_axial_c1b_gating.py` | 8 | 412–418 | 758–765 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 21 | `gap1_producer/global_axial_c1b_gating.py` | 9 | 427–433 | 774–780 | −1/+1 | DIFF-K | header coarse cap |
| 22 | `gap1_producer/global_axial_c1b_gating.py` | 10 | 489–497 | 836–842 | −3/+1 | DIFF-E | resume cap test moved |
| 23 | `gap1_producer/global_axial_c1b_gating.py` | 11 | 502–507 | 847–853 | −0/+1 | DIFF-E | stop-field holder |
| 24 | `gap1_producer/global_axial_c1b_gating.py` | 12 | 515–522 | 861–878 | −0/+10 | DIFF-E | resume cap test recorded as RESOURCE_CAP; segment_end stop fields |
| 25 | `gap1_producer/global_axial_c1b_gating.py` | 13 | 536–543 | 892–901 | −2/+4 | DIFF-E | MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 26 | `gap1_producer/global_axial_c1b_gating.py` | 14 | 550–580 | 908–945 | −8/+15 | DIFF-E | accepted counters advance only on ACCEPT; candidate cap test (F5); dispatch + record; terminal decision classification (F3) |
| 27 | `gap1_producer/global_axial_c1b_gating.py` | 15 | 582–587 | 947–954 | −0/+2 | DIFF-E | candidate counters recorded (F5) |
| 28 | `gap1_producer/global_axial_c1b_gating.py` | 16 | 592–598 | 959–965 | −1/+1 | DIFF-A | live right-child-first; resume replay right-child-first |
| 29 | `gap1_producer/global_axial_c1b_gating.py` | 17 | 601–619 | 968–984 | −7/+5 | DIFF-E | exact union + overlap; segment end overlap record |
| 30 | `gap1_producer/global_axial_c1b_gating.py` | 18 | 622–627 | 987–994 | −0/+2 | DIFF-E | overlap failure after segment end |
| 31 | `gap1_producer/global_axial_c1b_producer.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
| 32 | `gap1_analysis/c1b_resumable_driver.py` | 1 | 18–34 | 18–52 | −9/+27 | DIFF-E | pin manifest path / chain label; pinned blob paths (7 new + 17 closure + 1 read-only) |
| 33 | `gap1_analysis/c1b_resumable_driver.py` | 2 | 341–350 | 359–369 | −2/+3 | DIFF-E | resume_state accepted rule (F5/B2) |
| 34 | `gap1_checker/global_axial_c1b_kernel.py` | 1 | 30–36 | 30–36 | −1/+1 | DIFF-K | caps |
| 35 | `gap1_checker/global_axial_c1b_kernel.py` | 2 | 50–57 | 50–57 | −2/+2 | DIFF-K | work ceilings |
| 36 | `gap1_checker/global_axial_c1b_kernel.py` | 3 | 60–65 | 60–182 | −0/+117 | DIFF-K | constants/domain |
| 37 | `gap1_checker/global_axial_c1b_kernel.py` | 4 | 876–881 | 993–1136 | −0/+138 | DIFF-K | U1 controls |
| 38 | `gap1_checker/global_axial_c1b_kernel.py` | 5 | 1183–1188 | 1438–1552 | −0/+109 | DIFF-B | X fixed path |
| 39 | `gap1_checker/global_axial_c1b_kernel.py` | 6 | 1403–1408 | 1767–1858 | −0/+86 | DIFF-D | endpoint gate |
| 40 | `gap1_checker/global_axial_c1b_kernel.py` | 7 | 1563–1568 | 2013–2031 | −0/+13 | DIFF-C | L negative path |
| 41 | `gap1_checker/global_axial_c1b_kernel.py` | 8 | 1630–1635 | 2093–2122 | −0/+24 | DIFF-E | region dispatcher |
| 42 | `gap1_checker/global_axial_c1b_kernel.py` | 9 | 1802–1808 | 2289–2297 | −1/+3 | DIFF-K | preflight banner |
| 43 | `gap1_checker/global_axial_c1b_kernel.py` | 10 | 1824–1829 | 2313–2319 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 44 | `gap1_checker/global_axial_c1b_kernel.py` | 11 | 1832–1835 | 2322–2328 | −0/+3 | DIFF-K | preflight controls |
| 45 | `gap1_checker/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 46 | `gap1_checker/global_axial_c1b_gating.py` | 2 | 142–147 | 142–456 | −0/+309 | DIFF-E | ledger/overlap/union helpers |
| 47 | `gap1_checker/global_axial_c1b_gating.py` | 3 | 312–318 | 621–627 | −1/+1 | DIFF-E | replay schema label |
| 48 | `gap1_checker/global_axial_c1b_gating.py` | 4 | 320–325 | 629–653 | −0/+19 | DIFF-A | checker plan-order audit |
| 49 | `gap1_checker/global_axial_c1b_gating.py` | 5 | 343–355 | 671–693 | −1/+11 | DIFF-E | checker L/X field verification; checker resume re-classifies a terminal cap stop |
| 50 | `gap1_checker/global_axial_c1b_gating.py` | 6 | 364–372 | 702–710 | −2/+2 | DIFF-E | resume previous_root for L/X |
| 51 | `gap1_checker/global_axial_c1b_gating.py` | 7 | 389–400 | 727–738 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 52 | `gap1_checker/global_axial_c1b_gating.py` | 8 | 402–407 | 740–780 | −0/+35 | DIFF-K | U1 header metadata block |
| 53 | `gap1_checker/global_axial_c1b_gating.py` | 9 | 412–418 | 785–792 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 54 | `gap1_checker/global_axial_c1b_gating.py` | 10 | 427–433 | 801–807 | −1/+1 | DIFF-K | header coarse cap |
| 55 | `gap1_checker/global_axial_c1b_gating.py` | 11 | 467–472 | 841–847 | −0/+1 | DIFF-A | checker plan-order audit call |
| 56 | `gap1_checker/global_axial_c1b_gating.py` | 12 | 479–485 | 854–860 | −1/+1 | DIFF-E | checker replay_state call (kernel) |
| 57 | `gap1_checker/global_axial_c1b_gating.py` | 13 | 487–494 | 862–869 | −2/+2 | DIFF-E | checker replay_state recall (kernel); checker resume cap test moved |
| 58 | `gap1_checker/global_axial_c1b_gating.py` | 14 | 498–503 | 873–879 | −0/+1 | DIFF-E | stop-field holder |
| 59 | `gap1_checker/global_axial_c1b_gating.py` | 15 | 507–513 | 883–900 | −1/+12 | DIFF-E | checker cap stop after its record; checker segment_end stop fields; resume cap test recorded as RESOURCE_CAP |
| 60 | `gap1_checker/global_axial_c1b_gating.py` | 16 | 520–527 | 907–916 | −2/+4 | DIFF-E | checker MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 61 | `gap1_checker/global_axial_c1b_gating.py` | 17 | 532–561 | 921–970 | −14/+34 | DIFF-E | checker dispatch + record + field checks; checker root-count outcome per region (F2) + cap classification (F3) |
| 62 | `gap1_checker/global_axial_c1b_gating.py` | 18 | 563–581 | 972–996 | −6/+12 | DIFF-E | checker cap stop after its record; checker exact union + overlap; checker segment end overlap record; checker segment_end stop fields; overlap failure after segment end |
| 63 | `gap1_checker/global_axial_c1b_checker.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |

## 5. v0.1 → v0.2 の差分

`diffs_v0_1_to_v0_2/` にファイル別のものと、`ALL_7_FILES_V0_1_TO_V0_2.diff` がある。

| ファイル | −/+（diff の行数） | 内容 |
|---|---|---|
| producer gating | −14/+94 | F4 の helper（`gap1_negative_block_closure`、`GAP1_L_RULES`）。F5 の helper（`gap1_counts_accepted`、`gap1_ledger_count_audit`）。`gap1_terminal_abort` が `cap_test_*` を使うようにした。replay で audit を呼ぶ。decision の決め方（候補値で判定し、確定は ACCEPT のときだけ）。payload に `cap_test_*` |
| checker gating | −15/+93 | 同じ helper。`replay_state` で audit を呼ぶ。live のループの候補値での判定（plan の ACCEPT と ABORT）。payload に `cap_test_*` |
| driver | −2/+3 | `resume_state` の受け入れの規則（B2/F5） |
| kernel 2本、入口 2本 | 0 | v0.1 と byte 一致 |
