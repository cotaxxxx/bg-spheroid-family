#!/usr/bin/env python3
"""Static controls for the C-gap-1 (U1) implementation (instruction v2 section 9, controls 1-10, plus a name lint;
v0.1 adds controls 11-15 for instruction v0.1 F1/F2/F3/Q10-Q11/Q15; v0.2 adds 16-17 for F4/F5/B2).

Reads source text only: SHA-256 / git-blob hashing, AST, symtable, exact Fraction arithmetic on literal constants.
No module of the repository is imported or executed; no numerical kernel is called.
Usage: python3 -I static_controls.py <tree_root> <authority_dir> <hunk_table.tsv>
"""
import ast
import builtins
import hashlib
import json
import symtable
import sys
from fractions import Fraction
from pathlib import Path

ROOT, AUTH, HUNKS = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
RESULTS = []


def blob(path):
    data = Path(path).read_bytes()
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(cid, status, detail):
    RESULTS.append((cid, status, detail))
    print(f"CONTROL {cid} {status} :: {detail}")


def module(path):
    text = (ROOT / path).read_text()
    return text, ast.parse(text)


def top_functions(tree):
    return {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}


def literal(tree, name):
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    return node.value
                if isinstance(target, ast.Tuple):
                    for i, elt in enumerate(target.elts):
                        if isinstance(elt, ast.Name) and elt.id == name and isinstance(node.value, ast.Tuple):
                            return node.value.elts[i]
    raise KeyError(name)


def eval_const(node):
    """Exact evaluation of literal constants: ints, Fraction(a, b), tuples, dicts, strings, Path(...) as str."""
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Tuple):
        return tuple(eval_const(e) for e in node.elts)
    if isinstance(node, ast.List):
        return [eval_const(e) for e in node.elts]
    if isinstance(node, ast.Dict):
        return {eval_const(k): eval_const(v) for k, v in zip(node.keys, node.values)}
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Fraction":
        return Fraction(*[eval_const(a) for a in node.args])
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Path":
        return "PATH:" + eval_const(node.args[0])
    raise ValueError(ast.dump(node)[:80])


BASE7 = {
    "producer/global_axial_c1b_kernel.py": "67dda838369302010ef3d589937b834b96ede4d8",
    "producer/global_axial_c1b_gating.py": "a93ca173ae0bededcd5a0248aa07ac3348f9a243",
    "producer/global_axial_c1b_producer.py": "0616fbd7c9c85f77c8e80b61a5b3b536b45012a8",
    "analysis/c1b_resumable_driver.py": "5fd308bb4c02c6ddbd612ddbedb18f6b9e22bc3d",
    "checker/global_axial_c1b_kernel.py": "4eaca55ddf79b437fc756d666294372e5d1a6ba4",
    "checker/global_axial_c1b_gating.py": "03df262012bfbebcf4d2ea173933186c70abafbf",
    "checker/global_axial_c1b_checker.py": "0760764ef7592be1ddd4ffec3966e9c6ec930a5b",
}
IMP15 = {
    "producer/monotone_tube_refinement_producer.py": "c2fee40053ab055ce352e93e1c6d1fc43e46310a",
    "checker/monotone_tube_refinement_checker.py": "15d660265552fc2f2c83ffe897ed5efab8514da2",
    "checker/monotone_tube_interval_checker.py": "f2fa2a5a42d35b8b77e3c63fa0d9ad48ce562a77",
    "producer/global_axial_c1b_endpoint_r.py": "29d441a578f10fe7f4beb38476d3699f3648a3b1",
    "checker/global_axial_c1b_endpoint_r.py": "1a953b22c12a89afc06790b28d6b0dea9680dc43",
    "producer/endpoint_interval_producer.py": "51060fea01cb9ff661518b7c52146f71187846ff",
    "producer/monotone_tube_interval_producer.py": "b6d96df223c0e423e804d96f4892a8e818c05827",
    "producer/global_axial_c0_producer.py": "c4c8d6b59d3829e1843d149b7857eda5800287aa",
    "checker/global_axial_c0_checker.py": "85978625e029b01c8ae40fa8234566f10eea251c",
    "checker/endpoint_local_controls.py": "c913c47d228e51a15f56957f5df9196efa1b22c3",
    "checker/oblate_axis_prototype.py": "df402583c320c459ff4f72dc5294558f14f44d31",
    "checker/endpoint_interval_checker.py": "4cb16f8a975e5a3be601a7926af695ad5be57790",
    "checker/endpoint_local_checker.py": "2bddddf6e9a08ca7acae94c89bd4d5ab1de861bc",
    "producer/global_axial_c0_producer_v2.py": "cdbdf51f8656c1fcae97666cc1846461b250a591",
    "checker/global_axial_c0_checker_v2.py": "fbec890588d2d390ea67bc90116b80bb37ebf9cc",
}
IMP2 = {
    "producer/c0a_four_group_v2.py": "2bb556ab4f0c0cfd9ce6afa65d762551dd3791f4",
    "checker/c0a_four_group_v2.py": "18e66b6450cd2a379bbb869a99e4e5ce6999f6e5",
}
NEW7 = {
    "producer/global_axial_c1b_kernel.py": "gap1_producer/global_axial_c1b_kernel.py",
    "producer/global_axial_c1b_gating.py": "gap1_producer/global_axial_c1b_gating.py",
    "producer/global_axial_c1b_producer.py": "gap1_producer/global_axial_c1b_producer.py",
    "analysis/c1b_resumable_driver.py": "gap1_analysis/c1b_resumable_driver.py",
    "checker/global_axial_c1b_kernel.py": "gap1_checker/global_axial_c1b_kernel.py",
    "checker/global_axial_c1b_gating.py": "gap1_checker/global_axial_c1b_gating.py",
    "checker/global_axial_c1b_checker.py": "gap1_checker/global_axial_c1b_checker.py",
}
KERNELS = ("gap1_producer/global_axial_c1b_kernel.py", "gap1_checker/global_axial_c1b_kernel.py")
GATINGS = ("gap1_producer/global_axial_c1b_gating.py", "gap1_checker/global_axial_c1b_gating.py")

# ---------------------------------------------------------------- control 1: pins
rows = []
ok1 = True
for table, label in ((BASE7, "baseline7"), (IMP15, "import15"), (IMP2, "import+2")):
    for path, expected in table.items():
        got = blob(ROOT / path)
        rows.append((label, path, expected, got, got == expected))
        ok1 = ok1 and got == expected
for kernel in KERNELS:
    _, tree = module(kernel)
    code_auth = eval_const(literal(tree, "GAP1_AUTHORITY_SHA256"))
    for name, h in code_auth.items():
        real = sha256(AUTH / name)
        rows.append(("authority_in_code:" + kernel.split("/")[0], name, h, real, h == real))
        ok1 = ok1 and h == real
    code_base = eval_const(literal(tree, "GAP1_BASELINE_BLOBS"))
    code_imp = eval_const(literal(tree, "GAP1_IMPORT_CLOSURE_17"))
    ok1 = ok1 and code_base == BASE7 and code_imp == {**IMP15, **IMP2}
    rows.append(("code_constants:" + kernel.split("/")[0], "GAP1_BASELINE_BLOBS/GAP1_IMPORT_CLOSURE_17",
                 "7+17", f"{len(code_base)}+{len(code_imp)}", code_base == BASE7 and code_imp == {**IMP15, **IMP2}))
for r in rows:
    print("PIN", *r)
record(1, "PASS" if ok1 else "FAIL",
       f"baseline 7/7, imports {sum(1 for r in rows if r[0]=='import15' and r[4])}/15 + "
       f"{sum(1 for r in rows if r[0]=='import+2' and r[4])}/2 (B1 record b48887c1), authority/code constants match="
       f"{all(r[4] for r in rows if r[0].startswith(('authority', 'code')))}")

# ---------------------------------------------------------------- control 2: only the 7 new files are new code
present = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob("*.py"))
gap1_files = [p for p in present if p.startswith("gap1_")]
init_files = [p for p in gap1_files if p.endswith("__init__.py")]
ok2 = sorted(gap1_files) == sorted(NEW7.values()) and not init_files
record(2, "PASS" if ok2 else "FAIL",
       f"gap1_* python files = {len(gap1_files)} (expected 7), __init__.py added = {len(init_files)}; "
       "baseline files are compared by blob in control 1 and are not edited (see IMPLEMENTATION_REPORT for tree diff)")

# ---------------------------------------------------------------- control 3: hunk classification
lines = [l.rstrip("\n").split("\t") for l in HUNKS.read_text().splitlines() if l and not l.startswith("HUNKS")]
problems = [l for l in lines if l[-1] != "OK"]
cats = {}
for l in lines:
    cats[l[8]] = cats.get(l[8], 0) + 1
record(3, "PASS" if not problems and lines else "FAIL",
       f"hunks={len(lines)} unclassified/mixed={len(problems)} per-category={cats}")

# ---------------------------------------------------------------- control 4: protected bodies byte-identical
PROTECTED_KERNEL = (
    "g_box", "gt_box", "_g_density_stable", "_glam_density", "glam_box", "_positive_q_box", "_certified_positive_q",
    "_positive_inv_wq32", "_positive_reciprocal_wq32", "_root_gl_corner_wall_density", "root_gl_corner_wall_box",
    "root_gl_corner_band_box", "_root_gl_corner_certificate", "predictor_scan", "select_predictor_candidate",
    "choose_predictor", "root_localize", "_refine_failed_root_gt_cell", "_newton_candidate", "_intersect_newton",
    "_outward_hull", "predictor_accept", "tube_stage", "tube_first_pass", "_tube_gt_eval", "_t2_endpoint_activation",
    "_t2_endpoint_refine", "exterior_seed", "exterior_cover", "eval_exterior", "mono_closure_box", "_mono_truth",
    "_e0_counts", "e_children", "exact_middle_partition", "_attempt_with_tc", "attempt", "attempt_replay",
    "interval", "split", "_arb_exact_fraction", "_arb_snapshot", "_arb_bounds_finite",
)
changed_report = {}
ok4 = True
for base_path, new_path in NEW7.items():
    btext, btree = module(base_path)
    ntext, ntree = module(new_path)
    bfun, nfun = top_functions(btree), top_functions(ntree)
    changed, missing = [], []
    for name, node in bfun.items():
        if name not in nfun:
            missing.append(name); continue
        if ast.get_source_segment(btext, node) != ast.get_source_segment(ntext, nfun[name]):
            changed.append(name)
    added = sorted(set(nfun) - set(bfun))
    changed_report[new_path] = {"changed": changed, "missing": missing, "added": added}
    if "kernel" in new_path:
        bad = [n for n in changed if n in PROTECTED_KERNEL] + [n for n in missing]
        ok4 = ok4 and not bad
    else:
        ok4 = ok4 and not missing
for key in ("W0", "PRED_ACCEPT", "ROOT_TARGET", "BITS", "DEG", "USTAR", "T_STAGES", "E_STAGES", "E0_TBOXES",
            "E0_LBOXES", "E_BOX_CAP", "MONO_WORK_CAP", "PRED_GRID_DEN", "PRED_SCAN_PANELS", "ROOT_MV_STEPS",
            "ROOT_G_PANELS", "ROOT_GT_PANELS", "ROOT_GL_PANELS", "ROOT_GT_T_CELLS", "ROOT_GL_T_CELLS",
            "ROOT_GL_CORNER_K", "ROOT_GL_CORNER_TAU", "ROOT_GT_CLAMP_TAU", "ROOT_GL_CORNER_WALL_PANELS",
            "ROOT_GT_REFINE_DEPTH", "T2_ENDPOINT_REFINE_DEPTH", "L_LO", "L_HI", "DLAM", "N_COARSE",
            "T_LO", "T_MID_HI", "T_HI", "C1B_NUMERIC_ROOTS", "C1B_NUMERIC_IMPORT_CLOSURE", "BOB_RECEIPT_BLOB"):
    for base_path in ("producer/global_axial_c1b_kernel.py", "checker/global_axial_c1b_kernel.py"):
        _, bt = module(base_path); _, nt = module(NEW7[base_path])
        same = eval_const(literal(bt, key)) == eval_const(literal(nt, key))
        ok4 = ok4 and same
        if not same:
            print("CONSTANT_CHANGED", base_path, key)
for path, rep in changed_report.items():
    print("BODY", path, json.dumps(rep))
record(4, "PASS" if ok4 else "FAIL",
       "every protected kernel function (g_box, gt_box, densities, P1 scan, P2 select, choose_predictor, root "
       "localization, tube, exterior, mono, attempt/attempt_replay) is byte-identical; protected constants "
       "(W0, PRED_ACCEPT, ROOT_TARGET, BITS, DEG, stages, panels, C1b reference domain) identical; changed baseline "
       f"functions: { {k: v['changed'] for k, v in changed_report.items()} }")


# ---------------------------------------------------------------- call graph helpers
def calls_of(fn):
    out = set()
    for node in ast.walk(fn):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                out.add(node.func.id)
            elif isinstance(node.func, ast.Attribute):
                out.add("." + node.func.attr)
    return out


def reach(funcs, start):
    seen, stack = set(), [start]
    while stack:
        name = stack.pop()
        if name in seen or name not in funcs:
            continue
        seen.add(name)
        stack.extend(c for c in calls_of(funcs[name]) if c in funcs)
    return seen


FORBIDDEN_LX = {"choose_predictor", "predictor_scan", "select_predictor_candidate", "root_localize", "attempt",
                "attempt_replay", "_attempt_with_tc", "predictor_accept", "tube_first_pass", "tube_stage",
                "_refine_failed_root_gt_cell", "_root_gl_corner_certificate", "glam_box"}

# ---------------------------------------------------------------- control 5: L/X cannot reach predictor/root
ok5 = True
detail5 = []
for kernel in KERNELS:
    _, tree = module(kernel)
    funcs = top_functions(tree)
    for start in ("attempt_l", "attempt_x", "x_lower_tube", "endpoint_gate"):
        hit = sorted(reach(funcs, start) & FORBIDDEN_LX)
        ok5 = ok5 and not hit
        detail5.append(f"{kernel.split('/')[0]}:{start}->forbidden={hit}")
    dispatcher = funcs["attempt_gap1" if "producer" in kernel else "attempt_replay_gap1"]
    branch_ok = True
    for node in ast.walk(dispatcher):
        if isinstance(node, ast.If) and isinstance(node.test, ast.Compare) and \
                getattr(node.test.left, "id", None) == "region":
            pass
    src = ast.get_source_segment(module(kernel)[0], dispatcher)
    r_calls = src.count("attempt(slab, previous_root)") + src.count("attempt_replay(slab, previous_root, expected_tc)")
    branch_ok = r_calls == 1 and src.count("attempt_l(slab)") == 1 and src.count("attempt_x(slab)") == 1
    ok5 = ok5 and branch_ok
    detail5.append(f"{kernel.split('/')[0]}:dispatcher single R call, L/X call only attempt_l/attempt_x={branch_ok}")
record(5, "PASS" if ok5 else "FAIL", "; ".join(detail5))

# ---------------------------------------------------------------- control 6: R order and P2 rule
ptext, ptree = module("gap1_producer/global_axial_c1b_kernel.py")
cl = ast.get_source_segment(ptext, top_functions(ptree)["coarse_ledger"])
gp_text, _ = module("gap1_producer/global_axial_c1b_gating.py")
gc_text, gc_tree = module("gap1_checker/global_axial_c1b_gating.py")
sel_ok = True
for kernel in KERNELS:
    t, tr = module(kernel)
    sel = ast.get_source_segment(t, top_functions(tr)["select_predictor_candidate"])
    sel_ok = sel_ok and "if abs(continuation - scan_mid) <= ROOT_TARGET:" in sel and "1, 64" not in sel
    cp = top_functions(tr).get("choose_predictor")
    if cp is not None:
        sel_ok = sel_ok and "Fraction(9, 16) if previous_root is None else (previous_root[0] + previous_root[1]) / 2" in ast.get_source_segment(t, cp)
order_ok = ("return list(reversed(q)), ok" in cl and gp_text.count("queue = [right, left] + queue") == 2
            and "queue = [left, right] + queue" not in gp_text
            and "gap1_plan_order_audit(plan, kernel)" in gc_text
            and "queue = [(coarse, depth + 1, mid, lr), (coarse, depth + 1, ll, mid)] + queue" in gc_text)
acc_ok = ("previous_root = root" in gp_text and gp_text.count("previous_root = root") == 1)
record(6, "PASS" if (order_ok and sel_ok and acc_ok) else "FAIL",
       f"descending coarse queue + right-child-first (live and resume) + checker plan-order audit={order_ok}; "
       f"P2 '<= ROOT_TARGET' (equality -> continuation), P0 9/16 then accepted-neighbour midpoint={sel_ok}; "
       f"previous_root updated only on ACCEPT={acc_ok}")

# ---------------------------------------------------------------- control 7: endpoint success path
ok7 = True
d7 = []
for kernel in KERNELS:
    t, tr = module(kernel)
    funcs = top_functions(tr)
    eg = funcs["endpoint_gate"]
    gcalls = [n for n in ast.walk(eg) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "g_box"]
    gtcalls = [n for n in ast.walk(eg) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "gt_box"]
    seed_ok = (len(gcalls) == 1 and [getattr(a, "id", None) for a in gcalls[0].args[:2]] == ["ENDPOINT_T_SEED", "ENDPOINT_T_SEED"])
    src = ast.get_source_segment(t, eg)
    pass_sets = src.count('rec["endpoint_pass"] = True')
    idents = {n.id for n in ast.walk(eg) if isinstance(n, ast.Name)} | \
             {n.attr for n in ast.walk(eg) if isinstance(n, ast.Attribute)}
    consts = {n.value for n in ast.walk(eg) if isinstance(n, ast.Constant)}
    no_alt = (not any("BOB" in i.upper() or "LAMBDA_CONST" in i.upper() or i in ("root_localize", "C_LAMBDA", "C_Lambda")
                      for i in idents) and 1956000 not in consts)  # AST identifiers/constants only (comments excluded)
    disp = ast.get_source_segment(t, funcs["attempt_gap1" if "producer" in kernel else "attempt_replay_gap1"])
    gate_used = "eok, erec, ework = endpoint_gate(slab)" in disp and 'if not eok:' in disp
    good = seed_ok and len(gtcalls) == 1 and pass_sets == 1 and no_alt and gate_used and \
        "elif not cumulative < 0:" in src and "contribution = arb(0) if upper <= 0 else upper" in src
    ok7 = ok7 and good
    d7.append(f"{kernel.split('/')[0]}: one seed g_box at 31/32={seed_ok}, gt_box in the 16-box loop={len(gtcalls)==1}, "
              f"single success assignment={pass_sets==1}, no B_ob/C_Lambda/root path={no_alt}, dispatcher requires gate={gate_used}")
    # B_ob corner certificate: bob_covers uses the C1b reference domain [9/20,5/8]; every U1 slab has ll < 9/20.
    Llo = eval_const(literal(tr, "L_LO")); hi = eval_const(literal(tr, "GAP1_LAMBDA_HI"))
    d7.append(f"bob_covers impossible for U1 slabs (ll < {hi} <= L_LO={Llo}) = {hi <= Llo}")
    ok7 = ok7 and hi <= Llo
record(7, "PASS" if ok7 else "FAIL", "; ".join(d7))

# ---------------------------------------------------------------- control 8: ownership and region grid (exact)
_, tr = module("gap1_producer/global_axial_c1b_kernel.py")
lo, xlo, xhi, hi = (eval_const(literal(tr, n)) for n in ("GAP1_LAMBDA_LO", "GAP1_X_LO", "GAP1_X_HI", "GAP1_LAMBDA_HI"))
d = eval_const(literal(tr, "GAP1_DLAM"))
grid = ((xlo - lo) / d, (xhi - xlo) / d, (hi - xhi) / d)
gp = gp_text
own_ok = (grid == (118, 7, 35) and all(g.denominator == 1 for g in grid)
          and '"699/1600": "X", "281/640": "R", "9/20": "consistency_only"' in (ROOT / "gap1_producer/global_axial_c1b_gating.py").read_text()
          and "meets = max(a, kernel.T_LO) < min(b, kernel.GAP1_X_SPLIT_T)" in gp
          and gc_text.count("def gap1_boundary_overlap(accepted, kernel):") == 1)
record(8, "PASS" if own_ok else "FAIL",
       f"region grid {grid} on 1/3200 (no straddling slab); owners 699/1600=X (L overlap: root count 0, g(1/2)<0), "
       "281/640=R (X overlap: root count 1, T_* meets (1/2,5/8)), 9/20 consistency only; t=5/8 owner X negative "
       "block, t=31/32 owner endpoint seed; overlap checks run in both lineages after the exact union")

# ---------------------------------------------------------------- control 9: lineage independence
def imports(path):
    _, tree = module(path)
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module:
            out.append(n.module)
        elif isinstance(n, ast.Import):
            out += [a.name for a in n.names]
        elif isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "import_module":
            out.append("DYNAMIC:" + ast.unparse(n.args[0]))
    return out
d9 = []
ok9 = True
for path in NEW7.values():
    imps = imports(path)
    if path.startswith("gap1_checker"):
        bad = [m for m in imps if m.startswith(("gap1_producer", "producer"))]
    elif path.startswith("gap1_producer"):
        bad = [m for m in imps if m.startswith(("gap1_checker", "checker"))]
    else:
        bad = [m for m in imps if m.startswith(("gap1_", "producer", "checker", "flint", "mpmath"))]
    ok9 = ok9 and not bad
    d9.append(f"{path}: imports={sorted(set(imps))} forbidden={bad}")
dyn_ok = True
for kernel in KERNELS:
    src = (ROOT / kernel).read_text()
    pkg = kernel.split("/")[0]
    dyn_ok = dyn_ok and 'lineage = __name__.split(".", 1)[0]' in src and \
        (ROOT / pkg / "global_axial_c1b_gating.py").is_file() and \
        'Path(__file__).with_name("global_axial_c1b_gating.py")' in src
ok9 = ok9 and dyn_ok
for x in d9:
    print("IMPORTS", x)
record(9, "PASS" if ok9 else "FAIL",
       "checker files import no producer/gap1_producer module; producer files import no checker/gap1_checker "
       "module except the pinned baseline edges inside the 17; shared gap1_analysis driver imports no numerical "
       f"package; dynamic gating lookup resolves inside the own gap1 package (static path exists)={dyn_ok}. "
       "Run-time resolution of namespace packages is NOT_VERIFIED here (see OPEN_QUESTIONS)")

# ---------------------------------------------------------------- control 10: numeric contract constants and codes
expect = {
    "BITS": None, "DEG": 50, "USTAR": Fraction(3, 5), "W0": Fraction(1, 16), "PRED_ACCEPT": Fraction(1, 64),
    "ROOT_TARGET": Fraction(1, 128), "MAX_DEPTH": 3, "MAX_ACCEPTED": 1280, "MAX_ATTEMPTED": 2400,
    "PRED_GRID_DEN": 1024, "PRED_SCAN_PANELS": 256,
    "T_STAGES": (("T0", 8, 4, 4096), ("T1", 16, 8, 4096), ("T2", 32, 16, 8192)),
    "GAP1_X_T_STAGES": (("X-T0", 8, 4, 4096), ("X-T1", 16, 8, 4096), ("X-T2", 32, 16, 8192)),
    "ROOT_MV_STEPS": 8, "ROOT_G_PANELS": 32768, "ROOT_GT_PANELS": 8192, "ROOT_GL_PANELS": 8192,
    "ROOT_GT_T_CELLS": 16, "ROOT_GL_T_CELLS": 16, "ROOT_GL_CORNER_K": 16, "ROOT_GL_CORNER_TAU": Fraction(65535, 65536),
    "ROOT_GT_CLAMP_TAU": Fraction(255, 256), "ROOT_GL_CORNER_WALL_PANELS": 8192, "ROOT_GT_REFINE_DEPTH": 2,
    "T2_ENDPOINT_REFINE_DEPTH": 4, "E0_TBOXES": 24, "E0_LBOXES": 8,
    "E_STAGES": (("E0", 1024), ("E1", 2048), ("E2", 4096)), "E_BOX_CAP": 4096, "MONO_WORK_CAP": 1048576,
    "ENDPOINT_T_SEED": Fraction(31, 32), "ENDPOINT_DT": Fraction(1, 512), "ENDPOINT_N_BOXES": 16,
    "ENDPOINT_SEED_PANELS": 8192, "ENDPOINT_GT_PANELS": 8192, "ATTEMPT_WORK_CEILING": 25600000,
    "GLOBAL_ATTEMPT_WORK_CEILING": 61440000000, "ACCEPTED_WORK_CEILING": 32768000000,
    "GAP1_DLAM": Fraction(1, 3200), "GAP1_N_COARSE": 160, "GAP1_REGION_SLABS": (("L", 118), ("X", 7), ("R", 35)),
    "GAP1_X_SPLIT_T": Fraction(5, 8),
}
REQUIRED_CODES = {"CERTIFICATE_INCONCLUSIVE", "PRECISION_INCONCLUSIVE", "APPROX_DEGREE_INCONCLUSIVE",
                  "ENDPOINT_SEED_G_INCONCLUSIVE", "ENDPOINT_GT_CELL_INCONCLUSIVE", "ENDPOINT_CUMULATIVE_MVT_INCONCLUSIVE",
                  "NONFINITE", "RESOURCE_CAP", "CONTRACT_MISMATCH", "DIFF_OUTSIDE_ALLOWLIST", "IMPORT_BLOB_MISMATCH",
                  "PREDICTOR_RULE_MISMATCH", "ENDPOINT_PARTITION_MISMATCH", "ENDPOINT_NONFINITE",
                  "ENDPOINT_RESOURCE_CAP", "BOB_SIGN_CONSISTENCY_FAILED"}
ok10 = True
d10 = []
for kernel, bits in zip(KERNELS, (160, 192)):
    _, tr = module(kernel)
    for name, value in expect.items():
        got = eval_const(literal(tr, name))
        want = bits if name == "BITS" else value
        if got != want:
            ok10 = False; d10.append(f"{kernel}:{name}={got}!={want}")
    codes = set(eval_const(literal(tr, "GAP1_FAILURE_CODES")))
    if not REQUIRED_CODES <= codes:
        ok10 = False; d10.append(f"{kernel}: missing codes {sorted(REQUIRED_CODES - codes)}")
for g in GATINGS:
    t = (ROOT / g).read_text()
    for key in ('"region": region', '"diff_categories_used"', '"endpoint": None', '"failure_class"',
                '"x_lower_tube_stage"', '"region_pieces"'):
        if key not in t:
            ok10 = False; d10.append(f"{g}: ledger key {key} missing")
record(10, "PASS" if ok10 else "FAIL",
       "precision 160/192, degree 50, caps 3/1280/2400, ceilings 25.6M/61.44G/32.768G, stages, panels, endpoint "
       "16x1/512 seed 31/32 with 8192 panels, 1/3200 grid 118/7/35, failure vocabulary and ledger keys" +
       ("" if ok10 else " :: " + "; ".join(d10)))

# ---------------------------------------------------------------- control 11 (v0.1, F1): X is direct g_box only
MONO_OR_EXTERIOR = {"mono_closure_box", "_mono_truth", "_mono_cap_allows", "_validate_mono_box_side",
                    "eval_exterior", "exterior_cover", "exterior_seed", "_e0_counts"}
X_FUNCS = ("attempt_x", "x_lower_tube", "x_negative_cover", "x_negative_eval", "x_negative_seed")
ok11, d11 = True, []
for kernel in KERNELS:
    t, tr = module(kernel)
    funcs = top_functions(tr)
    for start in X_FUNCS:
        hit = sorted(reach(funcs, start) & (MONO_OR_EXTERIOR | FORBIDDEN_LX))
        ok11 = ok11 and start in funcs and not hit
        d11.append(f"{kernel.split('/')[0]}:{start}->mono/exterior/predictor={hit}")
    ev = funcs["x_negative_eval"]
    names = {n.func.id for n in ast.walk(ev) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
    direct_only = "g_box" in names and "gt_box" not in names and not (names & MONO_OR_EXTERIOR)
    ev_src = ast.get_source_segment(t, ev)
    resolve_rule = "good = finite and value.upper() < 0" in ev_src
    seed_src = ast.get_source_segment(t, funcs["x_negative_seed"])
    seed_ok = ("split(GAP1_X_SPLIT_T, T_MID_HI, E0_TBOXES)" in seed_src and "split(slab.ll, slab.lr, E0_LBOXES)" in seed_src)
    cov_src = ast.get_source_segment(t, funcs["x_negative_cover"])
    cov_names = [n.id for n in ast.walk(funcs["x_negative_cover"]) if isinstance(n, ast.Name)]  # AST names only (comments excluded)
    ladder_ok = ("enumerate(E_STAGES)" in cov_src and cov_names.count("E_BOX_CAP") == 2 and "e_children(box)" in cov_src)
    l_mono = "exterior_cover" in reach(funcs, "attempt_l")
    consts = (eval_const(literal(tr, "E0_TBOXES")), eval_const(literal(tr, "E0_LBOXES")), eval_const(literal(tr, "E_BOX_CAP")),
              tuple(p for _, p in eval_const(literal(tr, "E_STAGES"))))
    good = direct_only and resolve_rule and seed_ok and ladder_ok and l_mono and consts == (24, 8, 4096, (1024, 2048, 4096))
    ok11 = ok11 and good
    d11.append(f"{kernel.split('/')[0]}: x_negative_eval calls g_box only={direct_only}, resolved iff finite and upper<0="
               f"{resolve_rule}, E0 24x8 on [5/8,31/32]={seed_ok}, ladder E0/E1/E2 + E_BOX_CAP={ladder_ok} {consts}, "
               f"L keeps baseline exterior (mono allowed)={l_mono}")
record(11, "PASS" if ok11 else "FAIL", "; ".join(d11))

# ---------------------------------------------------------------- control 12 (v0.1, F2): X root-count label
ok12, d12 = True, []
for kernel in KERNELS:
    t, tr = module(kernel)
    labels = eval_const(literal(tr, "GAP1_ROOT_COUNT_LABELS"))
    good = labels == {"L": "ROOT_FREE_REGION", "X": "ROOT_COUNT_BY_C1A_SIGN_NO_T_STAR", "R": "RESOLVED_WITH_CERTIFIED_T_STAR"}
    rule = eval_const(literal(tr, "GAP1_X_ROOT_COUNT_RULE"))
    good = good and all(s in rule for s in ("g(1/2,lambda) <= 0", "g(1/2,lambda) > 0", "C1a", "gate D",
                                            "no T_star", "no lambda_x approximation"))
    ok12 = ok12 and good
    d12.append(f"{kernel.split('/')[0]}: labels L/X/R={good}")
for g in GATINGS:
    t, tr = module(g)
    code_consts = [n.value for n in ast.walk(tr) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
    free_literal = sum(1 for c in code_consts if c == "ROOT_FREE_REGION")
    funcs = top_functions(tr)
    ro = ast.get_source_segment(t, funcs["gap1_root_outcome"])
    rc = ast.get_source_segment(t, funcs["gap1_root_count_record"])
    good = (free_literal == 0 and 'if region in ("L", "X"):\n        return kernel.GAP1_ROOT_COUNT_LABELS[region]' in ro
            and '"t_star_constructed": False, "lambda_x_approximation_used": False' in rc
            and 'if _gap1_attempt_reason(result) != "PASS":\n        return "UNRESOLVED"' in ro
            and '"certified": certified, "accepted": None, "root_count": None,' in rc
            and 'gap1["root_count"] = gap1_root_count_record(kernel, region, result, closure)' in t)
    if "checker" in g:
        good = good and ("root_outcome = gap1_root_outcome(kernel, region, result)" in t
                         and "if root_outcome != kernel.GAP1_ROOT_COUNT_LABELS[region]:" in t)
    ok12 = ok12 and good
    d12.append(f"{g.split('/')[0]}: no ROOT_FREE_REGION literal in code={free_literal == 0}, per-region label/record={good}")
record(12, "PASS" if ok12 else "FAIL", "; ".join(d12))

# ---------------------------------------------------------------- control 13 (v0.1, F3): RESOURCE_CAP classification
ok13, d13 = True, []
helpers = ("gap1_cap_exceeded", "gap1_cap_stop", "gap1_mark_decision", "gap1_terminal_abort", "gap1_failure_class",
           "_gap1_attempt_reason", "gap1_root_outcome", "gap1_root_count_record")
seg = {}
for g in GATINGS:
    t, tr = module(g)
    funcs = top_functions(tr)
    seg[g] = {h: ast.get_source_segment(t, funcs[h]) for h in helpers}
    raises = [n.args[0].value for n in ast.walk(tr) if isinstance(n, ast.Call) and getattr(n.func, "id", None) == "SystemExit"
              and n.args and isinstance(n.args[0], ast.Constant)]
    old_cap_exits = sorted(set(raises) & {"MAX_ATTEMPTED_SLABS_EXCEEDED", "GLOBAL_ATTEMPT_WORK_CEILING_EXCEEDED",
                                          "CHECKER_ACCEPTED_CEILING_EXCEEDED"})
    no_check_ceiling = ".check_ceiling" not in calls_of(funcs["run_full"])
    rf = ast.get_source_segment(t, funcs["run_full"])
    # every slab_record append is preceded in the loop body by the terminal classification
    mark_before_record = rf.index("gap1_stop = gap1_mark_decision(") < rf.index('ledger.append("slab_record", payload)')
    seg_end = ("if gap1_stop is not None:\n            payload.update(gap1_stop)" in rf
               and 'raise SystemExit("RESOURCE_CAP:" + gap1_stop["resource_cap"])' in rf
               and "next_cap = gap1_cap_exceeded(kernel, global_work, accepted_count, accepted_work, attempted + 1)" in rf
               and "gap1_stop = gap1_cap_stop(next_cap, None)" in rf and "resume_cap = gap1_cap_exceeded(" in rf
               and "MAX_ATTEMPTED" not in [n.value for n in ast.walk(funcs["run_full"]) if isinstance(n, ast.Constant)])
    if "producer" in g:
        wiring = ('cap = gap1_cap_exceeded(kernel, global_work, cap_test_accepted_count, cap_test_accepted_work, attempted) if decision == "ABORT" else None' in rf
                  and 'gap1_terminal_abort(kernel, persisted["terminal"], "decision")' in t)
    else:
        wiring = ('checker_decision = "ABORT" if (cap is not None or fixed_decision == "ABORT") else "REPLAYED"' in rf
                  and 'gap1_mark_decision(result, "ABORT" if checker_decision == "ABORT" else fixed_decision, cap,' in rf
                  and '"checker_reason": result["reason"]' in rf and 'raise SystemExit("CHECKER_TERMINAL_ABORT:" + gap1_stop["abort_cause"])' in rf
                  and rf.count('cap = gap1_cap_exceeded(kernel, global_work, cap_test_accepted_count, cap_test_accepted_work, attempted)') == 2
                  and 'gap1_terminal_abort(kernel, terminal, "checker_decision")' in t
                  and rf.count("replay_state(ledger.records, plan, kernel)") == 2)
    mark = seg[g]["gap1_mark_decision"]
    no_pass_abort = ('result["reason"] = "RESOURCE_CAP:" + cap' in mark and 'gap1["failure_class"] = "RESOURCE_CAP"' in mark
                     and 'raise SystemExit("CONTRACT_MISMATCH:ABORT_WITHOUT_CAUSE")' in mark
                     and 'result["reason"] = "CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED"' in mark
                     and "PASS but whose decision is ABORT" not in seg[g]["gap1_failure_class"])
    good = not old_cap_exits and no_check_ceiling and mark_before_record and seg_end and wiring and no_pass_abort
    ok13 = ok13 and good
    d13.append(f"{g.split('/')[0]}: old unrecorded cap exits={old_cap_exits}, check_ceiling removed={no_check_ceiling}, "
               f"classification before slab_record={mark_before_record}, segment_end carries RESOURCE_CAP + cap name={seg_end}, "
               f"live/resume/replay wiring={wiring}, no PASS+ABORT pair={no_pass_abort}")
same = all(seg[GATINGS[0]][h] == seg[GATINGS[1]][h] for h in helpers)
_, ktr = module(KERNELS[0])
caps_const = eval_const(literal(ktr, "GAP1_RESOURCE_CAPS"))
order_src = seg[GATINGS[0]]["gap1_cap_exceeded"]
prio_ok = "for cap in kernel.GAP1_RESOURCE_CAPS:" in order_src and "if value > ceiling:" in order_src and caps_const == ("GLOBAL_ATTEMPT_WORK_CEILING", "MAX_ACCEPTED", "ACCEPTED_WORK_CEILING", "MAX_ATTEMPTED")
ok13 = ok13 and same and prio_ok
d13.append(f"classification helpers text-identical in both lineages={same}; caps tested in the order of GAP1_RESOURCE_CAPS (global>accepted count>accepted work>attempted), MAX_ATTEMPTED via attempted+1 before each attempt={prio_ok}")
record(13, "PASS" if ok13 else "FAIL", "; ".join(d13))

# ---------------------------------------------------------------- control 14 (v0.1, Q10/Q11): read-only pin
dtext, dtree = module("gap1_analysis/c1b_resumable_driver.py")
req = eval_const(literal(dtree, "REQUIRED_C1B_BLOB_PATHS"))
cmp_rel = "analysis/c1b_cross_lineage_compare.py"
cmp_blob = blob(ROOT / cmp_rel)
ok14 = cmp_rel in req and len(req) == 25 and len(set(req)) == 25
d14 = [f"driver REQUIRED_C1B_BLOB_PATHS has {len(req)} unique paths (7 new + 17 closure + compare.py)={ok14}",
       f"measured blob of {cmp_rel} at baseline={cmp_blob}"]
for kernel in KERNELS:
    t, tr = module(kernel)
    pins = eval_const(literal(tr, "GAP1_READ_ONLY_PINS"))
    pf = ast.get_source_segment(t, top_functions(tr)["preflight"])
    order = pf.index("gap1_read_only_pin_check()") < pf.index("v211_preflight_controls()")
    good = pins == {cmp_rel: "33cdd3290bfa09c88cd8936e1f4557af491f0bc2"} and cmp_blob == pins[cmp_rel] and order
    ok14 = ok14 and good
    d14.append(f"{kernel.split('/')[0]}: GAP1_READ_ONLY_PINS == measured blob, checked before v211 read={good}")
record(14, "PASS" if ok14 else "FAIL", "; ".join(d14))

# ---------------------------------------------------------------- control 15 (v0.1, Q15): stub controls (not run)
ok15, d15 = True, []
labels15 = ("L_DIRECT_NEGATIVE_PASS", "L_POSITIVE_FAIL", "L_MONO_CLOSURE_AVAILABLE", "X_DIRECT_NEGATIVE_PASS",
            "X_LOWER_TUBE_FAIL", "X_NO_MONO_CLOSURE_FAIL", "ENDPOINT_SEED_M1_UJ_P1_PASS", "ENDPOINT_SEED_M1_64_UJ_P1_FAIL",
            "ENDPOINT_NEGATIVE_UJ_DROPPED_PASS", "ENDPOINT_SEED_NONNEGATIVE_FAIL", "ENDPOINT_NONFINITE_FAIL")
for kernel in KERNELS:
    t, tr = module(kernel)
    funcs = top_functions(tr)
    sc = funcs["gap1_stub_controls"]
    src = ast.get_source_segment(t, sc)
    consts = [n.value for n in ast.walk(sc) if isinstance(n, ast.Constant) and isinstance(n.value, str)]
    has_labels = all(consts.count(l) == 1 for l in labels15)
    restored = any(isinstance(n, ast.Try) and n.finalbody and "g_box, gt_box = saved_g, saved_gt" in ast.get_source_segment(t, n.finalbody[0])
                   for n in ast.walk(sc))
    required = ('g_box, gt_box = g_const(arb(-1)), gt_const(arb(1))' in src and 'g_box = g_const(arb(-1) / 64)' in src
                and "Fraction(-31, 32) <= upper < 0" in src and "upper >= Fraction(1, 64)" in src)
    wired = ("gap1_stub_controls()" in ast.get_source_segment(t, funcs["preflight"])
             and "mono_closure_box = eval_exterior = exterior_cover = forbidden" in src
             and "mono_closure_box, eval_exterior, exterior_cover = saved_mono, saved_eval, saved_cover" in src)
    good = has_labels and restored and required and wired and "len(results) != 11" in src
    ok15 = ok15 and good
    d15.append(f"{kernel.split('/')[0]}: 11 labelled stub controls={has_labels}, g_box/gt_box restored in finally={restored}, "
               f"endpoint seed=-1/U_j=+1 PASS and seed=-1/64/U_j=+1 FAIL present={required}, called by preflight and X run with mono/exterior replaced by a raising stub={wired}")
d15.append("written only: no stub control was executed (instruction v0.1 section 2.5)")
record(15, "PASS" if ok15 else "FAIL", "; ".join(d15))

# ---------------------------------------------------------------- control 16 (v0.2): consistency inside one record
ok16, d16 = True, []
dtext, dtree = module("gap1_analysis/c1b_resumable_driver.py")
for g in GATINGS:
    t, tr = module(g)
    funcs = top_functions(tr)
    rf_node = funcs["run_full"]
    rf = ast.get_source_segment(t, rf_node)
    # (a) accepted <-> counters: committed counters change only by the single commit statement, never by "+=",
    #     and the commit sits in the branch that makes the slab accepted.
    aug = [n for n in ast.walk(rf_node) if isinstance(n, ast.AugAssign) and isinstance(n.target, ast.Name)
           and n.target.id in ("accepted_count", "accepted_work")]
    commit = "accepted_count, accepted_work = cap_test_accepted_count, cap_test_accepted_work"
    if "producer" in g:
        branch = ('else:\n                decision = "ACCEPT"\n                ' + commit + '\n                previous_root = root') in rf
    else:
        branch = ('if cap is None:\n                ' + commit + '\n                previous_root = root') in rf
    mark = ast.get_source_segment(t, funcs["gap1_mark_decision"])
    a_ok = (not aug and rf.count(commit) == 1 and rf.count("previous_root = root") == 1 and branch
            and 'gap1["root_count"]["accepted"] = decision == "ACCEPT"' in mark
            and '"cap_test_accepted_count": cap_test_accepted_count' in rf.replace("\\n", ""))
    # (b) rule <-> guards: the L rule is a function of the closure method, the method of the guards actually
    #     recorded; *_MONO is the suffix baseline eval_exterior gives mono guards, X guards carry X_DIRECT_G only.
    rc = ast.get_source_segment(t, funcs["gap1_root_count_record"])
    cl = ast.get_source_segment(t, funcs["gap1_negative_block_closure"])
    ser = ast.get_source_segment(t, funcs["gap1_serialize_record"])
    b_ok = ('"rule": GAP1_L_RULES[method] if (certified and method is not None) else None' in rc
            and 'str(kind).endswith("_MONO")' in cl and '"method": GAP1_CLOSURE_DIRECT_AND_MONO if mono else GAP1_CLOSURE_DIRECT_ONLY' in cl
            and 'closure = gap1_negative_block_closure(rec.get("exterior_guards", ()))' in ser
            and 'raise SystemExit("CONTRACT_MISMATCH:X_MONO_CLOSURE")' in ser)
    # (c) reason / failure_class / abort_cause / resource_cap: every assignment block of gap1_mark_decision.
    mnode = funcs["gap1_mark_decision"]
    combos = []
    for node in ast.walk(mnode):
        if isinstance(node, ast.If):
            body = ast.get_source_segment(t, node)
            combos.append(body)
    cap_block = next(b for b in combos if b.startswith("if cap is not None:"))
    c_ok = (all(x in cap_block for x in ('gap1["abort_cause"] = "RESOURCE_CAP"', 'gap1["resource_cap"] = cap',
                                         'gap1["failure_class"] = "RESOURCE_CAP"', 'result["reason"] = "RESOURCE_CAP:" + cap'))
            and mark.count('gap1["failure_class"] = ') == 2 and mark.count('result["reason"] = ') == 2
            and 'gap1["failure_class"] = "CONTRACT_MISMATCH"\n        result["reason"] = "CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED"' in mark
            and 'if abort_cause not in GAP1_NON_CAP_ABORT_CAUSES:' in mark
            and eval_const(literal(tr, "GAP1_NON_CAP_ABORT_CAUSES")) == ("MAX_DEPTH_EXHAUSTED", "PRODUCER_PLAN_ABORT"))
    good = a_ok and b_ok and c_ok
    ok16 = ok16 and good
    d16.append(f"{g.split('/')[0]}: accepted<->counters (commit only on acceptance, no '+=', candidate recorded)={a_ok}, "
               f"L rule from recorded guards / X has no mono={b_ok}, reason/failure_class/abort_cause/resource_cap blocks={c_ok}")
# kernel side of (b): the mono guard suffix and the X guard kind as produced
for kernel in KERNELS:
    t, tr = module(kernel)
    funcs = top_functions(tr)
    ev = ast.get_source_segment(t, funcs["eval_exterior"])
    xe = ast.get_source_segment(t, funcs["x_negative_eval"])
    k_ok = ('mono_guards.append((label, box.side + "_MONO",' in ev and 'sign_guards.append((label, box.side,' in ev
            and 'guards.append((label, "X_DIRECT_G",' in xe)
    ok16 = ok16 and k_ok
    d16.append(f"{kernel.split('/')[0]}: guard kinds as counted (sign=box.side, mono=box.side+'_MONO', X=X_DIRECT_G)={k_ok}")
record(16, "PASS" if ok16 else "FAIL", "; ".join(d16))

# ---------------------------------------------------------------- control 17 (v0.2): ledger vs rebuilt counters
ok17, d17 = True, []
rs = ast.get_source_segment(dtext, top_functions(dtree)["resume_state"])
rule = 'payload["decision"] == "ACCEPT" and payload.get("checker_decision", "REPLAYED") != "ABORT"'
drv_ok = (rule in rs and 'global_work += int(payload["charged_work"])' in rs and 'work = int(payload["result"]["work_total"])' in rs
          and 'attempted += 1' in rs and 'accepted_work += work' in rs)
d17.append(f"driver resume_state: accepted iff ({rule}); global = charges + work_total; attempted = attempt_begin count={drv_ok}")
ok17 = ok17 and drv_ok
for g in GATINGS:
    t, tr = module(g)
    funcs = top_functions(tr)
    ca = ast.get_source_segment(t, funcs["gap1_counts_accepted"])
    au = ast.get_source_segment(t, funcs["gap1_ledger_count_audit"])
    ta = ast.get_source_segment(t, funcs["gap1_terminal_abort"])
    rf = ast.get_source_segment(t, funcs["run_full"])
    rp = ast.get_source_segment(t, funcs["replay" if "producer" in g else "replay_state"])
    same_rule = ("return " + rule) in ca
    audit = ('stored = (int(payload["attempted_count"]), int(payload["cumulative_work_after"]),' in au
             and 'int(payload["accepted_count"]), int(payload["accepted_work"]))' in au
             and 'if stored != (attempted, global_work, accepted_count, accepted_work):' in au
             and 'global_work += int(payload["charged_work"])' in au and 'if gap1_counts_accepted(payload):' in au
             and '.get("accepted") is not gap1_counts_accepted(payload)' in au
             and 'not in ("REPLAYED", "ABORT"):' in au)
    wired = (rp.index("gap1_ledger_count_audit(records)") < rp.index("gap1_terminal_abort(")
             and 'int(payload["cap_test_accepted_count"])' in ta and 'int(payload["cap_test_accepted_work"])' in ta)
    live = ('global_work = state["global_work"]' in rf.replace("; ", "\n    ") or 'global_work = state["global_work"]' in rf) and \
           'attempt_work = result["work_total"]' in rf and 'len(state["accepted"])' in rf and 'state["accepted_work"]' in rf
    good = same_rule and audit and wired and live
    ok17 = ok17 and good
    d17.append(f"{g.split('/')[0]}: accepted rule identical to resume_state={same_rule}, audit compares attempted/global/"
               f"accepted count/accepted work per slab_record={audit}, audit before terminal-abort and cap re-test on cap_test_*={wired}, "
               f"live counters start from resume_state and add work_total={live}")
record(17, "PASS" if ok17 else "FAIL", "; ".join(d17))

# ---------------------------------------------------------------- control 0: undefined-name lint (symtable)
def module_names(text):
    tree = ast.parse(text)
    names = set(dir(builtins)) | {"__name__", "__file__"}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for a in node.names:
                names.add((a.asname or a.name).split(".")[0])
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in targets:
                for n in ast.walk(t):
                    if isinstance(n, ast.Name):
                        names.add(n.id)
    return names
lint = []
for path in NEW7.values():
    text = (ROOT / path).read_text()
    defined = module_names(text)
    table = symtable.symtable(text, path, "exec")
    def walk(tab):
        for child in tab.get_children():
            for sym in child.get_symbols():
                if sym.is_global() and sym.is_referenced() and sym.get_name() not in defined:
                    lint.append((path, child.get_name(), sym.get_name()))
            walk(child)
    walk(table)
for item in lint:
    print("UNDEFINED_GLOBAL", *item)
record(0, "PASS" if not lint else "FAIL", f"unresolved global names in the 7 new files = {len(lint)}")

print("SUMMARY", " ".join(f"C{c}={s}" for c, s, _ in sorted(RESULTS)))
