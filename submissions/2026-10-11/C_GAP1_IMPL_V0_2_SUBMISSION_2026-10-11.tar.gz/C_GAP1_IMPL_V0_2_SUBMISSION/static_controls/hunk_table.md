| # | new file | hunk | baseline lines | new lines | −/+ lines | category | edit label(s) |
|---|---|---|---|---|---|---|---|
| 1 | `gap1_producer/global_axial_c1b_kernel.py` | 1 | 29–35 | 29–35 | −1/+1 | DIFF-K | caps |
| 2 | `gap1_producer/global_axial_c1b_kernel.py` | 2 | 49–56 | 49–56 | −2/+2 | DIFF-K | work ceilings |
| 3 | `gap1_producer/global_axial_c1b_kernel.py` | 3 | 59–64 | 59–181 | −0/+117 | DIFF-K | constants/domain |
| 4 | `gap1_producer/global_axial_c1b_kernel.py` | 4 | 84–94 | 201–209 | −5/+3 | DIFF-A | descending queue |
| 5 | `gap1_producer/global_axial_c1b_kernel.py` | 5 | 883–888 | 998–1141 | −0/+138 | DIFF-K | U1 controls |
| 6 | `gap1_producer/global_axial_c1b_kernel.py` | 6 | 1206–1211 | 1459–1573 | −0/+109 | DIFF-B | X fixed path |
| 7 | `gap1_producer/global_axial_c1b_kernel.py` | 7 | 1426–1431 | 1788–1879 | −0/+86 | DIFF-D | endpoint gate |
| 8 | `gap1_producer/global_axial_c1b_kernel.py` | 8 | 1586–1591 | 2034–2052 | −0/+13 | DIFF-C | L negative path |
| 9 | `gap1_producer/global_axial_c1b_kernel.py` | 9 | 1644–1649 | 2105–2131 | −0/+21 | DIFF-E | region dispatcher |
| 10 | `gap1_producer/global_axial_c1b_kernel.py` | 10 | 1814–1820 | 2296–2304 | −1/+3 | DIFF-K | preflight banner |
| 11 | `gap1_producer/global_axial_c1b_kernel.py` | 11 | 1837–1842 | 2321–2327 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 12 | `gap1_producer/global_axial_c1b_kernel.py` | 12 | 1845–1848 | 2330–2336 | −0/+3 | DIFF-K | preflight controls |
| 13 | `gap1_producer/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 14 | `gap1_producer/global_axial_c1b_gating.py` | 2 | 142–147 | 142–456 | −0/+309 | DIFF-E | ledger/overlap/union helpers |
| 15 | `gap1_producer/global_axial_c1b_gating.py` | 3 | 317–322 | 626–633 | −0/+2 | DIFF-E | resume re-classifies a terminal ABORT |
| 16 | `gap1_producer/global_axial_c1b_gating.py` | 4 | 328–337 | 639–648 | −2/+2 | DIFF-A | live right-child-first; resume replay right-child-first |
| 17 | `gap1_producer/global_axial_c1b_gating.py` | 5 | 341–347 | 652–658 | −1/+1 | DIFF-E | replay schema label |
| 18 | `gap1_producer/global_axial_c1b_gating.py` | 6 | 389–400 | 700–711 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 19 | `gap1_producer/global_axial_c1b_gating.py` | 7 | 402–407 | 713–753 | −0/+35 | DIFF-K | U1 header metadata block |
| 20 | `gap1_producer/global_axial_c1b_gating.py` | 8 | 412–418 | 758–765 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 21 | `gap1_producer/global_axial_c1b_gating.py` | 9 | 427–433 | 774–780 | −1/+1 | DIFF-K | header coarse cap |
| 22 | `gap1_producer/global_axial_c1b_gating.py` | 10 | 489–497 | 836–842 | −3/+1 | DIFF-E | resume cap test moved |
| 23 | `gap1_producer/global_axial_c1b_gating.py` | 11 | 502–507 | 847–853 | −0/+1 | DIFF-E | stop-field holder |
| 24 | `gap1_producer/global_axial_c1b_gating.py` | 12 | 515–522 | 861–878 | −0/+10 | DIFF-E | resume cap test recorded as RESOURCE_CAP; segment_end stop fields |
| 25 | `gap1_producer/global_axial_c1b_gating.py` | 13 | 536–543 | 892–901 | −2/+4 | DIFF-E | MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 26 | `gap1_producer/global_axial_c1b_gating.py` | 14 | 550–580 | 908–945 | −8/+15 | DIFF-E | accepted counters advance only on ACCEPT; candidate cap test (F5); dispatch + record; terminal decision classification (F3) |
| 27 | `gap1_producer/global_axial_c1b_gating.py` | 15 | 582–587 | 947–954 | −0/+2 | DIFF-E | candidate counters recorded (F5) |
| 28 | `gap1_producer/global_axial_c1b_gating.py` | 16 | 592–598 | 959–965 | −1/+1 | DIFF-A | live right-child-first; resume replay right-child-first |
| 29 | `gap1_producer/global_axial_c1b_gating.py` | 17 | 601–619 | 968–984 | −7/+5 | DIFF-E | exact union + overlap; segment end overlap record |
| 30 | `gap1_producer/global_axial_c1b_gating.py` | 18 | 622–627 | 987–994 | −0/+2 | DIFF-E | overlap failure after segment end |
| 31 | `gap1_producer/global_axial_c1b_producer.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
| 32 | `gap1_analysis/c1b_resumable_driver.py` | 1 | 18–34 | 18–52 | −9/+27 | DIFF-E | pin manifest path / chain label; pinned blob paths (7 new + 17 closure + 1 read-only) |
| 33 | `gap1_analysis/c1b_resumable_driver.py` | 2 | 341–350 | 359–369 | −2/+3 | DIFF-E | resume_state accepted rule (F5/B2) |
| 34 | `gap1_checker/global_axial_c1b_kernel.py` | 1 | 30–36 | 30–36 | −1/+1 | DIFF-K | caps |
| 35 | `gap1_checker/global_axial_c1b_kernel.py` | 2 | 50–57 | 50–57 | −2/+2 | DIFF-K | work ceilings |
| 36 | `gap1_checker/global_axial_c1b_kernel.py` | 3 | 60–65 | 60–182 | −0/+117 | DIFF-K | constants/domain |
| 37 | `gap1_checker/global_axial_c1b_kernel.py` | 4 | 876–881 | 993–1136 | −0/+138 | DIFF-K | U1 controls |
| 38 | `gap1_checker/global_axial_c1b_kernel.py` | 5 | 1183–1188 | 1438–1552 | −0/+109 | DIFF-B | X fixed path |
| 39 | `gap1_checker/global_axial_c1b_kernel.py` | 6 | 1403–1408 | 1767–1858 | −0/+86 | DIFF-D | endpoint gate |
| 40 | `gap1_checker/global_axial_c1b_kernel.py` | 7 | 1563–1568 | 2013–2031 | −0/+13 | DIFF-C | L negative path |
| 41 | `gap1_checker/global_axial_c1b_kernel.py` | 8 | 1630–1635 | 2093–2122 | −0/+24 | DIFF-E | region dispatcher |
| 42 | `gap1_checker/global_axial_c1b_kernel.py` | 9 | 1802–1808 | 2289–2297 | −1/+3 | DIFF-K | preflight banner |
| 43 | `gap1_checker/global_axial_c1b_kernel.py` | 10 | 1824–1829 | 2313–2319 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 44 | `gap1_checker/global_axial_c1b_kernel.py` | 11 | 1832–1835 | 2322–2328 | −0/+3 | DIFF-K | preflight controls |
| 45 | `gap1_checker/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 46 | `gap1_checker/global_axial_c1b_gating.py` | 2 | 142–147 | 142–456 | −0/+309 | DIFF-E | ledger/overlap/union helpers |
| 47 | `gap1_checker/global_axial_c1b_gating.py` | 3 | 312–318 | 621–627 | −1/+1 | DIFF-E | replay schema label |
| 48 | `gap1_checker/global_axial_c1b_gating.py` | 4 | 320–325 | 629–653 | −0/+19 | DIFF-A | checker plan-order audit |
| 49 | `gap1_checker/global_axial_c1b_gating.py` | 5 | 343–355 | 671–693 | −1/+11 | DIFF-E | checker L/X field verification; checker resume re-classifies a terminal cap stop |
| 50 | `gap1_checker/global_axial_c1b_gating.py` | 6 | 364–372 | 702–710 | −2/+2 | DIFF-E | resume previous_root for L/X |
| 51 | `gap1_checker/global_axial_c1b_gating.py` | 7 | 389–400 | 727–738 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 52 | `gap1_checker/global_axial_c1b_gating.py` | 8 | 402–407 | 740–780 | −0/+35 | DIFF-K | U1 header metadata block |
| 53 | `gap1_checker/global_axial_c1b_gating.py` | 9 | 412–418 | 785–792 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 54 | `gap1_checker/global_axial_c1b_gating.py` | 10 | 427–433 | 801–807 | −1/+1 | DIFF-K | header coarse cap |
| 55 | `gap1_checker/global_axial_c1b_gating.py` | 11 | 467–472 | 841–847 | −0/+1 | DIFF-A | checker plan-order audit call |
| 56 | `gap1_checker/global_axial_c1b_gating.py` | 12 | 479–485 | 854–860 | −1/+1 | DIFF-E | checker replay_state call (kernel) |
| 57 | `gap1_checker/global_axial_c1b_gating.py` | 13 | 487–494 | 862–869 | −2/+2 | DIFF-E | checker replay_state recall (kernel); checker resume cap test moved |
| 58 | `gap1_checker/global_axial_c1b_gating.py` | 14 | 498–503 | 873–879 | −0/+1 | DIFF-E | stop-field holder |
| 59 | `gap1_checker/global_axial_c1b_gating.py` | 15 | 507–513 | 883–900 | −1/+12 | DIFF-E | checker cap stop after its record; checker segment_end stop fields; resume cap test recorded as RESOURCE_CAP |
| 60 | `gap1_checker/global_axial_c1b_gating.py` | 16 | 520–527 | 907–916 | −2/+4 | DIFF-E | checker MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 61 | `gap1_checker/global_axial_c1b_gating.py` | 17 | 532–561 | 921–970 | −14/+34 | DIFF-E | checker dispatch + record + field checks; checker root-count outcome per region (F2) + cap classification (F3) |
| 62 | `gap1_checker/global_axial_c1b_gating.py` | 18 | 563–581 | 972–996 | −6/+12 | DIFF-E | checker cap stop after its record; checker exact union + overlap; checker segment end overlap record; checker segment_end stop fields; overlap failure after segment end |
| 63 | `gap1_checker/global_axial_c1b_checker.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
