| # | new file | hunk | baseline lines | new lines | −/+ lines | category | edit label(s) |
|---|---|---|---|---|---|---|---|
| 1 | `gap1_producer/global_axial_c1b_kernel.py` | 1 | 29–35 | 29–35 | −1/+1 | DIFF-K | caps |
| 2 | `gap1_producer/global_axial_c1b_kernel.py` | 2 | 49–56 | 49–56 | −2/+2 | DIFF-K | work ceilings |
| 3 | `gap1_producer/global_axial_c1b_kernel.py` | 3 | 59–64 | 59–181 | −0/+117 | DIFF-K | constants/domain |
| 4 | `gap1_producer/global_axial_c1b_kernel.py` | 4 | 84–94 | 201–209 | −5/+3 | DIFF-A | descending queue |
| 5 | `gap1_producer/global_axial_c1b_kernel.py` | 5 | 883–888 | 998–1141 | −0/+138 | DIFF-K | U1 controls |
| 6 | `gap1_producer/global_axial_c1b_kernel.py` | 6 | 1206–1211 | 1459–1573 | −0/+109 | DIFF-B | X fixed path |
| 7 | `gap1_producer/global_axial_c1b_kernel.py` | 7 | 1426–1431 | 1788–1879 | −0/+86 | DIFF-D | endpoint gate |
| 8 | `gap1_producer/global_axial_c1b_kernel.py` | 8 | 1586–1591 | 2034–2052 | −0/+13 | DIFF-C | L negative path |
| 9 | `gap1_producer/global_axial_c1b_kernel.py` | 9 | 1644–1649 | 2105–2131 | −0/+21 | DIFF-E | region dispatcher |
| 10 | `gap1_producer/global_axial_c1b_kernel.py` | 10 | 1814–1820 | 2296–2304 | −1/+3 | DIFF-K | preflight banner |
| 11 | `gap1_producer/global_axial_c1b_kernel.py` | 11 | 1837–1842 | 2321–2327 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 12 | `gap1_producer/global_axial_c1b_kernel.py` | 12 | 1845–1848 | 2330–2336 | −0/+3 | DIFF-K | preflight controls |
| 13 | `gap1_producer/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 14 | `gap1_producer/global_axial_c1b_gating.py` | 2 | 142–147 | 142–384 | −0/+237 | DIFF-E | ledger/overlap/union helpers |
| 15 | `gap1_producer/global_axial_c1b_gating.py` | 3 | 317–322 | 554–560 | −0/+1 | DIFF-E | resume re-classifies a terminal ABORT |
| 16 | `gap1_producer/global_axial_c1b_gating.py` | 4 | 328–337 | 566–575 | −2/+2 | DIFF-A | live right-child-first; resume replay right-child-first |
| 17 | `gap1_producer/global_axial_c1b_gating.py` | 5 | 341–347 | 579–585 | −1/+1 | DIFF-E | replay schema label |
| 18 | `gap1_producer/global_axial_c1b_gating.py` | 6 | 389–400 | 627–638 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 19 | `gap1_producer/global_axial_c1b_gating.py` | 7 | 402–407 | 640–680 | −0/+35 | DIFF-K | U1 header metadata block |
| 20 | `gap1_producer/global_axial_c1b_gating.py` | 8 | 412–418 | 685–692 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 21 | `gap1_producer/global_axial_c1b_gating.py` | 9 | 427–433 | 701–707 | −1/+1 | DIFF-K | header coarse cap |
| 22 | `gap1_producer/global_axial_c1b_gating.py` | 10 | 489–497 | 763–769 | −3/+1 | DIFF-E | resume cap test moved |
| 23 | `gap1_producer/global_axial_c1b_gating.py` | 11 | 502–507 | 774–780 | −0/+1 | DIFF-E | stop-field holder |
| 24 | `gap1_producer/global_axial_c1b_gating.py` | 12 | 515–522 | 788–805 | −0/+10 | DIFF-E | resume cap test recorded as RESOURCE_CAP; segment_end stop fields |
| 25 | `gap1_producer/global_axial_c1b_gating.py` | 13 | 536–543 | 819–828 | −2/+4 | DIFF-E | MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 26 | `gap1_producer/global_axial_c1b_gating.py` | 14 | 550–558 | 835–843 | −2/+2 | DIFF-E | dispatch + record |
| 27 | `gap1_producer/global_axial_c1b_gating.py` | 15 | 575–580 | 860–867 | −0/+2 | DIFF-E | terminal decision classification (F3) |
| 28 | `gap1_producer/global_axial_c1b_gating.py` | 16 | 592–598 | 879–885 | −1/+1 | DIFF-A | live right-child-first; resume replay right-child-first |
| 29 | `gap1_producer/global_axial_c1b_gating.py` | 17 | 601–619 | 888–904 | −7/+5 | DIFF-E | exact union + overlap; segment end overlap record |
| 30 | `gap1_producer/global_axial_c1b_gating.py` | 18 | 622–627 | 907–914 | −0/+2 | DIFF-E | overlap failure after segment end |
| 31 | `gap1_producer/global_axial_c1b_producer.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
| 32 | `gap1_analysis/c1b_resumable_driver.py` | 1 | 18–34 | 18–52 | −9/+27 | DIFF-E | pin manifest path / chain label; pinned blob paths (7 new + 17 closure + 1 read-only) |
| 33 | `gap1_checker/global_axial_c1b_kernel.py` | 1 | 30–36 | 30–36 | −1/+1 | DIFF-K | caps |
| 34 | `gap1_checker/global_axial_c1b_kernel.py` | 2 | 50–57 | 50–57 | −2/+2 | DIFF-K | work ceilings |
| 35 | `gap1_checker/global_axial_c1b_kernel.py` | 3 | 60–65 | 60–182 | −0/+117 | DIFF-K | constants/domain |
| 36 | `gap1_checker/global_axial_c1b_kernel.py` | 4 | 876–881 | 993–1136 | −0/+138 | DIFF-K | U1 controls |
| 37 | `gap1_checker/global_axial_c1b_kernel.py` | 5 | 1183–1188 | 1438–1552 | −0/+109 | DIFF-B | X fixed path |
| 38 | `gap1_checker/global_axial_c1b_kernel.py` | 6 | 1403–1408 | 1767–1858 | −0/+86 | DIFF-D | endpoint gate |
| 39 | `gap1_checker/global_axial_c1b_kernel.py` | 7 | 1563–1568 | 2013–2031 | −0/+13 | DIFF-C | L negative path |
| 40 | `gap1_checker/global_axial_c1b_kernel.py` | 8 | 1630–1635 | 2093–2122 | −0/+24 | DIFF-E | region dispatcher |
| 41 | `gap1_checker/global_axial_c1b_kernel.py` | 9 | 1802–1808 | 2289–2297 | −1/+3 | DIFF-K | preflight banner |
| 42 | `gap1_checker/global_axial_c1b_kernel.py` | 10 | 1824–1829 | 2313–2319 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 43 | `gap1_checker/global_axial_c1b_kernel.py` | 11 | 1832–1835 | 2322–2328 | −0/+3 | DIFF-K | preflight controls |
| 44 | `gap1_checker/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 45 | `gap1_checker/global_axial_c1b_gating.py` | 2 | 142–147 | 142–384 | −0/+237 | DIFF-E | ledger/overlap/union helpers |
| 46 | `gap1_checker/global_axial_c1b_gating.py` | 3 | 312–318 | 549–555 | −1/+1 | DIFF-E | replay schema label |
| 47 | `gap1_checker/global_axial_c1b_gating.py` | 4 | 320–325 | 557–581 | −0/+19 | DIFF-A | checker plan-order audit |
| 48 | `gap1_checker/global_axial_c1b_gating.py` | 5 | 343–355 | 599–620 | −1/+10 | DIFF-E | checker L/X field verification; checker resume re-classifies a terminal cap stop |
| 49 | `gap1_checker/global_axial_c1b_gating.py` | 6 | 364–372 | 629–637 | −2/+2 | DIFF-E | resume previous_root for L/X |
| 50 | `gap1_checker/global_axial_c1b_gating.py` | 7 | 389–400 | 654–665 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 51 | `gap1_checker/global_axial_c1b_gating.py` | 8 | 402–407 | 667–707 | −0/+35 | DIFF-K | U1 header metadata block |
| 52 | `gap1_checker/global_axial_c1b_gating.py` | 9 | 412–418 | 712–719 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 53 | `gap1_checker/global_axial_c1b_gating.py` | 10 | 427–433 | 728–734 | −1/+1 | DIFF-K | header coarse cap |
| 54 | `gap1_checker/global_axial_c1b_gating.py` | 11 | 467–472 | 768–774 | −0/+1 | DIFF-A | checker plan-order audit call |
| 55 | `gap1_checker/global_axial_c1b_gating.py` | 12 | 479–485 | 781–787 | −1/+1 | DIFF-E | checker replay_state call (kernel) |
| 56 | `gap1_checker/global_axial_c1b_gating.py` | 13 | 487–494 | 789–796 | −2/+2 | DIFF-E | checker replay_state recall (kernel); checker resume cap test moved |
| 57 | `gap1_checker/global_axial_c1b_gating.py` | 14 | 498–503 | 800–806 | −0/+1 | DIFF-E | stop-field holder |
| 58 | `gap1_checker/global_axial_c1b_gating.py` | 15 | 507–513 | 810–827 | −1/+12 | DIFF-E | checker cap stop after its record; checker segment_end stop fields; resume cap test recorded as RESOURCE_CAP |
| 59 | `gap1_checker/global_axial_c1b_gating.py` | 16 | 520–527 | 834–843 | −2/+4 | DIFF-E | checker MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 60 | `gap1_checker/global_axial_c1b_gating.py` | 17 | 532–559 | 848–890 | −13/+28 | DIFF-E | checker dispatch + record + field checks; checker root-count outcome per region (F2) + cap classification (F3) |
| 61 | `gap1_checker/global_axial_c1b_gating.py` | 18 | 563–581 | 894–918 | −6/+12 | DIFF-E | checker cap stop after its record; checker exact union + overlap; checker segment end overlap record; checker segment_end stop fields; overlap failure after segment end |
| 62 | `gap1_checker/global_axial_c1b_checker.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
