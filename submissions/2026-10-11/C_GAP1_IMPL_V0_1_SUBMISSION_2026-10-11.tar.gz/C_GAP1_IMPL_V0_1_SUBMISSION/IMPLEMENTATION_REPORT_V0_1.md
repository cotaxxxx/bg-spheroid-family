# IMPLEMENTATION_REPORT_V0_1 — C 空白① 実装 v0.1（Code、2026-10-11）

## 0. 位置づけと立場

- **拘束文書：** Code 宛指示書 v0.1 `drafts/2026-10-11/CODE_INSTRUCTION_C_GAP1_IMPL_V0_1_2026-10-11.md`。bg-spheroid-family main `d9457b2a52158aa8b6688646a83a41f2a006f86d`（親 `e34f6a09`、STATE v1.21）から直接読み、SHA-256 が `f8f436f37e4e43f7206b3970236b6d56e24422db4be73deee28a428b2de29bed` で一致することを確認した。
- **根拠：** 実装指示書 v2（`48204988`）、発出メモ（`51a167c7`）、chat 差分監査 §7 の Judge 裁定（`audits/CHAT_DIFF_AUDIT_C_GAP1_IMPL_V0_2026-10-11.md`、SHA-256 `bbba3f04…71d8`）。ChatGPT の監査（relay）は、F1–F3 の内容を理解するために読んだ。
- **出発点：** v0 提出物（`d4ddd33d…56d6e8`）の新しい7本。v0.1 は、v0 の生成スクリプトを拡張したものを baseline に当てて作った（v0 の edit に v0.1 の edit を加えた。§5）。
- **Code の立場：** 実装者であり、監査者ではない。静的 control と提出前の自己点検は自己確認にすぎない。差分監査は ChatGPT と chat が互いの記録を見ずに行う。
- **やっていないこと：**
  - 数値の実行
  - producer、checker、driver、スタブ control の実行
  - g_box、gt_box、interval kernel の呼び出し
  - 証明書や receipt の生成
  - commit、push、既存ファイルの変更、FREEZE
- **リポジトリに対して行った読み取り：** `git fetch origin main`（bg-spheroid-family のリモート追跡 ref が更新される）、`git show`、`git cat-file`。作業ツリーは変えていない。

## 1. 環境と作業前後の状態

| 項目 | 値 |
|---|---|
| 作業場所 | Code のクラウドコンテナ内の scratchpad（`gap1_v01/`） |
| Python | 3.11.15。生成スクリプトと静的 control だけに使った（`-I`） |
| baseline | bg-oblate-spheroid `85eca2288732a3cac65f4d5f87ecfd2ba5ce2e9b`（7本と import 17本は blob で一致。control 1） |
| 提出時点の状態 | bg-oblate-spheroid（HEAD `99467ed5`）、bg-spheroid-family（ローカル HEAD `d707e6ef`）、basepoint-geometry のどれも、`git status --short --untracked-files=all` が空 |

## 2. authority の SHA-256（コード中の `GAP1_AUTHORITY_SHA256`。control 1 で照合）

v0 の9件に、【v0.1】の2件を加えた。

| 文書 | SHA-256 |
|---|---|
| `C_GAP1_CONTRACT_DRAFT_V7.md` | a49148180fdeb33272e7358028caa55ec1dc06e5d4f526cd23eca50ff65c2a37 |
| `C_GAP1_IMPLEMENTATION_DESIGN_DRAFT_V2.md` | 0a407d1bec2d491befc2bdaee7dbfff29b3f93bf54f3aef466093dd9453038d1 |
| `C_GAP_ENDPOINT_ADDENDUM_DRAFT_V2.md` | 7471800d81caabdbbe3bfb5c8dc2e020434adbd0a67ed4e6bbd38afbea33d3a4 |
| `C_GAP_NUMERIC_CONTRACT_DRAFT_V1.md` | be67046f8bb2d6cb5b3c0e615ee7edb1338d91956f6eb1aa2701217c05600d07 |
| `G0_E1_UNIFORM_GT_PAPER_PROOF_DRAFT_V3.md` | 8bf8f5d87cfc2e6f424499804b0fd85d982cf480deb99a26c284367960578671 |
| `CHAT_RECORD_V7_CLARIFICATIONS_2026-10-11.md` | 541f3025728e027467433d2ff05ef12299b7cc2c6488fbe8bf2febe73fcf4d7c |
| `CHAT_RECORD_GAP1_IMPORT_CLOSURE_17_2026-10-11.md` | b48887c194b153ebbb12a652fc797ed79724e7212215b2471a780769564144d4 |
| `C_GAP1_CODE_IMPLEMENTATION_INSTRUCTION_DRAFT_V2_2026-10-11.md` | 48204988953911195a00789536956657556984cea1067486120e70e610cb9e6f |
| `ISSUE_NOTE_C_GAP1_IMPLEMENTATION_INSTRUCTION_V2_2026-10-11.md` | 51a167c7d37c244195df7d2f55a0d761f60593010ec22dba4f649eb7bdcbac5b |
| 【v0.1】`CODE_INSTRUCTION_C_GAP1_IMPL_V0_1_2026-10-11.md` | f8f436f37e4e43f7206b3970236b6d56e24422db4be73deee28a428b2de29bed |
| 【v0.1】`CHAT_DIFF_AUDIT_C_GAP1_IMPL_V0_2026-10-11.md` | bbba3f04b3ee87e561ab60d38a86f46d03ce9a5b7260982ec648626a99b271d8 |

## 3. pin の表（baseline → v0 → v0.1）

| path | baseline blob | v0 blob | v0.1 SHA-256 | v0.1 blob | 行数 |
|---|---|---|---|---|---|
| `gap1_producer/global_axial_c1b_kernel.py` | 67dda838… | a9c214d0… | 89b275a657a22a3d3880201c862b5b8bfcb9e002a4411d4e30837368f17dba99 | d341ee1214393c20dd551ce0fac2deacadabe563 | 2336 |
| `gap1_producer/global_axial_c1b_gating.py` | a93ca173… | 234c314f… | cbce2c782e949c2ee07ce79662f0c339afc6e241f01313510e2519382331345e | 3009cf03f8840eda99957b463fe70016d35f0b78 | 930 |
| `gap1_producer/global_axial_c1b_producer.py` | 0616fbd7… | 34ef3758… | 952caa157e8017cf519a28fce1109f52bab37666442038d3eb3aa1949db83da7（v0 と同一） | 34ef3758382de5993116c49d511b5b68e4e87bfa | 6 |
| `gap1_analysis/c1b_resumable_driver.py` | 5fd308bb… | 42c71f2b… | 753bc2477086543d4d69be71284d756416eb8e7c48e69bb35ca43e7af13dad9a | f9a8e993dfd5ab122c036e8c08dd57df1aeff055 | 391 |
| `gap1_checker/global_axial_c1b_kernel.py` | 4eaca55d… | 9bb9912c… | dcf2dc0af80d88ad1f862745f16b00faabdd9d786a197ca7ecfb7b629739513e | 8dc5fb3c261e8865d0c84401daaf04591674a097 | 2328 |
| `gap1_checker/global_axial_c1b_gating.py` | 03df2620… | 90e09c96… | 193a749f7baa686b0400e1fdb900f77527f2a9dab4ce8444b729ffa37ac0bc8c | 1e4e8ee5acbd84cfabac9c50223461b9e60e7ce7 | 934 |
| `gap1_checker/global_axial_c1b_checker.py` | 0760764e… | 5b526ddc… | 705c86eb853aa29bc127e43a06e45813995eea6315b2227a1536e2c38470245e（v0 と同一） | 5b526ddc4f48dc01d3f95eafb44f3d638e2e35ed | 6 |

- 7本とも AST の parse と compile-only を通る。
- baseline から `build/build_gap1.py` で作り直すと、byte 一致で再現する。
- import 17本と、読むだけの compare.py（`33cdd329`）は、変更していない。blob は control 1 と 14 で照合した。

## 4. 直したこと（指示書 v0.1 §2）

### F1（DIFF-B）：X の負値ブロックは直接の g_box だけ

- 新しい関数は3つ（両 kernel に同じテキスト）。
  - `x_negative_seed`：[5/8,31/32] の 24 t-box × 8 λ-box を作る。
  - `x_negative_eval`：各箱で `g_box` を一度だけ評価し、有限かつ upper<0 なら閉じる。
  - `x_negative_cover`：E0/E1/E2 = 1024/2048/4096 の panel。閉じない箱は 2×2 に分割する。live な終端の箱が E_BOX_CAP=4096 を超えたら打ち切る。
- E2 の後も閉じない箱が残る場合と、上限を超える場合は、どちらも `X_NEGATIVE` で、`CERTIFICATE_INCONCLUSIVE/X_NEGATIVE_INCONCLUSIVE` になる。mono 閉包への切替はない。
- `attempt_x` は `exterior_cover` の代わりに `x_negative_cover` を呼ぶ。
- baseline の `exterior_cover`、`eval_exterior`、`mono_closure_box` は byte 一致のまま（control 4）。
- X から mono／exterior に到達できないことは、静的には control 11、実行時にはスタブ control `X_NO_MONO_CLOSURE_FAIL`（mono／exterior を例外を投げるスタブに差し替えて走らせる。まだ実行していない）で確かめる。
- L は baseline の `exterior_cover(slab, 1/2, 1/2)`（mono 閉包と MONO_WORK_CAP あり）のまま。

### F2（DIFF-E/K）：X の根の数の label

- `ROOT_FREE_REGION` は L だけ。X は `ROOT_COUNT_BY_C1A_SIGN_NO_T_STAR`。
- ledger の `result.gap1.root_count` に、label、certified、accepted、root_count、規則の全文を書く。X では、C1a の blob と符号、gate D、`t_star_constructed=false`、`lambda_x_approximation_used=false` も書く。
- X の root_count は常に null。各 λ の根の数（0、または (1/2,5/8) の単純根1個）は g(1/2,λ) の符号で決まり、その符号は C1a と gate D で与えられる。schema §2.2 に書いた。
- λ_x の近似値で分岐する処理はない。
- checker の ACCEPT は、`checker_root_outcome` が region の label に一致することを要求する。v0 の「L/X なら無条件に `ROOT_FREE_REGION`」は無くなった。

### F3（DIFF-E）：資源上限で止まったことを機械で読める形で残す

- 共通の helper は次の5つで、両 gating に同じテキストで置いた（control 13）。
  - `gap1_cap_exceeded`：`GAP1_RESOURCE_CAPS` の順に「値 > 上限」を判定する。
  - `gap1_cap_stop`：cap 停止の segment_end の項目を作る。
  - `gap1_mark_decision`：record が終端になった理由を書く。
  - `gap1_terminal_abort`：resume と replay で分類を計算し直して照合する。
  - `_gap1_attempt_reason`：試行そのものの理由を取り出す。
- 何を記録するかの詳細は schema §2.3 にある。

### Q10/Q11（DIFF-E/K）

- driver の照合対象に `analysis/c1b_cross_lineage_compare.py` を加えた（25本）。
- kernel には `GAP1_READ_ONLY_PINS` を置き、preflight で v211 の control より前に blob を照合する。

### Q15（DIFF-K）

- `gap1_stub_controls` に11件を書いた（OPEN_QUESTIONS §A）。preflight から呼ばれる。
- **実行はしていない。**

### そのまま受理されたもの

Q2、Q4、Q5、Q6 は v0 のまま。Q1（pin manifest）は実行準備の段階に延期。

## 5. 差分の構成

- edit は 74（v0 は 57）、hunk は 62。分類は K 22、A 5、B 2、C 2、D 2、E 29。
- DIFF-A、C、D の hunk の中身は v0 と同じ。
- v0 → v0.1 の差分は `diffs_v0_to_v0_1/` にあり、STATIC_CONTROL_REPORT §5 に表がある。

## 6. F3 の分類表（コードを読んで導いたもの。実行による確認ではない）

**producer**

| 状況 | decision | 記録される分類 | resume／replay での再計算 |
|---|---|---|---|
| 試行が PASS で、cap なし | ACCEPT | — | ABORT の record は無いので、前処理は何もしない |
| 試行が不成立、depth<3、global 内 | REFINE | 試行の分類 | 同上 |
| 試行の work を加えて global を超えた（成否は問わない） | ABORT | RESOURCE_CAP／GLOBAL_ATTEMPT_WORK_CEILING | `cumulative_work_after` が上限を超える → 同じ |
| PASS で受け入れた後に件数が上限を超えた | ABORT | RESOURCE_CAP／MAX_ACCEPTED | record の `accepted_count`（加算済み）から → 同じ |
| PASS で受け入れた後に accepted work が上限を超えた | ABORT | RESOURCE_CAP／ACCEPTED_WORK_CEILING | record の `accepted_work` から → 同じ |
| 不成立、depth=3、cap なし | ABORT | MAX_DEPTH_EXHAUSTED、分類は試行のもの | depth と attempt_reason から → 同じ |
| 次の試行で attempted が MAX を超える | （record なし） | segment_end に RESOURCE_CAP／MAX_ATTEMPTED | resume しても attempted は同じなので、ループの最初で同じ判定になる |

**checker**

- plan の ACCEPT と REFINE については、checker 自身の cap を判定し、cap を超えた場合は producer と同じ形で記録する。
- plan の ABORT は schema §2.3 の5通りで分類する。
- どちらの系統でも、`reason=PASS` と ABORT が同じ record に並ぶ場合は無い。並びそうになる組は `CONTRACT_MISMATCH:*` で止めるか、checker では `CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED` を記録する。

この表を実行して確かめる非数値の単体テストの案は、OPEN_QUESTIONS §C にある（実行していない）。

## 7. 提出前の自己点検

- Code は、自分とは別のサブエージェントを起動し、読むだけの静的レビューを1回行った。import も実行もしていない。これは監査ではない。
- 確かな誤り2件（checker の plan ABORT での PASS/ABORT の組、R の certified）と、軽い指摘6件があった。
- 誤り2件と、軽い指摘のうち2件（MAX_ATTEMPTED の判定経路、スタブの no-mono 判定）を直した（schema §2.5）。
- 残りの4件は OPEN_QUESTIONS の B9–B12 に回した：segment_end の前に落ちた場合、checker の停止、checker で cap を先に判定する順序、X の trace。
- その後 Code が読み直して、checker の `root_count.accepted` の誤りも直した。

## 8. 提出物の一覧（tar.gz の中身。全ファイルを `MANIFEST.sha256` に載せた）

| path | 内容（指示書 v0.1 §3） |
|---|---|
| `IMPLEMENTATION_REPORT_V0_1.md` | この報告 |
| `new_files/gap1_*/*.py` | v0.1 の新しい7本 |
| `diffs_baseline_to_v0_1/` | baseline → v0.1 の全文 diff。各 `@@` に DIFF の分類 |
| `diffs_v0_to_v0_1/` | v0 → v0.1 の diff |
| `STATIC_CONTROL_REPORT_V0_1.md` | control 0–15、コマンド、途中の FAIL、hunk の分類表 |
| `static_controls/` | static_controls.py、hunk_classify.py、pairs.json、出力（最終版と run1）、実行前に記録した SHA、hunk_table.tsv/.md、authority_sha256.txt |
| `build/` | build_gap1.py、make_diffs.py、build_log.txt（EDITS 74）、gap1_edit_log.json |
| `LEDGER_AND_REPLAY_SCHEMA_V0_1.md` | 更新した schema |
| `OPEN_QUESTIONS_V0_1.md` | 更新した OPEN_QUESTIONS |

## 9. 最終行

IMPLEMENTATION_READY_FOR_CHAT_DIFF_AUDIT
