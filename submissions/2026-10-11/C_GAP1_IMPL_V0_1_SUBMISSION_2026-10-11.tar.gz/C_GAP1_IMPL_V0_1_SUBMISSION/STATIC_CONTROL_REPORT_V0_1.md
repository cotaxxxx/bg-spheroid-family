# STATIC_CONTROL_REPORT_V0_1 — C 空白① 実装 v0.1（Code、2026-10-11）

これは実装指示書 v0.1（`f8f436f3`）に対する静的 control の結果である。v0 の control 0–10 をそのまま走らせ、v0.1 で直した点を確かめる control 11–15 を加えた。

どの control も次のものだけを使う。
- ソースの文字列
- SHA-256 と git blob
- AST と symtable
- リテラル定数の厳密な Fraction 計算

リポジトリのモジュールは import も実行もしていない。g_box、gt_box、interval kernel、producer、checker、driver、スタブ control のどれも呼んでいない。

## 0. 総括

`SUMMARY C0=PASS C1=PASS C2=PASS C3=PASS C4=PASS C5=PASS C6=PASS C7=PASS C8=PASS C9=PASS C10=PASS C11=PASS C12=PASS C13=PASS C14=PASS C15=PASS`

最終版では FAIL は0件である。NOT_VERIFIED の項目は、OPEN_QUESTIONS_V0_1 §C に移した。

## 1. 実行したコマンド（作業領域は Code の scratchpad。リポジトリには書いていない）

```
# 入力：baseline（bg-oblate-spheroid 85eca228 の producer/ checker/ analysis/ を git archive したもの）= tree/
#       v0 の新しい7本（v0 提出物 d4ddd33d の new_files/）= v0/
#       拘束文書（bg-spheroid-family d9457b2a から git show）= authority/
cp -r tree out
python3 -I build/build_gap1.py tree out > build/build_log.txt                       # 末尾 "EDITS 74"
python3 -I static_controls/hunk_classify.py out "$(cat static_controls/pairs.json)" out/gap1_edit_log.json > static_controls/hunk_table.tsv
python3 -I static_controls/static_controls.py out authority static_controls/hunk_table.tsv > static_controls/static_controls.stdout
python3 -I build/make_diffs.py out v0 static_controls/pairs.json static_controls/hunk_table.tsv out/gap1_edit_log.json .
python3 -I -c "import sys; [compile(open(p).read(), p, 'exec', dont_inherit=True) for p in sys.argv[1:]]" out/gap1_*/*.py   # compile-only
```

**再現性：** 提出の直前に、空のディレクトリで baseline から作り直した。build_log、edit log、7本、hunk_table.tsv、static_controls.stdout は、すべて byte 一致した。

**最終版のスクリプト**（`static_scripts_sha256_pre_run.txt` の `final_pre_run_4` の行。各実行の直前に SHA を記録した）

| script | SHA-256 |
|---|---|
| `build/build_gap1.py` | dd4e3cbf314a311a17a8660d6c2c660982c4611cd7a00c2488850670b773d1ec |
| `build/make_diffs.py` | 9cb026546e9fda55e68cb5e33751856793f5b531ead4d38e69d41c893665374b |
| `static_controls/hunk_classify.py` | de82a47c39fd489acbaf1a1ec6031baa639743a243988de6151f71c8e119f7d4（v0 と同一） |
| `static_controls/static_controls.py` | 09292ab812c23616eeeb13c4b7234a2fd80aadce96ed3e7bc705d4a8a6656856 |

`static_scripts_sha256_pre_run.txt` には、途中の版の SHA も実行順に全部残してある（§3）。

## 2. control ごとの結果（最終版）

| # | 内容 | 判定 | 根拠（static_controls.stdout） |
|---|---|---|---|
| 0 | 新しい7本に未解決のグローバル名がない | PASS | 0件（途中の版で1件見つけて直した。§3） |
| 1 | pin：baseline 7本、import 15本と追加2本、コード中の authority SHA（【v0.1】11件。指示書 v0.1 `f8f436f3` と chat 差分監査 `bbba3f04` を追加）が実測値と一致 | PASS | 7/7、15/15、2/2、authority 11件×2系統が一致 |
| 2 | 新規は7本、`__init__.py` は0本、baseline は無変更 | PASS | 両リポジトリとも作業ツリーの `git status` が空 |
| 3 | どの hunk も DIFF 分類一つだけに対応する | PASS | 62 hunk、未分類と混在は0。K 22、A 5、B 2、C 2、D 2、E 29 |
| 4 | 保護対象の関数と定数が byte 一致 | PASS | g_box、gt_box、密度、P1/P2、choose_predictor、根の局在化、tube、**exterior_cover、eval_exterior、mono_closure_box**、attempt／attempt_replay、および定数。変わった baseline 関数は v0 と同じ集合（下記） |
| 5 | L/X から predictor と根の関数に到達できない | PASS | 両系統 |
| 6 | R の順序規則 | PASS | v0 と同じ |
| 7 | endpoint gate の構造 | PASS | v0 と同じ（DIFF-D は v0 から無変更） |
| 8 | region の格子、owner、overlap | PASS | v0 と同じ |
| 9 | 系統の分離と import | PASS（実行時の解決は NOT_VERIFIED） | checker は producer 系を import しない |
| 10 | 数値契約の定数 | PASS | v0 と同じ |
| **11** | 【F1】X は直接の g_box だけ | PASS | 両系統で、`attempt_x`、`x_lower_tube`、`x_negative_cover`、`x_negative_eval`、`x_negative_seed` から次のいずれにも到達しない：`mono_closure_box`、`_mono_*`、`eval_exterior`、`exterior_cover`、`exterior_seed`、`_e0_counts`、predictor／根の関数。`x_negative_eval` が呼ぶ数値 kernel は `g_box` だけ（`gt_box` なし）。箱が閉じる条件は「有限かつ upper<0」。E0 は [5/8,31/32] の 24×8、ladder は E_STAGES（1024/2048/4096）、E_BOX_CAP の判定は2か所（AST の名前で数えた）。L は baseline の exterior（mono あり）のまま |
| **12** | 【F2】X の根の数の label | PASS | `GAP1_ROOT_COUNT_LABELS` は L=`ROOT_FREE_REGION`、X=`ROOT_COUNT_BY_C1A_SIGN_NO_T_STAR`、R=`RESOLVED_WITH_CERTIFIED_T_STAR`。X の規則の文字列は、g(1/2,λ)≤0 と >0 の場合分け、C1a、gate D、T_* なし、λ_x 近似なしを含む。gating のコード中に `ROOT_FREE_REGION` のリテラルは0件。label は `attempt_reason=PASS` のときだけ出る。checker の ACCEPT は region の label との一致を要求する |
| **13** | 【F3】RESOURCE_CAP の分類 | PASS | 両 gating で、record を残さない旧来の cap 終了（`MAX_ATTEMPTED_SLABS_EXCEEDED`、`GLOBAL_ATTEMPT_WORK_CEILING_EXCEEDED`、`CHECKER_ACCEPTED_CEILING_EXCEEDED`）は0件。`check_ceiling` の呼び出しも無い。`gap1_mark_decision` は slab_record の前にある。segment_end は `RESOURCE_CAP` と cap 名を持つ。MAX_ATTEMPTED は `attempted + 1` で判定する。resume と replay の配線もある（producer は `gap1_terminal_abort(…,"decision")`、checker は `(…,"checker_decision")` と plan ABORT の分類）。PASS と ABORT の組が出ない。分類の helper 8関数は両系統で同一テキスト。cap は `GAP1_RESOURCE_CAPS` の順に判定する |
| **14** | 【Q10/Q11】読むだけの pin | PASS | driver の `REQUIRED_C1B_BLOB_PATHS` は重複なしの25本で、compare.py を含む。compare.py の baseline での実測 blob は `33cdd3290bfa09c88cd8936e1f4557af491f0bc2` で、`GAP1_READ_ONLY_PINS` と一致する。`gap1_read_only_pin_check()` は preflight で `v211_preflight_controls()` より前にある |
| **15** | 【Q15】スタブ control（書いただけ） | PASS | 両系統に11件の label がある。`finally` で g_box、gt_box、mono_closure_box、eval_exterior、exterior_cover を元に戻す。端点の2件（`g_const(arb(-1))`×`gt_const(arb(1))` で `-31/32 ≤ upper < 0`、`g_const(arb(-1) / 64)` で `upper ≥ 1/64` かつ `ENDPOINT_CUMULATIVE_MVT_INCONCLUSIVE`）がある。preflight から呼ばれる。X のテスト中は mono／exterior を、例外を投げるスタブに差し替える。**実行はしていない** |

**control 4 で変わった baseline 関数**（v0 と同じ集合。どれも allowlist 内）

| ファイル | 関数 |
|---|---|
| producer kernel | `coarse_ledger`（A）、`preflight`（K） |
| producer gating | `replay`（A/E）、`estimates`（K）、`header_payload`（K）、`run_full`（A/E） |
| checker kernel | `preflight`（K） |
| checker gating | `replay_state`（E）、`estimates`（K）、`header_payload`（K）、`run_full`（A/E） |

## 3. 途中の FAIL と修正（記録）

1. **control 0 の FAIL（実装の誤り）。** v0.1 の最初の生成で、`UNDEFINED_GLOBAL gap1_checker/global_axial_c1b_gating.py replay_state kernel` が出た。checker の `replay_state(records, plan)` には `kernel` の引数が無いのに、新しく足した前処理が `kernel` を使っていた。→ `replay_state(records, plan, kernel)` に変え、呼び出し2か所も直した（DIFF-E）。control 0 がこの誤りを捕まえた。
2. **control 11 の FAIL（control の誤り）。** `static_controls_run1.stdout` が、その時の出力をそのまま残したもの。E_BOX_CAP の出現回数をソースの文字列で数えていたため、コメント中の語まで数えて3回になった。→ AST の名前だけで数えるように変えた。実装は変えていない。
   - この run1 は、§4 の自己点検で直す前の build に対する出力である。最終版の build に対する出力は `static_controls.stdout`。
3. **提出前の自己点検（Code が起動した、読むだけのサブエージェントによる静的レビュー。監査ではない）で見つかった実装の誤り**と、その修正。
   - checker が producer の cap 停止の slab（plan では ABORT）を、`reason=PASS` と `decision=ABORT` の組で記録していた。
   - R の `root_count.certified` が、試行の成否を見ていなかった。
   - MAX_ATTEMPTED が共通の cap 関数を通っていなかった。
   - スタブの no-mono 判定が、常に真になる形だった。
   - 修正の内容は LEDGER_AND_REPLAY_SCHEMA_V0_1 §2.5 にある。修正に合わせて control 12、13、15 を強めた。
4. checker の `root_count.accepted` が、checker 自身の `REPLAYED` を渡していたため、受け入れた slab でも false になる誤りを、Code が読み直して見つけて直した。
5. authority の pin に、指示書 v0.1 と chat 差分監査（Judge 裁定 §7 を含む）を追加した。

## 4. hunk ごとの表（baseline → v0.1、control 3 と 4）

分類の列は `hunk_classify.py` が出したもので、これが正である。edit の label の列は、`make_diffs.py` が、hunk の行と全行一致する edit の新しい行から推定した参考の値である。行が同じ文字列の edit（producer の live と resume の right-child-first など）は、両方の label が並ぶことがある。各 diff の `@@` 行にも同じ分類を書いた。

| # | new file | hunk | baseline lines | new lines | −/+ lines | category | edit label(s) |
|---|---|---|---|---|---|---|---|
| 1 | `gap1_producer/global_axial_c1b_kernel.py` | 1 | 29–35 | 29–35 | −1/+1 | DIFF-K | caps |
| 2 | `gap1_producer/global_axial_c1b_kernel.py` | 2 | 49–56 | 49–56 | −2/+2 | DIFF-K | work ceilings |
| 3 | `gap1_producer/global_axial_c1b_kernel.py` | 3 | 59–64 | 59–181 | −0/+117 | DIFF-K | constants/domain |
| 4 | `gap1_producer/global_axial_c1b_kernel.py` | 4 | 84–94 | 201–209 | −5/+3 | DIFF-A | descending queue |
| 5 | `gap1_producer/global_axial_c1b_kernel.py` | 5 | 883–888 | 998–1141 | −0/+138 | DIFF-K | U1 controls |
| 6 | `gap1_producer/global_axial_c1b_kernel.py` | 6 | 1206–1211 | 1459–1573 | −0/+109 | DIFF-B | X fixed path |
| 7 | `gap1_producer/global_axial_c1b_kernel.py` | 7 | 1426–1431 | 1788–1879 | −0/+86 | DIFF-D | endpoint gate |
| 8 | `gap1_producer/global_axial_c1b_kernel.py` | 8 | 1586–1591 | 2034–2052 | −0/+13 | DIFF-C | L negative path |
| 9 | `gap1_producer/global_axial_c1b_kernel.py` | 9 | 1644–1649 | 2105–2131 | −0/+21 | DIFF-E | region dispatcher |
| 10 | `gap1_producer/global_axial_c1b_kernel.py` | 10 | 1814–1820 | 2296–2304 | −1/+3 | DIFF-K | preflight banner |
| 11 | `gap1_producer/global_axial_c1b_kernel.py` | 11 | 1837–1842 | 2321–2327 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 12 | `gap1_producer/global_axial_c1b_kernel.py` | 12 | 1845–1848 | 2330–2336 | −0/+3 | DIFF-K | preflight controls |
| 13 | `gap1_producer/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 14 | `gap1_producer/global_axial_c1b_gating.py` | 2 | 142–147 | 142–384 | −0/+237 | DIFF-E | ledger/overlap/union helpers |
| 15 | `gap1_producer/global_axial_c1b_gating.py` | 3 | 317–322 | 554–560 | −0/+1 | DIFF-E | resume re-classifies a terminal ABORT |
| 16 | `gap1_producer/global_axial_c1b_gating.py` | 4 | 328–337 | 566–575 | −2/+2 | DIFF-A | live right-child-first; resume replay right-child-first |
| 17 | `gap1_producer/global_axial_c1b_gating.py` | 5 | 341–347 | 579–585 | −1/+1 | DIFF-E | replay schema label |
| 18 | `gap1_producer/global_axial_c1b_gating.py` | 6 | 389–400 | 627–638 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 19 | `gap1_producer/global_axial_c1b_gating.py` | 7 | 402–407 | 640–680 | −0/+35 | DIFF-K | U1 header metadata block |
| 20 | `gap1_producer/global_axial_c1b_gating.py` | 8 | 412–418 | 685–692 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 21 | `gap1_producer/global_axial_c1b_gating.py` | 9 | 427–433 | 701–707 | −1/+1 | DIFF-K | header coarse cap |
| 22 | `gap1_producer/global_axial_c1b_gating.py` | 10 | 489–497 | 763–769 | −3/+1 | DIFF-E | resume cap test moved |
| 23 | `gap1_producer/global_axial_c1b_gating.py` | 11 | 502–507 | 774–780 | −0/+1 | DIFF-E | stop-field holder |
| 24 | `gap1_producer/global_axial_c1b_gating.py` | 12 | 515–522 | 788–805 | −0/+10 | DIFF-E | resume cap test recorded as RESOURCE_CAP; segment_end stop fields |
| 25 | `gap1_producer/global_axial_c1b_gating.py` | 13 | 536–543 | 819–828 | −2/+4 | DIFF-E | MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 26 | `gap1_producer/global_axial_c1b_gating.py` | 14 | 550–558 | 835–843 | −2/+2 | DIFF-E | dispatch + record |
| 27 | `gap1_producer/global_axial_c1b_gating.py` | 15 | 575–580 | 860–867 | −0/+2 | DIFF-E | terminal decision classification (F3) |
| 28 | `gap1_producer/global_axial_c1b_gating.py` | 16 | 592–598 | 879–885 | −1/+1 | DIFF-A | live right-child-first; resume replay right-child-first |
| 29 | `gap1_producer/global_axial_c1b_gating.py` | 17 | 601–619 | 888–904 | −7/+5 | DIFF-E | exact union + overlap; segment end overlap record |
| 30 | `gap1_producer/global_axial_c1b_gating.py` | 18 | 622–627 | 907–914 | −0/+2 | DIFF-E | overlap failure after segment end |
| 31 | `gap1_producer/global_axial_c1b_producer.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
| 32 | `gap1_analysis/c1b_resumable_driver.py` | 1 | 18–34 | 18–52 | −9/+27 | DIFF-E | pin manifest path / chain label; pinned blob paths (7 new + 17 closure + 1 read-only) |
| 33 | `gap1_checker/global_axial_c1b_kernel.py` | 1 | 30–36 | 30–36 | −1/+1 | DIFF-K | caps |
| 34 | `gap1_checker/global_axial_c1b_kernel.py` | 2 | 50–57 | 50–57 | −2/+2 | DIFF-K | work ceilings |
| 35 | `gap1_checker/global_axial_c1b_kernel.py` | 3 | 60–65 | 60–182 | −0/+117 | DIFF-K | constants/domain |
| 36 | `gap1_checker/global_axial_c1b_kernel.py` | 4 | 876–881 | 993–1136 | −0/+138 | DIFF-K | U1 controls |
| 37 | `gap1_checker/global_axial_c1b_kernel.py` | 5 | 1183–1188 | 1438–1552 | −0/+109 | DIFF-B | X fixed path |
| 38 | `gap1_checker/global_axial_c1b_kernel.py` | 6 | 1403–1408 | 1767–1858 | −0/+86 | DIFF-D | endpoint gate |
| 39 | `gap1_checker/global_axial_c1b_kernel.py` | 7 | 1563–1568 | 2013–2031 | −0/+13 | DIFF-C | L negative path |
| 40 | `gap1_checker/global_axial_c1b_kernel.py` | 8 | 1630–1635 | 2093–2122 | −0/+24 | DIFF-E | region dispatcher |
| 41 | `gap1_checker/global_axial_c1b_kernel.py` | 9 | 1802–1808 | 2289–2297 | −1/+3 | DIFF-K | preflight banner |
| 42 | `gap1_checker/global_axial_c1b_kernel.py` | 10 | 1824–1829 | 2313–2319 | −0/+1 | DIFF-K | read-only pin check before v211 |
| 43 | `gap1_checker/global_axial_c1b_kernel.py` | 11 | 1832–1835 | 2322–2328 | −0/+3 | DIFF-K | preflight controls |
| 44 | `gap1_checker/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 45 | `gap1_checker/global_axial_c1b_gating.py` | 2 | 142–147 | 142–384 | −0/+237 | DIFF-E | ledger/overlap/union helpers |
| 46 | `gap1_checker/global_axial_c1b_gating.py` | 3 | 312–318 | 549–555 | −1/+1 | DIFF-E | replay schema label |
| 47 | `gap1_checker/global_axial_c1b_gating.py` | 4 | 320–325 | 557–581 | −0/+19 | DIFF-A | checker plan-order audit |
| 48 | `gap1_checker/global_axial_c1b_gating.py` | 5 | 343–355 | 599–620 | −1/+10 | DIFF-E | checker L/X field verification; checker resume re-classifies a terminal cap stop |
| 49 | `gap1_checker/global_axial_c1b_gating.py` | 6 | 364–372 | 629–637 | −2/+2 | DIFF-E | resume previous_root for L/X |
| 50 | `gap1_checker/global_axial_c1b_gating.py` | 7 | 389–400 | 654–665 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 51 | `gap1_checker/global_axial_c1b_gating.py` | 8 | 402–407 | 667–707 | −0/+35 | DIFF-K | U1 header metadata block |
| 52 | `gap1_checker/global_axial_c1b_gating.py` | 9 | 412–418 | 712–719 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 53 | `gap1_checker/global_axial_c1b_gating.py` | 10 | 427–433 | 728–734 | −1/+1 | DIFF-K | header coarse cap |
| 54 | `gap1_checker/global_axial_c1b_gating.py` | 11 | 467–472 | 768–774 | −0/+1 | DIFF-A | checker plan-order audit call |
| 55 | `gap1_checker/global_axial_c1b_gating.py` | 12 | 479–485 | 781–787 | −1/+1 | DIFF-E | checker replay_state call (kernel) |
| 56 | `gap1_checker/global_axial_c1b_gating.py` | 13 | 487–494 | 789–796 | −2/+2 | DIFF-E | checker replay_state recall (kernel); checker resume cap test moved |
| 57 | `gap1_checker/global_axial_c1b_gating.py` | 14 | 498–503 | 800–806 | −0/+1 | DIFF-E | stop-field holder |
| 58 | `gap1_checker/global_axial_c1b_gating.py` | 15 | 507–513 | 810–827 | −1/+12 | DIFF-E | checker cap stop after its record; checker segment_end stop fields; resume cap test recorded as RESOURCE_CAP |
| 59 | `gap1_checker/global_axial_c1b_gating.py` | 16 | 520–527 | 834–843 | −2/+4 | DIFF-E | checker MAX_ATTEMPTED recorded as RESOURCE_CAP |
| 60 | `gap1_checker/global_axial_c1b_gating.py` | 17 | 532–559 | 848–890 | −13/+28 | DIFF-E | checker dispatch + record + field checks; checker root-count outcome per region (F2) + cap classification (F3) |
| 61 | `gap1_checker/global_axial_c1b_gating.py` | 18 | 563–581 | 894–918 | −6/+12 | DIFF-E | checker cap stop after its record; checker exact union + overlap; checker segment end overlap record; checker segment_end stop fields; overlap failure after segment end |
| 62 | `gap1_checker/global_axial_c1b_checker.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |

## 5. v0 → v0.1 の差分（指示書 v0.1 §1）

`diffs_v0_to_v0_1/` にファイル別のものと `ALL_7_FILES_V0_TO_V0_1.diff` がある。行数は diff の −/+ である。

| ファイル | −/+ | 内容 |
|---|---|---|
| producer kernel | −8/+184 | 定数（root count の label、X の規則、cap の順、読むだけの pin、authority 2件）。X の直接だけの負値ブロック（`x_negative_seed`、`x_negative_eval`、`x_negative_cover`）。`attempt_x` の差し替え。domain control の c8。`gap1_read_only_pin_check`。`gap1_stub_controls`。preflight の呼び出し |
| checker kernel | −8/+184 | 同上（両系統の kernel の差分は同じ） |
| producer gating | −7/+144 | F2/F3 の helper。header の項目。replay の前処理。run_full の cap 記録 |
| checker gating | −19/+171 | 同上。checker の ACCEPT 規則。plan ABORT の分類。`replay_state` の kernel 引数 |
| driver | −0/+1 | compare.py を照合対象に追加 |
| 入口2本 | 0 | 変更なし |

## 6. B3：ハードコードされた path と動的 import（v0 からの追加分だけ）

| 呼び出し箇所 | 解決先 | 判定 |
|---|---|---|
| kernel の `gap1_read_only_pin_check` の `Path(__file__).parents[1] / "analysis/c1b_cross_lineage_compare.py"` | baseline の compare.py（読むだけ） | blob を `33cdd329…` と照合してから、v211 の control がそれを読む |
| driver の `REQUIRED_C1B_BLOB_PATHS` の `analysis/c1b_cross_lineage_compare.py` | 同上 | pin manifest（Q1、まだ作っていない）の `expected_blobs` に入る |

v0 のその他の項目（kernel の動的 gating import、receipt の path、`PINS_PATH` など）は変わっていない（v0 の STATIC_CONTROL_REPORT §5）。
