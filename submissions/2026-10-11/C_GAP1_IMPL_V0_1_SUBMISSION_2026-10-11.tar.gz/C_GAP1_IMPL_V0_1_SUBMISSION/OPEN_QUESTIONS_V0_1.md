# OPEN_QUESTIONS_V0_1 — C 空白① 実装 v0.1（Code、2026-10-11）

v0 の OPEN_QUESTIONS（Q1–Q15）が指示書 v0.1（`f8f436f3`）とその根拠の Judge 裁定でどう処理されたかを §A に、v0.1 の実装で新たに Judge の確認が要る点を §B に書いた。NOT_VERIFIED の項目と、後で行う数値テストの案は §C にある。テストはどれも実行していない。

## A. v0 の質問の処理状況

| v0 | 内容 | v0.1 での扱い |
|---|---|---|
| Q1 | ①専用の pin manifest（`GAP1_RESUMABLE_PINS.json`）が未作成 | **実行準備の段階に延期**（裁定）。v0.1 では作っていない。照合対象の path は25本になった（Q10/Q11） |
| Q2 | `__init__.py` を置かず、root から `python -m` で起動する | **受理**（v0 のまま） |
| Q3 | X の負値ブロックで mono 閉包が有効 | **F1 で取り消し。** X は直接の `g_box` だけで閉じる（`x_negative_cover`）。L の mono 閉包は残す |
| Q4 | R の right clamp を拒否して REFINE する | **受理**（v0 のまま） |
| Q5 | 160 slab 全体を降順、right-child-first で処理する | **受理**（v0 のまま） |
| Q6 | C1b の参照領域の定数を残し、`GAP1_*` を追加する | **受理**（v0 のまま） |
| Q7 | endpoint の16箱は常に全部評価し、例外時は panel 数を課金する | 記録のための事項。変更なし |
| Q8 | `ENDPOINT_RESOURCE_CAP` は語彙だけで、実行中には発生しない | 記録のための事項。変更なし |
| Q9 | `PRECISION_INCONCLUSIVE`／`APPROX_DEGREE_INCONCLUSIVE` は区別できない | 記録のための事項。変更なし |
| Q10 | kernel の import 閉包の self-check は baseline のまま | 共通 driver の照合対象（25本）でカバーする。kernel の self-check は変えていない |
| Q11 | compare.py が pin されていない | **済。** driver の `REQUIRED_C1B_BLOB_PATHS` に `analysis/c1b_cross_lineage_compare.py` を加えた。kernel にも `GAP1_READ_ONLY_PINS`（`33cdd329…`）を置き、v211 の control が読む前に `gap1_read_only_pin_check` で blob を照合する |
| Q12 | replay の schema ラベルを `GAP1_A1_REPLAY_V0` に変えた | 変更なし |
| Q13 | X の t=5/8 では追加の評価をしない | 変更なし（負値ブロックが直接 g になっても、閉区間が 5/8 を共有することは同じ） |
| Q14 | λ 境界の overlap の判定 | 変更なし。schema §5 に、辺での根の数と X 内部の slab の根の数の違いを書き足した |
| Q15 | 合成スタブの preflight control が無い | **済（書いただけで実行していない）。** `gap1_stub_controls` に11件。L：3件、X：3件、端点：5件。端点には指示された2件（seed=−1・U_j=+1 で PASS、seed=−1/64・U_j=+1 で FAIL）を含む |

## B. v0.1 で新たに確認してほしい事項

**B1. depth = 3 での不成立は `RESOURCE_CAP` に入れていない。**
- 指示書 v0.1 §2.3 が挙げている上限は、global work、accepted work、MAX_ACCEPTED、MAX_ATTEMPTED の4つである。`MAX_DEPTH` はここに入っていない。
- depth = 3 で試行が成立しなかった ABORT は、`abort_cause=MAX_DEPTH_EXHAUSTED` とした。`failure_class` は試行の分類（例：`CERTIFICATE_INCONCLUSIVE/X_NEGATIVE_INCONCLUSIVE`）のままである。
- これは、証明書が閉じなかったという事実を残すためである。
- depth の上限も `RESOURCE_CAP` として扱うべきかどうか、確認してほしい。

**B2. checker の slab_record の `decision` は、cap で止めた場合も plan の decision のままにした。**
- baseline では、checker の `decision` は「plan の固定 decision」を意味する（`replay_state` もそれを照合する）。
- checker 自身が cap で止めた場合は、新しい `checker_decision=ABORT` と `result.gap1.abort_cause=RESOURCE_CAP` で示し、`decision` には触っていない。
- そのため、checker が cap で止めた record では、`decision=ACCEPT` かつ `checker_decision=ABORT` という組が起こり得る（accepted の上限を、受け入れの直後に超えた場合）。読み手は `checker_decision` を見る必要がある。
- `decision` そのものを ABORT にするほうがよいか、判断してほしい。そうする場合は、`replay_state` の decision の照合も変えることになる。

**B3. resume の開始時に、すべての cap を調べるようにした。**
- baseline が resume 時に調べていたのは、attempted だけだった（record を残さず停止）。
- v0.1 では、segment_begin の後で4つの cap をすべて同じ関数で調べ、超えていれば `RESOURCE_CAP` の segment_end を書いてから停止する。
- global work が中断課金だけで上限を超えていた場合、baseline では次の試行の後で ABORT になった。v0.1 では、その試行を始める前に止まる。これは安全側の変更で、資源の使い方は少なくなる。

**B4. cap で ABORT した record の `root_count`。**
- `certified` は試行そのものの成否（`attempt_reason` が `PASS`）を表す。`accepted` は、その slab が受け入れられたかどうかを表す。
- そのため、試行は成立したが accepted の上限で ABORT した record では、`certified=true`、`accepted=false`、`decision=ABORT` となる（schema §2.2）。この二つの項目に分けた読み方でよいか確認してほしい。

**B5. depth で止まったときのプロセス終了文字列は baseline のまま。**
- cap で止まった場合の終了文字列は `RESOURCE_CAP:<cap>` である。
- depth = 3 で止まった場合は baseline の `C1B_UNRESOLVED <slab>` のまま変えていない。
- 理由は差分の都合である。その行は DIFF-A の行（REFINE の right-child-first）から3行しか離れていない。変えると、DIFF-A と DIFF-E が一つの hunk に混ざる。
- 機械で読む記録は segment_end の `abort_cause=MAX_DEPTH_EXHAUSTED` にある。

**B6. cap で止めて segment_end を書いた後は、例外で停止する。**
- producer と checker の `append_segment_end` は、stop の情報（`gap1_stop`）が `RESOURCE_CAP` のとき、segment_end を書いた後で `SystemExit("RESOURCE_CAP:<cap>")` を投げる。
- こうしたのは、呼び出し元の baseline の行（DIFF-A の行の近く）を変えずに済ませるためである。
- その結果、関数名から想像される以上のことを、この関数がしている。コメントで明示してある。

**B7. 端点、L、X のスタブ control は、本走の preflight でも毎回実行される。**
- 11件とも定数スタブなので、計算量は無視できる（最も多いものでも、スタブの呼び出しは数千回程度）。
- 終わると、`finally` で g_box と gt_box を必ず元に戻す。
- 今回は書いただけで、実行していない（v0.1 §2.5）。

**B8. `gap1_root_outcome` は producer の gating にもある。**
- 実際に呼ぶのは checker だけである。
- 判定の helper（`gap1_cap_exceeded`、`gap1_mark_decision`、`gap1_terminal_abort` など）は、両系統で同じテキストにした。静的 control 13 がそれを確かめる。
- 系統の独立性は、import していないことで保っている（control 9）。

**B9. slab_record の後、segment_end の前にプロセスが落ちた場合。**
- 例えば SIGKILL や、`append_segment_end` 内の環境照合の失敗である。この場合 ledger には、分類つきの ABORT の slab_record だけが残る。
- resume は `gap1_terminal_abort` でその分類を読み直し、`LEDGER_TERMINAL_ABORT:<分類>` で止まる。ただし、新しい segment_begin／segment_end は書かない。
- 機械で読める分類は slab_record の `result.gap1` にあるので、F3 の要件は満たしていると考える。resume 時に segment_end を補って書くかどうかは、判断してほしい。

**B10. checker は plan の ABORT の slab を記録した後で止まる。**
- baseline の checker は plan の最後まで進み、和集合の失敗として完了時の segment_end を書いていた。
- v0.1 では、plan の ABORT の slab（常に plan の最後の item）を自分の counter で分類する（schema §2.3 の表）。record と segment_end を書いた後、`RESOURCE_CAP:<cap>` または `CHECKER_TERMINAL_ABORT:<abort_cause>` で止まる。
- 和集合と overlap の照合は行わない（その run は完了しないので）。
- checker の試行が成立しているのに、checker の counter のどの cap でも説明できない場合は、`PRODUCER_PLAN_ABORT` とし、`CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED` を記録する。checker 側の判断で PASS として記録することはない。

**B11. checker で cap を、ACCEPT の再現の照合より先に判定する。**
- 試行の work を加えた直後に global の cap を超えた場合は、root outcome と `ok` の照合をせずに RESOURCE_CAP として記録する。
- この順序は baseline と同じである（baseline は global の超過をこの位置で、record を残さず止めていた）。
- 試行そのものの分類は、`attempt_failure_class` に残る。

**B12. X の負値ブロックの trace。**
- `GAP1_X_NEGATIVE_STAGE` の行は、baseline の `parse_trace` の取り込み対象外である。X の負値ブロックの非有限な値も、`C1B_NONFINITE` の行としては出力しない。
- 証明に関わる内容（各箱の guard、非有限の記録）は、`result.exterior_guards`／`exterior_nonfinite`（kind `X_DIRECT_G`）に全部残る。trace に入らないのは、stage ごとの件数と最悪の上界という要約だけである。
- `parse_trace` を広げるかどうかは、判断してほしい。

## C. NOT_VERIFIED と、後で行うテストの案（どれも実行していない）

| 項目 | 理由 | 後で行うテストの案 |
|---|---|---|
| namespace package と動的 gating import が実行時に正しく解決されること | `sys.path` に依存する | `importlib.util.find_spec` で `gap1_*` と17本の origin を出力する（非数値。許可が要る） |
| preflight 全体が PASS すること（baseline の数値 control、`c1a_preflight`、`gap1_domain_controls` の8件、`gap1_read_only_pin_check`、`gap1_stub_controls` の11件） | 数値評価を含む | 両系統で `python -m gap1_producer.global_axial_c1b_producer --ledger-only`（checker も同様）。全 control が PASS で、`GAP1_STUB_CONTROL … PASS` が11行出ることが成功条件 |
| F3 の分類の真理値表（生成時と replay 時で同じ分類になること） | 実行時の挙動。今回は静的な読解（IMPLEMENTATION_REPORT §6）と control 13 だけ | `gap1_cap_exceeded`／`gap1_mark_decision`／`gap1_terminal_abort` だけを、偽の kernel 定数（小さな上限）で呼ぶ非数値の単体テスト。次の各場合について、生成時の分類と replay 時の分類が一致すること、PASS と ABORT の組が現れないことを確かめる：producer の cap 4種、depth の消尽、ACCEPT、REFINE、checker の plan ABORT 5通り（schema §2.3 の表） |
| X が実際に mono 閉包を使わないこと | 静的な到達可能性は control 11 で PASS | スタブ control `X_NO_MONO_CLOSURE_FAIL` の実行（preflight の一部） |
| L/X/R のそれぞれで証明書が閉じるかどうか | 数値結果そのもの | 本走でしか確かめられない（Judge の実行許可が要る）。X は直接 g だけになったため、v0 より X の負値ブロックが閉じにくくなる可能性がある |
| producer と checker が同じ木を作ること | 実行時の挙動 | 本走後に checker の `GAP1_PLAN_ORDER_AUDIT PASS` を確認する |

NONE 以外の項目は以上である。
