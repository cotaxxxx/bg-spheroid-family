# LEDGER_AND_REPLAY_SCHEMA_V0_1 — C 空白① 実装 v0.1（Code、2026-10-11）

v0 の schema（`LEDGER_AND_REPLAY_SCHEMA_V0.md`）からの変更点を含む全文。指示書 v0.1（`f8f436f3`）§2 の F1–F3、Q10/Q11 に対応する箇所には【v0.1】と書いた。

record の連鎖形式は baseline と同じ（sequence、record_type、prev_sha256、payload、record_sha256 からなる canonical JSON）。chain ラベルは `GAP1_JSONL_CHAIN_V1`。record_type は baseline のまま（header、segment_begin、attempt_begin、slab_record、interrupted_attempt_charge、segment_end、lscpu_raw_trace）。

## 1. header（両系統、`header_payload`）

baseline の項目（chain_version、lineage、identity、precision_bits、degree、u_star、stages、caps、budgets、estimates、pin_manifest、phase、replay_schema）はそのまま。追加と変更は次のとおり（すべて DIFF-K）。

| key | 内容 |
|---|---|
| `lambda_domain` | `["2/5","9/20"]` |
| `caps.coarse`、`estimates.coarse_slabs` | 160（`GAP1_N_COARSE`） |
| `gap1.contract_id` | `C_GAP1_U1` |
| `gap1.authority_sha256` | v7、設計 v2、端点追補 v2、数値契約 v1、G0/E1 v3、clarifications、import 閉包記録、指示書 v2、発出メモ（全64桁） |
| `gap1.baseline_commit`、`baseline_blobs`、`import_closure_17` | `85eca228`、元の7本、17本の blob |
| `gap1.regions` | `[["L","2/5","699/1600",118],["X","699/1600","281/640",7],["R","281/640","9/20",35]]` |
| `gap1.dlambda`、`coarse`、`direction`、`refine_order` | `1/3200`、160、`decreasing`、`right_child_first` |
| `gap1.x_split_t`、`x_t_stages` | `5/8`、X-T0/X-T1/X-T2 |
| `gap1.endpoint` | partition_id、seed_t=`31/32`、dt=`1/512`、boxes=16、seed_panels=8192、gt_panels=8192 |
| `gap1.c1a` | receipt_blob `e494e789…`、signs `[["699/1600",-1],["281/640",1]]`、gate_D |
| `gap1.ownership` | 699/1600→X、281/640→R、9/20→consistency_only、t=5/8→X の負値ブロック、t=31/32→endpoint seed |
| `gap1.failure_codes`、`diff_categories_by_region` | 失敗分類語の一覧、region ごとの DIFF 分類 |
| 【v0.1】`gap1.x_negative_method` | `DIRECT_G_BOX_ONLY`（F1） |
| 【v0.1】`gap1.root_count_labels` | `{"L":"ROOT_FREE_REGION","X":"ROOT_COUNT_BY_C1A_SIGN_NO_T_STAR","R":"RESOLVED_WITH_CERTIFIED_T_STAR"}`（F2） |
| 【v0.1】`gap1.x_root_count_rule` | X の根の数の規則の全文（§2.2） |
| 【v0.1】`gap1.resource_caps_priority` | `["GLOBAL_ATTEMPT_WORK_CEILING","MAX_ACCEPTED","ACCEPTED_WORK_CEILING","MAX_ATTEMPTED"]`（F3、判定の優先順） |
| 【v0.1】`gap1.read_only_pins` | `{"analysis/c1b_cross_lineage_compare.py":"33cdd329…"}`（Q10/Q11） |

header は resume のたびに全項目を照合する（baseline の `verify_resume_header`）。v0 の ledger を v0.1 で resume することはできない（header 不一致で停止）。

## 2. slab_record の `result`（`gap1_serialize_record`、DIFF-E）

**R：** baseline の `serialize_record` の項目をそのまま残す。`predictor_mode` は producer では {continuation, relocated, null}、checker では {fixed_replay, null} に限る（それ以外は `PREDICTOR_RULE_MISMATCH`）。

**L/X：** `serialize_record(None, …)` の空の形を使い、predictor と root の項目（predictor_mode、t_c、T_star、left_clamp、right_clamp、t_minus、t_plus、T_0、sup_error、root_reason、tube_stage、middle_partition）はすべて null、root_mv_steps は空でなければならない（違反は `CONTRACT_MISMATCH:LX_PREDICTOR_FIELD_NONNULL`）。

- `exterior_guards`／`exterior_nonfinite`：L では baseline の exterior（直接 g と mono 閉包）の guard。【v0.1】X では `x_negative_cover` の guard で、kind は必ず `X_DIRECT_G`（mono の guard `*_MONO` は X には現れない）。

**`result.reason`：** 試行の理由（`PASS`、`L_NEGATIVE`、`X_NEGATIVE`、`ENDPOINT:<code>` など）。【v0.1】資源上限で止めた record に限り `RESOURCE_CAP:<cap 名>` に置き換える（§2.3）。

### 2.1 全 region 共通の `result.gap1`

| key | 内容 |
|---|---|
| `region` | `L`／`X`／`R`（厳密な λ の端点から `gap1_region`） |
| `diff_categories_used` | region ごとの DIFF 分類 |
| `region_pieces` | L：`[["L_NEGATIVE","1/2","31/32"]]`、X：`[["X_LOWER_GT","1/2","5/8"],["X_NEGATIVE","5/8","31/32"]]`、R：null |
| `x_lower_tube_stage`、`x_lower_tube_guards`、`x_lower_tube_nonfinite` | X だけ |
| 【v0.1】`x_negative_method` | X だけ。`DIRECT_G_BOX_ONLY` |
| `endpoint` | §2.4。本体が不成立で gate に到達しなければ null |
| 【v0.1】`root_count` | §2.2 |
| `failure_class` | PASS なら null。それ以外は `CERTIFICATE_INCONCLUSIVE/…`、`NONFINITE`、`ENDPOINT_NONFINITE`、`ENDPOINT_PARTITION_MISMATCH`、【v0.1】`RESOURCE_CAP` |
| 【v0.1】`attempt_reason` | 試行そのものの理由（資源上限で `reason` を置き換えた場合も元の値が残る） |
| 【v0.1】`attempt_failure_class` | `attempt_reason` から決まる分類（`gap1_failure_class`） |
| 【v0.1】`abort_cause` | null、`RESOURCE_CAP`、`MAX_DEPTH_EXHAUSTED`、`PRODUCER_PLAN_ABORT`（checker だけ）のいずれか |
| 【v0.1】`resource_cap` | `abort_cause=RESOURCE_CAP` のときだけ cap 名。それ以外は null |

### 2.2 【v0.1】根の数（F2、`result.gap1.root_count`）

| region | `label` | `root_count` | 意味 |
|---|---|---|---|
| L | `ROOT_FREE_REGION`（証明書が成立したとき）／`UNRESOLVED` | 0／null | [1/2,31/32] の g<0 の直接証明書と端点 gate による。U1 内の根は0 |
| X | `ROOT_COUNT_BY_C1A_SIGN_NO_T_STAR`（証明書が成立したとき）／`UNRESOLVED` | 常に null | **根がないという意味ではない。** 各 λ について、g(1/2,λ) ≤ 0 なら U1 内の根は0、g(1/2,λ) > 0 なら (1/2,5/8) にちょうど1個の単純根（v7 §5.1–5.3）。g(1/2,·) の符号は C1a receipt（699/1600 で負、281/640 で正）と gate D（∂_λF_x>0）で与えられる。T_* は作らない。λ_x の近似値による分岐はしない |
| R | `RESOLVED_WITH_CERTIFIED_T_STAR`／`UNRESOLVED` | 1／null | 試行全体が PASS で、かつ certified T_* が TARGET_WIDTH |

**どの region でも、label が `UNRESOLVED` 以外になるのは、試行そのものの理由（`attempt_reason`）が `PASS`（本体と端点 gate の両方が成立）のときだけ。** R も、v0.1 の自己点検の後でこの条件に揃えた（§2.5）。

その他の key：
- `certified`：label が `UNRESOLVED` でなければ true。試行の証明書が成立したことを表す。
- `accepted`：その slab が受け入れられたか。`gap1_mark_decision` が書く。producer では `decision=ACCEPT`、checker では plan の ACCEPT を checker が受け入れた（`checker_decision=REPLAYED`）ときに true。
- `rule`：文字列。
- X ではさらに `c1a_receipt_blob`、`c1a_signs`、`gate_D`、`t_star_constructed=false`、`lambda_x_approximation_used=false`。

資源上限で ABORT した record では、試行が成立していれば `certified=true`、`accepted=false` となる。label は資源上限で `result.reason` を置き換えた後も、`attempt_reason` から計算した値のままである。

**checker の `checker_root_outcome`（`gap1_root_outcome`）：** 上の `label` と同じ規則で、checker が自分の試行から決める。checker が plan の ACCEPT を受け入れる条件は、`checker_root_outcome` がその region の label（L：`ROOT_FREE_REGION`、X：`ROOT_COUNT_BY_C1A_SIGN_NO_T_STAR`、R：`RESOLVED_WITH_CERTIFIED_T_STAR`）に一致し、かつ checker 自身の試行が成立していること。v0 で X に `ROOT_FREE_REGION` を書いていた分岐は無くなった。

### 2.3 【v0.1】資源上限と ABORT（F3）

**cap の判定（`gap1_cap_exceeded`、両系統で同一テキスト）。** `kernel.GAP1_RESOURCE_CAPS` の順に調べ、最初に超えたものを返す（どれも「値 > 上限」）。MAX_ATTEMPTED は、各試行の前に「attempted + 1」で同じ関数を呼んで判定する（次の試行で上限を超えるなら止める。baseline の `attempted >= MAX_ATTEMPTED` と同値）。

1. `GLOBAL_ATTEMPT_WORK_CEILING`（累積 work、= `cumulative_work_after`）
2. `MAX_ACCEPTED`（`accepted_count`）
3. `ACCEPTED_WORK_CEILING`（`accepted_work`）
4. `MAX_ATTEMPTED`（`attempted_count`）

**producer の slab_record。** decision の決め方は baseline のまま（global 超過 → ABORT、成功 → ACCEPT の後で accepted の上限超過なら ABORT、失敗で depth < 3 → REFINE、depth = 3 → ABORT）。その直後に `gap1_mark_decision` が次を書く。

| 状況 | `decision` | `result.reason` | `gap1.failure_class` | `gap1.abort_cause` | `gap1.resource_cap` |
|---|---|---|---|---|---|
| ACCEPT | ACCEPT | PASS | null | null | null |
| REFINE | REFINE | 試行の理由 | 試行の分類 | null | null |
| cap による ABORT（試行の成否によらない） | ABORT | `RESOURCE_CAP:<cap>` | `RESOURCE_CAP` | `RESOURCE_CAP` | cap 名 |
| depth = 3 で不成立 | ABORT | 試行の理由（PASS ではあり得ない） | 試行の分類 | `MAX_DEPTH_EXHAUSTED` | null |

`attempt_reason`／`attempt_failure_class` には常に試行そのものの値が残る。したがって `reason=PASS` と `decision=ABORT` が同じ record に並ぶことはない。cap が無いのに ABORT で、しかも試行が PASS という組は `CONTRACT_MISMATCH:ABORT_WITHOUT_CAUSE` で止める（record は書かない。producer では到達しない）。

**checker の slab_record。** `decision` は baseline と同じく plan の固定 decision。【v0.1】次を加えた。

- `checker_decision`：`REPLAYED` または `ABORT`（checker 自身が cap で止めた場合と、plan の ABORT の slab）。
- `checker_reason`：`result.reason` と同じ値（cap のときは `RESOURCE_CAP:<cap>`）。
- cap の判定は、baseline と同じ位置で行う。まず試行の work を加えた直後に判定し、ACCEPT の受け入れで件数と work を加えた後にもう一度判定する。v0 までのように record を残さず `SystemExit` で止めることはしない。
- **plan の ABORT（producer がその slab で止まった）の扱い。** checker は自分の試行を行い、自分の counter で次のように分類する。ABORT の record を書いた後、segment_end を書いて止める。終了文字列は `RESOURCE_CAP:<cap>` または `CHECKER_TERMINAL_ABORT:<abort_cause>`。

| checker 自身の試行 | 分類 | `result.reason` | `failure_class` |
|---|---|---|---|
| global を超えている | `RESOURCE_CAP`／`GLOBAL_ATTEMPT_WORK_CEILING` | `RESOURCE_CAP:…` | `RESOURCE_CAP` |
| 成立。受け入れたと数えると accepted の cap を超える（producer と同じ数え方。このときだけ件数と work を加える） | `RESOURCE_CAP`／`MAX_ACCEPTED` または `ACCEPTED_WORK_CEILING` | `RESOURCE_CAP:…` | `RESOURCE_CAP` |
| 不成立、depth = 3 | `MAX_DEPTH_EXHAUSTED` | 試行の理由 | 試行の分類 |
| 不成立、depth < 3（producer の global 上限を checker の work では再現できない場合） | `PRODUCER_PLAN_ABORT` | 試行の理由 | 試行の分類 |
| 成立。checker の counter ではどの cap も説明できない | `PRODUCER_PLAN_ABORT` | `CONTRACT_MISMATCH:PLAN_ABORT_NOT_REPRODUCED` | `CONTRACT_MISMATCH` |

  どの行でも `reason=PASS` と ABORT は並ばない。これは v0.1 の自己点検で見つけた穴（§2.5）を塞いだもの。

**segment_end。** 資源上限で止まる場合は、次の場所で必ず segment_end を書いてから停止する。

| 停止の場所 | segment_end に加わる項目 | プロセスの終了文字列 |
|---|---|---|
| producer／checker の slab_record の直後（global、MAX_ACCEPTED、accepted work） | `reason=RESOURCE_CAP`、`failure_class=RESOURCE_CAP`、`resource_cap`、`abort_cause=RESOURCE_CAP`、`attempt_failure_class` | `RESOURCE_CAP:<cap>` |
| 次の試行の前（`attempted ≥ MAX_ATTEMPTED`） | 同上（`resource_cap=MAX_ATTEMPTED`、`attempt_failure_class=null`） | `RESOURCE_CAP:MAX_ATTEMPTED` |
| resume の開始時（中断課金の後で cap を超えていた場合。segment_begin の後で判定） | 同上 | `RESOURCE_CAP:<cap>` |
| producer の depth = 3 での不成立 | `reason=failure`、`failure_class`＝試行の分類、`abort_cause=MAX_DEPTH_EXHAUSTED`、`resource_cap=null` | baseline のまま `C1B_UNRESOLVED …` |
| checker の plan ABORT（cap 以外） | `reason=failure`、`failure_class`、`abort_cause`（`MAX_DEPTH_EXHAUSTED` または `PRODUCER_PLAN_ABORT`）、`resource_cap=null` | `CHECKER_TERMINAL_ABORT:<abort_cause>` |

baseline の resume 時の `check_ceiling(attempted, MAX_ATTEMPTED)` は、record を残さず止めるため取り除いた。その判定は segment_begin の後の `resume_cap` に移した。

**resume と replay で同じ分類になること。**
- producer の `replay` と checker の `replay_state` は、どちらも最初に `gap1_terminal_abort` を呼ぶ。
- ABORT の record（producer は `decision`、checker は `checker_decision`）が見つかった場合の手順は次のとおり。
  1. その record が最後の record であることを確かめる。そうでなければ `CONTRACT_MISMATCH:ABORT_NOT_LAST`。
  2. record に書かれた `cumulative_work_after`、`accepted_count`、`accepted_work`、`attempted_count` から、同じ `gap1_cap_exceeded` で cap を計算し直す。
  3. 保存されている (`abort_cause`、`resource_cap`、`failure_class`、`reason`) が、計算し直した値と一致すること、`attempt_failure_class` = `gap1_failure_class(attempt_reason)` であること、`root_count.accepted=false` であることを確かめる。不一致なら `CONTRACT_MISMATCH:ABORT_CLASSIFICATION`。cap が無い場合に許されるのは、`MAX_DEPTH_EXHAUSTED`（depth = 3 で試行が PASS でない）と、checker だけの `PRODUCER_PLAN_ABORT` である。
  4. `LEDGER_TERMINAL_ABORT:RESOURCE_CAP:<cap>` または `LEDGER_TERMINAL_ABORT:<abort_cause>` で停止する。
- slab_record の後、segment_end を書く前にプロセスが落ちた場合でも、分類は slab_record の `result.gap1` に残っている。resume は上の手順でその分類を読み直して停止するが、新しい segment_end は書かない（OPEN_QUESTIONS B9）。
- `MAX_ATTEMPTED` の停止では slab_record が無い。resume すると attempted は MAX のままなので、ループの最初で同じ `RESOURCE_CAP:MAX_ATTEMPTED` に再び到達する。

### 2.4 `result.gap1.endpoint`（`endpoint_gate`、DIFF-D、v0 から変更なし）

| key | 内容 |
|---|---|
| `endpoint_partition_id`、`endpoint_seed_t` | 固定値 |
| `endpoint_seed_g` | seed の arb snapshot |
| `endpoint_seed_g_upper` | seed の上界（厳密な dyadic 有理数） |
| `endpoint_gt_boxes[16]` | j、t_cell、dispatch（j=15 は `endpoint_corner_ordinary`）、Gt の snapshot、upper（厳密な有理数）、charts、work |
| `endpoint_contributions[16]` | max(0, U_j)（厳密な有理数）。全箱が有限のときだけ |
| `endpoint_cumulative_mvt_upper` | U_cum の上界（厳密な有理数） |
| `endpoint_pass`、`endpoint_reason`、`endpoint_work` | `endpoint_pass` が true になるのは U_cum < 0 のときだけ |

**slab_record の payload：** baseline の項目（attempt_sequence、coarse_index、refinement_depth、lambda_lo、lambda_hi、decision、result、accepted_count、accepted_work、cumulative_work_after、attempted_count、utc）。checker は baseline の checker_full_ok、checker_reason、checker_root_outcome、a1/a2 ラベルに加えて、【v0.1】`checker_decision` を持つ。

**segment_end（完了時）：** baseline の項目に加えて `gap1_boundary_overlap`（§5）。

### 2.5 【v0.1】自己点検で直した点（提出前）

提出前に、Code とは別の静的レビュー（Code が起動した読むだけのサブエージェント。監査ではない）を行い、次を直した。
1. checker が producer の cap 停止の slab（plan では ABORT）を再計算すると、`decision=ABORT`、`reason=PASS`、`failure_class=null` の record を書き、cap の分類を残さなかった（F3 の残り）。→ §2.3 の plan ABORT の表のとおりに分類する。
2. R の `root_count` が、試行が不成立（EXTERIOR、ENDPOINT など）でも `certified=true` と書けた。また cap の後で `result.reason` を置き換えると、label の再計算が一致しなかった。→ label は全 region で `attempt_reason=PASS` を要件とし、`attempt_reason` から計算する。`accepted` を追加した。
3. MAX_ATTEMPTED の判定が共通関数を通っていなかった。→ `attempted + 1` で共通関数を呼ぶ。
4. スタブ control の `X_NO_MONO_CLOSURE_FAIL` の no-mono 判定は、常に真になる形だった。→ X のテスト中は `mono_closure_box`／`eval_exterior`／`exterior_cover` を例外を投げるスタブに差し替え、到達したら FAIL にする。

## 3. replay plan（producer → checker、v0 から変更なし）

- ファイルは `checker_replay_exact.jsonl`、schema は `GAP1_A1_REPLAY_V0`。`REPLAY_KEYS` は baseline の16項目のまま。
- T_star、G0、Gt、Gl、Gpar、N_k、root_mv_steps は禁止（`REPLAY_PLAN_A2_FIELD_LEAK`）。
- L/X の item では t_c、clamp、t_minus、t_plus、T_0、producer_accept_root_outcome がすべて null（checker の `verify_gap1_lx_fields` が確認）。
- plan の `decision` は producer の decision。producer が cap または depth で ABORT した slab も ABORT として plan に入る（plan の最後の item）。checker はそれを再計算し、自分の counter で分類して `checker_decision=ABORT` で記録し、止まる（§2.3）。

## 4. checker が受け取る入力の境界（v7 §13、B2）

**受け取るもの：** 厳密な有理数の slab ラベル、decision、R の t_c、clamp と t± の厳密な有理数ラベル、producer ledger の SHA-256。

**使わないもの：** producer の区間上界、enclosure、T_star、endpoint の値、成否の判定、根の数の label。checker は自分の kernel（192 bit）で、L、X（直接 g だけ）、R、endpoint を計算し直し、`checker_root_outcome` を自分で決める。

**自分で確かめること：** plan の順序（`gap1_plan_order_audit`）、自分の ACCEPT による厳密な和集合と境界の overlap、【v0.1】自分の資源上限。

**共通 driver（`gap1_analysis`）：** stdlib だけを使う。【v0.1】照合対象の path は25本（新規7本、閉包17本、読むだけのファイル `analysis/c1b_cross_lineage_compare.py`）。

## 5. 共有辺の owner と overlap（v0 から変更なし）

| 辺 | owner | overlap 側 | 照合内容 | 失敗時 |
|---|---|---|---|---|
| λ=699/1600 | X | L | 根の数が両側で0（この λ では g(1/2)<0：L の閉箱証明書と C1a の負符号） | `CONTRACT_MISMATCH:BOUNDARY_OVERLAP` |
| λ=281/640 | R | X | 根の数が両側で1（X 側は C1a の正符号による §2.2 の規則、R 側は T_* が (1/2,5/8) と交わる） | `CONTRACT_MISMATCH:BOUNDARY_OVERLAP` |
| λ=9/20 | C1b／空白② | ①（整合だけ） | R の端の slab の endpoint 証明書が PASS | `BOB_SIGN_CONSISTENCY_FAILED` |
| t=5/8（X） | 負値ブロック（直接 g） | 下の tube | 閉区間が 5/8 を共有する（追加の評価はしない） | — |
| t=31/32 | endpoint の seed | L/X の負値ブロック、R の exterior | 閉辺を共有する | — |

overlap の行の `root_count_owner`／`root_count_overlap` は、辺そのものの λ での値である。X の内部の slab の根の数（§2.2）とは別物。

## 6. 失敗分類（v7 §10）

- `CERTIFICATE_INCONCLUSIVE` は上位分類。下位の分類は次のとおり。
  - `ENDPOINT_SEED_G_INCONCLUSIVE`、`ENDPOINT_GT_CELL_INCONCLUSIVE`、`ENDPOINT_CUMULATIVE_MVT_INCONCLUSIVE`
  - `<reason>_INCONCLUSIVE`。reason は `L_NEGATIVE`、`X_LOWER_TUBE`、`X_NEGATIVE`、`TUBE`、`ROOT_*`、`PREDICTOR`、`PREDICTOR_ACCEPT`、`EXTERIOR`、`R_RIGHT_CLAMP_FORBIDDEN`、`T_PARTITION` のいずれか。
  - 【v0.1】X の負値ブロックで E2 の後も閉じない箱が残る場合と、`E_BOX_CAP` を超える場合は、どちらも `X_NEGATIVE` で `CERTIFICATE_INCONCLUSIVE/X_NEGATIVE_INCONCLUSIVE` になる（mono 閉包への切替はない）。
- 別の分類：`NONFINITE`、`ENDPOINT_NONFINITE`、【v0.1】`RESOURCE_CAP`（§2.3、cap 名つき）、`CONTRACT_MISMATCH`（【v0.1】checker の `PLAN_ABORT_NOT_REPRODUCED` を含む）、`DIFF_OUTSIDE_ALLOWLIST`、`IMPORT_BLOB_MISMATCH`（【v0.1】読むだけの pin の不一致も含む）、`PREDICTOR_RULE_MISMATCH`、`ENDPOINT_PARTITION_MISMATCH`、`BOB_SIGN_CONSISTENCY_FAILED`、`DOMAIN_MISMATCH`、`COVERAGE_FAILED`。
- 語彙だけで、実行中に発生しない分類：`PRECISION_INCONCLUSIVE`、`APPROX_DEGREE_INCONCLUSIVE`、`ENDPOINT_RESOURCE_CAP`（OPEN_QUESTIONS）。
- `MAX_DEPTH_EXHAUSTED` と `PRODUCER_PLAN_ABORT` は失敗分類ではなく `abort_cause` の値である。分類は試行の分類（`CERTIFICATE_INCONCLUSIVE/…` など）のまま。ただし checker の試行が成立しているのに plan の ABORT を説明できない場合は `CONTRACT_MISMATCH`。
- どの分類も、それだけでは数学的反例を意味しない。不確定を ACCEPT に読み替えることもしない。
