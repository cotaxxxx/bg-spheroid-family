# STATIC_CONTROL_REPORT_V0_3 — C 空白①

静的検査のみ。数値 kernel / module / preflight は実行していない。

- C0〜C17：v0.2 controlsをそのまま再実行し全件PASS。
- C18：両kernelのauthority 17件、およびv0.3追加6件をmain実ファイルのSHA-256と照合してPASS。
- C19：checker-local `attempt_sequence` と `plan_attempt_sequence` の分離、attempt_begin/slab_recordへの記録、replay_stateのplan照合、中断課金後もplan番号を使う配線を静的に確認してPASS。
- hunk classification：baseline→v0.3 62 hunks、mixed/unclassified 0。
- compile-only：新規7本 `py_compile` PASS。

最終 summary：

`SUMMARY C0=PASS C1=PASS C2=PASS C3=PASS C4=PASS C5=PASS C6=PASS C7=PASS C8=PASS C9=PASS C10=PASS C11=PASS C12=PASS C13=PASS C14=PASS C15=PASS C16=PASS C17=PASS C18=PASS C19=PASS`
