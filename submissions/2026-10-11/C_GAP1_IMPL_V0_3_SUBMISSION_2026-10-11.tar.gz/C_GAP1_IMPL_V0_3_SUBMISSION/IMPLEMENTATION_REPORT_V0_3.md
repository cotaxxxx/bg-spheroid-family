# IMPLEMENTATION_REPORT_V0_3 — C 空白① 実装 v0.3（ChatGPT、2026-10-11）

## 0. 基準

- Judge 指示書：`bg-spheroid-family` main `4834b7216e200e759b64584552ed0e7dad905660` の `drafts/2026-10-11/CODE_INSTRUCTION_C_GAP1_IMPL_V0_3_2026-10-11.md`。
- 指示書 SHA-256：`6eb5a3e4df4278405e4b83f3be8fe53634d33461d5bd57b1dcc102720e728e75`。
- 出発点：main の v0.2 submission `eb5f6e86ae045b2e698d49cdfb31ccb3a26ebf52e2059587a44c37b5d419ed2b`。
- baseline：`bg-oblate-spheroid-c1b` commit `85eca2288732a3cac65f4d5f87ecfd2ba5ce2e9b`。
- 実装者は Judge 裁定により ChatGPT。既存 repository のファイルは変更していない。

数値実行、module import、producer/checker/preflight の実行、証明書生成、commit、push、FREEZE は行っていない。実施したのは pure-text build、static AST/text controls、`py_compile`、hash/diff/package 作成のみ。

## 1. A1 — authority pin 6件

main `4834b721` の実ファイルから SHA-256 を直接計測し、producer/checker 両 kernel の `GAP1_AUTHORITY_SHA256` に追加した。17件の authority を static control C1/C18 が実ファイルと照合し PASS。

追加値は `static_controls/authority_sha256.txt` と `LEDGER_AND_REPLAY_SCHEMA_V0_3.md` §0B に記録した。

## 2. A7 — checker sequence の分離

checker の `slab_record` に `plan_attempt_sequence = item["attempt_sequence"]` を追加した。診断の一貫性のため `attempt_begin` にも同じ field を追加した。

- `attempt_sequence`：checker 自身の試行番号。
- `plan_attempt_sequence`：producer replay plan の item 番号。
- `replay_state` の plan 照合は `plan_attempt_sequence` を使用する。

producer が中断して plan 番号に欠けがある場合でも item の番号をそのまま比較する。checker 自身の中断で local attempted counter が進んでも、plan item の番号は変わらない。C19 がこの配線を静的に確認して PASS。

## 3. 差分

v0.2→v0.3 の変更は3ファイルだけ。

- `gap1_producer/global_axial_c1b_kernel.py`：DIFF-K、authority pin 6件。
- `gap1_checker/global_axial_c1b_kernel.py`：DIFF-K、authority pin 6件。
- `gap1_checker/global_axial_c1b_gating.py`：DIFF-E、`plan_attempt_sequence` の記録と照合。

残り4本は v0.2 と byte-identical。baseline→v0.3 の62 hunksは、既存82 edit logにより DIFF-A/B/C/D/E/K のいずれか一つに分類され、unclassified/mixed=0。

## 4. 静的 controls

C0〜C19 全件 PASS。C18=A1、C19=A7。最終出力は `static_controls/static_controls.stdout`。

`py_compile` も新規7本すべて PASS。ただしこれは import/数値実行ではない。

## 5. 提出

- `new_files/`：v0.3 新規7本。
- `diffs_baseline_to_v0_3/`：baseline→v0.3 全文 diff。
- `diffs_v0_2_to_v0_3/`：v0.2→v0.3 全文 diff。
- `static_controls/`：C0〜C19 script/output、hunk table、authority 実測値、pre-run script hashes。
- `build/`：v0.3 builder、引き継いだ v0.2 builder、edit logs、build log。
- schema / open questions / MANIFEST。

IMPLEMENTATION_READY_FOR_CHAT_DIFF_AUDIT
