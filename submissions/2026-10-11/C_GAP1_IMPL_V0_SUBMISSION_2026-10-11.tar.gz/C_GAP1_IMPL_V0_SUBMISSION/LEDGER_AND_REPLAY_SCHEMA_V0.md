# LEDGER_AND_REPLAY_SCHEMA_V0 — C 空白①（Code、2026-10-11）

record の連鎖形式は baseline と同じ（sequence、record_type、prev_sha256、payload、record_sha256 からなる canonical JSON）。chain ラベルは `GAP1_JSONL_CHAIN_V1` で、`gap1_analysis/c1b_resumable_driver.py` の DIFF-E 変更による。record_type は baseline のまま（header、segment_begin、attempt_begin、slab_record、interrupted_attempt_charge、segment_end、lscpu_raw_trace）。

## 1. header（両系統、`header_payload`）

baseline の項目（chain_version、lineage、identity、precision_bits、degree、u_star、stages、caps、budgets、estimates、pin_manifest、phase、replay_schema）はそのまま残す。変更と追加は次のとおり。

| key | 内容 | 分類 |
|---|---|---|
| `lambda_domain` | `["2/5","9/20"]` | DIFF-K |
| `caps.coarse` | 160 | DIFF-K |
| `estimates.coarse_slabs`、および estimates の積算 | `GAP1_N_COARSE` で計算する | DIFF-K |
| `gap1.contract_id` | `C_GAP1_U1` | DIFF-K |
| `gap1.authority_sha256` | v7、設計 v2、端点追補 v2、数値契約 v1、G0/E1 v3、clarifications、import 閉包の記録、指示書 v2、発出メモ（全64桁） | DIFF-K |
| `gap1.baseline_commit`、`baseline_blobs`、`import_closure_17` | `85eca228`、元の7本の blob、17本の blob | DIFF-K |
| `gap1.regions` | `[["L","2/5","699/1600",118],["X","699/1600","281/640",7],["R","281/640","9/20",35]]` | DIFF-K |
| `gap1.dlambda`、`coarse`、`direction`、`refine_order` | `1/3200`、160、`decreasing`、`right_child_first` | DIFF-K |
| `gap1.x_split_t`、`x_t_stages` | `5/8`、X-T0/X-T1/X-T2 | DIFF-K |
| `gap1.endpoint` | partition_id、seed_t=`31/32`、dt=`1/512`、boxes=16、seed_panels=8192、gt_panels=8192 | DIFF-K |
| `gap1.c1a` | receipt_blob `e494e789…`、signs `[["699/1600",-1],["281/640",1]]`、gate_D の文字列 | DIFF-K |
| `gap1.ownership` | 699/1600→X、281/640→R、9/20→consistency_only、t=5/8→X の負値ブロック、t=31/32→endpoint seed | DIFF-K |
| `gap1.failure_codes`、`diff_categories_by_region` | 失敗分類語の一覧、region ごとに使う DIFF 分類 | DIFF-K |

## 2. slab_record の `result`（`gap1_serialize_record`、DIFF-E）

**R：** baseline の `serialize_record` が返す項目すべて（predictor_mode、t_c、T_star、left_clamp、right_clamp、t_minus、t_plus、T_0、tube_*、exterior_*、root_mv_steps、root_reason、middle_partition、work、reason、trace など）をそのまま残す。
- `predictor_mode` は、producer では {continuation, relocated, null}、checker では {fixed_replay, null} のいずれかでなければならない。それ以外は `PREDICTOR_RULE_MISMATCH` で停止する。

**L/X：** `serialize_record(None, …)` が返す空の形を使う。
- predictor と root の項目（predictor_mode、t_c、T_star、left_clamp、right_clamp、t_minus、t_plus、T_0、sup_error、root_reason、tube_stage、middle_partition）は、すべて null でなければならない。root_mv_steps も空でなければならない。
- 一つでも非 null なら `CONTRACT_MISMATCH:LX_PREDICTOR_FIELD_NONNULL` で停止する。
- exterior_guards と exterior_nonfinite には、L/X の負値ブロックの guard を書く。

**全 region に共通して `result.gap1` を追加する：**

| key | 内容 |
|---|---|
| `region` | `L`／`X`／`R`。厳密な λ の端点から `gap1_region` で決める |
| `diff_categories_used` | region ごとの DIFF 分類の一覧 |
| `region_pieces` | L：`[["L_NEGATIVE","1/2","31/32"]]`、X：`[["X_LOWER_GT","1/2","5/8"],["X_NEGATIVE","5/8","31/32"]]`、R：null（R は baseline の middle_partition を使う） |
| `x_lower_tube_stage`、`x_lower_tube_guards`、`x_lower_tube_nonfinite` | X だけで使う |
| `endpoint` | 下の表のとおり。region の本体が不成立で、gate に到達しなかった場合は null |
| `failure_class` | PASS なら null。それ以外は `CERTIFICATE_INCONCLUSIVE/…`、`NONFINITE`、`ENDPOINT_NONFINITE`、`ENDPOINT_PARTITION_MISMATCH` のいずれか |

**`result.gap1.endpoint`（`endpoint_gate`、DIFF-D）：**

| key | 内容 |
|---|---|
| `endpoint_partition_id`、`endpoint_seed_t` | 固定値 |
| `endpoint_seed_g` | seed の arb snapshot（mid、rad、lower、upper の文字列） |
| `endpoint_seed_g_upper` | 厳密な有理数（dyadic）。seed の上界 |
| `endpoint_gt_boxes[16]` | 各箱について j、t_cell、dispatch（j=15 は `endpoint_corner_ordinary`、それ以外は `ordinary`）、Gt の snapshot、upper（厳密な有理数）、charts、work |
| `endpoint_contributions[16]` | max(0, U_j)（厳密な有理数）。全箱が有限のときだけ記録する |
| `endpoint_cumulative_mvt_upper` | U_cum の上界（厳密な有理数） |
| `endpoint_pass`、`endpoint_reason`、`endpoint_work` | `endpoint_pass` が true になるのは U_cum < 0 のときだけ |

**slab_record の payload：** baseline の項目（attempt_sequence、coarse_index、refinement_depth、lambda_lo、lambda_hi、decision、result、accepted_count など）はそのまま。checker の payload には、baseline と同じく checker_full_ok、checker_reason、checker_root_outcome、a1/a2 ラベルが加わる。checker_root_outcome は、L/X では `ROOT_FREE_REGION` になる。

**segment_end（完了時）：** baseline の項目に加えて、`gap1_boundary_overlap` を記録する。
- 699/1600：owner、overlap、両側の根の数、g(1/2) の符号の根拠、pass
- 281/640：owner の T_star、T_star が (1/2, 5/8) と交わるか、pass
- 9/20：bob_sign_consistency、bob_receipt_blob、pass

## 3. replay plan（producer → checker）

- ファイルは `checker_replay_exact.jsonl`。schema は `GAP1_A1_REPLAY_V0`。
- `REPLAY_KEYS` は baseline の16項目のまま：schema、attempt_sequence、coarse_index、refinement_depth、lambda_lo、lambda_hi、tree_node、t_c、left_clamp、right_clamp、t_minus、t_plus、T_0、root_gt_t_cells、producer_accept_root_outcome、decision。
- T_star、G0、Gt、Gl、Gpar、N_k、root_mv_steps は禁止（baseline の `REPLAY_PLAN_A2_FIELD_LEAK` 検査のまま）。
- L/X の item では、t_c、clamp、t_minus、t_plus、T_0、producer_accept_root_outcome がすべて null になる。checker の `verify_gap1_lx_fields` がこれを確かめる。

## 4. checker が受け取る入力の境界（v7 §13、B2）

**受け取るもの：** 厳密な有理数の slab ラベル（coarse_index、depth、λ の端点）、decision、producer が決めた R の t_c（baseline と同じ A1 の固定入力）、clamp や t± などの厳密な有理数ラベル、producer ledger の SHA-256。

**使わないもの：** producer の区間上界、enclosure、T_star、endpoint の値、成功判定。checker は、自分の kernel（192 bit）で、L、X、R、endpoint をすべて計算し直す。

**independently 確かめること：**
- `gap1_plan_order_audit` で、plan の順序を確かめる。160 の coarse slab を降順に並べ、REFINE のときは右の子を先に置いた順序を厳密に作り直し、plan の順序と照合する。
- 自分の ACCEPT について、厳密な和集合が [2/5, 9/20] になることと、境界の overlap とを、自分で確かめる。

**共通 driver（`gap1_analysis`）：** stdlib だけを import する。担うのは、非数値の persistence、canonical JSON、ledger の連鎖、pin 照合、環境の snapshot、資源上限の判定だけである（静的 control 9）。

## 5. 共有辺の owner と overlap の判定

| 辺 | owner | overlap 側 | 照合内容 | 失敗時 |
|---|---|---|---|---|
| λ=699/1600 | X | L | 根の数が両側で0。g(1/2)<0（L の閉箱証明書と、C1a の負の符号） | `CONTRACT_MISMATCH:BOUNDARY_OVERLAP` |
| λ=281/640 | R | X | 根の数が両側で1。R の T_* が (1/2, 5/8) と交わる | `CONTRACT_MISMATCH:BOUNDARY_OVERLAP` |
| λ=9/20 | C1b／空白② | ①（整合だけ） | R の端の slab の endpoint 証明書が PASS → B_ob(9/20)<0 が帰結し、receipt と整合する | `BOB_SIGN_CONSISTENCY_FAILED` |
| t=5/8（X） | 負値ブロック | 下の tube | 両者の閉区間が 5/8 を共有する（追加の評価はしない） | — |
| t=31/32 | endpoint の seed | L/X の負値ブロック、R の exterior | 閉辺を共有する | — |

**順序：** 停止は、segment_end と最終行を書いた後に行う。overlap の失敗が先、和集合の失敗が後（`C1B_EXACT_UNION_FAIL`）。

## 6. 失敗分類（v7 §10）

- `CERTIFICATE_INCONCLUSIVE` は上位の分類である。下位の分類には次がある。
  - `ENDPOINT_SEED_G_INCONCLUSIVE`
  - `ENDPOINT_GT_CELL_INCONCLUSIVE`
  - `ENDPOINT_CUMULATIVE_MVT_INCONCLUSIVE`
  - `<reason>_INCONCLUSIVE`。reason は `L_NEGATIVE`、`X_LOWER_TUBE`、`X_NEGATIVE`、`TUBE`、`ROOT_*`、`PREDICTOR`、`PREDICTOR_ACCEPT`、`EXTERIOR`、`R_RIGHT_CLAMP_FORBIDDEN`、`T_PARTITION` のいずれか。
  - `PRECISION_INCONCLUSIVE` と `APPROX_DEGREE_INCONCLUSIVE` は語彙として保持している（OPEN_QUESTIONS Q9）。
- 別の分類として次を持つ：`NONFINITE`、`ENDPOINT_NONFINITE`、`RESOURCE_CAP`（decision が ABORT）、`ENDPOINT_RESOURCE_CAP`（Q8）、`CONTRACT_MISMATCH`、`DIFF_OUTSIDE_ALLOWLIST`、`IMPORT_BLOB_MISMATCH`、`PREDICTOR_RULE_MISMATCH`、`ENDPOINT_PARTITION_MISMATCH`、`BOB_SIGN_CONSISTENCY_FAILED`、`DOMAIN_MISMATCH`、`COVERAGE_FAILED`。
- どの分類も、それだけでは数学的反例を意味しない。不確定を ACCEPT に読み替えることもしない。
