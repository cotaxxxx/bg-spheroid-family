"""Static: map every unified-diff hunk (baseline -> gap1) to the DIFF categories of the edits whose added/removed
lines it contains. PASS iff every hunk maps to exactly one category and every edit is covered by a hunk."""
import json, sys, difflib
from pathlib import Path
out = Path(sys.argv[1]); log = json.loads(Path(sys.argv[3]).read_text())
PAIRS = json.loads(sys.argv[2])
rows, bad = [], 0
for base, new in PAIRS:
    a = (out / base).read_text().splitlines(); b = (out / new).read_text().splitlines()
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    groups = list(sm.get_grouped_opcodes(3))
    edits = [e for e in log if e["path"] == new]
    covered = set()
    for gi, group in enumerate(groups, 1):
        minus, plus = [], []
        for tag, i1, i2, j1, j2 in group:
            if tag != "equal":
                minus += a[i1:i2]; plus += b[j1:j2]
        cats = set()
        for ei, e in enumerate(edits):
            o = e["old"].splitlines(); n = e["new"].splitlines()
            added = [x for x in n if x not in o]; removed = [x for x in o if x not in n]
            hit = (added and all(x in plus for x in added)) or (removed and all(x in minus for x in removed))
            if hit and ((not added) or any(x in plus for x in added)):
                cats.add(e["category"]); covered.add(ei)
        a_lo, a_hi = group[0][1] + 1, group[-1][2]
        b_lo, b_hi = group[0][3] + 1, group[-1][4]
        ok = len(cats) == 1
        bad += 0 if ok else 1
        rows.append((new, gi, a_lo, a_hi, b_lo, b_hi, len(minus), len(plus), sorted(cats), "OK" if ok else "MIXED_OR_UNCLASSIFIED"))
    for ei, e in enumerate(edits):
        if ei not in covered:
            bad += 1; rows.append((new, "-", "-", "-", "-", "-", 0, 0, [e["category"]], "EDIT_NOT_MATCHED:" + e["label"]))
for r in rows:
    print("\t".join(str(x) for x in r))
print("HUNKS", sum(1 for r in rows if r[1] != "-"), "PROBLEMS", bad)
sys.exit(0 if bad == 0 else 1)
