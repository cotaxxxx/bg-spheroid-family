| # | new file | hunk | baseline lines | new lines | −/+ lines | category | edit label(s) |
|---|---|---|---|---|---|---|---|
| 1 | `gap1_producer/global_axial_c1b_kernel.py` | 1 | 29–35 | 29–35 | −1/+1 | DIFF-K | caps |
| 2 | `gap1_producer/global_axial_c1b_kernel.py` | 2 | 49–56 | 49–56 | −2/+2 | DIFF-K | work ceilings |
| 3 | `gap1_producer/global_axial_c1b_kernel.py` | 3 | 59–64 | 59–164 | −0/+100 | DIFF-K | constants/domain |
| 4 | `gap1_producer/global_axial_c1b_kernel.py` | 4 | 84–94 | 184–192 | −5/+3 | DIFF-A | descending queue |
| 5 | `gap1_producer/global_axial_c1b_kernel.py` | 5 | 883–888 | 981–1028 | −0/+42 | DIFF-K | U1 controls |
| 6 | `gap1_producer/global_axial_c1b_kernel.py` | 6 | 1206–1211 | 1346–1399 | −0/+48 | DIFF-B | X fixed path |
| 7 | `gap1_producer/global_axial_c1b_kernel.py` | 7 | 1426–1431 | 1614–1705 | −0/+86 | DIFF-D | endpoint gate |
| 8 | `gap1_producer/global_axial_c1b_kernel.py` | 8 | 1586–1591 | 1860–1878 | −0/+13 | DIFF-C | L negative path |
| 9 | `gap1_producer/global_axial_c1b_kernel.py` | 9 | 1644–1649 | 1931–1957 | −0/+21 | DIFF-E | region dispatcher |
| 10 | `gap1_producer/global_axial_c1b_kernel.py` | 10 | 1814–1820 | 2122–2130 | −1/+3 | DIFF-K | preflight banner |
| 11 | `gap1_producer/global_axial_c1b_kernel.py` | 11 | 1845–1848 | 2155–2160 | −0/+2 | DIFF-K | preflight controls |
| 12 | `gap1_producer/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 13 | `gap1_producer/global_axial_c1b_gating.py` | 2 | 142–147 | 142–266 | −0/+119 | DIFF-E | ledger/overlap/union helpers |
| 14 | `gap1_producer/global_axial_c1b_gating.py` | 3 | 328–337 | 447–456 | −2/+2 | DIFF-A | live right-child-first; resume replay right-child-first |
| 15 | `gap1_producer/global_axial_c1b_gating.py` | 4 | 341–347 | 460–466 | −1/+1 | DIFF-E | replay schema label |
| 16 | `gap1_producer/global_axial_c1b_gating.py` | 5 | 389–400 | 508–519 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 17 | `gap1_producer/global_axial_c1b_gating.py` | 6 | 402–407 | 521–556 | −0/+30 | DIFF-K | U1 header metadata block |
| 18 | `gap1_producer/global_axial_c1b_gating.py` | 7 | 412–418 | 561–568 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 19 | `gap1_producer/global_axial_c1b_gating.py` | 8 | 427–433 | 577–583 | −1/+1 | DIFF-K | header coarse cap |
| 20 | `gap1_producer/global_axial_c1b_gating.py` | 9 | 550–558 | 700–708 | −2/+2 | DIFF-E | dispatch + record |
| 21 | `gap1_producer/global_axial_c1b_gating.py` | 10 | 592–598 | 742–748 | −1/+1 | DIFF-A | live right-child-first |
| 22 | `gap1_producer/global_axial_c1b_gating.py` | 11 | 601–619 | 751–767 | −7/+5 | DIFF-E | exact union + overlap; segment end overlap record |
| 23 | `gap1_producer/global_axial_c1b_gating.py` | 12 | 622–627 | 770–777 | −0/+2 | DIFF-E | overlap failure after segment end |
| 24 | `gap1_producer/global_axial_c1b_producer.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
| 25 | `gap1_analysis/c1b_resumable_driver.py` | 1 | 18–34 | 18–51 | −9/+26 | DIFF-E | pin manifest path / chain label; pinned blob paths (7 new + 17 closure) |
| 26 | `gap1_checker/global_axial_c1b_kernel.py` | 1 | 30–36 | 30–36 | −1/+1 | DIFF-K | caps |
| 27 | `gap1_checker/global_axial_c1b_kernel.py` | 2 | 50–57 | 50–57 | −2/+2 | DIFF-K | work ceilings |
| 28 | `gap1_checker/global_axial_c1b_kernel.py` | 3 | 60–65 | 60–165 | −0/+100 | DIFF-K | constants/domain |
| 29 | `gap1_checker/global_axial_c1b_kernel.py` | 4 | 876–881 | 976–1023 | −0/+42 | DIFF-K | U1 controls |
| 30 | `gap1_checker/global_axial_c1b_kernel.py` | 5 | 1183–1188 | 1325–1378 | −0/+48 | DIFF-B | X fixed path |
| 31 | `gap1_checker/global_axial_c1b_kernel.py` | 6 | 1403–1408 | 1593–1684 | −0/+86 | DIFF-D | endpoint gate |
| 32 | `gap1_checker/global_axial_c1b_kernel.py` | 7 | 1563–1568 | 1839–1857 | −0/+13 | DIFF-C | L negative path |
| 33 | `gap1_checker/global_axial_c1b_kernel.py` | 8 | 1630–1635 | 1919–1948 | −0/+24 | DIFF-E | region dispatcher |
| 34 | `gap1_checker/global_axial_c1b_kernel.py` | 9 | 1802–1808 | 2115–2123 | −1/+3 | DIFF-K | preflight banner |
| 35 | `gap1_checker/global_axial_c1b_kernel.py` | 10 | 1832–1835 | 2147–2152 | −0/+2 | DIFF-K | preflight controls |
| 36 | `gap1_checker/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 37 | `gap1_checker/global_axial_c1b_gating.py` | 2 | 142–147 | 142–266 | −0/+119 | DIFF-E | ledger/overlap/union helpers |
| 38 | `gap1_checker/global_axial_c1b_gating.py` | 3 | 312–318 | 431–437 | −1/+1 | DIFF-E | replay schema label |
| 39 | `gap1_checker/global_axial_c1b_gating.py` | 4 | 320–325 | 439–463 | −0/+19 | DIFF-A | checker plan-order audit |
| 40 | `gap1_checker/global_axial_c1b_gating.py` | 5 | 343–348 | 481–494 | −0/+8 | DIFF-E | checker L/X field verification |
| 41 | `gap1_checker/global_axial_c1b_gating.py` | 6 | 364–372 | 510–518 | −2/+2 | DIFF-E | resume previous_root for L/X |
| 42 | `gap1_checker/global_axial_c1b_gating.py` | 7 | 389–400 | 535–546 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 43 | `gap1_checker/global_axial_c1b_gating.py` | 8 | 402–407 | 548–583 | −0/+30 | DIFF-K | U1 header metadata block |
| 44 | `gap1_checker/global_axial_c1b_gating.py` | 9 | 412–418 | 588–595 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 45 | `gap1_checker/global_axial_c1b_gating.py` | 10 | 427–433 | 604–610 | −1/+1 | DIFF-K | header coarse cap |
| 46 | `gap1_checker/global_axial_c1b_gating.py` | 11 | 467–472 | 644–650 | −0/+1 | DIFF-A | checker plan-order audit call |
| 47 | `gap1_checker/global_axial_c1b_gating.py` | 12 | 532–550 | 710–732 | −5/+9 | DIFF-E | checker accept rule for L/X; checker dispatch + record + field checks; checker root outcome for L/X |
| 48 | `gap1_checker/global_axial_c1b_gating.py` | 13 | 564–581 | 746–766 | −6/+9 | DIFF-E | checker exact union + overlap; checker segment end overlap record; overlap failure after segment end |
| 49 | `gap1_checker/global_axial_c1b_checker.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
