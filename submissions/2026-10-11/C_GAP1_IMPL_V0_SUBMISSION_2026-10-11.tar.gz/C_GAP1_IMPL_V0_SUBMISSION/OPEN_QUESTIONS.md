# OPEN_QUESTIONS — C 空白① 実装案 v0（Code、2026-10-11）

各項目には、Code が採った実装上の選択と、Judge の裁定が要るかどうかを書いた。NOT_VERIFIED の項目には、発出メモ N4 に従い、後で確かめるための数値テストの案を書いた。テストはどれも実行していない。

## A. Judge の裁定または確認が要る事項

**Q1. ①専用の pin manifest（`gap1_analysis/GAP1_RESUMABLE_PINS.json`）をまだ作っていない。**
- 共通 driver の `PINS_PATH` は、DIFF-E でこの path を指すように変えてある。
- この JSON は、実行環境が決まらないと書けない。中身は、ref、wheel dir と wheel SHA、python・pip・lscpu・os-release、commit 後の24ファイル（新規7本＋閉包17本）の blob である。
- このファイルを作るのは**実行の事前宣言の段階**とし、作成と監査の手順を Judge に決めてもらう必要がある。
- これは executable なファイルではなく、今回作った7本にも数えていない。

**Q2. 新しいパッケージには `__init__.py` を置いていない（PEP 420 の namespace package として扱う）。**
- `__init__.py` を足すと8本目のファイルになるため、置かなかった。baseline の `analysis/` も `__init__.py` のない namespace package である。
- そのため実行は、リポジトリの root から `python -m gap1_producer.global_axial_c1b_producer` の形で行う必要がある。checker も同様である。
- 同名の `gap1_*` が `sys.path` の上にほかにないことは、実行環境の側で保証してもらう必要がある。
- **NOT_VERIFIED。** テスト案：実行環境で `importlib.util.find_spec` を使い、`gap1_producer.global_axial_c1b_kernel`、`gap1_producer.global_axial_c1b_gating`、`gap1_analysis.c1b_resumable_driver` の各 origin と、`producer.*`／`checker.*` の17本の origin を出力する。これは数値計算をしない。ただしモジュールの解決を実際に行うので、Judge の許可が要る。

**Q3. L と X の負値ブロックで、baseline の mono 閉包が有効なままになっている。**
- L と X の負値ブロックには、baseline の `exterior_cover`／`eval_exterior` をそのまま（byte-identical で）使っている。
- この関数は直接 `g_box` で判定し、それで閉じない箱について、mono 閉包（右壁 g<0 と Gt<0 の組み合わせ）を `MONO_WORK_CAP` の範囲で試す。
- 数値契約 v1 では、`MONO_WORK_CAP` は L の cap（§4）にだけ書かれていて、X の負値ブロック（§5）には書かれていない。
- X でも mono 閉包を有効にしてよいか、確認してほしい。無効にする場合は、DIFF-B の差分を追加することになる。
- 数学的には、mono 閉包は G0/E1 v3 の範囲内の議論である。

**Q4. R の tube が t=1 に接する（right clamp）場合を拒否している。**
- `R_RIGHT_CLAMP_FORBIDDEN`。分類は `CERTIFICATE_INCONCLUSIVE/R_RIGHT_CLAMP_FORBIDDEN_INCONCLUSIVE` で、REFINE の対象になる。
- baseline では、clamp 時の右壁は B_ob receipt を使う方式であり、①ではこれが禁止されているため、拒否した。
- `CONTRACT_MISMATCH` として即停止する扱いのほうがよいかは、Judge に判断してもらいたい。
- なお、B_ob を用いる corner 証明書（`bob_covers`）は、C1b の参照領域 [9/20, 5/8] にもとづいて判定される。U1 のすべての slab は ll < 9/20 なので、この判定はもともと偽になる（静的 control 7）。

**Q5. L と X も含めて、160 slab 全体を λ の高い側から低い側へ処理する。**
- 契約が処理順を定めているのは R だけである。順序を一つの規則にそろえるため、全 slab に降順と right-child-first を適用した。
- L と X は predictor を使わないので、順序は結果に影響しない。checker はこの順序を独立に照合する（`gap1_plan_order_audit`）。
- 確認してほしい。

**Q6. C1b の参照領域の定数を残し、①の定数を別名で足した。**
- `L_LO=9/20`、`L_HI=5/8`、`DLAM=1/800`、`N_COARSE=140` は書き換えていない。理由は二つある。
  - baseline の preflight の数値 control（v211/v212 の C1 など）が、この領域で PASS することを期待値にしている。
  - B_ob の被覆判定がこの定数を使っている。
- ①の領域は `GAP1_*` の定数として追加し、DIFF-K に分類した。
- 指示書 §2 の DIFF-K「①固有の λ 境界」をこう読んでよいか、確認してほしい。
- 書き換える場合は、baseline の数値 control の期待値も選び直す必要があり、それは未規定の数値の選択になる。

## B. 実装上の選択（記録のための事項）

**Q7. endpoint の16箱は、seed が不成立でも必ずすべて評価する。**
- 指示書 §5 の「全て」に従った。仕事量は1 slab あたり 8192 + 16×8192 = 139,264 で固定である。
- seed の評価で `REndpointDomainGuard` などの例外が出た場合は、panel 数をそのまま work として計上する（保守的な計上。baseline の tube は 0 を計上する）。これは work の帳簿上の扱いだけで、判定には影響しない。

**Q8. `ENDPOINT_RESOURCE_CAP` は語彙として保持しているが、実行中に発生することはない。**
- endpoint の work は固定値（139,264）で、`ATTEMPT_WORK_CEILING` を下回る。
- baseline では `ATTEMPT_WORK_CEILING` は1 attempt ごとには強制されず、中断した attempt への課金にだけ使われている。この挙動は baseline のままにした。
- 資源上限に達した場合は、gating が decision=ABORT として記録する（`RESOURCE_CAP`）。

**Q9. `PRECISION_INCONCLUSIVE` と `APPROX_DEGREE_INCONCLUSIVE` は、実行中には区別できない。**
- 精度と次数は固定であり、どちらが原因で不確定になったかは判別できない。
- そのため、不確定はすべて `CERTIFICATE_INCONCLUSIVE/<reason>_INCONCLUSIVE` に分類する。両語は語彙として保持している。

**Q10. 実行中の import 閉包の self-check は baseline のままにした。**
- baseline の producer kernel は7本、checker kernel は9本を照合する。
- `checker/oblate_axis_prototype.py`（`df402583`）は、`producer/endpoint_interval_producer.py` から import されているが、どちらの kernel の self-check にも入っていない。
- 対応として、共通 driver の `REQUIRED_C1B_BLOB_PATHS` を「新規7本＋閉包17本」の24ファイルに広げた（DIFF-E）。これで環境 pin が17本すべてを照合する。kernel 側の self-check 自体は変えていない。
- 確認してほしい。

**Q11. `_v211_schema_counts` が、pin されていない baseline ファイルを読む。**
- 読むのは `analysis/c1b_cross_lineage_compare.py`（blob `33cdd3290bfa09c88cd8936e1f4557af491f0bc2`）の `A1_KEYS` リテラルで、AST として読むだけである。このファイルは7本にも17本にも入っていない。
- ①では `REPLAY_KEYS` を変えていないので、この control の期待値（15/16/14）はそのまま成り立つ。
- このファイルを pin の記録に加えるか、判断してほしい。

**Q12. replay plan の schema ラベルを変えた。**
- `GAP1_A1_REPLAY_V0` に変えて、C1b の plan と取り違えないようにした。
- `REPLAY_KEYS` は変えていない。region は、checker が厳密な λ の値から自分で決める。

**Q13. X の t=5/8 の閉辺については、追加の評価をしていない。**
- 下の tube のセル（t ≤ 5/8、Gt<0）と、負値ブロックの箱（t ≥ 5/8、g<0）が、どちらも閉区間として 5/8 を含むので、これで「overlap consistency only」とした。

**Q14. λ 境界の overlap 判定**
- 699/1600 では、L 側は L の証明書（t=1/2 を含む閉箱で g<0）、X 側は C1a の符号（負）を使う。どちらも根の数は0として照合する。
- 281/640 では、R の T_* が (1/2, 5/8) と交わることを厳密な有理数で確かめる。X 側は C1a の符号（正）から根の数を1とする。
- 9/20 では、R の端の slab の endpoint 証明書が PASS していることをもって、「B_ob(9/20) < 0 が帰結し、receipt の B_ob<0 on [9/20, 5/8] と一致する」と記録する。

**Q15. 新しい経路（L、X、endpoint）用の、合成スタブによる preflight control はまだ足していない。**
- baseline の `diagnostic_controls` に相当するものである。足す場合は DIFF-K の追加になる。差分監査で求められれば追加する。

## C. NOT_VERIFIED（静的検査では確定できないもの）と、後で行う数値テストの案（実行は未許可）

| 項目 | 理由 | 後で行うテストの案 |
|---|---|---|
| namespace package と動的 gating import が、実行時に正しく解決されること | 実行環境の `sys.path` に依存する | Q2 の `find_spec` による origin 出力。あるいは `--ledger-only` の preflight で、`C1B_V212_C6_*` の出力に `gap1_producer_v212_c6_*.json` が書かれることを確認する |
| preflight 全体（baseline の数値 control と、`c1a_preflight`／`gap1_domain_controls`）が PASS すること | baseline の数値 control は数値評価を含む | 両系統で `python -m gap1_producer.global_axial_c1b_producer --ledger-only` を走らせる（checker も同様）。成功条件は、全 control が PASS で、`GAP1_C1A_PIN_CHECK PASS` と `GAP1_DOMAIN_CONTROL ... PASS` が7件出ること |
| endpoint gate の区間算術（上側丸め、max(0,U_j) の扱い） | 実行時の挙動 | 合成スタブで `g_box`／`gt_box` を差し替えた control（例：seed=−1、U_j=+1 で U_cum=−1+16/512<0 になり PASS／seed=−1/64、U_j=+1 で FAIL）を DIFF-K として追加する案。Q15 を参照 |
| L/X/R のそれぞれで証明書が閉じるかどうか | 数値結果そのもの | 本走でしか確かめられない（Judge の実行許可が要る） |
| producer と checker が同じ木を作ること（plan の順序、decision、L/X の null field） | 実行時の挙動 | 小さな slab 集合での replay smoke（許可が要る）。あるいは本走後に checker の `GAP1_PLAN_ORDER_AUDIT PASS` を確認する |

NONE 以外の項目は以上である。
