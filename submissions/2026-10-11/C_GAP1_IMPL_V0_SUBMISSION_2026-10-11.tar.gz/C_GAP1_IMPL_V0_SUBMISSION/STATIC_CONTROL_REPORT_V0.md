# STATIC_CONTROL_REPORT_V0 — C 空白① 実装案 v0（Code、2026-10-11）

指示書 v2 §9 の静的 control 1–10 と、補助の control 0（未解決名の検査）の結果。どの control も、ソースの文字列、SHA-256、git blob、AST、symtable、リテラル定数の厳密な Fraction 計算だけを使う。リポジトリのモジュールは import も実行もしていない。g_box、gt_box、interval kernel、producer、checker、driver のどれも呼んでいない。

## 0. 総括

`SUMMARY C0=PASS C1=PASS C2=PASS C3=PASS C4=PASS C5=PASS C6=PASS C7=PASS C8=PASS C9=PASS C10=PASS`

FAIL は0件。NOT_VERIFIED は、実行時の namespace package の解決（control 9 の注記）だけで、OPEN_QUESTIONS の Q2 と §C に移した。

## 1. 実行したコマンド（作業領域は Code の scratchpad。リポジトリには書いていない）

```
# baseline の取り出し（bg-oblate-spheroid、85eca2288732a3cac65f4d5f87ecfd2ba5ce2e9b。この行と最後の compile-only の行は、行った操作と同等のコマンドを再構成したもの。他の行は、提出前の再現実行で使ったコマンドそのもの）
git -C bg-oblate-spheroid archive 85eca228 producer checker analysis | tar -x -C tree
# 7本の生成（文字列の厳密置換57件。各置換は一意一致を要求する）
python3 -I build/build_gap1.py tree out > build/build_log.txt          # 末尾 "EDITS 57"
# hunk の分類（difflib、文脈3行）
python3 -I static_controls/hunk_classify.py out "$(cat static_controls/pairs.json)" out/gap1_edit_log.json > static_controls/hunk_table.tsv
# 静的 control
python3 -I static_controls/static_controls.py out authority static_controls/hunk_table.tsv > static_controls/static_controls.stdout
# 補助：compile-only（import 実行なし）
python3 -I -c "import ast,sys; [compile(open(p).read(), p, 'exec', flags=ast.PyCF_ONLY_AST) for p in sys.argv[1:]]" out/gap1_*/*.py
```

`authority/` には、bg-spheroid-family main e34f6a09 から `git show` で取り出した拘束文書の写しを置いた。

**再現性。** 提出の直前に、空のディレクトリで baseline から作り直した。build_log、edit log、7本、hunk_table.tsv、static_controls.stdout は、すべて byte 一致した。

**スクリプトの SHA-256：**

| script | SHA-256 |
|---|---|
| `build/build_gap1.py` | 7dbeaa212a7db0232b8138832b43bae4925bd6e0b14e3df1c2764e0c387e1b9e |
| `static_controls/hunk_classify.py` | de82a47c39fd489acbaf1a1ec6031baa639743a243988de6151f71c8e119f7d4 |
| `static_controls/static_controls.py`（最終版） | b0fe73318f215642b530e61378c1f4d772047146898dd9e5f4e76f4d76dde568 |

`static_scripts_sha256_pre_run.txt` には、各実行の直前に記録した SHA を残してある。1行目の `7c53607b…` は、下の §3 で述べる修正前の static_controls.py の値である。

## 2. control ごとの結果

| # | 内容 | 判定 | 根拠（static_controls.stdout） |
|---|---|---|---|
| 0 | 新しい7本に未解決のグローバル名がない | PASS | 未解決名 0 |
| 1 | pin と import の照合：baseline 7本、import 15本と追加2本（B1 記録 b48887c1）、コード中の authority SHA と baseline／閉包の定数を、実測値と照合する | PASS | baseline 7/7、import 15/15 と 2/2、authority 9件×2系統が一致、`GAP1_BASELINE_BLOBS`／`GAP1_IMPORT_CLOSURE_17` が 7+17 で一致 |
| 2 | 新規ファイルの数、`__init__.py` を足していないこと、baseline を編集していないこと | PASS | gap1_*.py は7本、`__init__.py` は0本。baseline は control 1 の blob 照合で無変更。bg-oblate-spheroid と bg-spheroid-family の作業ツリーはどちらも `git status` が空 |
| 3 | どの hunk も、DIFF 分類一つだけに対応する（N4 の表は §4） | PASS | 49 hunk、未分類と混在は0。K 20、A 5、B 2、C 2、D 2、E 18 |
| 4 | 保護対象の関数と定数が byte 一致すること（N4 の表は §4） | PASS | g_box、gt_box、密度、P1 scan、P2 選択、choose_predictor、根の局在化、tube、exterior、mono、attempt／attempt_replay、および W0、PRED_ACCEPT、ROOT_TARGET、BITS、DEG、stages、panels、C1b の参照領域が一致。変わった baseline 関数は下の表のとおり |
| 5 | L/X から predictor と根の関数に到達できない | PASS | attempt_l、attempt_x、x_lower_tube、endpoint_gate から禁止関数に到達しない（両系統）。dispatcher で R を呼ぶのは1か所だけ |
| 6 | R の順序規則 | PASS | coarse は降順、REFINE は live と resume の両方で right-child-first、checker は plan の順序を照合する。P2 は `<= ROOT_TARGET`（等号のときは continuation）。P0 は 9/16、その後は隣の ACCEPT の中点。previous_root は ACCEPT のときだけ更新する |
| 7 | endpoint gate の構造 | PASS | 31/32 での seed g_box は1回、gt_box は16箱のループ内、成功の代入は1か所、B_ob／C_Λ／根の経路はなく、dispatcher は gate を必須にしている。U1 では `bob_covers` は成り立ち得ない（ll < 9/20 ≤ L_LO） |
| 8 | region の格子、owner、overlap | PASS | 1/3200 の格子で 118/7/35、またぐ slab なし。owner：699/1600 は X、281/640 は R、9/20 は整合だけ、t=5/8 は X の負値ブロック、t=31/32 は endpoint seed。overlap の検査は両系統で、厳密な和集合の後に行う |
| 9 | 系統の分離と import | PASS（実行時の解決は NOT_VERIFIED） | checker は producer 系を import しない。producer が checker を import するのは、17本の中の pin された baseline の辺だけ。共通 driver は stdlib だけを使う。動的な gating import は自分の gap1 package を指し、その path がソース上に存在する |
| 10 | 数値契約の定数 | PASS | 160/192 bit、次数50、caps 3/1280/2400、ceilings 25.6M/61.44G/32.768G、stages、panels、endpoint は 16×1/512・seed 31/32・8192 panels、格子は 1/3200 で 118/7/35、失敗分類と ledger の key |

**control 4 で、変更された baseline 関数（すべて allowlist 内）：**

| ファイル | 変更された baseline 関数 | 分類 |
|---|---|---|
| gap1_producer kernel | `coarse_ledger`（A）、`preflight`（K） | A、K |
| gap1_producer gating | `replay`（A/E）、`estimates`（K）、`header_payload`（K）、`run_full`（A/E） | A、E、K |
| gap1_checker kernel | `preflight`（K） | K |
| gap1_checker gating | `replay_state`（E）、`estimates`（K）、`header_payload`（K）、`run_full`（A/E） | A、E、K |
| producer/checker の入口、driver | 関数本体の変更なし（import と定数だけ） | E |

関数ごとの hunk は §4 の表に示した。一つの hunk には一つの分類だけが対応する。

## 3. 途中の FAIL とその修正（記録）

`static_controls_run1.stdout` は、最初の実行の出力をそのまま残したものである。そこでは C7 が FAIL だった。

- 原因は control の側にあった。「B_ob／C_Λ への経路がない」ことを、ソースの文字列の部分一致で調べていた。そのため、コメント中の語（"C_Lambda"、"B_ob"）に一致した。
- 修正として、AST の識別子と定数だけを調べるようにした。実装コードは変えていない。
- 修正後の最終版が b0fe7331… で、全 PASS になった。

## 4. N4：hunk ごとの表（control 3 と 4）

baseline と新しいファイルそれぞれの行範囲、分類、対応する edit を示す。`diffs/*.diff` の各 `@@` 行にも、同じ分類を書いてある。

| # | new file | hunk | baseline lines | new lines | −/+ lines | category | edit label(s) |
|---|---|---|---|---|---|---|---|
| 1 | `gap1_producer/global_axial_c1b_kernel.py` | 1 | 29–35 | 29–35 | −1/+1 | DIFF-K | caps |
| 2 | `gap1_producer/global_axial_c1b_kernel.py` | 2 | 49–56 | 49–56 | −2/+2 | DIFF-K | work ceilings |
| 3 | `gap1_producer/global_axial_c1b_kernel.py` | 3 | 59–64 | 59–164 | −0/+100 | DIFF-K | constants/domain |
| 4 | `gap1_producer/global_axial_c1b_kernel.py` | 4 | 84–94 | 184–192 | −5/+3 | DIFF-A | descending queue |
| 5 | `gap1_producer/global_axial_c1b_kernel.py` | 5 | 883–888 | 981–1028 | −0/+42 | DIFF-K | U1 controls |
| 6 | `gap1_producer/global_axial_c1b_kernel.py` | 6 | 1206–1211 | 1346–1399 | −0/+48 | DIFF-B | X fixed path |
| 7 | `gap1_producer/global_axial_c1b_kernel.py` | 7 | 1426–1431 | 1614–1705 | −0/+86 | DIFF-D | endpoint gate |
| 8 | `gap1_producer/global_axial_c1b_kernel.py` | 8 | 1586–1591 | 1860–1878 | −0/+13 | DIFF-C | L negative path |
| 9 | `gap1_producer/global_axial_c1b_kernel.py` | 9 | 1644–1649 | 1931–1957 | −0/+21 | DIFF-E | region dispatcher |
| 10 | `gap1_producer/global_axial_c1b_kernel.py` | 10 | 1814–1820 | 2122–2130 | −1/+3 | DIFF-K | preflight banner |
| 11 | `gap1_producer/global_axial_c1b_kernel.py` | 11 | 1845–1848 | 2155–2160 | −0/+2 | DIFF-K | preflight controls |
| 12 | `gap1_producer/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 13 | `gap1_producer/global_axial_c1b_gating.py` | 2 | 142–147 | 142–266 | −0/+119 | DIFF-E | ledger/overlap/union helpers |
| 14 | `gap1_producer/global_axial_c1b_gating.py` | 3 | 328–337 | 447–456 | −2/+2 | DIFF-A | live right-child-first; resume replay right-child-first |
| 15 | `gap1_producer/global_axial_c1b_gating.py` | 4 | 341–347 | 460–466 | −1/+1 | DIFF-E | replay schema label |
| 16 | `gap1_producer/global_axial_c1b_gating.py` | 5 | 389–400 | 508–519 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 17 | `gap1_producer/global_axial_c1b_gating.py` | 6 | 402–407 | 521–556 | −0/+30 | DIFF-K | U1 header metadata block |
| 18 | `gap1_producer/global_axial_c1b_gating.py` | 7 | 412–418 | 561–568 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 19 | `gap1_producer/global_axial_c1b_gating.py` | 8 | 427–433 | 577–583 | −1/+1 | DIFF-K | header coarse cap |
| 20 | `gap1_producer/global_axial_c1b_gating.py` | 9 | 550–558 | 700–708 | −2/+2 | DIFF-E | dispatch + record |
| 21 | `gap1_producer/global_axial_c1b_gating.py` | 10 | 592–598 | 742–748 | −1/+1 | DIFF-A | live right-child-first |
| 22 | `gap1_producer/global_axial_c1b_gating.py` | 11 | 601–619 | 751–767 | −7/+5 | DIFF-E | exact union + overlap; segment end overlap record |
| 23 | `gap1_producer/global_axial_c1b_gating.py` | 12 | 622–627 | 770–777 | −0/+2 | DIFF-E | overlap failure after segment end |
| 24 | `gap1_producer/global_axial_c1b_producer.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |
| 25 | `gap1_analysis/c1b_resumable_driver.py` | 1 | 18–34 | 18–51 | −9/+26 | DIFF-E | pin manifest path / chain label; pinned blob paths (7 new + 17 closure) |
| 26 | `gap1_checker/global_axial_c1b_kernel.py` | 1 | 30–36 | 30–36 | −1/+1 | DIFF-K | caps |
| 27 | `gap1_checker/global_axial_c1b_kernel.py` | 2 | 50–57 | 50–57 | −2/+2 | DIFF-K | work ceilings |
| 28 | `gap1_checker/global_axial_c1b_kernel.py` | 3 | 60–65 | 60–165 | −0/+100 | DIFF-K | constants/domain |
| 29 | `gap1_checker/global_axial_c1b_kernel.py` | 4 | 876–881 | 976–1023 | −0/+42 | DIFF-K | U1 controls |
| 30 | `gap1_checker/global_axial_c1b_kernel.py` | 5 | 1183–1188 | 1325–1378 | −0/+48 | DIFF-B | X fixed path |
| 31 | `gap1_checker/global_axial_c1b_kernel.py` | 6 | 1403–1408 | 1593–1684 | −0/+86 | DIFF-D | endpoint gate |
| 32 | `gap1_checker/global_axial_c1b_kernel.py` | 7 | 1563–1568 | 1839–1857 | −0/+13 | DIFF-C | L negative path |
| 33 | `gap1_checker/global_axial_c1b_kernel.py` | 8 | 1630–1635 | 1919–1948 | −0/+24 | DIFF-E | region dispatcher |
| 34 | `gap1_checker/global_axial_c1b_kernel.py` | 9 | 1802–1808 | 2115–2123 | −1/+3 | DIFF-K | preflight banner |
| 35 | `gap1_checker/global_axial_c1b_kernel.py` | 10 | 1832–1835 | 2147–2152 | −0/+2 | DIFF-K | preflight controls |
| 36 | `gap1_checker/global_axial_c1b_gating.py` | 1 | 14–20 | 14–20 | −1/+1 | DIFF-E | driver import |
| 37 | `gap1_checker/global_axial_c1b_gating.py` | 2 | 142–147 | 142–266 | −0/+119 | DIFF-E | ledger/overlap/union helpers |
| 38 | `gap1_checker/global_axial_c1b_gating.py` | 3 | 312–318 | 431–437 | −1/+1 | DIFF-E | replay schema label |
| 39 | `gap1_checker/global_axial_c1b_gating.py` | 4 | 320–325 | 439–463 | −0/+19 | DIFF-A | checker plan-order audit |
| 40 | `gap1_checker/global_axial_c1b_gating.py` | 5 | 343–348 | 481–494 | −0/+8 | DIFF-E | checker L/X field verification |
| 41 | `gap1_checker/global_axial_c1b_gating.py` | 6 | 364–372 | 510–518 | −2/+2 | DIFF-E | resume previous_root for L/X |
| 42 | `gap1_checker/global_axial_c1b_gating.py` | 7 | 389–400 | 535–546 | −3/+3 | DIFF-K | estimates coarse count; estimates coarse label |
| 43 | `gap1_checker/global_axial_c1b_gating.py` | 8 | 402–407 | 548–583 | −0/+30 | DIFF-K | U1 header metadata block |
| 44 | `gap1_checker/global_axial_c1b_gating.py` | 9 | 412–418 | 588–595 | −1/+2 | DIFF-K | header domain + U1 metadata |
| 45 | `gap1_checker/global_axial_c1b_gating.py` | 10 | 427–433 | 604–610 | −1/+1 | DIFF-K | header coarse cap |
| 46 | `gap1_checker/global_axial_c1b_gating.py` | 11 | 467–472 | 644–650 | −0/+1 | DIFF-A | checker plan-order audit call |
| 47 | `gap1_checker/global_axial_c1b_gating.py` | 12 | 532–550 | 710–732 | −5/+9 | DIFF-E | checker accept rule for L/X; checker dispatch + record + field checks; checker root outcome for L/X |
| 48 | `gap1_checker/global_axial_c1b_gating.py` | 13 | 564–581 | 746–766 | −6/+9 | DIFF-E | checker exact union + overlap; checker segment end overlap record; overlap failure after segment end |
| 49 | `gap1_checker/global_axial_c1b_checker.py` | 1 | 1–6 | 1–6 | −3/+3 | DIFF-E | entry imports |

## 5. B3：ハードコードされた path と動的 import の一覧（`static_controls/b3_path_inventory.txt`）

| 呼び出し箇所 | 実行時に解決される先（root から `python -m` で起動した場合） | 判定 |
|---|---|---|
| kernel の `importlib.import_module(lineage + ".global_axial_c1b_gating")` | `lineage = __name__.split(".")[0]` から、`gap1_producer.global_axial_c1b_gating` または `gap1_checker.…` | 自分の系統の新しいファイル（静的に path が存在することは control 9 で確認） |
| kernel の `BOB_RECEIPT`、`C1A_RECEIPT` | `analysis/GLOBAL_AXIAL_C1B_BOB_MACHINE_RECEIPT.md`、`analysis/GLOBAL_AXIAL_C1A_MACHINE_RECEIPT.md`（baseline と共有、読むだけ） | C1A は `c1a_preflight` で blob を照合（e494e789）。BOB は baseline の照合のまま |
| kernel の `GAP1_BASELINE_BLOBS` の `analysis/c1b_resumable_driver.py` | baseline の blob の記録（識別のための定数で、読み込みはしない） | 照合用の定数 |
| kernel の `Path(__file__).with_name("global_axial_c1b_gating.py")` | 自分の系統の gating（`_v211_schema_counts` が AST として読む） | 新しいファイル |
| kernel の `Path(__file__).parents[1] / "analysis" / "c1b_cross_lineage_compare.py"` | baseline の compare.py（33cdd329、AST だけ、pin なし） | OPEN_QUESTIONS Q11 |
| kernel の import 閉包の self-check（`C1B_NUMERIC_ROOTS`、package="producer"/"checker"） | baseline の `producer/`／`checker/` の数値モジュール | baseline のまま（Q10） |
| kernel の preflight の `C1B_PREFLIGHT_RECORD_DIR` | 環境変数で与える出力先 | baseline のまま |
| gating の `checker_replay_exact.jsonl`、`run_dir` | 実行時の run ディレクトリ | baseline のまま |
| driver の `PINS_PATH = gap1_analysis/GAP1_RESUMABLE_PINS.json` | ①専用の pin manifest（まだ作っていない） | Q1 |
| driver の `/etc/os-release`、`wheel_dir`、`C1B_PREFLIGHT_RECORD_DIR` | 環境の snapshot | baseline のまま |

## 6. NOT_VERIFIED（OPEN_QUESTIONS §C に移した）

- 実行時に namespace package と動的 gating import が正しく解決されること。テスト案は `find_spec` による origin の出力。
- preflight 全体が PASS すること。baseline の数値 control を含む。
- endpoint gate の区間算術の挙動。合成スタブによる control の案がある。
- 証明書が閉じるかどうか。
- producer と checker が同じ木を作ること。

どのテストも実行していない。実行には Judge の許可が要る。
