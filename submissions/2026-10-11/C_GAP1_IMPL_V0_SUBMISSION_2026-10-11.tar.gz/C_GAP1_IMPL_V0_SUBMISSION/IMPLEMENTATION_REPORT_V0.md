# IMPLEMENTATION_REPORT_V0 — C 空白① 実装案 v0（Code、2026-10-11）

## 0. 位置づけと立場

- **拘束文書。** 指示書 v2（48204988…、300行）と発出メモ（51a167c7…）。どちらも bg-spheroid-family main e34f6a098f8376cf8f64c606ddda9400f1c66079（親 0b430ed7fab0d18e8442722118fd5440f62784eb、STATE v1.20 519546d7…）にある。発出メモ N1 に従い、基準は main 0b430ed7 と読み、B1 と B2 の裁定に従った。
- **Code の立場。** Code は実装者であり、監査者ではない。この提出物について Code が自分で行った静的 control は、自己点検にすぎない。差分監査は、N3 のとおり ChatGPT と chat がそれぞれ独立に行う。
- **やっていないこと。** 数値の実行、producer／checker／driver の実行、g_box／gt_box／interval kernel の呼び出し、smoke run、証明書や receipt の生成、commit、push、既存ファイルの変更、FREEZE。リポジトリの既存の未追跡ファイルにも触れていない。
- **提出の形。** すべての成果物は Code の scratchpad で作り、この tar.gz 一つにまとめた。

## 1. 環境

| 項目 | 値 |
|---|---|
| 作業場所 | Code のクラウドコンテナ内の scratchpad（`gap1_impl/`） |
| Python | 3.11.15。build スクリプトと静的 control の実行だけに使った（`-I`） |
| baseline | bg-oblate-spheroid、commit 85eca2288732a3cac65f4d5f87ecfd2ba5ce2e9b（branch design/d-ob-p2 などに含まれる）。`git archive` で producer/、checker/、analysis/ を取り出した |
| authority | bg-spheroid-family e34f6a09 から `git show` で取り出した写し。SHA-256 は §2 |
| 作業前後のリポジトリ | bg-oblate-spheroid と bg-spheroid-family はどちらも、提出時点で `git status --short --untracked-files=all` が空（作業はすべて scratchpad で行い、リポジトリには書いていない）。commit も push もしていない。bg-oblate-spheroid の HEAD は 99467ed5（design/d-ob-p2）。bg-spheroid-family のローカル main は d707e6ef のままで、e34f6a09 は object として取得して読んだだけ |

## 2. authority の SHA-256（コード中の `GAP1_AUTHORITY_SHA256` と一致。control 1）

| 文書 | SHA-256 |
|---|---|
| `CHAT_RECORD_GAP1_IMPORT_CLOSURE_17_2026-10-11.md` | b48887c194b153ebbb12a652fc797ed79724e7212215b2471a780769564144d4 |
| `C_GAP1_CONTRACT_DRAFT_V7.md` | a49148180fdeb33272e7358028caa55ec1dc06e5d4f526cd23eca50ff65c2a37 |
| `C_GAP1_IMPLEMENTATION_DESIGN_DRAFT_V2.md` | 0a407d1bec2d491befc2bdaee7dbfff29b3f93bf54f3aef466093dd9453038d1 |
| `C_GAP_ENDPOINT_ADDENDUM_DRAFT_V2.md` | 7471800d81caabdbbe3bfb5c8dc2e020434adbd0a67ed4e6bbd38afbea33d3a4 |
| `C_GAP_NUMERIC_CONTRACT_DRAFT_V1.md` | be67046f8bb2d6cb5b3c0e615ee7edb1338d91956f6eb1aa2701217c05600d07 |
| `G0_E1_UNIFORM_GT_PAPER_PROOF_DRAFT_V3.md` | 8bf8f5d87cfc2e6f424499804b0fd85d982cf480deb99a26c284367960578671 |
| `CHAT_RECORD_V7_CLARIFICATIONS_2026-10-11.md` | 541f3025728e027467433d2ff05ef12299b7cc2c6488fbe8bf2febe73fcf4d7c |
| `C_GAP1_CODE_IMPLEMENTATION_INSTRUCTION_DRAFT_V2_2026-10-11.md` | 48204988953911195a00789536956657556984cea1067486120e70e610cb9e6f |
| `ISSUE_NOTE_C_GAP1_IMPLEMENTATION_INSTRUCTION_V2_2026-10-11.md` | 51a167c7d37c244195df7d2f55a0d761f60593010ec22dba4f649eb7bdcbac5b |

## 3. 新しい7本の path、役割、import の解決

| 新しい path | 元にした baseline | 役割 | 通常の import の解決先 |
|---|---|---|---|
| `gap1_producer/global_axial_c1b_kernel.py` | `producer/global_axial_c1b_kernel.py` | producer kernel（160 bit）。①の定数、L/X 経路、endpoint gate、dispatcher、preflight の追加 control | stdlib、flint、`producer.global_axial_c0_producer`、`producer.c0a_four_group_v2`、`producer.global_axial_c1b_endpoint_r`、`producer.global_axial_c0_producer_v2`、`producer.monotone_tube_refinement_producer`（すべて17本の中） |
| `gap1_producer/global_axial_c1b_gating.py` | `producer/global_axial_c1b_gating.py` | producer の gating（キュー、ledger、replay plan、和集合と overlap） | stdlib、`gap1_analysis.c1b_resumable_driver` |
| `gap1_producer/global_axial_c1b_producer.py` | `producer/global_axial_c1b_producer.py` | 入口 | `gap1_producer.*`、`gap1_analysis.*` |
| `gap1_analysis/c1b_resumable_driver.py` | `analysis/c1b_resumable_driver.py` | 共通の非数値 driver（B2） | stdlib だけ |
| `gap1_checker/global_axial_c1b_kernel.py` | `checker/global_axial_c1b_kernel.py` | checker kernel（192 bit） | stdlib、flint、`checker.global_axial_c0_checker`、`checker.c0a_four_group_v2`、`checker.monotone_tube_refinement_checker`、`checker.monotone_tube_interval_checker`、`checker.global_axial_c1b_endpoint_r`、`checker.global_axial_c0_checker_v2`（すべて17本の中） |
| `gap1_checker/global_axial_c1b_gating.py` | `checker/global_axial_c1b_gating.py` | checker の gating（plan の順序の照合、自分で計算した結果による和集合と overlap） | stdlib、`gap1_analysis.c1b_resumable_driver` |
| `gap1_checker/global_axial_c1b_checker.py` | `checker/global_axial_c1b_checker.py` | 入口 | `gap1_checker.*`、`gap1_analysis.*` |

- **動的 import。** kernel の `importlib.import_module(lineage + ".global_axial_c1b_gating")` は、`lineage = __name__.split(".")[0]` なので、自分の系統の gap1 gating に解決される。
- **preflight の path。** C1A receipt は blob を照合し、BOB receipt は baseline の照合のまま。compare.py は AST として読むだけ（Q11）。一覧は STATIC_CONTROL_REPORT §5。
- **起動の方法。** リポジトリの root から `python -m gap1_producer.global_axial_c1b_producer`（checker も同様）で起動する前提である。実行時の解決は NOT_VERIFIED（Q2）。

## 4. pin の表（変更前の blob → 変更後の SHA-256 と blob）

| 新しい path | 変更前の blob（baseline） | 変更後の SHA-256 | 変更後の blob | 行数 |
|---|---|---|---|---|
| `gap1_producer/global_axial_c1b_kernel.py` | 67dda838369302010ef3d589937b834b96ede4d8 | d8bab9fd3bd7e9daf240bc3686bc718c39c028a446a81028fddd60799abd611c | a9c214d0e29bed8be561aab967070cd0accd8346 | 2160 |
| `gap1_producer/global_axial_c1b_gating.py` | a93ca173ae0bededcd5a0248aa07ac3348f9a243 | b5cbf1671fbb88f2d913d7753c37874cb820b3dc8e135eb566e88dc6d17c81a5 | 234c314f99d37c1f5980b215729680c04665560a | 793 |
| `gap1_producer/global_axial_c1b_producer.py` | 0616fbd7c9c85f77c8e80b61a5b3b536b45012a8 | 952caa157e8017cf519a28fce1109f52bab37666442038d3eb3aa1949db83da7 | 34ef3758382de5993116c49d511b5b68e4e87bfa | 6 |
| `gap1_analysis/c1b_resumable_driver.py` | 5fd308bb4c02c6ddbd612ddbedb18f6b9e22bc3d | f8b9d597953288bd5ecee749a38f64caeb8a578cd567d77004c26dc3b17035a9 | 42c71f2b81b0af78e2690ad5cd800299e33491ce | 390 |
| `gap1_checker/global_axial_c1b_kernel.py` | 4eaca55ddf79b437fc756d666294372e5d1a6ba4 | 2db35e7241bc37e512dbc369d5eebf78d9f0366baf0a6dcc613940200cf02bfe | 9bb9912cb7eabd499ac3b30afb28cab4e347a6dd | 2152 |
| `gap1_checker/global_axial_c1b_gating.py` | 03df262012bfbebcf4d2ea173933186c70abafbf | e33a6342a0339dc542fdc1d9a3a92c568f7e518a7c5b0cd23a72d7acd6be5ac8 | 90e09c96d40ff0915cfee71b418e847e5788b070 | 782 |
| `gap1_checker/global_axial_c1b_checker.py` | 0760764ef7592be1ddd4ffec3966e9c6ec930a5b | 705c86eb853aa29bc127e43a06e45813995eea6315b2227a1536e2c38470245e | 5b526ddc4f48dc01d3f95eafb44f3d638e2e35ed | 6 |

7本とも AST の parse と compile-only を通る。baseline から `build/build_gap1.py` で作り直すと、byte 一致で再現する。

## 5. import 閉包17本（当初15本＋補足2本、記録 b48887c1）

baseline 85eca228 の tree で実測した blob と、記録の値を照合した。

| # | path | 区分 | blob | 照合 |
|---|---|---|---|---|
| 1 | `producer/monotone_tube_refinement_producer.py` | 当初15 | c2fee40053ab055ce352e93e1c6d1fc43e46310a | MATCH |
| 2 | `checker/monotone_tube_refinement_checker.py` | 当初15 | 15d660265552fc2f2c83ffe897ed5efab8514da2 | MATCH |
| 3 | `checker/monotone_tube_interval_checker.py` | 当初15 | f2fa2a5a42d35b8b77e3c63fa0d9ad48ce562a77 | MATCH |
| 4 | `producer/global_axial_c1b_endpoint_r.py` | 当初15 | 29d441a578f10fe7f4beb38476d3699f3648a3b1 | MATCH |
| 5 | `checker/global_axial_c1b_endpoint_r.py` | 当初15 | 1a953b22c12a89afc06790b28d6b0dea9680dc43 | MATCH |
| 6 | `producer/endpoint_interval_producer.py` | 当初15 | 51060fea01cb9ff661518b7c52146f71187846ff | MATCH |
| 7 | `producer/monotone_tube_interval_producer.py` | 当初15 | b6d96df223c0e423e804d96f4892a8e818c05827 | MATCH |
| 8 | `producer/global_axial_c0_producer.py` | 当初15 | c4c8d6b59d3829e1843d149b7857eda5800287aa | MATCH |
| 9 | `checker/global_axial_c0_checker.py` | 当初15 | 85978625e029b01c8ae40fa8234566f10eea251c | MATCH |
| 10 | `checker/endpoint_local_controls.py` | 当初15 | c913c47d228e51a15f56957f5df9196efa1b22c3 | MATCH |
| 11 | `checker/oblate_axis_prototype.py` | 当初15 | df402583c320c459ff4f72dc5294558f14f44d31 | MATCH |
| 12 | `checker/endpoint_interval_checker.py` | 当初15 | 4cb16f8a975e5a3be601a7926af695ad5be57790 | MATCH |
| 13 | `checker/endpoint_local_checker.py` | 当初15 | 2bddddf6e9a08ca7acae94c89bd4d5ab1de861bc | MATCH |
| 14 | `producer/global_axial_c0_producer_v2.py` | 当初15 | cdbdf51f8656c1fcae97666cc1846461b250a591 | MATCH |
| 15 | `checker/global_axial_c0_checker_v2.py` | 当初15 | fbec890588d2d390ea67bc90116b80bb37ebf9cc | MATCH |
| 16 | `producer/c0a_four_group_v2.py` | 補足2（b48887c1） | 2bb556ab4f0c0cfd9ce6afa65d762551dd3791f4 | MATCH |
| 17 | `checker/c0a_four_group_v2.py` | 補足2（b48887c1） | 18e66b6450cd2a379bbb869a99e4e5ce6999f6e5 | MATCH |

結果は 17/17 MATCH。どれも編集していない。

- **shadowing。** 新しい package 名（`gap1_producer`、`gap1_checker`、`gap1_analysis`）は baseline のどの path とも衝突しない。新しいファイルは `producer.*`／`checker.*` を名前で直接 import するので、baseline の17本を shadow しない。`__init__.py` は置いていない（Q2）。
- **driver の pin。** 共通 driver の `REQUIRED_C1B_BLOB_PATHS` は、新規7本と17本を合わせた24 path に広げた（Q10）。

## 6. 差分の構成（edit 57件、hunk 49件）

| ファイル | DIFF の分類ごとの edit 数 |
|---|---|
| gap1_producer kernel | K 6、A 1、B 1、C 1、D 1、E 1 |
| gap1_producer gating | E 7、K 5、A 2 |
| gap1_producer の入口 | E 1 |
| gap1_analysis driver | E 2 |
| gap1_checker kernel | K 6、B 1、C 1、D 1、E 1 |
| gap1_checker gating | E 11、K 5、A 2 |
| gap1_checker の入口 | E 1 |

hunk ごとの分類と行範囲は STATIC_CONTROL_REPORT §4 にある。diff の全文は `diffs/ALL_7_FILES.diff`（ファイル別のものもある）。

## 7. 設計上の判断（詳細と、Judge の確認が要る点は OPEN_QUESTIONS）

1. **R の数値経路は baseline のまま。** R は baseline の `attempt`／`attempt_replay` を変更なしで呼び、その後に endpoint gate をかける。predictor、根、tube、exterior、mono の関数は byte 一致である（control 4）。R の right clamp は拒否する（Q4）。
2. **L/X は新しい関数で扱う。**
   - `attempt_l`：[1/2, 31/32] で、baseline の `exterior_cover` による g<0。
   - `attempt_x`：まず `x_lower_tube` で [1/2, 5/8] の Gt<0 を示す（X-T0/T1/T2、壁は使わない）。次に [5/8, 31/32] の g<0。
   - L/X から predictor や根の関数には到達しない（control 5）。L/X の replay で t_c が非 null なら `CONTRACT_MISMATCH` で停止する。
3. **endpoint gate（DIFF-D）は、全 region で成功の必要条件にした。**
   - seed は 31/32 での g_box 1回。そのあと gt_box を16箱計算する。j=15 は corner dispatch。
   - U_cum = G_seed + Σ (1/512)·max(0, U_j) を、厳密な有理数で記録する。
   - 成功条件は U_cum<0 だけ。B_ob、C_Λ、根の経路は使わない（control 7）。
4. **順序。** coarse の 160 slab を λ の降順で処理し、REFINE は right-child-first にした。checker は、plan の順序を自分で作り直して照合する（control 6、Q5）。
5. **定数。** C1b の参照領域の定数は残し、①の定数を `GAP1_*` として追加した（Q6）。資源上限、精度、次数は数値契約 v1 のとおり（control 10）。
6. **ledger と replay。** chain は `GAP1_JSONL_CHAIN_V1`、replay schema は `GAP1_A1_REPLAY_V0`。`REPLAY_KEYS` は baseline のまま。詳細は LEDGER_AND_REPLAY_SCHEMA_V0.md にある。
7. **停止の順序。** overlap の失敗は、segment_end と最終行を書いた後に停止する。overlap を先に判定し、和集合を後に判定する。

## 8. 提出物の一覧（tar.gz の中身。全ファイルを `MANIFEST.sha256` に載せた）

| path | 内容（指示書 §10 の番号） |
|---|---|
| `IMPLEMENTATION_REPORT_V0.md` | この報告（1、3、4） |
| `new_files/gap1_*/*.py` | 新しい7本の全文（2） |
| `diffs/*.diff`、`diffs/ALL_7_FILES.diff` | 全文の unified diff。各 hunk に DIFF の分類を書いた（2） |
| `STATIC_CONTROL_REPORT_V0.md` | control 0–10、コマンド、N4 の hunk 表、B3（5） |
| `static_controls/` | static_controls.py、hunk_classify.py、pairs.json、出力（最終版と run1）、hunk_table.tsv/.md、スクリプトの SHA、B3 の一覧（5） |
| `build/` | build_gap1.py、build_log.txt（EDITS 57）、gap1_edit_log.json（57 edit の old/new の全文） |
| `LEDGER_AND_REPLAY_SCHEMA_V0.md` | (6) |
| `OPEN_QUESTIONS.md` | Q1–Q15 と、NOT_VERIFIED の項目に対するテスト案（7） |

## 9. 最終行

IMPLEMENTATION_READY_FOR_CHAT_DIFF_AUDIT
