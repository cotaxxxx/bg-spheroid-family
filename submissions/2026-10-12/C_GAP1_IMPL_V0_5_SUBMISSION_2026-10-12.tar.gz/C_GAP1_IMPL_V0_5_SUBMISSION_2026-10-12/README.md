# C_GAP1 implementation v0.5 submission

Source implementation: v0.4.1 implementation commit `70af038bd44945780bb7e94149a54c77fa177ed0`; actual pinned run3 worktree HEAD/reference used here: `d68dfd918b73f3de0158947f5330ee2605646a4b` (direct child; implementation files are unchanged between the two).

Authority: contract v9 plus v9.1 delta. Boundary `GAP1_X_LO = 83/200` (m=48); C1a negative gating point remains `699/1600`; positive gating point remains `281/640`; slab counts L/X/R = 48/78/34.

The 7 audit files are in `new_files/`; `v0_4_1_reference/` contains the byte-exact reference files and `diffs_v0_4_1_to_v0_5/` contains their unified diffs. Only the producer/checker kernels and gatings change; driver, producer entry point, and checker entry point are unchanged.

Pre-diagnostic status before this submission: v9.1 requested body diagnostics X 48..116 and L 0..47 passed 117/117. Those records are NOT_EVIDENCE and are stored separately in bg-spheroid-family main commit `924d6de467e2fe05cb52be6e86fd519929d06429`. They are not promoted to formal run4 evidence by this submission.

No run4 was started. Static Python compilation and producer/checker `gap1_domain_controls()` through C21 passed on the candidate files.
