# C_GAP1 implementation v0.4 submission

Source: v0.3 RUN_COMMIT `7ec8e087c1da91e8993cdec6c7ac6334149bced1`. Contract: v8 delta, main `e08e9849dd17075e6e471cbc76290d7dbc660562`.

7 submitted files in `new_files/`; `v0_3_reference/` and `diffs_v0_3_to_v0_4/` enable independent comparison. No production run or X diagnostic was executed.

Boundary: 703/1600; C1a POS point remains 281/640; slab counts L/X/R=118/8/34.
