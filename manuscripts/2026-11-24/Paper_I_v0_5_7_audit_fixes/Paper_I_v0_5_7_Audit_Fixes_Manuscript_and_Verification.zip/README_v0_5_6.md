# Paper I v0.5.6 — audit handoff (23 November 2026)

This release is derived from the v0.5.4 manuscript. v0.5.5 is **not** the parent.

Read `REVISION_v0_5_6_JA.md`, `VALIDATION_v0_5_6_JA.md`, and `SOURCE_DIFF_v0_5_4_to_v0_5_6.patch` for the changed-text scope. The main PDF is `Paper_I_v0_5_6_Integrated_EN.pdf`.

Original v0.5.4 verification and provenance materials, including `CURRENT_REPRODUCTION_v0_5_4.md`, are retained unchanged. Historical README and revision records still bear their original version names. The PDF's full-family classification remains conditional on C1–C6.

The research text and author's materials are under CC BY 4.0, and author-created program source is MIT, as described in LICENSE. Author verification remains pending. This package has not yet received Claude's v0.5.6 differential audit or Judge's publication authorization.
