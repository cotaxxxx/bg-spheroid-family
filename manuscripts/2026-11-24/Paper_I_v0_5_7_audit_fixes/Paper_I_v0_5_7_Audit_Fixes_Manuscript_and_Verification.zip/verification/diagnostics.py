"""Floating point only. Normalized quadrupole variation and near-rim chord Hessian."""
import sys,json
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source'))
from make_diagnostic_figures import SphereRule,angular_functions
from scipy.special import roots_legendre
def amplitude(rule,l):
    r=brentq(lambda t:rule.evaluate(l,t,0,'rho'),.01,.999999)
    x,y,m=rule.x,rule.y,rule.mu
    k=1-r*x;d2=(x-r)**2+y*y+(l*m)**2;s2=x*x+y*y+(m/l)**2
    g=k/np.sqrt(s2*d2);_,p,_=angular_functions(g)
    amp=np.sum(rule.w*k*g*p*(((x-r)**2-y*y)/d2-(x*x-y*y)/s2))
    return [r,amp,amp/r**2]
def rim(l,r,z,n):
    nodes,w=roots_legendre(n);m=(nodes[:,None]+1)/2
    phi=np.arange(2*n)*np.pi/n;ex=np.sqrt(1-m*m)*np.cos(phi)
    v=z*m+r*ex;d2=(1-r*r-z*z)+v*v;d=np.sqrt(d2)
    C=1+(l*l-1)*m*m;ci=1/C;total=0
    for h in (1,-1):
        ell=d-h*v;mu=z+h*ell*m
        B=1+(1/l**2-1)*mu*mu;T=1/np.sqrt(B*C);g=d*T
        _,p,Q=angular_functions(g)
        b=z*(1-m*m)-r*ex*m-h*m*d*(l*l-1)*(1-m*m)*ci
        val=T*(p*d2*l*l*(1-m*m)*ci*ci-Q*b*b)
        total+=np.sum((w[:,None]/(4*n))*((1-h*v/d)/2)*val)
    return total
if __name__=='__main__':
    data={}
    for n in [96,192]:
        rule=SphereRule(n,2*n);rims=[]
        for l in [1/128,1/64,1/32,.25,.35,.4,.4079,.42]:
            radius=.9999 if l<=1/32 else .9995
            vals=[rim(l,radius*np.sin(a),radius*np.cos(a),n) for a in np.linspace(0,np.pi/2,17)]
            rims.append([l,radius,min(vals),max(vals)])
        data[n]=dict(amplitude={l:amplitude(rule,l) for l in (2.1,3.,4.,4.7)},rim=rims)
    print(json.dumps(data,indent=2))
