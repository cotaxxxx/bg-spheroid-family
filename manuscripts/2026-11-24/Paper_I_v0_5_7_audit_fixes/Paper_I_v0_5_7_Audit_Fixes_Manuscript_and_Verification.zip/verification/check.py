"""Verify exact endpoint comparisons and coverage independently of the new drivers."""
import csv,json,sys
from fractions import Fraction as F
from pathlib import Path
import gzip
v=Path(__file__).resolve().parent
sys.path[:0]=[str(v/'bridge'),str(v.parent/'audit')]
from verify_cover import check_one
from cover_check import inspect
r=v/'results'
def table(p):
    with p.open() as f:return list(csv.DictReader(f))
def box(row):
    keys=['l0','l1','r0','r1']+(['z0','z1'] if 'z0' in row else [])
    return tuple(int(row[k]) for k in keys)
def bisect(b,i):
    a=list(b);c=list(b);a[i+1]=c[i]=(a[i]+a[i+1])//2
    return tuple(a),tuple(c)
c=table(r/'c6.csv')
assert len(c)==1024 and {(int(x['i']),int(x['j']),int(x['k'])) for x in c}=={(i,j,k) for i in range(16) for j in range(8) for k in range(8)}
cap=min(int(x['floor_lower_times_2pow48']) for x in c)
assert F(cap,2**48)>F(47473218194072764542240096942353646083,2**127)>F(1,4)
z=json.loads((r/'endpoints.json').read_text())
assert z['center']['intervals'][0][1]<0<z['center']['intervals'][1][0]
for l,targets in [('5',[1,1,F(-3,16)]),('8',[F(-1,20),F(-2,5),F(-3,5)])]:
    for num,target in zip(z['anchors'][l],targets):assert F(num,z['anchor_den'])<target
for x in json.loads((r/'weak.json').read_text()):
    assert F(x['trials_lower_2pow48'][-1][2],2**48)>F(x['original_lower_2pow36'],2**36)>0
def check_radial(src,out):
    leaves=0;pieces=0;upper=F(-1000)
    for p in sorted(src.glob('*.tsv')):
        with p.open() as f:old={x['path']:x for x in csv.DictReader(f,delimiter='\t') if x['decision']=='negative'}
        rows=table(out/(p.stem+'.csv'));d={(x['leaf'],x['path']):x for x in rows}
        assert len(d)==len(rows)
        for leaf,orig in old.items():
            prefix={x['path'][:j] for x in rows if x['leaf']==leaf for j in range(len(x['path'])+1)}
            stack=[('',box(orig))]
            while stack:
                path,b=stack.pop();assert path in prefix
                if (leaf,path) in d:
                    x=d.pop((leaf,path));assert box(x)==b and x['mode']==orig['mode']
                    val=F.from_float(float(x['upper']));assert val<0
                    upper=max(upper,val);pieces+=1
                else:
                    i=0 if b[1]-b[0]>3*(b[3]-b[2]) else 2
                    stack.extend((path+str(j),t) for j,t in enumerate(bisect(b,i)))
            leaves+=1
        assert not d
    return leaves,pieces,upper

src=v.parent/'audit/mono';inspect(src)
leaves,pieces,upper=check_radial(src,r/'equator')
assert leaves==731 and upper<F(-1,512)
for k in range(4):
    with open(r/'band'/f'slab{k:02}.tsv') as f:
        records=list(csv.DictReader(f,delimiter='\t'))
    d={x['path']:x for x in records};assert len(d)==len(records)
    stack=[('x',(2**20+k*2**18,2**20+(k+1)*2**18,0,2**20))]
    while stack:
        path,b=stack.pop();x=d.pop(path);assert box(x)==b
        if x['decision']=='negative':
            hi=F(int(x['ahi']),2**36) if x['mode']=='T' else F(3*(int(x['bhi'])-int(x['alo']))*2**40,2**36*b[3]**2)
            assert hi<=F(-95257877,2**36)
        else:
            assert x['decision'] in ('splitl','splitr')
            stack.extend((path+str(i),h) for i,h in enumerate(bisect(b,0 if x['decision']=='splitl' else 2)))
    assert not d
lowleaves,lowpieces,lowupper=check_radial(r/'band',r/'band_second')
assert lowleaves==176 and lowupper<0
bridge=json.loads((r/'bridge.json').read_text())
for k in (5,6,7):
    root=v/'bridge'; check_one(root,k,None)
    with gzip.open(root/f'cover_{k}.tsv.gz','rt') as f:
        next(f);old=list(csv.DictReader(f,delimiter='\t'))
    updates=table(r/f'refine_{k}.csv');d={x['path']:x for x in updates};assert len(d)==len(updates)
    good=[];empty=0
    def visit(row):
        global empty
        kind=row['kind'];b=box(row);path=row['path']
        if kind=='empty':empty+=1;return
        val=F(int(row['num']),int(row['den']))
        if kind in ('negative','upper') and val<=F(-1,1000):good.append(val);return
        a=d.pop(path+'0');c=d.pop(path+'1')
        assert any((box(a),box(c))==bisect(b,i) for i in (0,2,4))
        for s in (a,c):visit(s)
    for row in old:
        if row['kind']!='split':visit(row)
    assert not d and (len(good),empty,str(max(good)))==tuple(bridge[str(k)][s] for s in ('negative','empty','upper'))
print(json.dumps(dict(near_parent_boxes=lowleaves,near_final_boxes=lowpieces,near_upper=float(lowupper),c4_parent_boxes=leaves,c4_final_boxes=pieces,c4_least_negative=float(upper),c6_min_num=cap,c6_den=2**48,bridge=bridge),indent=2))
