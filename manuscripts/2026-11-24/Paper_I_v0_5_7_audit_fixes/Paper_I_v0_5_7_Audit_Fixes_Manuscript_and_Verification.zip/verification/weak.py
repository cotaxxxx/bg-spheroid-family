"""Arb re-enclosures of the least original positive Ez lower bound within two declared populations."""
from flint import arb,ctx
import csv,gzip,json,sys
from pathlib import Path
from functools import lru_cache
ctx.prec=144
U=2**20
def span(a,b):return arb(a).union(arb(b))
@lru_cache(None)
def table():
    vals=[]
    for j in range(4097):
        g=arb(j)/4096
        if j==4096:vals.append((arb(2),arb(2)));continue
        a=g.acos();p=2*a/(1-g*g).sqrt();vals.append((g*p-a*a,g*g*p))
    return vals
def index(x,op):return max(0,min(4096,int(getattr(x*4096,op)().unique_fmpz())))
def bound(box,n,m):
    L,r,z=[span(a,b)/U for a,b in zip(box[::2],box[1::2])]
    on_axis=(box[2]==box[3]==0)
    cos=[arb(0)] if on_axis else [(arb.pi()*span(i,i+1)/m).cos() for i in range(m)]
    tab=table();total=arb(0)
    for j in range(n):
        mu=-1+2*span(j,j+1)/n
        sl=1-mu**2
        s=sl.nonnegative_part().sqrt()
        S=(1+(1/L**2-1)*mu**2).sqrt()
        dz=L*(mu-z)
        for c in cos:
            d2=(s-r)**2+2*r*s*(1-c)+dz**2
            if d2>0:
                d=d2.sqrt();u=(dz/d).intersection(span(-1,1))
                g=(1-z*mu-r*s*c)/(d*S)
                i=index(g.lower(),'floor');k=index(g.upper(),'ceil')
            else:u=span(-1,1);i=0;k=4096
            J=tab[i][0].union(tab[k][0]);K=tab[i][1].union(tab[k][1])
            total+=(mu*J-L*S*u*K).lower()
    return int(((total/(n*len(cos))).lower()*2**48).floor().unique_fmpz())
def select(one,three):
    rr=[]
    for p in sorted((one/'leaves').glob('*V.tsv')):
        for line in p.read_text().splitlines():
            a=line.split()
            if a[-1]=='sign' and int(a[2])>=21*U//32 and a[4:6]==['0','0'] and int(a[10])>0:
                rr.append((int(a[10]),p.name,a[0],list(map(int,a[2:8]))))
    tt=[]
    for p in sorted((three/'final').glob('V*.tsv.gz')):
        with gzip.open(p,'rt') as f:
            for d in csv.DictReader(f,delimiter='\t'):
                if d['action']=='positive':
                    tt.append((int(d['alo']),p.name,d['path'],[int(d[k]) for k in 'l0 l1 r0 r1 z0 z1'.split()]))
    return [(len(a),*min(a)) for a in (rr,tt)]
if __name__=='__main__':
    p=Path(__file__).parent
    if len(sys.argv)==3:boxes=select(*(Path(s) for s in sys.argv[1:]))
    else:boxes=json.loads((p/'weak_selection.json').read_text())
    out=[]
    for population,old,tree,path,box in boxes:
        trials=[]
        for n,m in [(256,64),(512,128),(1024,256),(2048,256)]:
            lo=bound(box,n,m);trials.append((n,m,lo))
            if lo>old*2**12:break
        out.append(dict(tree=tree,path=path,box=box,population=population,original_lower_2pow36=old,trials_lower_2pow48=trials))
    print(json.dumps(out,indent=2))
