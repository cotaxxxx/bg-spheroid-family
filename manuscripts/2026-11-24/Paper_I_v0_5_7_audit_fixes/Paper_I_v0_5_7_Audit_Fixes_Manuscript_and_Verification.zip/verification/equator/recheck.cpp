// Independent integration on the fixed sphere (inner) and chord directions (outer).
// Basic operations use IEEE binary64 round-to-nearest; each result is widened.
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <map>
#include <vector>
#include <stdexcept>
using std::min;using std::max;
struct I {double l,h; I(double a=0):l(a),h(a){} I(double a,double b):l(a),h(b){if(!(a<=b))throw std::runtime_error("empty interval");}};
double dn(double x){return x-std::abs(x)*0x1p-50-0x1p-1022;}
double up(double x){return x+std::abs(x)*0x1p-50+0x1p-1022;}
I operator+(I a,I b){return {dn(a.l+b.l),up(a.h+b.h)};}
I operator-(I a,I b){return {dn(a.l-b.h),up(a.h-b.l)};}
I operator-(I a){return {-a.h,-a.l};}
I operator*(I a,I b){double p=a.l*b.l,q=a.l*b.h,r=a.h*b.l,s=a.h*b.h;return {dn(min(min(p,q),min(r,s))),up(max(max(p,q),max(r,s)))};}
I operator/(I a,I b){if(b.l<=0)throw std::runtime_error("divisor");return a*I(dn(1/b.h),up(1/b.l));}
I sq(I a){double low=max({0.,a.l,-a.h}), high=max(-a.l,a.h);return {max(0.,dn(low*low)),up(high*high)};}
I root(I a){return {max(0.,dn(std::sqrt(max(0.,a.l)))),up(std::sqrt(a.h))};}
I clip(I a,double l,double h){return {max(l,a.l),min(h,a.h)};}
I meet(I a,I b){return clip(a,b.l,b.h);}
std::array<std::array<I,4>,2049> P;
struct Angle{I c,s;};
std::map<int,std::vector<Angle>> quad,half;
void tables(const char*path){
 std::ifstream f(path);auto read=[&](){double l,h;f>>l>>h;return I(l,h);};
 for(int n:{32,64,128,256}){
   std::vector<Angle> q,h;
   for(int j=0;j<=n;++j){I s=read(),c=read();q.push_back({c,s});s=read();c=read();h.push_back({c,s});}
   for(int j=0;j<n;++j){quad[n].push_back({clip({q[j+1].c.l,q[j].c.h},0,1),clip({q[j].s.l,q[j+1].s.h},0,1)});
     half[n].push_back({clip({h[j+1].c.l,h[j].c.h},-1,1),clip({min(h[j].s.l,h[j+1].s.l),max(h[j].s.h,h[j+1].s.h)},0,1)});}
 }
 for(auto &row:P)for(auto &v:row)v=read();
 if(!f) throw std::runtime_error("table");
}
std::array<I,4> values(I g){
 I u=1-g;int a=max(0,(int)std::floor(2048*u.l)),b=min(2048,(int)std::ceil(2048*u.h));
 std::array<I,4> f;for(int d=0;d<4;++d)f[d]={P[a][d].l,P[b][d].h};return f;
}
I inside(I l,I r,int n,int m){
 I total,l2=sq(l),ecc=1-1/l2;
 for(int j=0;j<n;++j){
   I mu((double)j/n,(j+1.)/n),mu2=sq(mu),s2=1-mu2,s=root(s2),S=root(meet(1-ecc*mu2,s2+mu2/l2));
   for(auto a:half.at(m)){
     I x=s*a.c,y=s*a.s,k=1-r*x;
     I d2=meet(1+(l2-1)*mu2-2*r*x+sq(r),sq(s-r)+2*s*r*(1-a.c)+l2*mu2);
     d2.l=max(d2.l,sq(1-r).l);
     I D=root(d2),g=clip(k/(D*S),0,1),u=clip(y/D,0,1),u2=clip(sq(y)/d2,0,1),ny=y/S;
     I g1=meet(g*u-ny,ny*(k/d2-1)),z=u2-1;
     I g2=g*z*.5+u*g1,g3=g*u*z+g1*(3*u2-1)*.5;
     I g4=g*(5*u2-1)*z*.375+g1*u*(5*u2-3)*.5;
     auto p=values(g);
     I f3=-p[0]*g3+p[1]*g1*g2-p[2]*sq(g1)*g1/6;
     I f4=-p[0]*g4+p[1]*(g1*g3+sq(g2)*.5)-p[2]*sq(g1)*g2*.5+p[3]*sq(sq(g1))/24;
     total=total+24*S/(d2*D)*(g*f4-ny*f3);
   }
 }
 return total/(double(n)*m);
}
I outside(I l,I r,int n,int m){
 I total,l2=sq(l),ecc=1-1/l2;
 for(int j=0;j<n;++j){
   I t((double)j/n,(j+1.)/n),a2=1-sq(t),v=r*t,d2=clip(1-sq(r)*a2,0,1),d=root(d2);
   I ratio=d.l>0?clip(v/d,0,1):I(0,1),w=(1-ratio)*.5;
   for(auto a:quad.at(m)){
     I az=sq(a.c),ay=sq(a.s),m2=a2*az,y2=a2*ay,C=1+(l2-1)*m2,ci=1/C,U=1-ci;
     I val[2];
     for(int k=0;k<2;++k){
       int sign=2*k-1;I ell=clip(d-sign*v,0,2),xx=sq(clip(r*a2+sign*t*d,-1,1));
       I mu2=clip(meet(sq(ell)*m2,(1-xx)*az),0,1);
       I B=meet(1-ecc*mu2,1/l2+ecc*(xx+(1-xx)*ay));
       I T=1/root(B*C),g=clip(d*T,0,1);auto p=values(g);I Q=2*p[0]-g*p[1];
       I bx=r*a2+sign*t*d*U,by2=y2*sq(sign*d*U-v);
       val[k]=T*(p[0]*d2*sq(ci)*(y2-sq(t))-Q*(sq(bx)-by2));
     }
     I blend=meet(val[0]+w*(val[1]-val[0]),val[1]+(1-w)*(val[0]-val[1]));
     blend=meet(blend,(1-w)*val[0]+w*val[1]);total=total+blend;
   }
 }
 return 3*total/(double(n)*m*sq(r));
}
int main(int argc,char**argv){tables(argv[1]);int l,h,a,b,n,m;char mode;
 while(std::cin>>mode>>l>>h>>a>>b>>n>>m){
   I L(l*0x1p-20,h*0x1p-20),r(a*0x1p-20,b*0x1p-20);
   I x=mode=='T'?inside(L,r,n,m):outside(L,r,n,m);
   std::cout<<std::setprecision(17)<<x.h<<std::endl;
 }}
