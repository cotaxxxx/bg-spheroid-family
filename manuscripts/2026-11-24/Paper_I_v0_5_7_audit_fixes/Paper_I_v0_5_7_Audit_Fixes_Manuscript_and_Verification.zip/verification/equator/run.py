"""Re-enclose the exact terminal boxes, trying small grids before geometric splits."""
import csv,subprocess,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def run(job):
    source,out,exe,table=job
    p=subprocess.Popen([exe,table],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    with open(source) as f,open(out,'w',buffering=1) as dest:
        writer=csv.writer(dest);writer.writerow('leaf path l0 l1 r0 r1 mode n m upper'.split())
        for row in csv.DictReader(f,delimiter='\t'):
            if row['decision']!='negative':continue
            box=tuple(int(row[k]) for k in ('l0','l1','r0','r1'));mode=row['mode'];pending=[('',box)]
            while pending:
                path,b=pending.pop()
                for n,m in [(32,32),(64,32),(128,64),(256,128)]:
                    p.stdin.write(' '.join(map(str,(mode,*b,n,m)))+'\n');p.stdin.flush()
                    upper=float(p.stdout.readline())
                    if upper<0:break
                if upper<0 or len(path)>=8:
                    writer.writerow((row['path'],path,*b,mode,n,m,repr(upper)))
                else:
                    i=0 if b[1]-b[0]>3*(b[3]-b[2]) else 2
                    a=list(b);c=list(b);a[i+1]=c[i]=(b[i]+b[i+1])//2
                    pending.extend([(path+'1',c),(path+'0',a)])
    p.stdin.close();assert p.wait()==0
if __name__=='__main__':
    src,out,exe,table=sys.argv[1:];Path(out).mkdir(exist_ok=True)
    with ProcessPoolExecutor(6) as pool:list(pool.map(run,[(s,Path(out)/(s.stem+'.csv'),exe,table) for s in sorted(Path(src).glob('*.tsv'))]))
