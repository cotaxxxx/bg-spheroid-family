"""Monotone endpoint tables for derivatives of P(1-v) and azimuth geometry."""
from flint import arb,ctx
import math,sys
ctx.prec=128
def bounds(x):
    return (math.nextafter(float(x.lower()),-math.inf),math.nextafter(float(x.upper()),math.inf))
with open(sys.argv[1],'w') as f:
    for n in [32,64,128,256]:
        for j in range(n+1):
            for x in (arb.pi()*j/(2*n),arb.pi()*j/n):
                for trig in x.sin_cos(): print(*bounds(trig),file=f)
    # p_j < 2/2^j, derivative tails order <=3, j>=97, bounded by 2^-68.
    p=[arb(2)]
    for j in range(1,97):p.append(p[-1]*j/(2*j+1))
    for i in range(2049):
        u=arb(i)/2048
        for d in range(4):
            v=arb(0)
            for j in range(96,d-1,-1):v=v*u+p[j]*math.prod(range(j-d+1,j+1))
            print(bounds(v)[0],bounds(v+arb(2)**-68)[1],file=f)
