"""Independent enclosure of (7.33). python-flint 0.8.0. Work on the entire parameter cells."""
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
from flint import arb,ctx
import csv,sys
ctx.prec=144
N,M=120,64
def cell(i,n):
    return (arb(2*i+1,1)/(2*n))
def sq(x):return x**2
@lru_cache(None)
def angles():
    start=(arb(3)/4).acos()
    length=arb.pi()-arb(1)/64-start
    theta=[(start+length*cell(i,N)).sin_cos() for i in range(N)]
    cosphi=[(arb.pi()*cell(i,M)).cos() for i in range(M)]
    return length,theta,cosphi
def calc(index):
    i,j,kidx=index
    ep,w,u=cell(i,80),cell(j,8),cell(kidx,8)
    v=ep*w;z=(1-sq(v)).sqrt();r=v*u
    length,theta,cs=angles()
    total=arb(0)
    for s,mu in theta:
        b=(sq(s)+sq(ep*mu)).max(s.lower()**2).sqrt()
        dz=z-mu
        plus=1-z*mu
        for c in cs:
            # s^2 + r^2 - 2rs cos(phi) as a sum of nonnegative terms.
            A=sq(s-r)+2*s*r*(1-c)
            d2=(sq(dz)+sq(ep)*A).max(dz.lower()**2)
            d=d2.sqrt()
            k=plus-r*s*c
            g=ep*k/(d*b)
            f=mu*k
            h=f+sq(k)*dz/d2
            integrand=s/(b*d)*(arb.pi()*(f+h)-g*(f.max(arb(0))+2*h.max(arb(0))))
            total+=integrand.lower()
    lower=(length*total/(2*N*M)-arb.pi()/(64*z)-ep*sq(w)*(1+sq(w)).sqrt()/(1+z))
    assert lower.is_finite()
    return i,j,kidx,int((lower.lower()*2**48).floor().unique_fmpz())
if __name__=='__main__':
    with open(sys.argv[1],'w') as f,ProcessPoolExecutor(max_workers=4) as pool:
        writer=csv.writer(f);writer.writerow(['i','j','k','floor_lower_times_2pow48'])
        for row in pool.map(calc,[(i,j,k) for i in range(16) for j in range(8) for k in range(8)],chunksize=4):writer.writerow(row)
