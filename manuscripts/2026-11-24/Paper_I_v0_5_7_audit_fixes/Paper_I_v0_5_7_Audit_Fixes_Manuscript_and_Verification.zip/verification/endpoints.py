"""Independent rational endpoint tests for the oblate centre; six prolate anchors."""
from flint import arb,acb,ctx
import json,sys
ctx.prec=160
def center(n):
    l=arb(n)/10**12
    def integrand(t,analytic):
        s,m=t.sin_cos()
        a=(l-1/l)*s*m
        # atan via principal logarithms with holomorphy test on complex panels.
        i=acb(0,1)
        alpha=((1+i*a).log(analytic=analytic)-(1-i*a).log(analytic=analytic))/(2*i)
        den=s*s+l*l*m*m
        return s*(2*l*l*s*s+4*l*(1-l*l)*m*s**3*alpha)/den**2
    val=acb.integral(integrand,0,arb.pi()/2,abs_tol=arb(2)**-100)
    assert val.is_finite() and val.imag.contains(0)
    return val.real
def anchors(lam):
    N=8192;l=arb(lam**2-1).sqrt();v=[arb(0) for _ in range(3)]
    for j in range(N):
        m=arb(2*j+1,1)/(2*N);x=l*m;c=(1+x*x).sqrt();g=1/c
        # Monotonicity Q(g) >= Q at the upper endpoint; Q(1)=10/3.
        # For x>0, arccos(1/sqrt(1+x^2))=atan(x).
        x0=l*j/N
        if j==0:q=arb(10)/3
        else:
            c0=(1+x0*x0).sqrt();g0=1/c0;P=2*c0*x0.atan()/x0
            q=((2-g0*g0)*P-2*g0)/(1-g0*g0)
        U=1-g*g; Y=(1-m*m)/2;J=Y**2/2
        factors=(U**2*Y,(1+U)**2*J,(1+U)**2*m**2*Y)
        for h,f in enumerate(factors):v[h]+=(q*g*f).lower()
    return [int(((p-l*h/N).upper()*2**48).ceil().unique_fmpz()) for h,p in zip(v,[3*arb.pi()/4,3*arb.pi()/4,arb.pi()/2])]
if __name__=='__main__':
    ns=[407958860300,407958860301];values=[center(n) for n in ns]
    assert values[0]<0<values[1]
    D=2**96
    result=dict(center=dict(params_times_1e12=ns,den=D,intervals=[[int((a.lower()*D).floor().unique_fmpz()),int((a.upper()*D).ceil().unique_fmpz())] for a in values]),anchor_den=2**48,anchors={l:anchors(l) for l in (5,8)})
    print(json.dumps(result,indent=2))
