"""Replace each terminal with upper endpoint above -1/1000 using nested dyadic cuts."""
from fractions import Fraction as F
from pathlib import Path
import csv,gzip,subprocess,sys,json
from run_cover import rule
root=Path(__file__).resolve().parent
worker=subprocess.Popen([sys.argv[1],str(root/'geometry.tbl')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
outdir=Path(sys.argv[2]);outdir.mkdir(exist_ok=True)
stats={}
for slab in (5,6,7):
    with gzip.open(root/f'cover_{slab}.tsv.gz','rt') as src:
        next(src);old=list(csv.DictReader(src,delimiter='\t'))
    best=None;count=0;replaced=0;empty=0
    with open(outdir/f'refine_{slab}.csv','w') as dst:
        w=csv.writer(dst);w.writerow('path l0 l1 r0 r1 z0 z1 nm na kind num den'.split())
        def checked(path,box):
            global best,count,empty
            grid,cut,_=rule(box)
            worker.stdin.write(' '.join(map(str,box+grid))+'\n'); worker.stdin.flush()
            kind,num,den=worker.stdout.readline().split();v=F(int(num),int(den))
            assert kind in ('empty','upper')
            if kind=='empty':empty+=1
            elif v>F(-1,1000):kind='split'
            else:count+=1;best=v if best is None else max(best,v)
            w.writerow((path,)+box+grid+(kind,num,den))
            if kind=='split':split(path,box,cut)
        def split(path,box,cut):
            lo=list(box);hi=list(box);mid=(box[cut]+box[cut+1])//2
            assert box[cut]<mid<box[cut+1];lo[cut+1]=hi[cut]=mid
            checked(path+'0',tuple(lo));checked(path+'1',tuple(hi))
        for row in old:
            if row['kind']=='empty':empty+=1
            if row['kind']!='negative':continue
            v=F(int(row['num']),int(row['den']))
            if v<=F(-1,1000):count+=1;best=v if best is None else max(best,v);continue
            box=tuple(int(row[k]) for k in 'l0 l1 r0 r1 z0 z1'.split());replaced+=1
            split(row['path'],box,rule(box)[1])
    stats[slab]=dict(upper=str(best),replaced_parents=replaced,negative=count,empty=empty)
worker.stdin.close();assert worker.wait()==0
print(json.dumps(stats,indent=2))
