#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
v=$PWD
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
py=${ARB_PYTHON:-python}
export PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1
"$py" endpoints.py > "$stage/endpoints.json"
"$py" cap.py "$stage/c6.csv"
"$py" weak.py > "$stage/weak.json"
"$py" equator/table.py "$stage/table.txt"
cmp equator/table.txt "$stage/table.txt"
g++ -O3 -std=c++17 -fno-fast-math -ffp-contract=off equator/recheck.cpp -o "$stage/equator"
python equator/run.py ../audit/mono "$stage/radial" "$stage/equator" "$stage/table.txt"
diff -qr results/equator "$stage/radial"
g++ -O3 -std=c++20 -fno-fast-math -ffp-contract=off bridge/chord_box.cpp -o "$stage/bridge"
python bridge/refine.py "$stage/bridge" "$stage" > "$stage/bridge.json"
bash band/run.sh "$stage/band" > "$stage/band.json"
diff -qr results/band "$stage/band/ledgers"
python equator/run.py "$stage/band/ledgers" "$stage/near_second" "$stage/equator" "$stage/table.txt"
diff -qr results/band_second "$stage/near_second"
for f in c6.csv endpoints.json weak.json bridge.json refine_{5,6,7}.csv band.json; do cmp "results/$f" "$stage/$f"; done
python check.py > "$stage/checked.json"
cmp results/checked.json "$stage/checked.json"
