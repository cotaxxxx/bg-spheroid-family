#!/usr/bin/env bash
set -eu
here=$(cd "$(dirname "$0")"; pwd)
audit=$here/../../audit
out=$1
mkdir -p "$out"
sed 's/a<2\*SCALE/a<SCALE/' "$audit/snapshots/kernel.cpp" > "$out/kernel.cpp"
g++ -I"$audit/snapshots" -std=c++20 -O3 -frounding-math -ffp-contract=off -fno-fast-math "$out/kernel.cpp" -o "$out/kernel"
sed -e 's/2\*U+slab_id/U+slab_id/g' -e 's/2\*U+(slab_id/U+(slab_id/g' -e 's/range(12)/range(4)/' "$audit/single_gate.py" > "$out/run.py"
sed -e 's/2\*U+i/U+i/g' -e 's/2\*U+(i/U+(i/g' -e 's/range(12)/range(4)/' "$audit/cover_check.py" > "$out/check.py"
python "$out/run.py" "$out/kernel" "$out/ledgers"
python "$out/check.py" "$out/ledgers"
