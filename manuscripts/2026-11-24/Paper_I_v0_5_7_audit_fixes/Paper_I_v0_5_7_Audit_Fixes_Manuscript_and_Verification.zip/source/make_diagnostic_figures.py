"""Illustrative floating-point figures; these outputs are not certificates.

The energy and its first/axial second derivatives are evaluated directly on
the reference sphere. No producer interval kernel is imported. Interval branch
records are copied separately, with their original rational endpoints.
"""
from pathlib import Path
from fractions import Fraction
import csv
import json
import shutil
import time
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.optimize import brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT/'figures'
DATA = ROOT/'research'/'figure_data'
FIG.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)
START = time.monotonic()
CO, BO, BP, CP = 0.40795886, 0.64354577, 2.06538229, 4.72438340

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,
                     'axes.spines.top':False,'axes.spines.right':False,
                     'mathtext.fontset':'stix','pdf.fonttype':42,
                     'axes.labelsize':10,'legend.fontsize':8})

def angular_functions(c):
    c = np.clip(c, 0., 1.)
    delta = 1-c
    theta = np.arccos(c)
    f = theta*theta
    small = delta < 1e-4
    coeff = [2.,2/3,4/15,4/35,16/315,16/693,32/3003]
    ps = np.zeros_like(c)+coeff[-1]
    for a in coeff[-2::-1]: ps = a+delta*ps
    ds = np.zeros_like(c)+(len(coeff)-1)*coeff[-1]
    for n in range(len(coeff)-2,0,-1): ds=n*coeff[n]+delta*ds
    with np.errstate(divide='ignore',invalid='ignore'):
        p = np.where(small,ps,2*theta/np.sqrt(np.maximum(0.,1-c*c)))
        dp = np.where(small,-ds,(c*p-2)/(1-c*c))
    return f,p,2*p+c*dp

class SphereRule:
    def __init__(self,n_mu=128,n_phi=256):
        mu,wm=leggauss(n_mu)
        phi=2*np.pi*np.arange(n_phi)/n_phi
        s=np.sqrt(1-mu*mu)
        self.x=(s[:,None]*np.cos(phi)).ravel()
        self.y=(s[:,None]*np.sin(phi)).ravel()
        self.mu=np.broadcast_to(mu[:,None],(n_mu,n_phi)).ravel()
        self.w=np.broadcast_to(wm[:,None]/(2*n_phi),(n_mu,n_phi)).ravel()
        self.order=(n_mu,n_phi)

    def evaluate(self,lam,rho,z,kind='energy'):
        rho,z=np.broadcast_arrays(np.asarray(rho,float),np.asarray(z,float))
        shape=rho.shape;rr=rho.ravel();zz=z.ravel();out=[]
        S=np.sqrt(1-self.mu*self.mu+self.mu*self.mu/(lam*lam))
        for begin in range(0,len(rr),24):
            r=rr[begin:begin+24,None]; qz=zz[begin:begin+24,None]
            k=1-r*self.x-qz*self.mu
            R2=(self.x-r)**2+self.y*self.y
            v=self.mu-qz
            D2=R2+lam*lam*v*v;D=np.sqrt(D2)
            c=k/(D*S)
            f,p,Q=angular_functions(c)
            if kind=='energy': val=k*f
            elif kind=='rho':
                val=self.x*(c*p-f)-S*(self.x-r)/D*(c*c*p)
            elif kind=='z':
                val=self.mu*(c*p-f)-lam*lam*S*v/D*(c*c*p)
            elif kind=='zz':
                h1=lam*lam*k*v/D2
                val=p*lam*lam*k*k*R2/(S*D2*D2*D)-Q*(self.mu-h1)**2/(S*D)
            else: raise ValueError(kind)
            out.extend(val@self.w)
        return np.asarray(out).reshape(shape)

def axis_gradient(lam,z,n=768):
    # Axisymmetry removes the azimuth integral exactly, but quadrature is floating point.
    mu,w=AXIS_RULES[n]
    S=np.sqrt(1-mu*mu+mu*mu/(lam*lam))
    k=1-z*mu;D=np.sqrt(1-mu*mu+lam*lam*(mu-z)**2)
    c=k/(D*S);f,p,_=angular_functions(c)
    return np.sum(w*(mu*(c*p-f)-lam*lam*S*(mu-z)/D*c*c*p))/2

if __name__ == '__main__':
    AXIS_RULES={n:leggauss(n) for n in [384,768]}
    rule=SphereRule()
    rho_rule=SphereRule(192,384)

    axial_lam=np.linspace(CO+0.001,BO-0.001,69)
    axial=[]
    for lam in axial_lam:
        root=brentq(lambda z:axis_gradient(lam,z),1e-4,0.999999,xtol=2e-12)
        coarse=brentq(lambda z:axis_gradient(lam,z,384),1e-4,0.999999,xtol=2e-12)
        axial.append((lam,root,abs(root-coarse)))
    with (DATA/'oblate_axis_branch.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['lambda_float','positive_z_float','order_doubling_difference'])
        w.writerows(axial)

    pro_lam=np.linspace(BP+0.003,CP-0.003,65)
    pro=[]
    for lam in pro_lam:
        root=brentq(lambda r:float(rho_rule.evaluate(lam,r,0.,'rho')),1e-4,0.999999,xtol=2e-11)
        pro.append((lam,root))
    with (DATA/'prolate_circle_branch.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['lambda_float','rho_float']);w.writerows(pro)

    base=ROOT.parent/'stationary_review/input/CODEX_D_PRO_WINDOW_STATIONARY_20261119/tables'
    for name in ['radius_at_lambda.tsv','lambda_at_radius.tsv']:
        if (base/name).exists():
            shutil.copyfile(base/name,DATA/name)
        elif not (DATA/name).exists():
            raise FileNotFoundError('The supplied recorded rational table is required: '+name)
    with (DATA/'radius_at_lambda.tsv').open() as f:
        cert=list(csv.DictReader(f,delimiter='\t'))
    cx=np.array([float(Fraction(r['lambda'])) for r in cert])
    cl=np.array([float(Fraction(r['rho_lo'])) for r in cert])
    ch=np.array([float(Fraction(r['rho_hi'])) for r in cert])

    fig,axs=plt.subplots(1,2,figsize=(7.1,3.25),layout='constrained')
    x,y,err=np.asarray(axial).T
    axs[0].plot(x,y,color='#1f5e7c',lw=1.8,label='numerical axial branch')
    axs[0].plot(x,-y,color='#1f5e7c',lw=1.8)
    axs[0].plot([CO,x[0]],[0,y[0]],color='#1f5e7c',ls=':',lw=1)
    axs[0].plot([CO,x[0]],[0,-y[0]],color='#1f5e7c',ls=':',lw=1)
    axs[0].plot([x[-1],BO],[y[-1],1],color='#1f5e7c',ls=':',lw=1)
    axs[0].plot([x[-1],BO],[-y[-1],-1],color='#1f5e7c',ls=':',lw=1)
    axs[0].axhline(0,color='0.35',lw=.8,ls='--',label='centre')
    axs[0].scatter([CO,BO,BO],[0,1,-1],s=22,facecolors='white',edgecolors='#1f5e7c',zorder=4)
    axs[0].set(xlabel=r'shape $\lambda$',ylabel=r'reference axial coordinate $z$',title='Oblate: two isolated saddles',ylim=(-1.08,1.08))
    axs[0].legend(loc='center right',frameon=True,facecolor='white',framealpha=.95)
    px,py=np.asarray(pro).T
    axs[1].plot(px,py,color='#a65327',lw=1.8,label='numerical circle radius')
    axs[1].plot([BP,px[0]],[1,py[0]],color='#a65327',ls=':',lw=1)
    axs[1].plot([px[-1],CP],[py[-1],0],color='#a65327',ls=':',lw=1)
    axs[1].errorbar(cx,(cl+ch)/2,yerr=(ch-cl)/2,fmt='o',ms=3,color='#183e54',capsize=3,label='seven recorded enclosures',zorder=3)
    axs[1].scatter([BP,CP],[1,0],s=22,facecolors='white',edgecolors='#a65327',zorder=4)
    axs[1].set(xlabel=r'shape $\lambda$',ylabel=r'reference circle radius $\rho$',title='Prolate: one saddle circle',ylim=(-.045,1.05))
    axs[1].legend(loc='lower left',frameon=False)
    for a in axs:a.grid(color='.9',lw=.6);a.set_axisbelow(True)
    fig.savefig(FIG/'branches.pdf');fig.savefig(FIG/'branches.png',dpi=230);plt.close(fig)

    grid=np.linspace(-.98,.98,99)
    X,Z=np.meshgrid(grid,grid);mask=X*X+Z*Z<=.98**2
    fig,axs=plt.subplots(2,2,figsize=(7.1,6.1),layout='constrained')
    contour_records=[]
    for ax,lam in zip(axs.ravel(),[.3,.52,3.,6.]):
        values=rule.evaluate(lam,np.abs(X[mask]),np.abs(Z[mask]))
        surface=np.full(X.shape,np.nan);surface[mask]=values
        filled=ax.contourf(X,Z,surface,levels=20,cmap='viridis')
        ax.contour(X,Z,surface,levels=10,colors='white',linewidths=.4,alpha=.55)
        phi=np.linspace(0,2*np.pi,361);ax.plot(np.cos(phi),np.sin(phi),color='0.3',lw=.8)
        ax.scatter([0],[0],c='white',edgecolors='black',s=23,zorder=5)
        if lam==.52:
            root=brentq(lambda z:axis_gradient(lam,z),1e-4,.999999)
            ax.scatter([0,0],[root,-root],marker='x',c='white',s=45,lw=1.4,zorder=5)
        if lam==3.:
            root=(cl[2]+ch[2])/2
            ax.scatter([root,-root],[0,0],marker='x',c='white',s=45,lw=1.4,zorder=5)
        ax.set(xlabel=r'$q_1$',ylabel=r'$q_3$',title=rf'$\lambda={lam:g}$',xlim=(-1.04,1.04),ylim=(-1.04,1.04),aspect='equal')
        fig.colorbar(filled,ax=ax,shrink=.84,pad=.02,label=r'$\widehat E_\lambda$')
        np.savez_compressed(DATA/f'energy_section_lambda_{lam:g}.npz',q1=X,q3=Z,energy=surface)
        contour_records.append({'lambda':lam,'points':int(mask.sum()),'sample_min':float(values.min()),'sample_max':float(values.max())})
    fig.savefig(FIG/'energy_sections.pdf');fig.savefig(FIG/'energy_sections.png',dpi=220);plt.close(fig)

    # A diagnostic supporting only a conjecture. It is not a global Hessian bound.
    g=np.linspace(0.,.96,25);R,T=np.meshgrid(g,g);use=R*R+T*T<=.96**2
    zz_rule=SphereRule(96,192);conjecture=[]
    for lam in [1/16,1/8,1/4,.35,.4,.4079]:
        vals=zz_rule.evaluate(lam,R[use],T[use],'zz')
        i=int(vals.argmax());rs=R[use];zs=T[use]
        conjecture.append({'lambda':lam,'points':len(vals),'max_sampled_Ezz':float(vals[i]),'rho_at_sample_max':float(rs[i]),'z_at_sample_max':float(zs[i]),'centre_Ezz':float(zz_rule.evaluate(lam,0.,0.,'zz'))})
    (DATA/'concavity_diagnostic.json').write_text(json.dumps(conjecture,indent=2)+'\n')
    meta={'classification':'NON_INTERVAL_DIAGNOSTIC_ONLY','orders':{'contours':rule.order,'prolate_branch':rho_rule.order,'oblate_branch':[768,384],'concavity':zz_rule.order},'units':'reference coordinates; radians squared energy','contour_radius_max':.98,'concavity_radius_max':.96,'axial_max_order_difference':float(max(a[2] for a in axial)),'contours':contour_records,'elapsed_seconds':time.monotonic()-START,'numpy':np.__version__,'warnings':['No directed rounding or quadrature remainder bound.','Sample extrema are not bounds over a continuum.','Dotted endpoint segments are guides to the classification endpoints.','Recorded rational intervals retain the status of their source package.']}
    (DATA/'diagnostic_metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta,indent=2));print(json.dumps(conjecture,indent=2))
