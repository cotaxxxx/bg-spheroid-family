"""Reproducible point illustrations, not interval or global bounds."""
from pathlib import Path
import csv,json
import numpy as np
from make_diagnostic_figures import SphereRule,ROOT

small=SphereRule(128,256);large=SphereRule(256,512)
rows=[]
for lam in [1.,1.5,2.,3.,5.]:
    r=z=.2
    vals=[]
    for rule in [small,large]:
        V=float(rule.evaluate(lam,r,z,'z'))/z
        H=float(rule.evaluate(lam,r,z,'rho'))/r
        vals.append((V,H))
    rows.append({'lambda':lam,'rho':r,'z':z,'V_float':vals[1][0],
                 'H_float':vals[1][1],'max_order_difference':max(abs(vals[1][j]-vals[0][j]) for j in [0,1])})
out=ROOT/'research/figure_data/point_values.csv'
with out.open('w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(json.dumps(rows,indent=2))
