"""Render the branch figure from supplied data, without rerunning quadrature."""
import csv
from fractions import Fraction
import numpy as np
from make_diagnostic_figures import ROOT, FIG, DATA, CO, BO, BP, CP, plt

axial=np.loadtxt(DATA/'oblate_axis_branch.csv',delimiter=',',skiprows=1)
pro=np.loadtxt(DATA/'prolate_circle_branch.csv',delimiter=',',skiprows=1)
with (DATA/'radius_at_lambda.tsv').open() as f:
    recorded=list(csv.DictReader(f,delimiter='\t'))
cx=np.array([float(Fraction(r['lambda'])) for r in recorded])
cl=np.array([float(Fraction(r['rho_lo'])) for r in recorded])
ch=np.array([float(Fraction(r['rho_hi'])) for r in recorded])
fig,axs=plt.subplots(1,2,figsize=(7.1,3.25),layout='constrained')
x,y,err=axial.T
axs[0].plot(x,y,color='#1f5e7c',lw=1.8,label='numerical axial branch')
axs[0].plot(x,-y,color='#1f5e7c',lw=1.8)
for sign in [-1,1]:
    axs[0].plot([CO,x[0]],[0,sign*y[0]],color='#1f5e7c',ls=':',lw=1)
    axs[0].plot([x[-1],BO],[sign*y[-1],sign],color='#1f5e7c',ls=':',lw=1)
axs[0].axhline(0,color='0.35',lw=.8,ls='--',label='centre')
axs[0].scatter([CO,BO,BO],[0,1,-1],s=22,facecolors='white',edgecolors='#1f5e7c',zorder=4)
axs[0].set(xlabel=r'shape $\lambda$',ylabel=r'reference axial coordinate $z$',title='Oblate: two isolated saddles',ylim=(-1.08,1.08))
axs[0].legend(loc='center right',frameon=True,facecolor='white',framealpha=.95)
px,py=pro.T
axs[1].plot(px,py,color='#a65327',lw=1.8,label='numerical circle radius')
axs[1].plot([BP,px[0]],[1,py[0]],color='#a65327',ls=':',lw=1)
axs[1].plot([px[-1],CP],[py[-1],0],color='#a65327',ls=':',lw=1)
axs[1].errorbar(cx,(cl+ch)/2,yerr=(ch-cl)/2,fmt='o',ms=3,color='#183e54',capsize=3,label='seven recorded enclosures',zorder=3)
axs[1].scatter([BP,CP],[1,0],s=22,facecolors='white',edgecolors='#a65327',zorder=4)
axs[1].set(xlabel=r'shape $\lambda$',ylabel=r'reference circle radius $\rho$',title='Prolate: one saddle circle',ylim=(-.045,1.05))
axs[1].legend(loc='lower left',frameon=False)
for a in axs:
    a.grid(color='.9',lw=.6)
    a.set_axisbelow(True)
fig.savefig(FIG/'branches.pdf')
fig.savefig(FIG/'branches.png',dpi=230)
plt.close(fig)
