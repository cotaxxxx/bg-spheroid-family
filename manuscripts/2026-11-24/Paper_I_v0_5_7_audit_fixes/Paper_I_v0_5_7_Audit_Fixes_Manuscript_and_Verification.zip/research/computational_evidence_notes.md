# Computational evidence: source notes for the English major revision

Date: 2026-11-20. Scope: reading archived sources, implementation, reports, ledgers, and audits. No new sign-producer run, numerical certification, repository write, process intervention, or status promotion was performed for this revision. The only new computation was exact aggregation of archived ledger metadata and ordinary file inspection.

## 1. Editorial contract

The six items are **Computational assertions**, labeled `comp:c1` through `comp:c6`. The main classification is conditional on these assertions and the analytic lemmas, rather than being presented as a new unconditional certification. Existing archive labels such as `DIAGNOSTIC_ONLY / NOT_EVIDENCE`, `NOT_BINDING`, and scoped `CERTIFIED_WITHIN_SCOPE` are not altered by this manuscript.

The parent verified via the GitHub API that `cotaxxxx/bg-spheroid-family` and `cotaxxxx/basepoint-geometry` have `private:false` and `visibility:public`. This subtask also directly checked `https://api.github.com/repos/cotaxxxx/bg-oblate-spheroid`: `full_name=cotaxxxx/bg-oblate-spheroid`, `private=false`, `visibility=public`, `default_branch=main`. Public accessibility is not an independent audit and is not a journal publication.

Definitions use the reference energy `E = widehat E_lambda` with `L = diag(1,1,lambda)`, sphere probability average, and `q=(rho,0,z)`. Do not mix the volume-preserving physical coordinate Hessian with the reference Hessian when quoting numerical margins. Positive coordinate congruence preserves inertia but does not preserve numerical eigenvalues.

The completed LaTeX section is `sections/computational_evidence.tex`, with main label `sec:computational`. The final reference file is `references_computation.bib`. The parent should define:

```tex
\newtheorem{computationalassertion}{Computational assertion}
\renewcommand{\thecomputationalassertion}{C\arabic{computationalassertion}}
```

## 2. Fixed sources and their roles

### C1: finite oblate transverse signs

- Fixed report commit: `6f22a41f56e8439c63c4731d5bd6e39a10ced86f`.
- Path: `runs/2026-11-19/D_OB_FULL_FAMILY_CODEX/D_OB_FULL_FAMILY.md`.
- Report blob: `ac4e4e1a96b7c5c691c429929b7283e6a885473c`.
- [Report](https://github.com/cotaxxxx/bg-spheroid-family/blob/6f22a41f56e8439c63c4731d5bd6e39a10ced86f/runs/2026-11-19/D_OB_FULL_FAMILY_CODEX/D_OB_FULL_FAMILY.md).
- Source package inspected locally: `/workspace/scratch/2929c6ca3779/incoming_d_ob_full_20261119/source/`.
- [Audit V53](https://github.com/cotaxxxx/bg-spheroid-family/blob/d304b92edbaf514c6be5f948c92c5a3b857172fd/runs/2026-11-20/D_OB_FULL_FAMILY_CODEX_AUDIT_V53/CHAT_AUDIT_D_OB_FULL_FAMILY_CODEX_V53.md), blob `c71e81f958a9c2828fe254f34483950b90486ccc`.
- [V53 research-adoption ruling](https://github.com/cotaxxxx/bg-spheroid-family/blob/d304b92edbaf514c6be5f948c92c5a3b857172fd/runs/2026-11-20/D_OB_FULL_FAMILY_CODEX_AUDIT_V53/JUDGE_RULING_D_OB_FULL_FAMILY_ADOPT_20261120.md).

Use §§1,5,8 for the finite band. Do not quote the earlier unresolved thin-limit discussion in §§4,7 as the latest whole-family state. Its later analytic closure is a separate V54 source, not a finite-box assertion. The lower band `0<lambda<1/32` is absent from C1 deliberately.

Implementation files directly read: `interval.hpp`, `kernel.cpp`, `map.cpp`, `graded.cpp`, `pole.cpp`, `pole_prec.cpp`, `cover.py`, `salvage.py`, `PLAN` through `PLAN12`, and reproduction/checking records. Principal facts:

- Binary64 interval endpoints; `FE_UPWARD`; directed lower endpoints by sign reversal; no fast math; contraction disabled; startup rounding test.
- Positive sqrt lower endpoint is one binary64 step below the upward sqrt; zero exact.
- Geometry-derived ratio bounds replace division by an interval containing zero.
- Coefficient table 8192 cells, degree 60, tail allowance `2^-38` for required functions/derivatives.
- Graded variable `m=1-(1-t)^2` with exact interval-cell weights; positive-sum `C=(1-m^2)+lambda^2 m^2`.
- H > 0 is sometimes concluded from X=E_rho > 0 only when the entire box has rho lower endpoint > 0.
- Axis low-z strip is handled by signed E_zz integrated from 0; high-z strip by direct E_z.
- Ordinary box endpoints: denominator `2^20`; output endpoints: denominator `2^36`.
- Main report explicitly says it ran each producer and checker, not one additional all-in-one invocation of `reproduce.sh`.

Audit V53 independently re-enclosed 123 selected items: 49 initial, 72 supplemental, 2 follow-ups. This is not the denominator of the full sign cover. Initial 7000-second and later two-hour audit timeouts are not production wall times. The later adoption record says the outstanding optional/extra check completed. Original aggregate production time: **not recorded in inspected report and run summaries**. Peak memory and processor model: **not recorded in inspected summaries**.

### C2: scalar axis classification and the center value c_o

- Assembly commit: `2c084bc05e5dd0b0d7deeb9f9c293deeb1d5e40a`.
- Path: `drafts/2026-11-16/C_AXIS_GLOBAL_COVER_ASSEMBLY_V1/C_AXIAL_GLOBAL_COVER_ASSEMBLY_DRAFT_V1.md`.
- [Fixed assembly](https://github.com/cotaxxxx/bg-spheroid-family/blob/2c084bc05e5dd0b0d7deeb9f9c293deeb1d5e40a/drafts/2026-11-16/C_AXIS_GLOBAL_COVER_ASSEMBLY_V1/C_AXIAL_GLOBAL_COVER_ASSEMBLY_DRAFT_V1.md).
- Use §§0–5 for quantified root count, endpoint ownership, root simplicity, lower-half analytic transfer, and negative cubic. The version records v1 Judge V23 closure and v1.1 wording-audit status separately.
- Center repository inspected at `e3f2c4974aa222bc076d706be885a346fca8f581`.
- [Center judge receipt](https://github.com/cotaxxxx/bg-oblate-spheroid/blob/e3f2c4974aa222bc076d706be885a346fca8f581/analysis/CENTER_AXIS_COEFFICIENT_JUDGE_RECEIPT.md), blob `0e4b199b93753ca84c97db7767eb5de84dcc8a1b`.
- [Center producer](https://github.com/cotaxxxx/bg-oblate-spheroid/blob/e3f2c4974aa222bc076d706be885a346fca8f581/producer/center_axis_coefficient_producer.py), blob `0b604f1dc17c8aba2825f25659b5d06a77c20c16`.
- [Center checker](https://github.com/cotaxxxx/bg-oblate-spheroid/blob/e3f2c4974aa222bc076d706be885a346fca8f581/checker/center_axis_coefficient_checker.py), blob `3af01fbc62a77061ab6131ca442ff39f3e25a722`.
- [Center machine receipt](https://github.com/cotaxxxx/bg-oblate-spheroid/blob/e3f2c4974aa222bc076d706be885a346fca8f581/analysis/CENTER_AXIS_COEFFICIENT_MACHINE_RECEIPT.md).
- [Pitchfork machine receipt](https://github.com/cotaxxxx/bg-oblate-spheroid/blob/e3f2c4974aa222bc076d706be885a346fca8f581/analysis/CENTER_PITCHFORK_MACHINE_RECEIPT.md), blob `4279f0597874a260af1b2274e693c568bc3b24b3`.

The center Judge receipt certifies only the stated scope, including `h_o'>0` on `[1/4,1]`, negative at `2/5` and positive at `83/200`. It does **not** certify the finer decimal `0.4079588603`. The pitchfork receipt explicitly excludes any numerical refinement of c_o and marks the evaluation at that decimal `REPORTED_NOT_GATING`. A search for existing finer certified brackets in the center reports/code and repository search did not identify one. Therefore the manuscript uses `(2/5,83/200)` as the certified bracket and any approximate decimal only as a diagnostic.

Center producer: Arb 160 bits; checker: Arb 192 bits. Both use 64 lambda boxes, `REG_PANELS=1024`, `POINT_PANELS=4096`, degree 50 for `asin(sqrt(u))/sqrt(u)` on `u<=3/5`, with geometric tail bounds through its second derivative. The `PANELS` setting is an inverse step on `[0,sqrt(2)]`, not literally the total number of integration cells: the partition is rational steps `1/panels` plus a final exact-sqrt(2) cell. Do not say “1024 total angular cells.” Pitchfork code uses 64 lambda boxes and 4096 panel setting, with analogous third-derivative tail.

Independence declaration is explicit: `CHECKER_KERNEL=TRANSCRIBED_COPY_NOT_INDEPENDENT_DERIVATION`, `INDEPENDENCE_SCOPE=PRECISION/PARTITION/GATING`. A separate symbolic audit supplies derivational checking. The negative cubic used in the adopted global axis assembly is also a consequence of its C0 gate and analytic transfer; do not treat the separate pitchfork receipt's `EXTERNAL_JUDGE_PENDING` label as silently upgraded.

The scalar root census uses 160 upper-half slabs on `[2/5,9/20]`, 159 accepted tubes on `[9/20,5/8]` (124 nonclamped, 35 ending at the pole), and 124 outer-cap cover parents, plus lower-half and polar-band gates. These are different populations and must not be summed as disjoint full-space boxes. A uniform total of legacy scalar-kernel evaluations, maximum depth across all receipts, and aggregate production runtime: **not recorded in the inspected assembly**.

Polar trace refinement comes from the C1 package §§5,8: 272 lambda intervals, 244 negative-value intervals, 14 positive-value intervals, 14 contiguous positive-derivative intervals. The refined bracket `(674802,674811)/2^20` has endpoint output margins `-175746/2^36` and `+153930/2^36`. The `pole_prec.cpp` anchored mean-value table narrows the interval while preserving outward inclusion.

### C3: near-sphere [1,2]

- Corrected producer report commit: `c44ee454f94acda95bf056d2b52a55d34a7fbaa5`.
- [Report](https://github.com/cotaxxxx/bg-spheroid-family/blob/c44ee454f94acda95bf056d2b52a55d34a7fbaa5/runs/2026-11-19/D_PRO_NEAR_BOUNDARY_CODEX/D_PRO_NEAR_BOUNDARY.md), blob `50e732b8995384db1e9a34b3660d6d77ba95c6bc`.
- Latest corrected audit commit: `211246e1c0e294ef6603b5b98ce25841f9e8ef10`.
- [Audit](https://github.com/cotaxxxx/bg-spheroid-family/blob/211246e1c0e294ef6603b5b98ce25841f9e8ef10/runs/2026-11-19/D_PRO_NEAR_BOUNDARY_CODEX_AUDIT_V51/CHAT_AUDIT_D_PRO_NEAR_BOUNDARY_CODEX_V51.md), blob `1b883168891f6f59d6d4a61656ec1cdf33f10892`.
- [Reproduction log](https://github.com/cotaxxxx/bg-spheroid-family/blob/211246e1c0e294ef6603b5b98ce25841f9e8ef10/runs/2026-11-19/D_PRO_NEAR_BOUNDARY_CODEX_AUDIT_V51/rerun/nb_reproduce.log), blob `96fcb809ea0d193c96a2113b6c7394a3be1ee8bf`.

The report says the finite-window kernel is reused with the lambda input lower-bound guard changed. The large source ZIP could not be materialized through the GitHub connector in this subtask (the >1 MB contents response had no base64 payload, and blob text retrieval rejected binary encoding). Thus this revision directly inspected the V50 base implementation, the corrected V51 report, audit, and reproduction log, not an expanded V51 ZIP. **Maximum depth and original production time are not recorded in the inspected texts.** This is an explicit record limitation; it is not a claim that no such data exists anywhere in the ZIP.

Final cover only: 4 lambda quarters, 16 trees. Counts are 28358 positive E_z plus 424 empty, 89 positive E_zz, 11 positive H equator, 4 negative radial curvature equator, 9 positive boundary. Initial E03 and checker failures and subsequent planned corrections remain disclosed in the report; only `final/` is used. E2 retracts the polynomial lower bound `4/9`; the actual uniform `E_z/z>=16189/2^36` comes directly from the interval cover.

Independent re-enclosure population: 35 distinct leaves = 11/11 H, 4/4 radial curvature, 9/9 boundary, 8/28358 E_z, 3/89 E_zz. Same-kernel all-tree regeneration and parent-child/rational-volume checks are separate. Replay times recorded: V/Z generation 86.891191988 s, E/B generation 0.846231346 s, checker 141.470563538 s, complete script `real 3m54.958s`. Do not rebrand those as original production times or add parallel per-root times.

### C4: finite prolate [2,5]

- Fixed package/audit commit: `854c553448db680634bfc599fd222f97f6c13b7b`.
- [Archive directory](https://github.com/cotaxxxx/bg-spheroid-family/tree/854c553448db680634bfc599fd222f97f6c13b7b/runs/2026-11-19/D_PRO_WINDOW_CODEX_AUDIT_V50).
- [ZIP source](https://github.com/cotaxxxx/bg-spheroid-family/blob/854c553448db680634bfc599fd222f97f6c13b7b/runs/2026-11-19/D_PRO_WINDOW_CODEX_AUDIT_V50/CODEX_D_PRO_WINDOW_STATIONARY_20261119.zip).
- ZIP SHA-256: `66a71b7c0dac153ebb84885e76381f3ae2eec39d62fc9c267a9a6b743b361e6b`.
- [Audit V50](https://github.com/cotaxxxx/bg-spheroid-family/blob/854c553448db680634bfc599fd222f97f6c13b7b/runs/2026-11-19/D_PRO_WINDOW_CODEX_AUDIT_V50/CHAT_AUDIT_D_PRO_WINDOW_CODEX_V50.md), blob `7c340c78f7d509748e289a08cf65446ba09cfe87`.
- Directly inspected local source: `/workspace/scratch/2929c6ca3779/stationary_review/input/CODEX_D_PRO_WINDOW_STATIONARY_20261119/`.

Use the original report in the ZIP; the relayed `.txt` version corrupts some LaTeX. The primary stated quantities and bounds are in original §§2–4 and7, workload in §§6,8. The source code `quadrature.cpp` implements the tensor-Simpson enclosure, and `interval.hpp`, `kernel.cpp`, `map.cpp` implement the direct and chord interval kernels. Degree 96 table at 4096 cells is for the location refinement, distinct from degree60/8192-cell principal covers.

The fourth-order Simpson remainder is signed, not an empirical convergence estimate. Normalized polynomial `t(t-1)(t-1/2)^2` has integral `-1/120`; the enclosed Taylor coefficient is `f^(4)/4!`. Two-dimensional remainder is decomposed with positive weights. Output scale for narrow endpoint signs is `2^-47`.

Counts from the archived terminal rows:

| Group | Terminal conditions | Maximum binary depth |
|---|---|---:|
| Z | 3681 positive E_zz | 9 |
| V | 11129 positive E_z, 113 empty | 12 |
| E | 39 H positive, 62 E_rhorho negative, 85 E_yyyy negative | 8 |
| T | 12 E_yyyy negative central strips | 0 |
| C | 12 H_c lambda-decreasing | 0 |
| B | 1 H_b lambda-decreasing, 13 H_b negative | 2 |
| D | 13 H positive, 42 H negative, 144 H_lambda negative | 6 |
| General H atlas | 2872 positive, 6961 negative, 253 empty, 21254 sign undetermined | 12 |
| Heavy slab X | 3653 negative, 3 empty | 15 |

Heavy slab is `[79/16,5]`; this is a later separate computational package and does not confer authority to intervene in any old process. Its integer recheck on the same geometric leaves has 11274 evaluation attempts = 7618 grid retries +3653 negative+3 empty, not 11274 geometric leaves. C4's classification does not require pretending the 21254 undetermined general-H atlas leaves are signed.

Recorded production elapsed times, compilation excluded: principal N3 3.86 s, extra N4 25.29 s, N5 0.92 s for 171 interval quadratures at33 radii, N6 0.91 s for42 quadratures plus2 coefficients at7 parameter sections, N7 1.23 s. Independent build with UBSan is same-formula replay, not independent derivation. `FULL_REPRODUCTION.json` covers146 ledgers; some are location records rather than trees.

Independent interval sample:22 selected V/Z leaves. The audit explicitly did not independently replay all general-H, E/D, or N5/N6 with a separate implementation, and did not separately hand-derive the entire fourth-derivative and parameter-derivative kernels. This limitation appears in the manuscript.

### C5: tail finite bridge and coefficient anchors

- Producer fixed commit: `05d17069e389ab86874315caeb22f65323d7b9b8`.
- [Producer directory](https://github.com/cotaxxxx/bg-spheroid-family/tree/05d17069e389ab86874315caeb22f65323d7b9b8/runs/2026-11-19/D_PRO_L1_CHORD_BRIDGE_CODEX).
- [Report](https://github.com/cotaxxxx/bg-spheroid-family/blob/05d17069e389ab86874315caeb22f65323d7b9b8/runs/2026-11-19/D_PRO_L1_CHORD_BRIDGE_CODEX/CODEX_D_PRO_L1_CHORD_BRIDGE_20261119.md), blob `ad0003c00b81f6ede3d1f7cebf8e73bf48d961c7`.
- [One-dimensional producer code](https://github.com/cotaxxxx/bg-spheroid-family/blob/05d17069e389ab86874315caeb22f65323d7b9b8/runs/2026-11-19/D_PRO_L1_CHORD_BRIDGE_CODEX/chord_tail.py), blob `a45fe6c7f165f409bfb3f9821e24aa47254e1fce`.
- `probe1.stdout.jsonl` blob `5acca289db0403bd2ff070340ce12d5787c21571`.
- Source ZIP SHA-256: `59b31dc455a7038d05c3618c12b8e53fc787e350414db145aeac2048f37ff9ea`; 48 members. Expanded at `research/V49/`.
- [Audit](https://github.com/cotaxxxx/bg-spheroid-family/blob/cb38e50e812e492c1e32da7cd01be1280eb05674/runs/2026-11-19/D_PRO_L1_CHORD_CODEX_AUDIT_V49/CHAT_AUDIT_D_PRO_L1_CHORD_CODEX_V49.md).

Let `A_c=3pi/4-N_c`, `A_e=3pi/4-N_e`, `A_p=pi/2-N_p`. These are positive-coefficient upper caps minus negative-coefficient integrals; they are not the exact `P_i-N_i`. Exact recorded **upper** endpoints are:

| lambda | A_c | A_e | A_p |
|---:|---|---|---|
|5|74467423489001741621311270817 / 2^96|10940372283526635217985663335 / 2^94|−7870588223902604035685558393 / 2^95|
|8|−35777134336410318076884028905 / 2^99|−65199030312476567590573545383 / 2^97|−25215800364261094199794446561 / 2^95|

The actual `chord_tail.py` is 96-bit Arb with 2048 cells on m∈[0,1]. It evaluates a degree12 positive lower polynomial in `h=(1-C^(-1/2))/2`. Recurrence `a_0=1`, `a_(n+1)=a_n(2n+2)/(2n+3)`, `q_n=(4+2n)a_n-(n+1)a_(n+1)`. Dropping the nonnegative tail is a rigorous lower bound. Endpoint C is used in the correct monotonic direction in each positive factor. A reported0.124s includes all9 stored parameter evaluations, not merely the two required anchors. Audit uses4096 cells and degree14.

The finite bridge kernel uses24 fixed fractional bits,128-bit integer intermediates, exact corrected integer roots, positive sum/geometric bounds `C<=64`, `B>=1/64`, and144-bit Arb-generated2048-cell coefficient/moment tables. Degree16 P upper polynomial adds `4h^17`; degree16 Q lower polynomial discards the positive tail. The paired negative expression is essential; decorrelating signs term-by-term would not reproduce the recorded proof kernel. The analytic handling of a clipped gamma argument must use the feasible relation between its numerator and denominator; the math agent has explicitly proved it in the tail section.

Bridge counts and actual-depth metadata: [5,6]1467 negative+3 empty, maxdepth15, largestgrid256×32; [6,7]261+2,maxdepth9,largestgrid128×16; [7,8]117+0,maxdepth8,largestgrid64×8. Total1845 negative+5 empty. Recorded wall times4.05,.26,.06s. Same-formula alternate-build full replay4.28s.

Independent audit23/1845 negative leaves. Producer separate Arb spot check:3 weakest parents →24 children (20 negative,4 unresolved) →32 grandchildren all negative. Do not say24/24 first-level independent checks passed, and do not count both generations as disjoint full-cover leaves.

### C6: compact polar lower envelope

- Commit `cf541c0e429cce27670654832bbc7fbd532fb547`.
- [Directory](https://github.com/cotaxxxx/bg-spheroid-family/tree/cf541c0e429cce27670654832bbc7fbd532fb547/runs/2026-11-19/D_PRO_LAMBDA0_GAP_ASTRA_AUDIT_V43).
- [Report](https://github.com/cotaxxxx/bg-spheroid-family/blob/cf541c0e429cce27670654832bbc7fbd532fb547/runs/2026-11-19/D_PRO_LAMBDA0_GAP_ASTRA_AUDIT_V43/ASTRA_D_PRO_LAMBDA0_GAP_REPORT_20261119.md), blob `6d725ffe658b7a563cb00767c06fea6a15b282bb`.
- [Audit](https://github.com/cotaxxxx/bg-spheroid-family/blob/cf541c0e429cce27670654832bbc7fbd532fb547/runs/2026-11-19/D_PRO_LAMBDA0_GAP_ASTRA_AUDIT_V43/CHAT_AUDIT_D_PRO_LAMBDA0_GAP_ASTRA_V43.md).
- Source ZIP SHA-256: `09473aac223553c17a8c0646555a18e05c4839167fdb3211d8d9ac6766f2c303`;33 members. Expanded at `research/V43/ASTRA_D_PRO_LAMBDA0_GAP_RESEARCH_20261119/`.

Use only §§3.1–3.4, formulasG6–G10, and the fixed cover. The old huge sufficient threshold2^13000 depends on a separate unverified compact-C2 remainder and is not an input to the present λ>=5 proof.

`ENVIRONMENT.json`:Python3.12.14,python-flint0.8.0,Arb128 bits,4 processes,96×48 spatial grid,16×8×8 parameter grid. `CAP_COVER_R2_SUMMARY.json`:1024/1024, all lower>1/4,58.87256897499992s. `check_cover.py` checks indices,exact rational endpoints,duplicates,lower bounds; it is not a second integral implementation. The entire1024-box regeneration and matching lower endpoints are documented by the audit, as is analytic lower-envelope inspection. No separately implemented full1024-box integration is claimed.

The first four-box pilot had two failed lower bounds. Its results remain archived. The second plan fixed the finer outer grid before running. There is no adaptive tree depth: the cover is fixed.

## 3. Ledger metadata aggregation

`archived_ledger_metadata.json` stores direct counts from existing TSV/gzipped TSV rows. No kernel was executed. A path with root `x` and d binary digits has binary depthd. C1 salvage path `parent:x` is an annotation of the same parent box: the suffix `:x` is not two additional subdivisions. All8 salvage entries succeeded on their original depth14 parents with a4096×64 grid; planned later subdivision was not actually needed.

| C1 family | Files/trees | All recorded nodes | Terminal counts | Maximum depth |
|---|---:|---:|---|---:|
|leaves|70|16956|4408 sign,145 empty,3960 open|13|
|finer|60|19828|9805 sign,139 empty|19|
|low|40|37596|18487 sign,331 empty|16|
|window|16|1366|655 sign,36 empty|10|
|thin|8|274428|122677 sign,1198 empty,13343 open|18|
|mixed|8|138414|49641 sign,439 empty,19131 open|14|
|recovered|8|19131|19123 sign,8 open|14, same boxes|
|salvage|8|8|8 sign|14, same boxes|
|rim|one supplemental file|13343|13343 positive X|18, same boxes|

The first four groups have186 trees and37966 terminal records, consistent with the report. The selected effective H cover does not use every originally open leaf from the coarse groups. Main-group overlap, same-box retries, and empty boxes must all remain explicit.

## 4. Remaining transparency limits

1. The assertions expose mathematical gates and finite populations but do not replace complete independent audit of each kernel.
2. The user-supplied ordinary numerical values and newly drawn figures are noninterval diagnostics; they must be separated from the rational enclosures above.
3. Coarse certified c_o bracket remains coarse. Fine decimal output is not a theorem-gating interval.
4. C3 source ZIP was not expanded in this subtask; its implementation description is supported by the corrected report's explicit V50 reuse statement and the V50 code. Maximum depth and original runtime remain not recorded in the inspected record.
5. C1 original production elapsed time, a unified C2 work/depth count, peak memory, and a common CPU model/budget were not identified. No inferred values are inserted.
6. Same-kernel alternate compiler/build checks, exact cover reconstruction, independent formula derivation, independent interval implementation, and diagnostic point agreement are separate forms of evidence and are described separately.
