# 第一論文 v0.5.1｜公開前の最小限の編集修正記録

- 作成日：2026年11月23日
- 指示：Judge承認済み。前版v0.5の監査R1を反映する。
- 監査原本：`cotaxxxx/experimental-mathematics-ai-collaboration`、commit `6b3388edd57f8ad23f1cc3e161551ad2c332931b`、`docs/CHAT_AUDIT_PAPER_I_V0_5_DIFF_20261123.md`
- 修正の基準：v0.5の原本ZIP（SHA-256 `ed0c20f1cb8830e7d72a94e9d3d9f7aca5a1be1b56afbb85cc44f21d1a8ab814`）
- v0.4の原本ZIP（SHA-256 `57ee540bb8f3679e1b5abfaf043d6c961d934a981bddfb9d0dba0bd32a4c4d91`）
- 扁平側V24の固定記録：https://github.com/cotaxxxx/bg-spheroid-family/blob/c41ab3bdd87a633830cfda4d4d2f45ab9e77b588/STATE.md

## 指示された二点の編集

1. 1ページ目：タイトル直後の枠囲み「Status of this revision」を撤去し、要旨の後の見出しを「Main result and status」とした。第一段落「Conditional classification」はv0.5から完全に不変。第二段落に、C1–C6依存と研究稿の状態、λ∈[2/5,33/50]の独立監査を含む検証完了、球の命題4.2の計算なしの証明を統合した。
2. 論文の公開用の二箇所（冒頭と第3節末尾）から`Judge`、`V24 ruling`、`CLOSED`、`evidence grade`という内部用語を除き、著者の検証記録・固定コミットと適用範囲に変更。球の「independently proves」も「proves ... without computational input」にした。

## 変更していない数学的な内容

- 定理3.1、表1、表2、計算的主張C1–C6、数値、球§4.2の証明、要旨を変更していない。
- 証拠の全体的な認証の追加なし。全族分類はC1–C6の成立を仮定する条件付き定理のまま。
- 解析的な球の結果と扁平側のλ∈[2/5,33/50]のみの検証結果は独立して説明。
- 検証コード・結果・台帳・図・計算補足PDF・参考文献をv0.4から変更していない。
- 第三者による独立査読やZenodo公開を主張しない。

## 添付と再現

- 完成PDF：`Paper_I_v0_5_1_Integrated_EN.pdf`
- ソースZIP：`Paper_I_v0_5_1_Manuscript_and_Verification.zip`
- v0.4→v0.5.1のsource patch：`SOURCE_DIFF_v0_4_to_v0_5_1.patch`（v0.4の2ソースへ適用してバイト一致確認済み）
- 全ファイルSHA：ZIP内`SHA256SUMS`と外部`Paper_I_v0_5_1_ARTIFACT_SHA256SUMS.txt`。

**状態：REVISION_CANDIDATE / NEEDS_CLAUDE_DIFF_AUDIT / NOT_PUBLISHED**
