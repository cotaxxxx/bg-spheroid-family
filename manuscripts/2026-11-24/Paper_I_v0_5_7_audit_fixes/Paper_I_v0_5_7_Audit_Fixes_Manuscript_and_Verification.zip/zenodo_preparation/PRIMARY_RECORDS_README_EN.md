# Paper I v0.5.7 — primary-record copies prepared for potential Zenodo deposit

This folder documents *preparation*, not submission or publication.
No Zenodo identifier is claimed for Paper I.

Records proposed for accompanying the manuscript:
1. V24 Judge ruling: provenance/V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md.
   English reading summary: provenance/EN_SUMMARIES/V24_JUDGE_RULING_SUMMARY_EN.md.
2. C2 axial census assembly v1.1: provenance/C2/C_AXIAL_GLOBAL_COVER_ASSEMBLY_DRAFT_V1.md.
   English reading summary: provenance/EN_SUMMARIES/C2_AXIS_ASSEMBLY_SUMMARY_EN.md.
3. Optional C2 sign-gate navigation: C2_AXIS_CENSUS_TRACE_v0_5_4.md.
4. Precise independent/replay scope for each C1--C6:
   CURRENT_REPRODUCTION_v0_5_4.md (unaltered historical name).

The two Japanese primary records have been copied without modification
and have their original Git blob identities verified against pinned
source commits. The English summaries are editorial reading aids,
not rulings or new certified derivations.

Before a Zenodo deposit: check archive hashes, licence terms (article
CC BY 4.0; code MIT under LICENSE), author signoff scope in section 10,
final bundle content, and the reviewer's difference audit. Archive
metadata and final public release remain separate Judge-controlled steps.
