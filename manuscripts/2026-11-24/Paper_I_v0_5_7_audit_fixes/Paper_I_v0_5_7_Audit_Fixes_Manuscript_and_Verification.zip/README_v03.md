# Integrated Paper I, working draft v0.3 (20 November 2026)

One English manuscript on spheroids. Start with main.tex or the accompanying PDF. The geometric result remains conditional on the six explicit computational assertions in the manuscript. The additional calculation is recorded for checking (DIAGNOSTIC_ONLY / NOT_EVIDENCE).

## Build
On a full TeX Live installation run `latexmk -pdf main.tex`. All figures are included. The complete source, including bibliography, is editable.

## Reproduce the additional calculations
Run `bash audit/reproduce.sh` from a fresh extraction on Linux x86_64. It rebuilds the interval program, generates all twelve trees into an empty temporary directory, checks exact subdivisions and the rational upper bound and independently reevaluates three whole V50 rectangles. It compares the individual ledgers and separate interval bounds with the supplied outputs. Tested with GCC 14.2.0, Python 3.12.14, NumPy 2.3.5 and mpmath 1.3.0, using the default nearest IEEE binary64 environment for the Python process. The V50 C++ process initializes upward rounding itself. Please retain compiler rounding flags. Plot with `(cd audit && python gate_map.py)` (Matplotlib 3.10.8).
- audit/snapshots contains byte copies of src/{kernel.cpp,interval.hpp} and ledgers/N3/E*.tsv.gz, ledgers/N4/D*.tsv.gz from the fixed V50 archive (commit 854c553448db680634bfc599fd222f97f6c13b7b; original ZIP SHA-256 66a71b7c0dac153ebb84885e76381f3ae2eec39d62fc9c267a9a6b743b361e6b).
- audit/mono contains the new producer output. Outer coordinates are integer multiples of 2^-20; output values are integer multiples of 2^-36. For mode E, columns a,b are the endpoints for H and c,d for E_xx (column names alo,ahi,blo,bhi). A leaf is admissible for the fourth derivative only if its inner radius is positive and d<a. For mode T the recorded upper end of the first interval bounds E_yyyy itself. Neither case needs a boundary fourth derivative. Unresolved leaves would cause the checker to stop.
- audit/selected contains the independent checker outputs for the three historical boxes. Their selection favours narrow boxes; the sample tests the three quantities and is not a statistical estimate. Preliminary tests on an ungraded angular mesh were poorly conditioned for the shape derivative near the boundary. The released chart clusters nodes toward the contact direction and encloses each full selected rectangle without outer subdivision.
- Rebuilding the original expressions with a separate -O1 undefined-behaviour-sanitized build gave the same new ledgers, byte for byte. This is same-kernel replay.
- REPRODUCTION.md and research/fixed_source_manifest.json describe the existing C1--C6 material. Workload/status claims in the historical notes refer to v0.2. They do not describe new work in audit/.
- The new routines were developed in this revision. Author approval and external review of the supporting calculations remain pending. No archival dataset DOI has been assigned.
