**Retained v0.2 provenance notes. For the v0.3 calculations and their replay, see [README.md](README.md).**

# Reproduction and provenance guide

## What this bundle is

This is a **manuscript and diagnostic bundle**, with diagnostic data and a fixed provenance map. It is **not a complete proof archive**, and it is not a new independent certification of Computational Assertions C1–C6.

The paper states the full classification as a consequence of the analytic arguments and C1–C6. Existing source labels and scoped dependencies remain in force. Public repository access, matching hashes, a project adoption decision, and reproduction using the original kernel are different facts; none should be substituted for an independent mathematical audit.

The machine-readable source map is [research/fixed_source_manifest.json](research/fixed_source_manifest.json). It records the repository, full commit, path, role, available hash, code/ledger/checker correspondence, and inspection limitations for each assertion. Additional source detail and exact coefficient endpoints are in [research/computational_evidence_notes.md](research/computational_evidence_notes.md). [research/archived_ledger_metadata.json](research/archived_ledger_metadata.json) contains counts read from existing ledgers, without running an integral.

The main manuscript sources are `main.tex`, `sections/`, and the three `references*.bib` files. The figures and their ordinary numerical data are diagnostics. They do not replace the exact interval gates. This guide documents historical calculation entrypoints; it does not introduce a new integrated proof script.

**No numerical producer or numerical checker command below was executed to prepare this revision or this guide.** Read-only byte-integrity checks of the existing C1, C4, C5, and C6 package members were performed against their `SHA256SUMS`; all four checks passed. Reading code, counting ledger rows, and checking file hashes do not re-establish the numerical inequalities.

## Source package map

All versions below are fixed by full commit and path in the JSON manifest. Acquire the specified complete package before a future reproduction; the manuscript's selected copies are not a substitute for that package. Work on a fresh writable copy where the original README requires it.

| Assertion | Fixed source and code archive | Ledger and checker correspondence | Availability and limitation |
|---|---|---|---|
| **C1** Finite oblate band | `bg-spheroid-family`, commit `6f22a41f56e8439c63c4731d5bd6e39a10ced86f`; `D_OB_FULL_FAMILY.zip` | `leaves/`, `finer/`, `low/`, `window/`, `thin/`, `mixed/`, `recovered/`, `salvage/`, `rim.tsv`, `pole.tsv`, `bracket.log`; `checker.py`, `optional_check.py`, `validate_extra.py` | Complete expanded source inspected in the working environment, outside this revision directory. It is not duplicated here as a full archive. |
| **C2** Oblate scalar axis census | Fixed global assembly at `2c084bc05e5dd0b0d7deeb9f9c293deeb1d5e40a`, plus center records/code in `bg-oblate-spheroid` at `e3f2c4974aa222bc076d706be885a346fca8f581` | Center producer/checker, historical C0/C1/gap receipts and root-tube ledgers, and the polar records shared with C1 | Selected receipts and center-code reading copies were inspected in the working environment; they are not included in this distribution. The full legacy dependency chain is not assembled into one replayable package. |
| **C3** Near-spherical band | `bg-spheroid-family`, corrected producer commit `c44ee454f94acda95bf056d2b52a55d34a7fbaa5`; `D_PRO_NEAR_BOUNDARY.zip` | Reported final trees `V00–03`, `Z00–03`, `E00–03`, `B00–03` under `final/`; `checker.py` | Corrected report, audit and reproduction log inspected. Complete ZIP not expanded in this revision. |
| **C4** Finite prolate window | `bg-spheroid-family`, commit `854c553448db680634bfc599fd222f97f6c13b7b`; `CODEX_D_PRO_WINDOW_STATIONARY_20261119.zip` | `ledgers/N3/` through `N7/`; `src/recheck.py`, `src/extra_recheck.py`, `src/integer_check.py`, and diagnostic checks | Complete expanded package inspected outside this revision directory. Use the report in the ZIP; the relayed TXT version has damaged mathematical typesetting. |
| **C5** Finite tail bridge and anchors | `bg-spheroid-family`, commit `05d17069e389ab86874315caeb22f65323d7b9b8`; `CODEX_D_PRO_L1_CHORD_BRIDGE_20261119.zip` | `probe1.stdout.jsonl`, `cover_5.tsv.gz`, `cover_6.tsv.gz`, `cover_7.tsv.gz`; `verify_cover.py`, `check_claims.py`, Arb spot-check scripts | The ZIP and expanded source were inspected in the working environment. Neither is included in this manuscript distribution; acquire the fixed ZIP listed in the manifest. |
| **C6** Polar lower-envelope integral | `bg-spheroid-family`, commit `cf541c0e429cce27670654832bbc7fbd532fb547`; `ASTRA_D_PRO_LAMBDA0_GAP_RESEARCH_20261119.zip` | `CAP_COVER_R2.jsonl`, its summary and log; `check_cover.py`, `exact_checks.py`, `algebra_checks.py` | The ZIP and expanded source were inspected in the working environment. Neither is included in this manuscript distribution; acquire the fixed ZIP listed in the manifest. |

The manuscript distribution omits the upstream working copies and source archives. The fixed manifest preserves their exact locations and inspection status. Acquire those same pinned archives before attempting reproduction. C2 still needs its complete legacy dependency chain assembled, and the complete C3 ZIP was not materialized in this revision.

### Archive SHA-256 values

These are identities of the specified archive versions, not mathematical validity statements.

| Package | SHA-256 | Verification basis in this revision |
|---|---|---|
| C1 | `4ef5785bbde4787f5ddc110517439bdd569e8f514a90f29b2a82353096ab03aa` | Read from the published archive manifest; existing expanded members separately matched their internal manifest. |
| C3 | `d083e423091d519988436c87b8ecdc331db8deaeaff6c13115c5fa3424d23b87` | Read from the corrected published manifest; ZIP bytes not materialized. |
| C4 | `66a71b7c0dac153ebb84885e76381f3ae2eec39d62fc9c267a9a6b743b361e6b` | Pinned original-package identity; existing expanded members matched their internal manifest. |
| C5 | `59b31dc455a7038d05c3618c12b8e53fc787e350414db145aeac2048f37ff9ea` | Downloaded ZIP bytes hashed locally; expanded members also matched. |
| C6 | `09473aac223553c17a8c0646555a18e05c4839167fdb3211d8d9ac6766f2c303` | Downloaded ZIP bytes hashed locally; expanded members also matched. |

The editorial working copy `research/V51_report_pinned.md` (not included in this distribution) has one extra final newline relative to the canonical report. The manifest records both digests and that exact difference. Use the repository version for byte-level identity checks.

## Recorded reproduction commands

Only commands explicitly present in the inspected original report, README, script, or workflow are given below. They are documented entrypoints, not a statement that this revision ran them successfully. No unrecorded command for an integrated C2 proof is supplied.

### C1: finite oblate source package

Source: the fixed report's reproduction section and the inspected `reproduce.sh`.

```bash
bash reproduce.sh
```

Run from the complete extracted package. The script checks its manifests, copies sources into a new temporary directory, compiles the directed-rounding C++ kernels, regenerates the selected tree families and supplemental records, compares them to the archive, and invokes its three checker stages. It removes its temporary directory on exit. This is a potentially substantial historical calculation, not a lightweight manuscript build.

The recorded requirements include C++20, Python 3, and a compiler/environment that respects the binary64 rounding mode. The actual floating-point flags are preserved in the script. The original aggregate production time is not recorded in the inspected summary; audit timeouts must not be substituted for it.

### C2: center coefficient only

Source: `.github/workflows/center-axis-coefficient-prototype.yml` at the fixed center-repository commit. These commands must be run from a complete repository root, since the two scripts import other repository modules and use the pinned dependency file.

```bash
python -m pip install --require-hashes --only-binary=:all: --requirement requirements-interval.txt
PYTHONPATH=. python producer/center_axis_coefficient_producer.py
PYTHONPATH=. python checker/center_axis_coefficient_checker.py
```

This workflow addresses the center-axis coefficient. It does **not** replay all C2 root-tube, gap-cover, boundary-band, and analytic-transfer inputs. The global assembly lists those dependencies in its §7; each receipt's own frozen run/blob pins must be followed. A one-command full C2 reproduction has not been identified or assembled here.

The producer uses 160-bit Arb and the checker 192-bit Arb. The checker explicitly declares a transcribed mathematical kernel and independence in precision, partition construction, and acceptance checks. The negative cubic's historical receipt has its own scope/status; the adopted global assembly also derives the needed cubic sign through its C0 gate and transfer. The decimal `0.4079588603` is not a certified refined bracket for the center transition.

### C3: corrected near-sphere package

Source: the corrected producer report.

```bash
bash reproduce.sh
```

This is a quoted original entrypoint. The script itself and the complete ZIP were **not expanded in this revision**, so this guide does not claim to have inspected its entire command sequence. The report and corrected audit identify the adopted `final/` ledgers and the 16 trees. The report explicitly says that the finite-window kernel is reused with its parameter lower-bound guard changed.

The original production elapsed time and maximum tree depth are not recorded in the inspected report/log texts. The available audit log records a later regeneration and checking run; those times are labeled as audit replay times in the manuscript. E2's withdrawn spherical polynomial bound is not part of the accepted input.

### C4: finite prolate window

Source: the inspected package `README.md` and `reproduce.sh`.

For alternate-build replay of the archived terminal and quadrature records:

```bash
bash reproduce.sh replay
```

For regeneration of the producer records followed by replay:

```bash
bash reproduce.sh full
```

The script works in a new temporary directory. The full mode compares decompressed ledger rows so gzip header timestamps do not affect equality. Requirements recorded by the README are Linux, a rounding-aware C++ compiler, Python 3, NumPy, and SymPy. `python-flint` is needed only if the upstream integer-kernel coefficient table is regenerated from scratch; the archived table is sufficient for its integer recheck. Matplotlib is used for figures.

Original-kernel replay includes more records than the logical classification needs. In particular, the general-H atlas preserves 21,254 sign-undetermined leaves; those are not silently promoted to signed leaves. The classification uses the separate vertical, equatorial and parameter-derivative covers. A successful original-kernel replay does not supply a second derivation of its fourth-order or parameter-derivative formulas.

### C5: finite tail bridge and coefficient anchors

Source: the inspected package `README.md` and `reproduce.sh`.

```bash
bash reproduce.sh
```

The original script creates a fresh output directory, rebuilds the coefficient table and integer kernels, computes the anchors and all three bridge slabs, checks tree structure, replays with another build, compares the archived outputs, and runs the preserved diagnostic/Arb spot checks. Its internal timeout values are part of the original script and are not changed here.

Recorded requirements are Linux, C++20, Python 3.12, `python-flint` 0.8.0, and NumPy 2.3.5; the original compiler is GCC 14.2.0. The README permits separate Python environments through `FLINT_PYTHON` and `NUMPY_PYTHON`. The bridge uses three processes; spot checks use at most four.

The independent audit covers 23 selected negative leaves out of 1,845. The producer's additional three-parent Arb check preserves its four unresolved first-generation children and subsequent successful subdivision. These are overlapping local checks, not a second independent full cover.

### C6: polar lower-envelope integral

Source: the inspected package `README.md`. Use a **fresh writable extracted copy** of its root directory; these scripts write their output next to themselves.

```bash
python cap_cover_r2.py && python check_cover.py && python exact_checks.py && python algebra_checks.py
```

Recorded requirements are Python 3, `python-flint` 0.8.0, and SymPy. NumPy is used only by the separate exploratory point script. The fixed interval cover uses 128-bit Arb, four local processes, 1,024 outer boxes, and a 96×48 spatial grid.

`check_cover.py` validates indices, exact endpoints, duplicates and rational lower bounds. It is not an independent integral implementation. The original audit regenerated the same 1,024-box cover and checked the analytic lower-envelope derivation; this bundle does not claim a second independently implemented full integration. The script sequence also retains historical exact checks whose scope may exceed the C6 input. In particular, the old `2^13000` sufficient threshold depends on a separate remainder argument and is not used by the current proof for λ≥5.

## What remains outside this reproduction claim

The thin-oblate analytic report and the prolate axial L2 argument have separate fixed references in `references.bib` and the manifest. Their mathematical derivations cannot be replaced by executing a numerical script. The asymptotic appendix of the former and the old transverse threshold of the latter are explicitly excluded from the present input chain.

C2 still needs a consolidated map of all raw legacy ledgers and their pinned evaluators for a complete integrated replay. C3 still needs its complete corrected package to be materialized and inspected in the revision environment. Full independently implemented interval re-enclosure of every required gate is not supplied by the sample audits. A common processor/memory profile or a unified whole-project runtime is not recorded and has not been estimated.

Any later reproduction should report separately: byte identity, exact coverage reconstruction, original-kernel replay, independent formula derivation, independent interval evaluation, and noninterval diagnostic agreement. These checks answer different questions.
