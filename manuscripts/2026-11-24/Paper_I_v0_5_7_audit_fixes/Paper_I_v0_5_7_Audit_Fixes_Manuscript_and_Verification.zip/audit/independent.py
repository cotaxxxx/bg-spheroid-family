"""Whole-box Darboux sign checks directly on the fixed sphere; no V50 kernel imports.
Each requested file/path is a selected geometric leaf of the original archive.
"""
import csv, gzip, json, sys
from pathlib import Path
from functools import lru_cache
import numpy as np
from mpmath import iv
iv.dps=45
U=2**20
def low(x):return np.nextafter(x,-np.inf)
def high(x):return np.nextafter(x,np.inf)
class I:
    __array_priority__=1000
    def __init__(self,l,h=None):
        self.l=np.asarray(l,dtype=float);self.h=self.l if h is None else np.asarray(h,dtype=float)
    def __add__(a,b):
        b=ball(b);return I(low(a.l+b.l),high(a.h+b.h))
    __radd__=__add__
    def __neg__(a):return I(-a.h,-a.l)
    def __sub__(a,b):return a+-ball(b)
    def __rsub__(a,b):return -a+b
    def __mul__(a,b):
        b=ball(b);v=[a.l*b.l,a.h*b.h,a.l*b.h,a.h*b.l]
        return I(low(np.minimum.reduce(v)),high(np.maximum.reduce(v)))
    __rmul__=__mul__
    def __truediv__(a,b):
        b=ball(b)
        if np.any(b.l<=0):raise ValueError('nonpositive divisor')
        return a*I(low(1/b.h),high(1/b.l))
    def __rtruediv__(a,b):return ball(b)/a
    def sq(a):
        return I(np.maximum(0,low(np.maximum(np.maximum(a.l,-a.h),0)**2)),
                 high(np.maximum(a.l**2,a.h**2)))
    def sqrt(a):return I(np.maximum(0,low(np.sqrt(np.maximum(0,a.l)))),high(np.sqrt(a.h)))
def ball(x):return x if isinstance(x,I) else I(x)
@lru_cache(None)
def grid(n):
    s=np.arange(2*n+1)/(2*n)
    x=1-2*s*s  # dyadic cell endpoints, clustered at the direction of contact
    X=I(x[1:,None],x[:-1,None])
    horiz=(1-X.sq()).sqrt()
    angles=[iv.pi*i/(2*n) for i in range(n+1)]
    # Outward binary64 casts of 45-digit interval transcendental endpoints.
    def bounds(fun):
        ends=[fun(v) for v in angles]
        return I(np.maximum(0,low([min(float(a.a),float(b.a)) for a,b in zip(ends,ends[1:])])),
                 np.minimum(1,high([max(float(a.b),float(b.b)) for a,b in zip(ends,ends[1:])])))
    return X,horiz*bounds(iv.cos),horiz*bounds(iv.sin)
@lru_cache(None)
def angular_table():
    # P(1-u)=sum p_j u^j, p_0=2, p_j=j p_(j-1)/(2j+1).
    # For derivatives through order 2 the omitted tail at u<=1 is
    # bounded by sum_{j>=81} 2*j^2/2^j < 2^-64.
    N=4096
    u=I(np.arange(N)/N,(np.arange(N)+1)/N)
    coeff=[I(2)]
    for j in range(1,81):coeff.append(coeff[-1]*j/(2*j+1))
    out=[]
    for d in range(3):
        acc=I(0)
        for j in range(80,d-1,-1):
            fac=(1,j,j*(j-1))[d]
            acc=acc*u+coeff[j]*fac
        out.append(acc+I(0,2**-64))
    return out
def functions(g):
    # 1-g by interval subtraction before conversion to an index.
    u=1-g; a=np.clip(np.floor(u.l*4096),0,4095).astype(int);b=np.clip(np.floor(u.h*4096),0,4095).astype(int)
    P,minusP1,P2=[I(v.l[a],v.h[b]) for v in angular_table()]
    return P,2*P-g*minusP1,-3*minusP1+g*P2
def mean(f):
    # Pairwise addition with outward rounding; grid cardinality is a power of two.
    a=f.l.ravel();b=f.h.ravel();size=len(a)
    while len(a)>1:a=low(a[::2]+a[1::2]);b=high(b[::2]+b[1::2])
    return float(low(a[0]/size)),float(high(b[0]/size))
def enclosure(kind,box,n):
    la,lb,ra,rb=box;L=I(la/U,lb/U);r=I(ra/U,rb/U);x,y,m=grid(n)
    D2=(x-r).sq()+y.sq()+(L*m).sq()
    # Independent geometric lower bound from |L(xi-q)|>=1-r, L>=1.
    D2.l=np.maximum(D2.l,(1-r).sq().l)
    D=D2.sqrt();S2=x.sq()+y.sq()+(m/L).sq()
    S2.l=np.maximum(S2.l,(1/L).sq().l)
    S=S2.sqrt();g=(1-r*x)/(D*S);g=I(np.maximum(0,g.l),np.minimum(1,g.h))
    P,Q,Q1=functions(g);A=g.sq()*P;W=S/D
    ux=(x-r)/D;uy=y/D;nx=x/S;ny=y/S
    bx=nx-g*ux;by=ny-g*uy
    if kind=='radial_curvature_negative':f=W*(A*(1-ux.sq())-Q*bx.sq())
    elif kind=='radial_decreasing':
        f=3*W*(A*(uy.sq()-ux.sq())-Q*(bx.sq()-by.sq()))/r.sq()
    else:
        ds=-m.sq()/(L*L.sq()*S2);dd=L*m.sq()/D2
        dg=-g*(dd+ds);dy=-ny*ds-dg*uy+g*uy*dd
        term=A*(1-uy.sq())-Q*by.sq()
        f=W*((ds-dd)*term+g*Q*dg*(1-uy.sq())+2*A*uy.sq()*dd-Q1*dg*by.sq()-2*Q*by*dy)
    weights=(2*np.arange(2*n)+1)/(2*n)  # exact mean density dx/2 on each panel
    return mean(f*I(weights[:,None]))
def read_leaves(root,pattern):
    for p in sorted(Path(root).glob(pattern)):
        with gzip.open(p,'rt') as f:
            for row in csv.DictReader(f,delimiter='\t'):
                if not row['action'].startswith('split'):
                    yield (p.name.split('.')[0],row['path'],row['action'],tuple(int(row[k]) for k in ['l0','l1','r0','r1']))
def children(box):
    a,b,c,d=box
    if (b-a)>3*(d-c):m=(a+b)//2;return [(a,m,c,d),(m,b,c,d)]
    m=(c+d)//2;return [(a,b,c,m),(a,b,m,d)]
def verify(leaf):
    tree,path,kind,box=leaf
    todo=[(box,0)];rows=[]
    while todo:
        b,d=todo.pop()
        for n in (32,64,128,256):
            lo,hi=enclosure(kind,b,n)
            if hi<0:break
        if hi>=0 and d<8:todo.extend((c,d+1) for c in children(b))
        else:rows.append(dict(box=b,lower=lo,upper=hi,n=n))
    return dict(tree=tree,path=path,kind=kind,box=box,upper=max(r['upper'] for r in rows),parts=rows)
if __name__=='__main__':
    from concurrent.futures import ProcessPoolExecutor
    R=sys.argv[1]
    leaves=list(read_leaves(R,'ledgers/N3/E*.gz'))+list(read_leaves(R,'ledgers/N4/D*.gz'))
    # Narrowest normalized width, then largest inner radius, then tree and binary path.
    selected=[min((v for v in leaves if v[2]==kind),key=lambda v:((v[3][1]-v[3][0])+3*(v[3][3]-v[3][2]),-v[3][2],v[0],v[1])) for kind in ('radial_curvature_negative','radial_decreasing','lambda_decreasing')]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for r in pool.map(verify,selected):
            Path(sys.argv[2],r['kind']+'.json').write_text(json.dumps(r,indent=2)+'\n');print(r['kind'],r['upper'],len(r['parts']),flush=True)
