"""Check exact domains, binary splits, accepted inequalities, and the inferred uniform margin."""
import csv,sys,json
from collections import Counter
from pathlib import Path
from fractions import Fraction as F
U=2**20
def inspect(directory):
    count=Counter(); upper=None
    for i in range(12):
        with open(Path(directory)/f'slab{i:02}.tsv') as f:rows=list(csv.DictReader(f,delimiter='\t'))
        by={r['path']:r for r in rows}
        assert len(by)==len(rows)
        todo=[('x',(2*U+i*U//4,2*U+(i+1)*U//4,0,U))]
        while todo:
            path,box=todo.pop();r=by.pop(path)
            assert tuple(int(r[k]) for k in ['l0','l1','r0','r1'])==box
            a,b,c,d=box
            if r['decision']=='negative':
                if r['mode']=='T':
                    assert d<=U//2
                    v=F(int(r['ahi']),2**36)
                else:
                    assert r['mode']=='E' and c>0 and int(r['bhi'])<int(r['alo'])
                    v=F(3*(int(r['bhi'])-int(r['alo']))*U**2,2**36*d*d)
                assert v<0
                count[r['mode']]+=1
                upper=v if upper is None else max(upper,v)
            else:
                if r['decision']=='splitl':m=(a+b)//2; halves=[(a,m,c,d),(m,b,c,d)]
                else:
                    assert r['decision']=='splitr';m=(c+d)//2;halves=[(a,b,c,m),(a,b,m,d)]
                todo.extend((path+str(j),v) for j,v in enumerate(halves))
        assert not by
    return dict(negative_leaves=count,upper=str(upper),upper_decimal=float(upper))
if __name__=='__main__':print(json.dumps(inspect(sys.argv[1]),indent=2))
