// DIAGNOSTIC_ONLY / NOT_EVIDENCE. Enclosures use probability sphere measure.
// Input: mode; six endpoints (lambda,rho,z, in 2^-20 units); two angular counts.
#include "interval.hpp"
#include <iostream>
#include <map>
#include <memory>
#include <string>
using std::string;
constexpr double SCALE=1048576.;
struct Outer {I l,r,z,l2,eps,ecc,delta;};
struct Result {I first,second;};
std::unique_ptr<Tables> tb;
std::map<int,std::vector<Arc>> ac;
const std::vector<Arc>& arcs(int n){
 if(!ac.count(n))ac.emplace(n,angular(n));
 return ac.at(n);
}
inline I pm(I v,int sig){return sig>0?v:-v;}
inline I accurate_B(I xisq,I horiz,I eps,I ecc){
 return meet(meet(1-ecc*xisq,eps+ecc*horiz),{eps.l,1});
}
// E_z directly on the original fixed sphere.
I gradient(const Outer& p,int nm,int na){
 I sum=0;
 for(int i=0;i<nm;i++){
  I mu{-1.+2.*i/nm,-1.+2.*(i+1)/nm},m2=sq(mu),s2=1-m2,s=root(s2);
  I B=accurate_B(m2,s2,p.eps,p.ecc),b=root(B),normalz=mu/(p.l*b);
  I dz=mu-p.z,lz=p.l*dz,lz2=sq(lz),rs=p.r*s;
  I dz2=sq(dz),base=sq(s-p.r);
  for(const auto& a:arcs(na)){
   I A=base+2*rs*(1-a.c);
   I k=meet(1-mu*p.z-rs*a.c,(p.delta+A+dz2)*.5);
   k=meet(k,{0,2});
   I D=root(A+lz2),vz=ratio_unit(lz,D);
   I g{0,1};
   if(D.l>0) g=bound01(k/(D*b));
   // Projection on the unit physical line. Remains bounded at the contact cell.
   I U=meet(mu*tb->get(JG,g)-p.l*b*vz*tb->get(KG,g),
            mu*tb->get(JG,g)-p.l*b*vz*meet(sq(g)*tb->get(FP,g),{0,2}));
   (void)normalz;
   sum=sum+U;
  }
 }
 return sum/(double(nm)*na);
}
// E_zz on the low-z strip: axial projection of the chord Hessian.
I axial_curvature(const Outer& p,int nm,int na){
 I sum=0;
 for(int i=0;i<nm;i++){
  I m{double(i)/nm,double(i+1)/nm},m2=sq(m),s2=1-m2,s=root(s2);
  I C=1+(p.l2-1)*m2,ci=inv(C),c=inv(root(C));
  I z0=p.z*m,v1=p.r*s, vbase=p.z*s2;
  I b0=-(p.l2-1)*s2*ci;
  I positive=p.l2*s2*sq(ci);
  for(const auto& a:arcs(na)){
   I ex=s*a.c, v=symclip(z0+v1*a.c);
   I d2=bound01(p.delta+sq(v));
   d2=meet(d2,1-sq(p.r*m*a.c-p.z*s)-sq(p.r)*a.ss);
   I d=root(d2),w=bound01((1-ratio_unit(v,d))*.5);
   I u=vbase-p.r*ex*m;
   I val[2];
   for(int k=0;k<2;k++){
    int sig=k?1:-1;
    I ell=meet(d-pm(v,sig),{0,2*d.h});
    I mu=symclip(p.z+pm(ell*m,sig)),x=symclip(p.r+pm(ell*ex,sig));
    I hor=bound01(sq(x)+sq(ell)*s2*a.ss);
    I B=accurate_B(sq(mu),hor,p.eps,p.ecc),T=c*inv(root(B));
    I g=bound01(d*T);
    I X=u+pm(m*d*b0,sig);
    val[k]=T*(tb->get(FP,g)*d2*positive-tb->get(QV,g)*sq(X));
   }
   sum=sum+blend(val[1],val[0],w);
  }
 }
 return sum/(double(nm)*na);
}
// Equator. Polar axis for e is the radial x axis. Return H and radial E_xx.
Result equator(const Outer& p,int nm,int na){
 I sh=0,sr=0,rr=sq(p.r);
 for(int i=0;i<nm;i++){
  I t{double(i)/nm,double(i+1)/nm},t2=sq(t),a2=1-t2;
  I v=p.r*t,d2=meet(1-rr*a2,1-rr+sq(v)),d=root(bound01(d2));
  I w=bound01((1-ratio_unit(v,d))*.5);
  I ell[2],xx2[2];
  for(int k=0;k<2;k++){
   int sig=k?1:-1;
   ell[k]=meet(d-pm(v,sig),{0,2*d.h});
   xx2[k]=sq(symclip(p.r*a2+pm(t*d,sig)));
  }
  for(const auto& a:arcs(na)){
   I m2=a2*a.cs,j=a2*a.ss,C=1+(p.l2-1)*m2,ci=inv(C),c=inv(root(C)),u=1-ci;
   I po=d2*ci,vh[2],vr[2];
   for(int k=0;k<2;k++){
    int sig=k?1:-1;
    I mu2=bound01(meet(sq(ell[k])*m2,(1-xx2[k])*a.cs));
    I B=accurate_B(mu2,xx2[k]+(1-xx2[k])*a.ss,p.eps,p.ecc);
    I T=c*inv(root(B)),g=bound01(d*T);
    I P=tb->get(FP,g)*po,Q=tb->get(QV,g);
    I gside=d*u-pm(v,sig);
    vh[k]=T*(P*(1-j*ci)-Q*j*sq(gside));
    vr[k]=T*(P*(1-t2*ci)-Q*sq(p.r*a2+pm(t*d*u,sig)));
   }
   sh=sh+blend(vh[1],vh[0],w);sr=sr+blend(vr[1],vr[0],w);
  }
 }
 I n=double(nm)*na;
 return {sh/n,sr/n};
}
// Equatorial H at center or boundary and its lambda derivative.
Result ends(const Outer& p,int nm,int na,bool boundary){
 I H=0,D=0;
 for(int i=0;i<nm;i++){
  I t{double(i)/nm,double(i+1)/nm},t2=sq(t);
  int count=boundary?na:1;
  for(int j0=0;j0<count;j0++){
   I m2=t2,j=(1-t2)*.5,k=1,d=1,xisq=t2;
   if(boundary){
    const Arc& a=arcs(na)[j0];m2=(1-t2)*a.cs;j=(1-t2)*a.ss;
    k=2;d=t;
    I four=bound01(meet(4*t2*(1-t2),1-sq(1-2*t2)));
    xisq=four*a.cs;
   }
   I C=1+(p.l2-1)*m2,ci=inv(C),B=accurate_B(xisq,1-xisq,p.eps,p.ecc);
   I T=inv(root(C*B)),g=bound01(d*T),F=tb->get(FP,g),Q=tb->get(QV,g);
   I fc=ci*(1-j*ci),qc=j*sq(k-ci);
   I A=F*fc-Q*qc,term=T*sq(d)*A;
   I logT=xisq*p.eps/(p.l*B)-p.l*m2*ci;
   I cip=-2*p.l*m2*sq(ci);
   I dA=g*logT*(-tb->get(NEGFP1,g)*fc+tb->get(NEGQ1,g)*qc)
          +cip*(F*(1-2*j*ci)+2*Q*j*(k-ci));
   H=H+term;D=D+(term*logT+T*sq(d)*dA);
  }
 }
 I n=double(nm)*(boundary?na:1);
 return {H/n,D/n};
}
// Original transverse fourth derivative; safe away from the boundary.
I transverse4(const Outer& p,int nm,int na){
 I sum=0;
 for(int i=0;i<nm;i++){
  I m{double(i)/nm,double(i+1)/nm},m2=sq(m),s2=1-m2,s=root(s2);
  I B=accurate_B(m2,s2,p.eps,p.ecc),b=root(B),C=1+(p.l2-1)*m2;
  for(const auto& a:arcs(na)){
   I x=s*a.c,y2=s2*a.ss,k=1-p.r*x;
   I D2=meet(C-2*p.r*x+sq(p.r),sq(s-p.r)+2*s*p.r*(1-a.c)+p.l2*m2);
   I Di=inv(root(D2)),g=bound01(k*Di/b),g2=sq(g);
   I P=tb->get(FP,g),Q=tb->get(QV,g),Q1=-tb->get(NEGQ1,g),Q2=tb->get(::Q2,g);
   I nu2=bound01(y2/D2),A=P*g2,L=1-nu2;
   I j=1-k/D2; // beta = y*j / b
   I beta2=meet(y2*sq(j)/B,{0,((1-g2)*L).h});
   I n_beta=y2*Di*j/b;
   I fourth=-3*(A+g2*Q)*sq(L)+12*A*nu2*L-24*n_beta*g*Q*L
          +(6*(Q+g*Q1)*L-12*nu2*Q)*beta2
          +8*n_beta*Q1*beta2-Q2*sq(beta2);
   sum=sum+b*Di/D2*fourth;
  }
 }
 return sum/(double(nm)*na);
}
int main(){
 try {
  setup();tb=std::make_unique<Tables>();
  string mode;int a,b,r,s,z,y,n,k;
  while(std::cin>>mode>>a>>b>>r>>s>>z>>y>>n>>k){
   if(a<2*SCALE||b>5*SCALE||a>b||r<0||r>s||s>SCALE||z<0||z>y||y>SCALE||
      n<1||n>1048576||(n&(n-1))||k<2||k>65536||(k&(k-1)))
    throw std::runtime_error("parameter range");
   I l{a/SCALE,b/SCALE},R{r/SCALE,s/SCALE},Z{z/SCALE,y/SCALE};
   if(sq(R).l+sq(Z).l>1){std::cout<<"empty"<<std::endl;continue;}
   R.h=std::min(R.h,root(1-sq(I(Z.l))).h);
   Z.h=std::min(Z.h,root(1-sq(I(R.l))).h);
   I L=sq(l),ep=inv(L),delta=bound01(1-sq(R)-sq(Z));
   Outer p{l,R,Z,L,ep,1-ep,delta};Result result;
   if(mode=="V")result={gradient(p,n,k),0};
   else if(mode=="Z")result={axial_curvature(p,n,k),0};
   else if(mode=="E")result=equator(p,n,k);
   else if(mode=="T")result={transverse4(p,n,k),0};
   else if(mode=="C"||mode=="B")result=ends(p,n,k,mode=="B");
   else throw std::runtime_error("bad mode");
   constexpr double units=0x1p36;
   for(I v:{result.first,result.second}){
    if(!std::isfinite(v.l)||!std::isfinite(v.h)||v.l>v.h||v.h>1e7||v.l<-1e7)
     throw std::runtime_error("range of result");
    std::cout<<static_cast<long long>(std::floor(v.l*units))<<' '
             <<static_cast<long long>(std::ceil(v.h*units))<<' ';
   }
   std::cout<<std::endl;
  }
  return std::cin.eof()?0:2;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 3;}
}
