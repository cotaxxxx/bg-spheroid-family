// DIAGNOSTIC_ONLY / NOT_EVIDENCE. Binary64 intervals; FE_UPWARD throughout.
#pragma once
#include <algorithm>
#include <array>
#include <bit>
#include <cfenv>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <stdexcept>
#include <vector>
#pragma STDC FENV_ACCESS ON
struct I { double l,h; I(double v=0):l(v),h(v){} I(double a,double b):l(a),h(b){} };
inline I operator-(I a){return {-a.h,-a.l};}
inline I operator+(I a,I b){return {-((-a.l)+(-b.l)),a.h+b.h};}
inline I operator-(I a,I b){return {-((-a.l)+b.h),a.h+(-b.l)};}
inline double dnprod(double a,double b){return -((-a)*b);}
inline I operator*(I a,I b){
 if(a.l>=0){
   if(b.l>=0)return {dnprod(a.l,b.l),a.h*b.h};
   if(b.h<=0)return {dnprod(a.h,b.l),a.l*b.h};
   return {dnprod(a.h,b.l),a.h*b.h};
 }
 if(a.h<=0)return -((-a)*b);
 if(b.l>=0)return {dnprod(a.l,b.h),a.h*b.h};
 if(b.h<=0)return {dnprod(a.h,b.l),a.l*b.l};
 return {std::min(dnprod(a.l,b.h),dnprod(a.h,b.l)),std::max(a.l*b.l,a.h*b.h)};
}
inline I inv(I a){if(a.l<=0)throw std::domain_error("nonpositive reciprocal");return {-((-1.0)/a.h),1.0/a.l};}
inline I operator/(I a,I b){return a*inv(b);}
inline I sq(I a){
 double u=std::max(-a.l,a.h), v=std::max({0.,a.l,-a.h});
 return {dnprod(v,v),u*u};
}
inline I meet(I a,I b){
 I r(std::max(a.l,b.l),std::min(a.h,b.h));
 if(!(r.l<=r.h))throw std::domain_error("disjoint intervals");
 return r;
}
inline I root(I a){
 if(a.l<0)throw std::domain_error("negative sqrt");
 double b=std::sqrt(a.l);
 // IEEE-754 sqrt in upward mode is an upper endpoint, even if inexact.
 if(a.l!=0) b=std::bit_cast<double>(std::bit_cast<uint64_t>(b)-1);
 return {b,std::sqrt(a.h)};
}
inline I bound01(I a){return meet(a,{0,1});}
inline I symclip(I a){return meet(a,{-1,1});}
inline I blend(I a,I b,I w){ // w*a+(1-w)*b; exact extrema of independent intervals
 I wl=w.l, wh=w.h;
 return {(I(b.l)+(I(a.l)-b.l)*(a.l>b.l?wl:wh)).l,
         (I(b.h)+(I(a.h)-b.h)*(a.h>b.h?wh:wl)).h};
}
inline I ratio_unit(I x,I d){ // known -1 <= x/d <= 1
 if(d.l>0)return symclip(x/d);
 if(d.h==0)return {-1,1};
 return {x.l>0?(-( (-x.l)/d.h)):(x.l==0?0.:-1.),
         x.h<0?x.h/d.h:(x.h==0?0.:1.)};
}
inline void setup(){
 if(std::fesetround(FE_UPWARD)!=0 || std::fegetround()!=FE_UPWARD)throw std::runtime_error("round mode");
 volatile double u=1.,t=0x1p-53;
 I p=I(u)+I(t), n=I(u)-I(-t);
 if(p.l!=1. || p.h!=1.+0x1p-52 || n.l!=1. || n.h!=p.h)
  throw std::runtime_error("rounding self-test");
}
constexpr int NT=8192;
enum Func { FP,QV, NEGFP1,NEGQ1,Q2, JG, KG, NFUNC };
struct Tables{
 std::array<std::array<I,NT+1>,NFUNC> a;
 Tables(){
  constexpr int N=60;
  std::array<I,N+2> aa,qq;
  aa[0]=1;
  for(int n=0;n<=N;n++)aa[n+1]=aa[n]*(2*n+2)/I(2*n+3);
  for(int n=0;n<=N;n++)qq[n]=(4+2*n)*aa[n]-(n+1)*aa[n+1];
  for(int i=0;i<=NT;i++){
   I g=double(i)/NT,h=(1-g)*.5;
   I p=0,q=0,p1=0,q1=0,q2=0,angle=0;
   for(int n=N;n>=0;--n){
    p=p*h+2*aa[n]; q=q*h+qq[n]; angle=angle*h+4*aa[n]/I(n+1);
    if(n>=1){p1=p1*h+n*aa[n]; q1=q1*h+(.5*n)*qq[n];}
    if(n>=2)q2=q2*h+(.25*n*(n-1))*qq[n];
   }
   I tail{0,0x1p-38};
   p=p+tail;q=q+tail;p1=p1+tail;q1=q1+tail;q2=q2+tail;angle=angle*h+tail;
   a[FP][i]=p;a[QV][i]=q;a[NEGFP1][i]=p1;a[NEGQ1][i]=q1;a[Q2][i]=q2;
   a[JG][i]=g*p-angle;a[KG][i]=sq(g)*p;
  }
 }
 I get(Func k,I g)const{
  int lo=std::max(0,int(g.l*NT)), hi=std::min(NT,int(std::ceil(g.h*NT)));
  if(k==JG||k==KG)return {a[k][lo].l,a[k][hi].h};
  return {a[k][hi].l,a[k][lo].h};
 }
};
struct Arc {I c,cs,ss;};
inline std::vector<Arc> angular(int n){
 if(n<2 || (n&(n-1)))throw std::runtime_error("non-dyadic azimuth grid");
 std::vector<I> p{1,0,-1}; I ck=0;
 for(int k=2;k<n;k*=2){
  ck=root((1+ck)*.5);
  std::vector<I> u(2*k+1);
  for(int j=0;j<=k;j++)u[2*j]=p[j];
  for(int j=0;j<k;j++)u[2*j+1]=symclip((p[j]+p[j+1])/(2*ck));
  p.swap(u);
 }
 std::vector<Arc> out;
 for(int j=0;j<n;j++){
  I c{p[j+1].l,p[j].h}, cs=sq(c);
  out.push_back({c,cs,1-cs});
 }
 return out;
}
