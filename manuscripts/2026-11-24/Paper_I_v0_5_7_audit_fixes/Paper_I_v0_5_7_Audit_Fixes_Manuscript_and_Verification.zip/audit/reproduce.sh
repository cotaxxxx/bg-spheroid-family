#!/usr/bin/env bash
set -eu -o pipefail
cd "$(dirname "$0")"
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
g++ -std=c++20 -O3 -frounding-math -ffp-contract=off -fno-fast-math snapshots/kernel.cpp -o "$stage/kernel"
python single_gate.py "$stage/kernel" "$stage/mono"
diff -qr mono "$stage/mono"
python cover_check.py "$stage/mono" > "$stage/summary.json"
diff mono_summary.json "$stage/summary.json"
mkdir "$stage/selected"
python independent.py snapshots "$stage/selected"
diff -qr selected "$stage/selected"
