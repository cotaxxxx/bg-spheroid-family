"""Test E_yyyy < 0 over the entire V50 equator using two equivalent representations."""
import argparse, csv, subprocess
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
U = 2**20
def slab(job):
    slab_id, exe, output = job
    proc = subprocess.Popen([exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,text=True)
    todo=[('x', 2*U+slab_id*U//4,2*U+(slab_id+1)*U//4,0,U)]
    with open(Path(output)/f'slab{slab_id:02}.tsv','w') as f:
        wr=csv.writer(f,delimiter='\t',lineterminator='\n')
        wr.writerow('path l0 l1 r0 r1 mode n k alo ahi blo bhi decision'.split())
        while todo:
            path,l,h,r,s=todo.pop()
            mode='T' if s<=U//2 else 'E'
            n,k=(64,32) if len(path)<5 else ((128,64) if len(path)<10 else (256,128))
            proc.stdin.write(f'{mode} {l} {h} {r} {s} 0 0 {n} {k}\n')
            proc.stdin.flush()
            a,b,c,d=map(int,proc.stdout.readline().split())
            if (mode=='T' and b<0) or (mode=='E' and r>0 and d<a): action='negative'
            elif len(path)>=18:action='unresolved'
            elif (s-r)*4 >= h-l:
                m=(r+s)//2
                todo.extend([(path+'1',l,h,m,s),(path+'0',l,h,r,m)])
                action='splitr'
            else:
                m=(l+h)//2
                todo.extend([(path+'1',m,h,r,s),(path+'0',l,m,r,s)])
                action='splitl'
            wr.writerow((path,l,h,r,s,mode,n,k,a,b,c,d,action))
    proc.stdin.close()
    if proc.wait():raise RuntimeError('kernel')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('kernel');p.add_argument('output');args=p.parse_args()
    Path(args.output).mkdir(exist_ok=True,parents=True)
    with ProcessPoolExecutor(max_workers=4) as pool:list(pool.map(slab,[(i,args.kernel,args.output) for i in range(12)]))
