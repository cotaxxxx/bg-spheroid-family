from pathlib import Path
import csv,gzip,sys
from collections import Counter
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
from matplotlib.patches import Rectangle,Patch
U=2**20
families=[('snapshots/ledgers/N3/E*.gz','V50: radial test'),('snapshots/ledgers/N4/D*.gz','V50: shape derivative'),('mono/slab*.tsv','New monotonicity test')]
names={'H_positive':('$H>0$','#c4dfa8'),'H_negative':('$H<0$','#9db7e2'),'radial_curvature_negative':('$E_{xx}<0$','#edb26f'),'radial_decreasing':('$E_{yyyy}<0$','#9c83bc'),'lambda_decreasing':('$H_\\lambda<0$','#83c6c5'),'T':('direct fourth derivative','#9c83bc'),'E':('Hessian difference','#edb26f')}
fig,axs=plt.subplots(1,3,figsize=(10,3.7),sharey=True)
for ax,(pattern,title) in zip(axs,families):
 groups={}
 for f in sorted(Path('.').glob(pattern)):
  with (gzip.open(f,'rt') if f.suffix=='.gz' else f.open()) as stream:
   for row in csv.DictReader(stream,delimiter='\t'):
    action=row.get('action',row.get('decision'))
    if action.startswith('split'):continue
    key=row['mode'] if action=='negative' else action
    a,b,c,d=[int(row[k])/U for k in ['l0','l1','r0','r1']]
    groups.setdefault(key,[]).append(Rectangle((a,c),b-a,d-c))
 handles=[]
 for key,rs in groups.items():
  label,color=names[key]
  ax.add_collection(PatchCollection(rs,facecolor=color,edgecolor='#414141',linewidths=.22))
  handles.append(Patch(facecolor=color,label=f'{label} ({len(rs)})'))
 ax.set(xlim=(2,5),ylim=(0,1),xlabel='Shape parameter $\\lambda$',title=title);ax.legend(handles=handles,loc='upper left',bbox_to_anchor=(0,-.23),fontsize=8,frameon=False)
axs[0].set_ylabel('Equatorial radius $\\rho$')
fig.subplots_adjust(left=.06,right=.99,top=.90,bottom=.36,wspace=.16)
fig.savefig('../figures/gate_map.pdf')
