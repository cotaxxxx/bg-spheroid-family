# V24 oblate-window verification — preserved primary source

- Source repository: `cotaxxxx/bg-spheroid-family`
- Source commit: `127be52046e9498d1306fe3d35c3e02e91c636de` (2026-11-16)
- Source path: `runs/2026-11-16/D_OB_GLOBAL_CLOSED_V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md`
- URL: https://github.com/cotaxxxx/bg-spheroid-family/blob/127be52046e9498d1306fe3d35c3e02e91c636de/runs/2026-11-16/D_OB_GLOBAL_CLOSED_V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md
- Upstream Git blob SHA-1: `07d30eff3db759abd0e6aab1ef07563cf77049a2`
- Raw SHA-256: `89435cf9457f1245c337d4433ad074258dea1c954a3bec90613f03cd2f092c3c`
- Language: Japanese.
- The source is preserved unchanged, including original internal governance terminology. It is historical evidence, not publication prose.
- Its associated audit is `CHAT_AUDIT_C_V1_1_AND_D_OB_GLOBAL_V0_20261116.md` at the same pinned commit and folder. That audit addressed mathematical assembly and source references and was not a full independent numerical replay.
- This snapshot is included to make the primary source available even if the upstream branch is later deleted. The original GitHub history has not been modified.
