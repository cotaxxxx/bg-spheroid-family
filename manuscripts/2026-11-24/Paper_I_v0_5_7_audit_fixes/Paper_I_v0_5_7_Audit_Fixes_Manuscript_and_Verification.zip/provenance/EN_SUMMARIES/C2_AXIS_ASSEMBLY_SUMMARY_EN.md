# English reading summary — C2 axial census, fixed assembly v1.1

**Primary source**: cotaxxxx/bg-spheroid-family,
commit 2c084bc05e5dd0b0d7deeb9f9c293deeb1d5e40a,
drafts/2026-11-16/C_AXIS_GLOBAL_COVER_ASSEMBLY_V1/C_AXIAL_GLOBAL_COVER_ASSEMBLY_DRAFT_V1.md.

**Source copy in this package**:
provenance/C2/C_AXIAL_GLOBAL_COVER_ASSEMBLY_DRAFT_V1.md.
Verified Git blob SHA-1: d73cd56e65819f850f636c6472fc36f5b2a5474d.
The source's own historical heading may mention the then-pending v1.1
wording-difference audit. Consult later separate audit receipts for
the audit status; do not rewrite the frozen primary text.

## Scope and statement
For lambda in [2/5,33/50], g(t,lambda) is the axial derivative on
t in (-1,1) with g(0,lambda)=0. The positive internal-root count
is N_+(lambda)=#{t in (0,1):g(t,lambda)=0}. The centre t=0 and pole
t=1 do not contribute.

The fixed 10-case sign-gate ledger leads to the following ordered
values of N_+:
0, 0, 1, 1, 1, 1, 1, 1, 0, 0.
Equivalently, a unique positive interior root exists only for
c_o<lambda<b_o. Its reflection yields the axial pair. At lambda=b_o
the root is on the **boundary** and is not counted; lambda_x is an
intermediate crossing at t=1/2, counted once, not a bifurcation.

The 10-case table is also mapped in
C2_AXIS_CENSUS_TRACE_v0_5_4.md, which identifies the owners of
shared endpoints 83/200, 703/1600, 9/20, 5/8, and 31/32.
The assembly uses the fixed C0/C1a--d, Gap-1/Gap-2, band, centre,
polar and analytic sign gates. In particular, it specifies existence,
uniqueness and exclusion, not just sampled graphs.

## Verification boundary
The assembly is a mathematically conditional construction from the
recorded sign gates. It is not a single self-contained rerun of all
underlying interval computations. The current reproduction map,
CURRENT_REPRODUCTION_v0_5_4.md row C2, reports a partial
centre workflow only; **no one-command comprehensive C2 replay** is
part of the bundled operations. A translated synopsis is not a new
certification, and the primary Japanese source remains controlling.

**Status**: Dig-produced English reading summary, not an independent audit.
