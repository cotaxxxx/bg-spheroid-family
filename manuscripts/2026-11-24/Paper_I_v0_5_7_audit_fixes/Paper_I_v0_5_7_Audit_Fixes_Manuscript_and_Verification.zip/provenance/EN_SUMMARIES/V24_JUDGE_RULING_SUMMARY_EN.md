# English reading summary — V24 D-OB global ruling (not a substitute for the Japanese primary record)

**Primary record**: cotaxxxx/bg-spheroid-family, pinned commit
127be52046e9498d1306fe3d35c3e02e91c636de,
runs/2026-11-16/D_OB_GLOBAL_CLOSED_V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md.

**Source copy in this package**:
provenance/V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md.
Verified Git blob SHA-1: 07d30eff3db759abd0e6aab1ef07563cf77049a2.
This is a summary prepared by Dig, not an English ruling issued by Judge.
In this project's governance, "Judge" denotes the author (Katsushi Furuta) acting as final decision-maker.

## Decided scope
Judge adopted the D-OB-GLOBAL theorem and ruled this defined scope CLOSED on
16 November 2026. For the oblate range lambda in [2/5,33/50], all
**interior** stationary points lie on the rotation axis. If N_+(lambda)
is the count of positive interior axial roots, the total number is
1 + 2 N_+(lambda).

- 2/5 <= lambda <= lambda_c: the centre alone (1 interior point).
- lambda_c < lambda < lambda_partial: the centre plus an axial symmetric pair (3).
- lambda_partial <= lambda <= 33/50: the centre alone (1).

At lambda=lambda_c the centre is degenerate, with a negative cubic
coefficient in the axial derivative. At the intermediate parameter lambda_x, the axial root passes
through t=1/2; this is not an additional bifurcation. At
lambda=lambda_partial the axial roots reach the boundary poles and
are **not** counted as interior stationary points.

## Evidence and limits
The ruling identifies the C-axis census accepted under V23 and the D5
global positive transverse-sign cover accepted under V18; the analytic
P1 mapping and similarity reduction connect the components.
The count is unchanged under the indicated positive volume-preserving
similarity normalization. Historical producer comparisons and external
human review are distinct follow-up work. This V24 ruling is not a
blanket certification of the entire spheroidal axis-ratio family and
does not remove Paper I's stated C1--C6 dependencies.

**Status**: primary Japanese Judge ruling copied without modification;
translation-summary metadata, not a new computation or independent audit.
