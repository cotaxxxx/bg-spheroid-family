# Paper I integrated research draft v0.5.4 — reviewer-response editorial candidate (2026-11-23)

Changes from v0.5.3: C2 ten-case gate/root-count table (source v1.1); scope-limited C1–C6 source/ledger/command table in `CURRENT_REPRODUCTION_v0_5_4.md`; explicit oblate branch endpoint argument under C1/C2; abstract's independent analytic results for sphere/thin-oblate end; C4 H-lambda purpose; §10 accurate AI-first-draft provenance caveat. No new interval numerical run, no proof-status upgrade, no completed author attestation. `REPRODUCTION.md` remains archived, unchanged. The full-family Theorem 3.1 is still conditional on C1–C6. **JOURNAL SUBMISSION HOLD; ZENODO NOT PUBLISHED; DIFFERENTIAL AUDIT PENDING.**

---

# Paper I integrated research draft v0.5.3 (2026-11-23)

This is a public-facing editorial revision of v0.5.2 following the Claude audit. No mathematical claim, theorem table, C1--C6 input, numeric result, figure, verification program or computational supplement changes.

- Precise audit scope: a separate project-level **AI-assisted** audit checked assembly and citations, not a fresh independent numerical replay or external human peer review.
- Section 10 discloses Claude's project-level audit and difference reviews in addition to ChatGPT's drafting and verification assistance.
- V24 primary-source provenance: an unchanged byte-exact Japanese record (upstream Git blob `07d30eff3db759abd0e6aab1ef07563cf77049a2`) is archived under `provenance/V24/`; `PROVENANCE.md` prints its full pinned original path.
- Section 10's print-visible text contains the complete commit and the original **basename**; the full original relative path is in the PDF hyperlink and included ZIP provenance note. This corrects the imprecise description in the archived v0.5.2 revision note rather than changing the publication typography.
- PDF metadata now specifies title, author, subject, and keywords.
- Build the integrated PDF with `latexmk -pdf main.tex` and the computational supplement as before.
- The supplied `SOURCE_DIFF_v0_4_to_v0_5_3.patch` is the complete source diff from pinned v0.4, independently replay-tested.

**Status:** v0.5.3 revision candidate for differential audit. Full-family Theorem 3.1 remains conditional on C1--C6. The oblate-window verification covers `lambda in [2/5,33/50]`, not all oblate shapes. No new certification, DOI, Zenodo publication or author final approval is claimed.

## Archived previous README (historical, unmodified below)

# Paper I integrated research draft v0.5.2 (2026-11-23)

This candidate preserves v0.5.1's full mathematical content while correcting the print-visible provenance of the oblate verification and adding approximate threshold values to the first-page summary.

- Changed manuscript sources: `main.tex` (version, threshold approximations, V24 primary-link), `sections/core.tex` (V24 primary-link), and `sections/numerical_discussion.tex` (print-visible V24 primary citation in Section 10).
- Complete replayable patch from v0.4: `SOURCE_DIFF_v0_4_to_v0_5_2.patch` (historical source patches are kept for archive context).
- Review record: `REVISION_v0_5_2_JA.md`.
- Certified? **No**: the full-family classification remains explicitly conditional on C1–C6; the oblate verification is only for the specified window, and the spherical proof is analytic. This is a revision candidate for Claude differential review, not an uploaded Zenodo release.

## Historical v0.5.1 README (unchanged text follows)

# Paper I v0.5.1 — two-part public-facing editorial revision

This version replaces v0.5's boxed front-matter status note with a unified, unboxed **Main result and status** section following the unchanged abstract and keywords. The first **Conditional classification** paragraph is byte-identical to v0.5; the second paragraph consolidates the conditional C1–C6 status, author-verified oblate range with fixed citation, and analytic sphere result.

The two public passages (front section and end of Section 3) replace internal governance language with author-attributed verification language and a fixed GitHub commit. They do not alter mathematical claims or computational records.

- Current patch from v0.4: `SOURCE_DIFF_v0_4_to_v0_5_1.patch`. Historical `SOURCE_DIFF_v0_4_to_v0_5.patch` is retained for provenance only, and is **not** the patch for this revision.
- Current revision note: `REVISION_v0_5_1_JA.md`.
- The complete SHA manifest is `SHA256SUMS` (do not apply the archived v0.4 hash list to this revision).
- This is a draft for Claude's differential audit before public release; it is not a certified submission or published Zenodo record.

## Archived v0.5 README (unaltered below)

# Integrated paper I, v0.5 (editorial revision)

This v0.5 manuscript places the conditional main conclusion before the table of contents and makes three limited clarifications (sphere boundary dominated convergence, sphere Taylor parity, and V24 oblate CLOSED scope). See `REVISION_v0_5_JA.md` for exact boundaries. All computational assets and verification code are inherited byte-for-byte from v0.4. The unchanged computational supplement remains named `Paper_I_v0_4_Computational_Supplement_EN.pdf`. No new certification, publication, DOI, or author approval is claimed. The archival v0.4 hash manifest is preserved under `provenance/`; it describes the OLD file versions and should not be run against the v0.5 tree. For v0.5 verify the root `SHA256SUMS` instead.

## Archived v0.4 README (unchanged below)

# Integrated paper I, v0.4

The English text is in `main.tex`. The separate computational supplement is in `supplement.tex`. Run `latexmk -pdf main.tex supplement.tex` with TeX Live to typeset both. The paper states the rotational classification conditional on named finite assertions. The new records are working calculations for independent inspection. The two non-interval diagnostics in this revision have no evidentiary role.

## Reproduce the revision

On Linux x86_64 install GCC with g++, Python 3.12 and python-flint 0.8.0. The command below re-integrates C6 and the six anchors, checks the two centre endpoints and the two weakest selected gradient leaves, generates the second equatorial arithmetic tables, rebuilds the secondary evaluator and reproduces all 907 original radial boxes on [1,5] including all sub-boxes. It also repeats the bridge refinement and the [1,2] producer. It checks its outputs against the stored records. Exact-byte comparison assumes the original arithmetic environment.

```sh
bash verification/reproduce.sh
```

If python-flint is installed separately, set `ARB_PYTHON=/absolute/path/to/python` for that command. The input files are read in place and outputs are regenerated in a fresh temporary directory. `python verification/check.py` checks coverage and compares the archived bounds without numerical integration. `bash audit/reproduce.sh` redoes the v0.3 radial producer on [2,5] and three earlier selected-derivative tests. It additionally needs NumPy and mpmath. The optional non-interval diagnostic command `OPENBLAS_NUM_THREADS=1 python verification/diagnostics.py` uses NumPy, SciPy, Matplotlib and the earlier fixed-sphere code. Two quadrature orders and all eight rim arcs are in `verification/results/diagnostics.json`.

## Traceability

- `verification/results/checked.json` collects the conclusions of the coverage checker. Input boxes are retained with integer coordinate endpoints. Every row in each second radial ledger gives the original leaf and a binary sub-path relative to that leaf. A blank sub-path is the entire original leaf. Round-trip binary64 upper endpoints are checked as exact dyadic rationals.
- `verification/results/c6.csv` uses the original 16 by 8 by 8 box indices. Its fourth column is the floor of the lower endpoint in units of 2^-48. The anchor upper endpoints in `endpoints.json` are rounded upwards in units of 2^-48. The centre signs use 2^-96.
- `verification/weak_selection.json` fixes the sample and box coordinates. To reconstruct selection and recalculate from the original two extracted archives, use `python verification/weak.py /path/to/oblate/root /path/to/near-sphere/root` in the Arb environment. The original ZIP SHA-256 values are listed in `verification/upstream.sha256`. The included bridge source, geometry and three original ledgers come from the fixed chord-bridge record in the bibliography.
- `verification/results/refine_*.csv` contains the child rows replacing original negative bridge leaves above the target -1/1000. `check.py` validates the original trees, geometry of every replacement and final maxima.
- `README_v03.md` and `REPRODUCTION.md` describe earlier stages. `research/fixed_source_manifest.json` identifies upstream materials for C1–C6. The source and evidence labels belong to their original packages. The present bundle covers the revision and does not consolidate all those archives or claim author approval, publication or a DOI.
