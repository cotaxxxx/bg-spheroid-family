# 第一論文 v0.5.2｜監査後の最小改訂記録

**日付：2026年11月23日**  
**記録・作成：Dig（ChatGPT）**  
**状態：差分監査前の改訂候補。Zenodo未公開。**

## 根拠

- Claudeのv0.5.1差分監査：`cotaxxxx/experimental-mathematics-ai-collaboration`, commit `ea7c2c9d416784d0d5a9b508befef74cd9dc18f2`, `docs/CHAT_AUDIT_PAPER_I_V0_5_1_DIFF_20261123.md`、数学PASS。§3の公開前推奨に対応。
- 扁平側の2026年11月16日一次記録：`cotaxxxx/bg-spheroid-family`, commit `127be52046e9498d1306fe3d35c3e02e91c636de`, `runs/2026-11-16/D_OB_GLOBAL_CLOSED_V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md`。URL：https://github.com/cotaxxxx/bg-spheroid-family/blob/127be52046e9498d1306fe3d35c3e02e91c636de/runs/2026-11-16/D_OB_GLOBAL_CLOSED_V24/JUDGE_RULING_D_OB_GLOBAL_CLOSED_20261116.md
- 原本v0.4ソース：`Paper_I_v0_4_Manuscript_and_Verification.zip` SHA-256 `57ee540bb8f3679e1b5abfaf043d6c961d934a981bddfb9d0dba0bd32a4c4d91`。

## 今回の編集

1. 第1ページ、要旨後の「Main result and status」に臨界値の参考値 \(c_o\approx0.408,\ b_o\approx0.644,\ b_p\approx2.065,\ c_p\approx4.724\) を明記。C1–C6依存と扁平・球の保証範囲は変更していない。
2. 冒頭と第3節末尾の「fixed verification record」のリンク先を、作業状況表STATE.mdから扁平側の一次の記録へ変更。
3. 第10節に一次の記録の相対パス・リポジトリ名・完全コミットSHA・クリック可能な固定リンクを、印刷しても識別可能な形で追加。これにより前出の「see Section 10」の参照先が存在する。
4. 版の表示v0.5.1→v0.5.2。数学の追加・削除は行っていない。

**v0.5.1から内容が変わったLaTeX原稿は `main.tex`、`sections/core.tex`、`sections/numerical_discussion.tex` の3ファイルだけ。** 他のtex・補足PDF・検証コード・数値・図・台帳・参考文献は一切不変。

## 維持する数学的区分

- 定理3.1は計算的主張C1〜C6を仮定した条件付きの分類のまま。表1・表2・数値は変更しない。
- 球の命題4.2は計算によらない解析的な証明のまま。
- 扁平側の既存の受理記録は \(\lambda\in[2/5,33/50]\) に限る。残りの扁平全域・全族分類へ拡張していない。
- 数学の証拠等級・採否を変更しない。Zenodo DOIの新規取得は主張しない。

## 添付

- `Paper_I_v0_5_2_Integrated_EN.pdf`（36ページを目標、ビルド後にページ数と図を点検）
- `Paper_I_v0_5_2_Manuscript_and_Verification.zip`
- `SOURCE_DIFF_v0_4_to_v0_5_2.patch`（凍結v0.4からの完全差分、再適用検証済み）
- ZIP内 `SHA256SUMS` と外部 `Paper_I_v0_5_2_ARTIFACT_SHA256SUMS.txt`。

**裁定：DIFF_AUDIT_PENDING / NO_MATHEMATICAL_RECLASSIFICATION**
