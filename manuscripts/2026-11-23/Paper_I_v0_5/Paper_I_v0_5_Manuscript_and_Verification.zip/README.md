# Integrated paper I, v0.5 (editorial revision)

This v0.5 manuscript places the conditional main conclusion before the table of contents and makes three limited clarifications (sphere boundary dominated convergence, sphere Taylor parity, and V24 oblate CLOSED scope). See `REVISION_v0_5_JA.md` for exact boundaries. All computational assets and verification code are inherited byte-for-byte from v0.4. The unchanged computational supplement remains named `Paper_I_v0_4_Computational_Supplement_EN.pdf`. No new certification, publication, DOI, or author approval is claimed. The archival v0.4 hash manifest is preserved under `provenance/`; it describes the OLD file versions and should not be run against the v0.5 tree. For v0.5 verify the root `SHA256SUMS` instead.

## Archived v0.4 README (unchanged below)

# Integrated paper I, v0.4

The English text is in `main.tex`. The separate computational supplement is in `supplement.tex`. Run `latexmk -pdf main.tex supplement.tex` with TeX Live to typeset both. The paper states the rotational classification conditional on named finite assertions. The new records are working calculations for independent inspection. The two non-interval diagnostics in this revision have no evidentiary role.

## Reproduce the revision

On Linux x86_64 install GCC with g++, Python 3.12 and python-flint 0.8.0. The command below re-integrates C6 and the six anchors, checks the two centre endpoints and the two weakest selected gradient leaves, generates the second equatorial arithmetic tables, rebuilds the secondary evaluator and reproduces all 907 original radial boxes on [1,5] including all sub-boxes. It also repeats the bridge refinement and the [1,2] producer. It checks its outputs against the stored records. Exact-byte comparison assumes the original arithmetic environment.

```sh
bash verification/reproduce.sh
```

If python-flint is installed separately, set `ARB_PYTHON=/absolute/path/to/python` for that command. The input files are read in place and outputs are regenerated in a fresh temporary directory. `python verification/check.py` checks coverage and compares the archived bounds without numerical integration. `bash audit/reproduce.sh` redoes the v0.3 radial producer on [2,5] and three earlier selected-derivative tests. It additionally needs NumPy and mpmath. The optional non-interval diagnostic command `OPENBLAS_NUM_THREADS=1 python verification/diagnostics.py` uses NumPy, SciPy, Matplotlib and the earlier fixed-sphere code. Two quadrature orders and all eight rim arcs are in `verification/results/diagnostics.json`.

## Traceability

- `verification/results/checked.json` collects the conclusions of the coverage checker. Input boxes are retained with integer coordinate endpoints. Every row in each second radial ledger gives the original leaf and a binary sub-path relative to that leaf. A blank sub-path is the entire original leaf. Round-trip binary64 upper endpoints are checked as exact dyadic rationals.
- `verification/results/c6.csv` uses the original 16 by 8 by 8 box indices. Its fourth column is the floor of the lower endpoint in units of 2^-48. The anchor upper endpoints in `endpoints.json` are rounded upwards in units of 2^-48. The centre signs use 2^-96.
- `verification/weak_selection.json` fixes the sample and box coordinates. To reconstruct selection and recalculate from the original two extracted archives, use `python verification/weak.py /path/to/oblate/root /path/to/near-sphere/root` in the Arb environment. The original ZIP SHA-256 values are listed in `verification/upstream.sha256`. The included bridge source, geometry and three original ledgers come from the fixed chord-bridge record in the bibliography.
- `verification/results/refine_*.csv` contains the child rows replacing original negative bridge leaves above the target -1/1000. `check.py` validates the original trees, geometry of every replacement and final maxima.
- `README_v03.md` and `REPRODUCTION.md` describe earlier stages. `research/fixed_source_manifest.json` identifies upstream materials for C1–C6. The source and evidence labels belong to their original packages. The present bundle covers the revision and does not consolidate all those archives or claim author approval, publication or a DOI.
