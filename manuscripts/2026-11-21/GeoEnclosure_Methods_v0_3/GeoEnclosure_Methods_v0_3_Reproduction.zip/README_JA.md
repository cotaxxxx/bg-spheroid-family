# GeoEnclosure 日本語研究ノート v0.3　再現資料

GeoEnclosure_Methods_JA.md は著者確認用の本文である。追試する対象は本文第6節、赤道面の固定した186箱の比較である。

## 再現

Linux、Python 3.10以降、g++（C++20）、bash、diff を使用する。展開したディレクトリで次を実行する。

    sha256sum -c SHA256SUMS
    bash reproduce.sh

最初のコマンドは配布された各ファイルの同一性を確認する。後者は一時ディレクトリに計算核をコンパイルし、12本の二分木と元記録の包囲端点を調べ、新しく生成した箱別判定と件数を rows.csv、results.json と比較する。再計算した箱数は186で、判定別件数は順に56・67・63である。丸めに関するコンパイルオプションは reproduce.sh に記録した。

## 箱別記録

rows.csv の各行が一つの終端箱に対応する。tree と leaf は元の圧縮台帳名と枝の識別子。l0,l1 は形状パラメータの両端、r0,r1 は半径の両端、z0,z1 は高さの両端で、いずれも整数を 2^20 で割って読む。n,k は角度積分の格子数。Hlo,Hhi は半径方向の量 H の包囲端点、ErrLo,ErrHi は半径方向の二階微分の包囲端点であり、それぞれ整数を 2^36 で割る。recorded_mode と recorded_test は元記録の表示と判定名である。fourthLo,fourthHi は、元台帳に四階微分がある箱で再現した包囲端点（単位 2^-36）。空欄は未評価を表す。results.json の by_original_test に元の判定別の内訳を収録した。

classification は本比較で付けた区分である。no_root は H の根の除外、down_at_root_curvature は半径方向の二階微分による根の交差方向の決定、down_at_root_fourth は接方向の四階微分による同じ決定を指す。後二者は根の存在を判定した件数ではない。

## 入力の出典

K. Furuta, *Counting stationary points and saddle circles of a cone-volume-weighted angle energy on spheroids*, v0.4 のソース・計算資料から計算核と N3/E00–E11 の台帳を使用した。元のアーカイブの SHA-256 は 57ee540bb8f3679e1b5abfaf043d6c961d934a981bddfb9d0dba0bd32a4c4d91。固定版は次の場所にある。

https://github.com/cotaxxxx/bg-spheroid-family/tree/a5ab9b5016c8df9b7f94cbfd7cd0e82aeba8dd28/manuscripts/2026-11-20/Paper_I_v0_4

比較用の compare.py は本研究ノートで追加した。同一の計算核で同一分割を再評価する実験である。独立実装による全域の検証や、細分化戦略の速度比較は対象外である。
