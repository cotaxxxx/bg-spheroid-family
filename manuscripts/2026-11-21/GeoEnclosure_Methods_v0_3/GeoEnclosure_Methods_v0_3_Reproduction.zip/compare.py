"""Compare two rules on identical terminal rectangles, with E mode on every leaf."""
import csv
import gzip
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
keys = ['l0', 'l1', 'r0', 'r1', 'z0', 'z1', 'n', 'k']
leaves = []
unit = 2**20
for i in range(12):
    p = root / 'input' / f'E{i:02}.tsv.gz'
    with gzip.open(p, 'rt') as source:
        rows = list(csv.DictReader(source, delimiter='\t'))
    tree = {r['path']: r for r in rows}
    assert len(rows) == len(tree)
    todo = [('x', (2*unit+i*unit//4, 2*unit+(i+1)*unit//4, 0, unit))]
    while todo:
        path, box = todo.pop()
        row = tree.pop(path)
        assert tuple(int(row[k]) for k in keys[:4]) == box
        assert int(row['z0']) == int(row['z1']) == 0
        if row['action'] in ('splitr','splitl'):
            j = 2 if row['action'] == 'splitr' else 0
            left, right = list(box), list(box)
            left[j+1] = right[j] = (box[j]+box[j+1])//2
            todo.extend([(path+'1',tuple(right)), (path+'0',tuple(left))])
        else:
            leaves.append((p.name, row))
    assert not tree
queries = {}
def query(row,mode):
    key = ' '.join([mode] + [row[k] for k in keys])
    queries[key] = None
    return key
jobs = [(name, row, query(row,'E'), query(row,row['mode'])) for name,row in leaves]
run = subprocess.run([sys.argv[1]],input='\n'.join(queries)+'\n',text=True,capture_output=True,check=True)
answers = dict(zip(queries,(list(map(int,s.split())) for s in run.stdout.splitlines()),strict=True))
counts = Counter()
by_original_test = {}
with open(sys.argv[2],'w') as out:
    w = csv.writer(out)
    w.writerow(['tree','leaf',*keys,'Hlo','Hhi','ErrLo','ErrHi','recorded_mode','recorded_test','classification','fourthLo','fourthHi'])
    for name,row,e,original in jobs:
        assert answers[original] == [int(row[k]) for k in ('alo','ahi','blo','bhi')]
        hl,hh,cl,ch = answers[e]
        if hl>0 or hh<0: result='no_root'
        elif ch<0: result='down_at_root_curvature'
        elif row['mode']=='T' and answers[original][1]<0: result='down_at_root_fourth'
        else: result='undecided'
        counts[result]+=1
        by_original_test.setdefault(row['action'], Counter())[result] += 1
        fourth = answers[original][:2] if row['mode'] == 'T' else ['', '']
        w.writerow([name,row['path'],*[row[k] for k in keys],hl,hh,cl,ch,row['mode'],row['action'],result,*fourth])
print(json.dumps(dict(leaves=len(leaves),outcomes=counts,source_replays=len(leaves),by_original_test=by_original_test),indent=2))
