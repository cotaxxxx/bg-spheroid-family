#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
g++ -std=c++20 -O3 -frounding-math -ffp-contract=off -fno-fast-math input/kernel.cpp -o "$tmp/kernel"
python3 -I compare.py "$tmp/kernel" "$tmp/rows.csv" > "$tmp/results.json"
diff -u rows.csv "$tmp/rows.csv"
diff -u results.json "$tmp/results.json"
cat "$tmp/results.json"
