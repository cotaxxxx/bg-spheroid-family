"""Recompute one raw observation using the ellipsoid's outward normal."""
import csv
import math
from pathlib import Path

source = Path(__file__).parent / "input/coarse_raw_first_row.csv"
with source.open(newline="") as stream:
    row, = csv.DictReader(stream)
values = {key: float(value) for key, value in row.items()}
x, y, z = (values[key] for key in ("x", "y", "z_boundary"))
shape, radius = values["lambda"], values["R"]
a = radius * shape ** (-1 / 3)
c = radius * shape ** (2 / 3)
direction = (x - values["rho"], y, z - values["z_base"])
normal = (x / a**2, y / a**2, z / c**2)
distance = math.hypot(*direction)
cosine = sum(d * n for d, n in zip(direction, normal)) / (distance * math.hypot(*normal))
angle = math.acos(cosine)
for key, actual in (("D", distance), ("gamma", cosine), ("Theta", angle)):
    if abs(actual - values[key]) > 1e-12:
        raise ValueError(f"{key}: recalculated {actual}, stored {values[key]}")
print(f"D={distance:.9f}  gamma={cosine:.9f}  Theta={angle:.9f} rad ({math.degrees(angle):.4f} deg)")
