import sympy as S, itertools, time
from fractions import Fraction as Fr
from math import comb
u,v,p,q=S.symbols('u v p q')
vv=S.Rational(3,8)*v
U=1+u*u; V=1+vv*vv; Tn=1-u*u; Gn=1-vv*vv; En=-4*u*vv*p
N0=S.Rational(1,2)*Gn**2*u**2*(3*U**2-7*Tn**2)-8*Gn*En*Tn*u**2+S.Rational(1,2)*En**2*(3*Tn**2-U**2)
N1=4*Gn**3*u**4-8*Gn**2*En*Tn*u**2+Gn*En**2*(3*Tn**2-2*U**2)+2*En**3*Tn
N2=-6*Gn**2*En**2*u**2+2*Gn*En**3*Tn+En**4
NS=12*N0-3*q*N1+q**2*N2-S.Rational(3,8)*q**3*Gn*En**4
Pp=S.Poly(S.expand(6*U**4*V**2-(1+q*vv**2)*NS),u,v,p,q)
# also independently check K = 4(1+q v^2) N_S/(U^4 V^2) equals the kernel from gamma,T,e,eta
g,T,e,eta=S.symbols('g T e eta')
s=1-T**2
V0=g**2*s*(3-7*T**2)/8-2*g*e*T*s+e**2*(3*T**2-1)/2
V1=g**3*s**2/4-2*g**2*e*T*s+g*e**2*(3*T**2-2)+2*e**3*T
V2=-S.Rational(3,2)*g**2*e**2*s+2*g*e**3*T+e**4
K=4*(1+eta*(1-g))*(12*V0-6*eta*V1+4*eta**2*V2-3*eta**3*g*e**4)
Ksub=K.subs({T:Tn/U,g:Gn/V,e:En/(U*V),eta:q*V/2})
print('K rationalization:', S.simplify(Ksub-4*(1+q*vv**2)*NS/(U**4*V**2))==0)
degs=[Pp.degree(x) for x in (u,v,p,q)]; print('degrees',degs,'terms',len(Pp.terms()))
# coefficient array as dict of Fractions
coef={}
for mon,c in Pp.terms(): coef[mon]=Fr(int(c.p),int(c.q))
n=degs
def shift_axis(coef,axis,k,m):
    # x -> (k + x')/m
    out={}
    for mon,c in coef.items():
        j=mon[axis]
        for i in range(j+1):
            nm=list(mon); nm[axis]=i; nm=tuple(nm)
            out[nm]=out.get(nm,Fr(0))+c*comb(j,i)*Fr(k)**(j-i)/Fr(m)**j
    return out
def bern_axis(coef,axis):
    out={}
    for mon,c in coef.items():
        i=mon[axis]
        for h in range(i,n[axis]+1):
            nm=list(mon); nm[axis]=h; nm=tuple(nm)
            out[nm]=out.get(nm,Fr(0))+c*Fr(comb(h,i),comb(n[axis],i))
    return out
t0=time.time(); gmin=None; neg=0
for ks in itertools.product(range(4),repeat=4):
    c=coef
    for ax in range(4): c=shift_axis(c,ax,ks[ax],4)
    for ax in range(4): c=bern_axis(c,ax)
    m=min(c.values())
    if m<0: neg+=1
    if gmin is None or m<gmin: gmin=m
print('boxes with negative Bernstein coeff:',neg,' global min coeff:',gmin,'=',float(gmin),' time',round(time.time()-t0,1),'s')
print('matches submitted min 26392159755/7516192768:', gmin==Fr(26392159755,7516192768))
