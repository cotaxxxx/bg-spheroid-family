import sympy as S
from math import comb
g,eta,zeta,bb,chi,X1,X3,B=S.symbols('g eta zeta b chi X1 X3 B')
T=bb*B*X1+zeta*X3; e=chi*(zeta*B*X1-bb*X3)
L=X1**2+X3**2; s=L-T**2
V0=g**2*s*(3*L-7*T**2)/8-2*g*e*T*s+e**2*(3*T**2-L)/2
V1=g**3*s**2/4-2*g**2*e*T*s+g*e**2*(3*T**2-2*L)+2*e**3*T
V2=-S.Rational(3,2)*g**2*e**2*s+2*g*e**3*T+e**4
Kfull=4*(1+eta*(1-g))*(12*V0-6*eta*V1+4*eta**2*V2-3*eta**3*g*e**4)
def mixed_phi(expr):
    c=S.Poly(S.expand(expr),X1,X3).coeff_monomial(X1**2*X3**2)
    return S.expand(sum(co*S.Rational(comb(k,k//2),2**k) for (k,),co in S.Poly(S.expand(c),B).terms() if k%2==0))
K22=S.Rational(1,6)*mixed_phi(Kfull)
r,v,q=S.symbols('r v q'); U=1+r**2; Vv=1+v**2; G=1-v**2
sub={zeta:(1-r**2)/U, bb:2*r/U, chi:2*v/Vv, g:G/Vv, eta:q*Vv/2}
Tn=2*r*B*X1+(1-r**2)*X3; En=2*v*((1-r**2)*B*X1-2*r*X3); Sn=L*U**2-Tn**2
N0=G**2*Sn*(3*L*U**2-7*Tn**2)/8-2*G*En*Tn*Sn+En**2*(3*Tn**2-L*U**2)/2
N1=G**3*Sn**2/4-2*G**2*En*Tn*Sn+G*En**2*(3*Tn**2-2*L*U**2)+2*En**3*Tn
N2=-S.Rational(3,2)*G**2*En**2*Sn+2*G*En**3*Tn+En**4
Nc=mixed_phi(12*N0-3*q*N1+q**2*N2-S.Rational(3,8)*q**3*G*En**4)
diff=S.together(K22.subs(sub)-2*(1+q*v**2)*Nc/(3*U**4*Vv**2))
print('match:', S.simplify(S.numer(diff))==0)
