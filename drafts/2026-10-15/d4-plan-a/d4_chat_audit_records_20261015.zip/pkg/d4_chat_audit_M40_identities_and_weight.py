import sympy as S
from fractions import Fraction as Fr
# --- 1. Legendre derivative identity for gamma along v=e1, at fixed X,n ---
t=S.symbols('t'); y1,y2,y3,n1,n2,n3=S.symbols('y1 y2 y3 n1 n2 n3', real=True)
Y=S.Matrix([y1-t,y2,y3]); n=S.Matrix([n1,n2,n3])
D=S.sqrt(Y.dot(Y)); gam=n.dot(Y)/D
D0=S.sqrt(y1**2+y2**2+y3**2); T=y1/D0; g0=(n1*y1+n2*y2+n3*y3)/D0; a=n1
Pl=[S.Integer(1),T]
for k in range(1,4): Pl.append(((2*k+1)*T*Pl[k]-k*Pl[k-1])/(k+1))
ok=True
for k in range(1,5):
    lhs=S.diff(gam,t,k).subs(t,0)
    rhs=S.factorial(k)*D0**(-k)*(g0*Pl[k]-a*Pl[k-1])
    d=S.simplify((lhs-rhs).subs({n3:S.sqrt(1-n1**2-n2**2)}))
    ok = ok and d==0
    print('Legendre k=%d:'%k, d==0)
# --- 2. Composite identity -F_vvvv with symbolic R derivatives ---
g,Tt,aa=S.symbols('gamma T a'); R0,R1,R2,R3=S.symbols('R R1 R2 R3'); Dd,w=S.symbols('D w',positive=True)
Pl2=[S.Integer(1),Tt]
for k in range(1,4): Pl2.append(((2*k+1)*Tt*Pl2[k]-k*Pl2[k-1])/(k+1))
eps=[None]+[g*Pl2[k]-aa*Pl2[k-1] for k in range(1,5)]
gd={k:S.factorial(k)*Dd**(-k)*eps[k] for k in range(1,5)}
G=[None,-2*R0,-2*R1,-2*R2,-2*R3]
G4=G[4]*gd[1]**4+6*G[3]*gd[1]**2*gd[2]+G[2]*(3*gd[2]**2+4*gd[1]*gd[3])+G[1]*gd[4]
G3=G[3]*gd[1]**3+3*G[2]*gd[1]*gd[2]+G[1]*gd[3]
h=w*Dd*g; hp=-w*aa
F4=h*G4+4*hp*G3
e=g*Tt-aa; s=1-Tt**2
V0=g**2*s*(3-7*Tt**2)/8-2*g*e*Tt*s+e**2*(3*Tt**2-1)/2
V1=g**3*s**2/4-2*g**2*e*Tt*s+g*e**2*(3*Tt**2-2)+2*e**3*Tt
V2=-S.Rational(3,2)*g**2*e**2*s+2*g*e**3*Tt+e**4
claim=2*w*Dd**(-3)*(24*R0*V0+12*R1*V1+4*R2*V2+R3*g*e**4)
print('-F_vvvv identity:', S.simplify(S.expand(-F4-claim))==0)
# --- 3. identity in §VI ---
lam,yy=S.symbols('lam y')
Q0=1-(1-lam**2)*yy
print('§VI identity:', S.expand((1+lam**2)**2*Q0**2-4*lam**2*(1-yy+lam**4*yy)-(1-lam**2)**2*(1-(1+lam**2)*yy)**2)==0)
# --- 4. J(c) and the c_min vs c_max issue ---
import mpmath as M
def J(c): return M.quad(lambda m_: (1-m_*m_)/(1-c*m_*m_)**1.5,[-1,1])
l=Fr(119,200); cmax=1-l*l; cmin=1-Fr(33,50)**2
Jlow=lambda c: Fr(4,3)+Fr(2,5)*c+Fr(3,14)*c**2+Fr(5,36)*c**3
print('J_low(cmax)=',float(Jlow(cmax)),' J_low(cmin)=',float(Jlow(cmin)),' J(cmin) exact~',J(float(cmin)),' J(cmax)~',J(float(cmax)))
for lab,c in (('as submitted (cmax)',cmax),('corrected (cmin)',cmin)):
    I=Fr(5,6)/l*(2/l-cmin*Jlow(c)/2); C=24*I
    print(lab,': C =',C,'=',float(C),' <100:',C<100)
print('submitted C ==', Fr(262876422851797011143,2718912000000000000)==24*Fr(5,6)/l*(2/l-cmin*Jlow(cmax)/2))
# true max over lambda of 24*(5/(6 lam))*(2/lam - c/2 J(c)) (audit-only)
best=max((24*5/(6*L)*(2/L-(1-L*L)/2*J(1-L*L)),L) for L in [0.595+i*0.001 for i in range(66)])
print('numeric max of corrected-structure bound over band:',best)
