import sympy as S, itertools, time
from fractions import Fraction as Fr
from math import comb
# ---- 1. Mixed-derivative kernel from the M40-audited composite (independent of Codex's polynomials) ----
# -F_vvvv along general unit v = 2 w D^-3 (24 R V0 + 12 R' V1 + 4 R'' V2 + R''' g e^4) with T=(Y/D).v, e=g T - n.v
# Mixed E_rhorhozz = (1/6)[X1^2 X3^2] of the quartic form Q(v)=D_v^4 E (polarization), on axis after phi-average.
g,eta,zeta,chi,X1,X3,B=S.symbols('g eta zeta chi X1 X3 B')
b=S.sqrt(1-zeta**2)
T=b*B*X1+zeta*X3
e=chi*(zeta*B*X1-b*X3)
L=X1**2+X3**2; s=L-T**2
V0=g**2*s*(3*L-7*T**2)/8-2*g*e*T*s+e**2*(3*T**2-L)/2
V1=g**3*s**2/4-2*g**2*e*T*s+g*e**2*(3*T**2-2*L)+2*e**3*T
V2=-S.Rational(3,2)*g**2*e**2*s+2*g*e**3*T+e**4
Scomp=12*V0-6*eta*V1+4*eta**2*V2-3*eta**3*g*e**4
Kfull=4*(1+eta*(1-g))*Scomp
def mixed_phi(expr):
    p=S.Poly(S.expand(expr),X1,X3)
    c=p.coeff_monomial(X1**2*X3**2)
    pb=S.Poly(S.expand(c),B)
    out=0
    for (k,),co in pb.terms():
        if k%2==0: out+=co*S.Rational(comb(k,k//2),2**k)
    return S.expand(out)
K22_sym=S.expand(S.Rational(1,6)*mixed_phi(Kfull))
# Codex's rational form
r,v,q=S.symbols('r v q')
U=1+r**2; Vv=1+v**2; G=1-v**2
K22_codex_sub={zeta:(1-r**2)/U, chi:2*v/Vv, g:G/Vv, eta:q*Vv/2}
# Build Codex N from their definition and compare to K22_sym under substitution
Tn=2*r*B*X1+(1-r**2)*X3; En=2*v*((1-r**2)*B*X1-2*r*X3); Sn=L*U**2-Tn**2
N0=G**2*Sn*(3*L*U**2-7*Tn**2)/8-2*G*En*Tn*Sn+En**2*(3*Tn**2-L*U**2)/2
N1=G**3*Sn**2/4-2*G**2*En*Tn*Sn+G*En**2*(3*Tn**2-2*L*U**2)+2*En**3*Tn
N2=-S.Rational(3,2)*G**2*En**2*Sn+2*G*En**3*Tn+En**4
Ncodex=mixed_phi(12*N0-3*q*N1+q**2*N2-S.Rational(3,8)*q**3*G*En**4)
K22_codex=2*(1+q*v**2)*Ncodex/(3*U**4*Vv**2)
d=S.simplify(K22_sym.subs(K22_codex_sub)-K22_codex)
print('K22 rational form matches audited composite:', d==0)
# ---- 2. Independent Bernstein certificate on 64 fixed boxes ----
poly=S.Poly(S.expand(72*U**4*Vv**2-(1+q*v**2)*Ncodex).subs(v,S.Rational(-3,8)+S.Rational(3,4)*S.Symbol('sv')),r,S.Symbol('sv'),q)
degs=[poly.degree(x) for x in poly.gens]; print('degrees',degs,'terms',len(poly.terms()))
coef={mon:Fr(int(c.p),int(c.q)) for mon,c in poly.terms()}
n=degs
def shift_axis(coef,axis,k,m):
    out={}
    for mon,c in coef.items():
        j=mon[axis]
        for i in range(j+1):
            nm=list(mon); nm[axis]=i; nm=tuple(nm)
            out[nm]=out.get(nm,Fr(0))+c*comb(j,i)*Fr(k)**(j-i)/Fr(m)**j
    return out
def bern_axis(coef,axis):
    out={}
    for mon,c in coef.items():
        i=mon[axis]
        for h in range(i,n[axis]+1):
            nm=list(mon); nm[axis]=h; nm=tuple(nm)
            out[nm]=out.get(nm,Fr(0))+c*Fr(comb(h,i),comb(n[axis],i))
    return out
gmin=None; gmax=None; neg=0
for ks in itertools.product(range(4),repeat=3):
    c=coef
    for ax in range(3): c=shift_axis(c,ax,ks[ax],4)
    for ax in range(3): c=bern_axis(c,ax)
    m=min(c.values()); M=max(c.values())
    if m<0: neg+=1
    gmin=m if gmin is None else min(gmin,m); gmax=M if gmax is None else max(gmax,M)
print('negative boxes:',neg,' min:',gmin,' max:',gmax)
print('matches Codex min 139515/1792:',gmin==Fr(139515,1792),' max 744477/512:',gmax==Fr(744477,512))
# ---- 3. rationals ----
l=Fr(119,200); cmin=Fr(1411,2500)
J=Fr(4,3)+Fr(2,5)*cmin+Fr(3,14)*cmin**2+Fr(5,36)*cmin**3
I=Fr(5,6)/l*(2/l-cmin*J/2); B22=48*I
print('B22',B22,B22==Fr(193787991018310321,995695312500000),float(B22))
M40=Fr(193787991018310321,1991390625000000)+Fr(2,10**8)
margin=Fr(1547,4860)-M40/384-B22/2*Fr(33,1625)**2
print('margin',margin,margin==Fr(900009544615558979777197,36346861687500000000000000),float(margin))
# ---- 4. sphere control of K22 integrand: g=1,eta=c/2 -> integrate t, then spherical mean of zeta
Ksph=K22_sym.subs({g:1,chi:0})
t=S.symbols('t'); Ksph_t=S.integrate(Ksph.subs(eta,(1-t**2)/2),(t,0,1))
# spherical mean over zeta uniform on [-1,1], weight w D^-3 /(2 lambda) =1/2
val=S.integrate(Ksph_t,(zeta,-1,1))/2
print('sphere -E22 =',val,' expect 16/9')
