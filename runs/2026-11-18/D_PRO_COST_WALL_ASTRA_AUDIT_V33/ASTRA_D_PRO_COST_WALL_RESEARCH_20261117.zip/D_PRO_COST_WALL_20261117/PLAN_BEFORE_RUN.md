# D-PRO cost wall: diagnostic plan CW1

DIAGNOSTIC_ONLY / NOT_EVIDENCE — NONRIGOROUS_FLOAT

Fixed before execution, 2026-11-17. This is not a global sign test.

1. Rebuild R0 f_beta and f_betabeta from primitive co-rotating geometry;
   reflect eta_z before averaging. Evaluate W and its tau derivative.
2. Compare integral of absolute derivative with absolute derivative after
   integrating the azimuth first, and after integrating h=eta_x first.
3. Fixed (R,tau,lambda): (3/4,1/8,2559/512), (1/2,1/2,2),
   (1/2,1/2,5), (15/16,1/8,5), (3/4,1/32,5), (3/4,3/4,5).
4. Two fixed rules: Gauss-Legendre h with 96 or 192 nodes, periodic
   azimuth trapezoid with 256 or 512 nodes. IEEE float64. No interval claim.
   Report both rules and differences, not just the better result.
5. Cross-check analytic tau derivative by a centered difference of W with
   step 1/100000 at the box-2 centre only. Diagnostic tolerance 1/100000.
6. Check a rational-azimuth residue formula against 8192-point azimuth
   trapezoid at R=3/4,tau=1/8,lambda=2559/512, h in {-3/4,0,1/2},
   w in {1/5,1/2,4/5}. Simple complex roots only. Relative/absolute scaled
   error tolerance 1/1000000. A failed residue test stays failed.
7. Sphere perturbation: use its newly derived 1D formula at
   R in {1/32,1/2,3/4,15/16} with the two h rules; compare numerical
   W/log(lambda) at lambda=exp(+/-1/10000), tau=1/8 and 1/2.
8. Record monotonic wall times. Maximum 120 seconds per program.
   No grid, tolerance or algorithm tuning after results. Any correction or
   follow-up is a separately recorded revision. No GPU/external PC/repo write.

Goal: rank exact azimuth integration and analytic leading-part subtraction.
No diagnostic output is authorization or a threshold for a certification run.
