# D-PRO cost-wall research package
**DIAGNOSTIC_ONLY / NOT_EVIDENCE**

Read `ASTRA_D_PRO_COST_WALL_REPORT_20261117.md` first. No global sign claim.
This is a research package, not a producer/checker release. Repository sources
were read only. The enclosed Python diagnostics do not perform GitHub writes.

## Files and reproduction

- `PLAN_BEFORE_RUN.md`, `cw1_diagnostics.py`, `CW1_RESULTS.json`: cancellation,
  one-variable integration, failed simple-pole residue tests, sphere response.
- `PLAN_CW2_BEFORE_RUN.md`, `cw2_resolvent.py`, `CW2_RESULTS.json`: untruncated
  finite Neumann polynomials on 27 fixed outer sample points.
- `cw3_microbench.py`, `CW3_RESULTS.json`: R3 local Arb algebra costs only.
- `PLAN_CW4_BEFORE_RUN.md`, `cw4_majorant.py`, `CW4_RESULTS.json`: total-degree
  tail for R²W followed by a conservative R_lower^-2 factor.
- `PLAN_CW5_BEFORE_RUN.md`, `cw5_coefficients.py`, `CW5_COEFFICIENTS.json`:
  35 signed integrated coefficients of W; float64 quadrature only.
- `cw5_majorant_full_w.py`, `CW5_TAIL.json`: adds the R^-2 factor to the
  majorant. Its source transformation is explicit and CW4 is unchanged.
- `cw5_arb_microbench.py`, its original stderr, `CW5_BENCH_IMPORT_FIX.md`,
  `cw5_arb_microbench_r1.py`, `CW5_ARB_BENCH_R1.json`: failed import and
  subsequent unchanged-algebra local benchmark, both preserved.
- `symbolic_checks.py`, `SYMBOLIC_RESULTS.json`: exact algebra checks.
- `cost_table.py`, `COST_TABLE.json`: conditional cost arithmetic.
- `inputs/`: supplied instruction and pinned V32 read-only source excerpts.
- `SHA256SUMS`: SHA-256 of every payload file except itself.

Use a separate directory/environment. NumPy 2.3.5, SciPy 1.17.0,
SymPy 1.14.0 were used for diagnostics. The Arb microbenchmarks used
python-flint 0.8.0. No NumPy/SciPy package is needed for the R1 Arb driver.
The float-polynomial “interval” arithmetic has NO directed rounding.
Neither its majorants nor the quadrature results are certified bounds.

Example (from this package directory):

```bash
python cw1_diagnostics.py > fresh_CW1.json
python cw2_resolvent.py > fresh_CW2.json
python cw4_majorant.py > fresh_CW4.json
python cw5_coefficients.py > fresh_CW5_coefficients.json
python cw5_majorant_full_w.py > fresh_CW5_tail.json
python symbolic_checks.py > fresh_symbolic.json
```

For local Arb timings, provide a READ-ONLY R3 checkout pinned to
`fdfb498f2117cc0c5d72e88cc3be05eac9727bd8`, whose root contains `prolate_r1/`:

```bash
PYTHONDONTWRITEBYTECODE=1 python cw3_microbench.py /path/to/pinned_R3 > fresh_CW3.json
PYTHONDONTWRITEBYTECODE=1 python cw5_arb_microbench_r1.py /path/to/pinned_R3 > fresh_CW5_arb.json
```

Do not replace original results with reruns. Use new filenames and preserve
the original failures. Recorded subsecond NumPy times are NOT Arb integration
cost predictions. The package includes no implementation of the rigorous
35-coefficient integral engine, common moment engine, or new w-map benchmark.

Sources reused: R0 derivative formulas; R4 rational geometry; R3 Jet and
density only for read-only microbenchmarks. No clean-room claim is made.
