"""DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT.
Separate CW5 extension; CW4 remains unchanged. Reuse its exact polynomial definitions.
"""
from pathlib import Path
source=Path(__file__).with_name('cw4_majorant.py').read_text()
source=source.replace("total=sum(absU)/(d0*s0*(1-asum)*(1-bsum))",
 "r=1/96\n        AR=[0,2*r,r*r]\n        total=sum(absU)/(rc*rc*d0*s0*(1-asum)*(1-bsum)*(1-sum(AR)))")
source=source.replace("major=conv(conv(absU,inverse_majorant(A,6),6),inverse_majorant(B,6),6)",
 "major=conv(conv(conv(absU,inverse_majorant(A,6),6),inverse_majorant(B,6),6),inverse_majorant(AR,6),6)")
source=source.replace("tail=(total-sum(major[:n+1])/(d0*s0))/(95/128)**2",
 "tail=total-sum(major[:n+1])/(rc*rc*d0*s0)")
exec(compile(source,'CW5 full-W variant of CW4','exec'))
