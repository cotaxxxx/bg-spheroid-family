"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. NONRIGOROUS_FLOAT.
CW1 fixed diagnostic; no interval enclosure or global sign claim.
R0 derivative formulas are reimplemented, not an independent derivation of R0.
"""
import json, time, math
import numpy as np
from numpy.polynomial import Polynomial as Poly
from scipy.special import roots_legendre

STATUS='DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT'
CASES=[(3/4,1/8,2559/512),(1/2,1/2,2),(1/2,1/2,5),
       (15/16,1/8,5),(3/4,1/32,5),(3/4,3/4,5)]
RULES=[(96,256),(192,512)]

def rcal(g):
    g=np.minimum(1.,np.maximum(0.,g)); q=1-g
    mask=q<1e-5
    den=np.maximum(1-g*g,np.finfo(float).tiny)
    rr=np.arccos(g)/np.sqrt(den)
    rp=(g*rr-1)/den
    coeff=[1.]
    for n in range(1,8): coeff.append(coeff[-1]*n/(2*n+1))
    rs=np.zeros_like(g); ps=np.zeros_like(g)
    for n in range(7,-1,-1): rs=rs*q+coeff[n]
    for n in range(7,0,-1): ps=ps*q-n*coeff[n]
    return np.where(mask,rs,rr),np.where(mask,ps,rp)

def pair_kernel(R,x,lam,h,v):
    c=(1-x*x)/(1+x*x); s=2*x/(1+x*x)
    sig2=(1-R)**2+2*R*(1-h); sig=np.sqrt(sig2); k=1-R*h
    d=lam*lam-1; e=d/(lam*lam)
    bs=[]; bbs=[]
    for vv in (v,-v):
        mx=(c*(h-R)-s*vv)/sig; mz=(s*(h-R)+c*vv)/sig
        xx=c*h-s*vv; xz=s*h+c*vv
        C=1+d*mz*mz; B=1-e*xz*xz
        g=np.minimum(1.,k/(sig*np.sqrt(C*B)))
        rr,rp=rcal(g)
        T=d*mx*mz/C-e*xx*xz/B
        Tb=d*(mx*mx-mz*mz)/C-2*(d*mx*mz/C)**2-e*(xx*xx-xz*xz)/B-2*(e*xx*xz/B)**2
        bs.append(2*k*g*rr*T)
        bbs.append(2*k*g*(rr*Tb-(rr+g*rp)*T*T))
    fb=(bs[0]+bs[1])/2; fbb=(bbs[0]+bbs[1])/2
    den=R*R*s*c
    W=fb/den
    dW=(fbb-(c*c-s*s)/(s*c)*fb)/den*2/(1+x*x)
    return W,dW

def make_grid(nh,nt):
    h,wh=roots_legendre(nh)
    theta=(np.arange(nt)+0.5)*2*np.pi/nt
    H=h[:,None]; V=np.sqrt(1-H*H)*np.cos(theta)[None,:]
    return H,V,wh[:,None]/2

def measurements(R,x,lam,nh,nt):
    start=time.monotonic(); H,V,WH=make_grid(nh,nt)
    W,D=pair_kernel(R,x,lam,H,V)
    avg_theta=D.mean(axis=1)
    avg_h=(D*WH).sum(axis=0)
    return {'R':R,'tau':x,'lambda':lam,'nh':nh,'nt':nt,
      'W':float(np.sum(W*WH)/nt),'dW_dtau':float(np.sum(D*WH)/nt),
      'L1_pointwise':float(np.sum(abs(D)*WH)/nt),
      'L1_after_azimuth':float(np.sum(abs(avg_theta)*WH[:,0])),
      'L1_after_h':float(np.mean(abs(avg_h))),
      'seconds':time.monotonic()-start}

def rational_polys(R,x,lam,h,w):
    t=4*x*x/(1+x*x)**2; z=Poly([0.,1.]); v2=(1-h*h)*z
    sig2=(1-R)**2+2*R*(1-h); k=1-R*h; a0=k*k/sig2
    a2=(h-R)**2/sig2; b2=v2/sig2
    d=lam*lam-1; e=d/(lam*lam)
    C0=1+d*((1-t)*b2+t*a2); B0=1-e*((1-t)*v2+t*h*h)
    cross=(h-R)*h*v2/sig2
    P=C0*B0-4*d*e*t*(1-t)*cross
    Pt=d*(a2-b2)*B0-C0*e*(h*h-v2)-4*d*e*(1-2*t)*cross
    Bs=1/(lam*lam)+e*(1-h*h-v2)
    Uc=(1-t)*b2+t*a2; Vc=(1-t)*b2-t*a2
    DC=1+2*d*Uc+d*d*Vc*Vc
    DCt=2*d*(a2-b2)+2*d*d*Vc*(-b2-a2)
    Ub=(1-t)*h*h+t*v2; Vb=(1-t)*h*h-t*v2
    DB=Bs*Bs+2*Bs*e*Ub+e*e*Vb*Vb
    DBt=2*Bs*e*(v2-h*h)+2*e*e*Vb*(-h*h-v2)
    Delta=DC*DB; Dt=DCt*DB+DC*DBt
    A=a0*(1-w*w); S=A*A+2*A*w*w*P+w**4*Delta
    N=A/2*Dt+w*w*(P*Dt-Delta*Pt)
    return 2*k*a0/(R*R)*N,Delta*S

def arcsine_residue(U,D):
    quotient,rem=divmod(U,D)
    roots=D.roots(); n=len(roots)
    sep=min((abs(roots[i]-roots[j])/(1+abs(roots[i])+abs(roots[j]))
             for i in range(n) for j in range(i)),default=float('inf'))
    if sep<1e-7: return {'status':'ROOT_CLUSTER_STOP','scaled_root_separation':float(sep)}
    moments=np.array([math.comb(2*j,j)/4**j for j in range(len(quotient.coef))])
    ans=complex(np.dot(quotient.coef,moments))
    roots=roots.astype(complex)
    for q in roots:
        branch=np.sqrt(q)*np.sqrt(q-1)
        ans-=rem(q)/D.deriv()(q)/branch
    return {'status':'EVALUATED','real':ans.real,'imag':ans.imag,
            'scaled_root_separation':float(sep),'degree':D.degree()}

def sphere_response(R,nh):
    h,wh=roots_legendre(nh); sig2=(1-R)**2+2*R*(1-h); k=1-R*h
    g=k/np.sqrt(sig2); rr,_=rcal(g)
    diff=R*(1-h*h)*(R-2*h)/sig2
    return float(3/(R*R)*np.dot(wh,k*g*rr*diff))

def main():
    start=time.monotonic(); out={'status':STATUS,'rules':RULES,'cases':[]}
    for case in CASES:
        records=[measurements(*case,*rule) for rule in RULES]
        out['cases'].append({'input':case,'records':records,
            'W_rule_difference':records[1]['W']-records[0]['W'],
            'dW_rule_difference':records[1]['dW_dtau']-records[0]['dW_dtau']})
    H,V,WH=make_grid(*RULES[-1]); R,x,L=CASES[0]; step=1/100000
    plus=pair_kernel(R,x+step,L,H,V)[0]; minus=pair_kernel(R,x-step,L,H,V)[0]
    fd=float(np.sum((plus-minus)/(2*step)*WH)/RULES[-1][1])
    analytic=out['cases'][0]['records'][-1]['dW_dtau']
    out['finite_difference_check']={'finite_difference':fd,'analytic':analytic,
       'tolerance':1e-5,'pass':abs(fd-analytic)<1e-5}
    out['residue_checks']=[]
    zz=np.cos((np.arange(8192)+0.5)*2*np.pi/8192)**2
    for h in [-3/4,0,1/2]:
        for w in [1/5,1/2,4/5]:
            U,D=rational_polys(R,x,L,h,w); result=arcsine_residue(U,D)
            ref=float(np.mean(U(zz)/D(zz)))
            result.update({'h':h,'w':w,'trapezoid_reference':ref})
            result['pass']=(result['status']=='EVALUATED' and
              abs(complex(result['real'],result['imag'])-ref)<=1e-6*(1+abs(ref)))
            out['residue_checks'].append(result)
    out['sphere_response']=[]
    for R in [1/32,1/2,3/4,15/16]:
        row={'R':R,'response':[sphere_response(R,nh) for nh,nt in RULES],'ratios':[]}
        for tau in [1/8,1/2]:
            for ell in [-1/10000,1/10000]:
                val=measurements(R,tau,math.exp(ell),*RULES[-1])['W']/ell
                row['ratios'].append({'tau':tau,'log_lambda':ell,'W_over_log_lambda':val})
        out['sphere_response'].append(row)
    out['seconds_total']=time.monotonic()-start
    print(json.dumps(out,indent=2,allow_nan=False))

if __name__=='__main__': main()
