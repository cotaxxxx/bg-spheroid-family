# CW4: total-degree tail majorant
DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT

Designed after CW2. CW2 tested UNTRUNCATED products of Neumann polynomials,
not total-degree-4 models. It does not establish the cost of 35 coefficients.
CW4 explicitly examines the missing total-degree tail.

Use the same box and centre. Substitute (R,t,q)=(Rc,tc,qc)+z*(dR,dt,dq),
where each displacement coefficient is the full interval from the transformed
box. Compute finite polynomial interval coefficients in float64 WITHOUT
outward rounding (therefore diagnostic, not an interval certificate).
Use absolute coefficient majorants and positive denominator centres to bound
the formal total-degree tail via two geometric resolvent series.
Orders m={2,4,6}; grids (h,azimuth,w)=(32,64,16),(48,96,24).
No tuning, no parameter sample selection, no sign gate.
If a denominator majorant sum >=1, mark the bound unavailable, do not replace
it by a finite estimate. Report geometric quadrature dependence and time.
Stop program after 120 seconds. Every reported integral remains nonrigorous.
