# CW2: frozen-denominator resolvent diagnostic

DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT

This follow-up was designed after CW1. It is a new diagnostic, not a revision
of CW1, R3, or R4 results. No sign is used to select points or settings.

Use the Sigma-cleared rational area-pair kernel derived in this research.
Use q=lambda^-2 as the algebraic parameter and t=4tau²/(1+tau²)².
Centre: R=3/4, tau=1/8, lambda=2559/512. Fixed box: R3 box 2.
Outer sample: all 27 combinations of low/mid/high in the ORIGINAL R,tau,lambda.
Rules: h Gauss64, azimuth128, w Gauss16; then h Gauss96, azimuth256,w Gauss32.
IEEE float64 only. No enclosure of the continuum of parameters is claimed.

For each rule and each sample, compute denominator ratios relative to centre,
and unexpanded exact-degree Neumann polynomials with order n in {2,4,6} for
each of the two denominators. Report maxima of sampled ratios, maximum
sampled integral error, and a sampled weighted absolute remainder estimate.
Comparison is to the full rational kernel on the SAME quadrature rule.
Also check its centre integral against CW1 (different quadrature, nonrigorous).
Do not identify the same-grid discrepancy or the sampled remainder estimate
with an interval error bound. Mathematical tail identity is proved separately.
Record times. Stop if a denominator is nonpositive, or after 120 seconds.

CW3 microbenchmark, also fixed now: existing R3 code read-only, python-flint
0.8.0, 128 bits; centre of box 2, integration point u=1/2,v=1/3.
One warmup plus three timings for kernel jets (u6), (u6,x1), (u6,x3),
(u6,x4), (u6,R1,x1,lambda1), and (u6,R1,x2,lambda1).
This measures local algebra cost only, NOT full-box time, widths or throughput.
