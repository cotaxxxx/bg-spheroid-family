"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact algebra checks, not independent audit."""
import sympy as s,json
out=[]
def ck(name,v):
    ok=s.cancel(v)==0;out.append({'name':name,'zero_residual':bool(ok)})
R,k,Sig,q,p,D,pt,Dt,w=s.symbols('R k Sig q p D pt Dt w',nonzero=True)
P=p/(q*Sig); Delta=D/(q*q*Sig*Sig); a0=k*k/Sig
A=a0*(1-w*w); SS=A*A+2*A*w*w*P+w**4*Delta
N=A*Dt/(2*q*q*Sig*Sig)+w*w*(P*Dt/(q*q*Sig*Sig)-Delta*pt/(q*Sig))
old=2*k*a0/R**2*N/(Delta*SS)
aa=k*k*(1-w*w); ss=q*q*aa*aa+2*q*aa*w*w*p+w**4*D
nn=q*aa*Dt/2+w*w*(p*Dt-D*pt)
new=2*q*k**3*nn/(R*R*D*ss)
ck('Sigma_cleared_kernel',old-new)
eps,v,L,P,D,Pt,Dt=s.symbols('eps v L P D Pt Dt',nonzero=True)
den=1-v+eps*v; ww=eps*v/den; a0=eps*eps*L
AA=a0*(1-ww*ww); SS=AA*AA+2*AA*ww*ww*P+ww**4*D
NN=AA*Dt/2+ww*ww*(P*Dt-D*Pt)
old=2*k*a0/R**2*NN/(D*SS)*eps/(den*den)
B=(1-v)**2+2*eps*v*(1-v)
Snew=B*B+2*B*P/L*v*v+D/L**2*v**4
Nnew=B*Dt/2+v*v/L*(P*Dt-D*Pt)
ck('w_transform_with_Jacobian',old-2*k*eps/R**2*Nnew/(D*Snew))
h=s.symbols('h'); Sigma=1+R*R-2*R*h
ck('a0_interior_lower_bound',(1-R*h)**2-(1-R*R)*Sigma-R*R*(h-R)**2)
b=s.symbols('b',positive=True)
ck('quadratic_minimum',(1-v)**2+b*v*v-b/(1+b)-(1+b)*(v-1/(1+b))**2)
x,y=s.symbols('x y')
for m in [2,4,6]:
    T=lambda z:sum((-z)**j for j in range(m+1))
    ck('finite_resolvent_m'+str(m),T(x)*T(y)*(1+x)*(1+y)-(1-(-x)**(m+1))*(1-(-y)**(m+1)))
ck('sphere_centre_12_over_5',3*s.integrate((1-h*h)*(1-2*h*h),(h,-1,1))-s.Rational(12,5))
def moment(m):
    return s.binomial(2*m,m)/2**(2*m)*s.pi**2/8+sum(2*s.binomial(2*m,m-j)/2**(2*m)*s.Rational((-1)**j-1,4*j*j) for j in range(1,m+1))
ck('sphere_boundary_value',24*(5*moment(3)-4*moment(4)-moment(2))-(9*s.pi**2/32-1))
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','checks':out,'all_zero':all(x['zero_residual'] for x in out)},indent=2))
raise SystemExit(0 if all(x['zero_residual'] for x in out) else 1)
