"""DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT.
Interval arithmetic below has NO outward rounding. It is a diagnostic only.
"""
import numpy as np,json,time
from scipy.special import roots_legendre

def I(x): return (np.asarray(x),np.asarray(x))
def ia(x,y): return (x[0]+y[0],x[1]+y[1])
def neg(x): return (-x[1],-x[0])
def mul(x,y):
    a,b,c,d=x[0]*y[0],x[0]*y[1],x[1]*y[0],x[1]*y[1]
    return (np.minimum(np.minimum(a,b),np.minimum(c,d)),np.maximum(np.maximum(a,b),np.maximum(c,d)))
def mag(x): return np.maximum(abs(x[0]),abs(x[1]))
class P:
    __array_priority__=10000
    def __init__(self,cs): self.cs=cs
    @staticmethod
    def lift(x): return x if isinstance(x,P) else P([I(x)])
    def __add__(self,x):
        x=P.lift(x); n=max(len(self.cs),len(x.cs))
        return P([ia(self.cs[j] if j<len(self.cs) else I(0),x.cs[j] if j<len(x.cs) else I(0)) for j in range(n)])
    __radd__=__add__
    def __neg__(self): return P([neg(x) for x in self.cs])
    def __sub__(self,x): return self+-P.lift(x)
    def __rsub__(self,x): return P.lift(x)+-self
    def __mul__(self,x):
        x=P.lift(x); out=[I(0) for _ in range(len(self.cs)+len(x.cs)-1)]
        for i,a in enumerate(self.cs):
            for j,b in enumerate(x.cs): out[i+j]=ia(out[i+j],mul(a,b))
        return P(out)
    __rmul__=__mul__
    def __pow__(self,n):
        out=P.lift(1)
        for _ in range(n): out=out*self
        return out

def polys(R,t,q,h,v2,w):
    sig=(1-R)**2+2*R*(1-h); k=1-R*h; d=1-q
    aa=(h-R)**2; uc=(1-t)*v2+t*aa; vc=(1-t)*v2-t*aa
    ac=q*sig+d*uc; B0=1-d*((1-t)*v2+t*h*h)
    cross=(h-R)*h*v2
    pp=ac*B0-4*d*d*t*(1-t)*cross
    pt=d*(aa-v2)*B0-ac*d*(h*h-v2)-4*d*d*(1-2*t)*cross
    c=q*q*sig*sig+2*q*d*sig*uc+d*d*vc*vc
    ct=2*q*d*sig*(aa-v2)+2*d*d*vc*(-v2-aa)
    bs=q+d*(1-h*h-v2); ub=(1-t)*h*h+t*v2; vb=(1-t)*h*h-t*v2
    b=bs*bs+2*bs*d*ub+d*d*vb*vb
    bt=2*bs*d*(v2-h*h)+2*d*d*vb*(-h*h-v2)
    delta=c*b; dt=ct*b+c*bt
    a=k*k*(1-w*w)
    ss=q*q*a*a+2*q*a*w*w*pp+w**4*delta
    nn=q*a*dt*(1/2)+w*w*(pp*dt-delta*pt)
    return 2*q*k**3*nn,delta,ss

def inverse_majorant(a,m):
    out=[np.ones_like(a[0])]
    for n in range(1,m+1): out.append(sum(a[j]*out[n-j] for j in range(1,min(n,len(a)-1)+1)))
    return out
def conv(a,b,m):
    return [sum(a[j]*b[n-j] for j in range(max(0,n-len(b)+1),min(n,len(a)-1)+1)) for n in range(m+1)]

def run(nh,nt,nw):
    start=time.monotonic(); hh,wh=roots_legendre(nh); ww,vw=roots_legendre(nw)
    h=hh[:,None,None]; th=(np.arange(nt)+.5)*2*np.pi/nt
    v2=(1-h*h)*np.cos(th)[None,:,None]**2; w=(ww[None,None,:]+1)/2
    weights=wh[:,None,None]*vw[None,None,:]/(4*nt)
    tf=lambda x:4*x*x/(1+x*x)**2
    rc=3/4; tc=tf(1/8); qc=(512/2559)**2
    R=P([I(rc),(np.asarray(95/128-rc),np.asarray(97/128-rc))])
    t=P([I(tc),(np.asarray(tf(15/128)-tc),np.asarray(tf(17/128)-tc))])
    q=P([I(qc),(np.asarray(1/25-qc),np.asarray((256/1279)**2-qc))])
    U,D,S=polys(R,t,q,h,v2,w)
    d0=D.cs[0][0]; s0=S.cs[0][0]
    A=[np.zeros_like(d0)]+[mag(c)/d0 for c in D.cs[1:]]
    B=[np.zeros_like(s0)]+[mag(c)/s0 for c in S.cs[1:]]
    asum=sum(A); bsum=sum(B); bad=(asum>=1)|(bsum>=1)
    result={'rule':[nh,nt,nw],'max_A_sum':float(np.max(asum)),'max_B_sum':float(np.max(bsum)),
            'bad_fraction':float(np.mean(bad)),'polynomial_degrees':[len(U.cs)-1,len(D.cs)-1,len(S.cs)-1]}
    if not np.any(bad):
        absU=[mag(c) for c in U.cs]
        total=sum(absU)/(d0*s0*(1-asum)*(1-bsum))
        major=conv(conv(absU,inverse_majorant(A,6),6),inverse_majorant(B,6),6)
        tails={}
        for n in [2,4,6]:
            tail=(total-sum(major[:n+1])/(d0*s0))/(95/128)**2
            tails[n]={'quadrature_estimate':float(np.sum(tail*weights)),
                      'minimum_raw_tail':float(np.min(tail))}
        result['total_degree_tail_estimates']=tails
    else: result['status']='MAJORANT_UNAVAILABLE'
    result['seconds']=time.monotonic()-start
    return result

if __name__=='__main__':
    print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT',
                     'rules':[run(32,64,16),run(48,96,24)]},indent=2))
