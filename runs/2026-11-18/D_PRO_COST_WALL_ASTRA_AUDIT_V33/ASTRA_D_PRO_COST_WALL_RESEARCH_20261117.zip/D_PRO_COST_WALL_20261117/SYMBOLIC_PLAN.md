# Exact checks planned before execution
DIAGNOSTIC_ONLY / NOT_EVIDENCE

Check only exact algebra: Sigma-cleared kernel, w-transform including
Jacobian, interior a0 lower-bound factorization, denominator quadratic
minimum identity, finite resolvent product identity for m=2,4,6,
sphere centre coefficient and boundary Fourier integral.
No parameter search, numerical quadrature, or sign sampling in this script.
