"""DIAGNOSTIC_ONLY / NOT_EVIDENCE: local rational-kernel jet timings only."""
import sys,time,json,statistics
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
from flint import arb,fmpq as Q,ctx
from prolate_r1.jets import Jet
from cw4_majorant import polys
shapes=[(('u',),(6,)),(('u','t'),(6,1)),(('u','t'),(6,3)),
        (('u','t'),(6,4)),(('u','R','t','q'),(6,1,1,1)),(('u','R','t','q'),(6,1,2,1))]
out=[]
with ctx.workprec(128):
    for names,orders in shapes:
        def seed(x,n): return Jet.constant(arb(x),orders,names.index(n) if n in names else None)
        def run():
            R=seed(Q(3,4),'R'); t=seed(Q(256,4225),'t'); q=seed(Q(512,2559)**2,'q')
            u=seed(Q(1,2),'u'); h=1-8*u**2/(1+u**2)**2
            sp=4*u*(1-u**2)/(1+u**2)**2
            v2=(sp*(arb.pi()/3).cos())**2; w=arb(Q(1,2))
            U,D,S=polys(R,t,q,h,v2,w)
            return U/(R*R*D*S)
        j=run(); times=[]
        for _ in range(3):
            st=time.perf_counter(); run(); times.append(time.perf_counter()-st)
        out.append({'active':names,'orders':orders,'coefficients':len(j.c),
                    'seconds':times,'median_seconds':statistics.median(times),
                    'finite':all(c.is_finite() for c in j.c)})
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','timings':out},indent=2))
