"""DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT.
Signed coefficients of a rational total-degree-four model, no enclosure.
"""
import numpy as np,json,time,itertools
from scipy.special import roots_legendre
from cw4_majorant import polys

DEG=4
IND=sorted([a for a in itertools.product(range(DEG+1),repeat=3) if sum(a)<=DEG],key=lambda a:(sum(a),a))
ZERO=(0,0,0)
class T:
    __array_priority__=10000
    def __init__(self,c): self.c=c
    @staticmethod
    def lift(x): return x if isinstance(x,T) else T({ZERO:x})
    def __add__(self,x):
        x=T.lift(x); return T({a:self.c.get(a,0)+x.c.get(a,0) for a in self.c.keys()|x.c.keys()})
    __radd__=__add__
    def __neg__(self): return T({a:-c for a,c in self.c.items()})
    def __sub__(self,x): return self+-T.lift(x)
    def __rsub__(self,x): return T.lift(x)+-self
    def __mul__(self,x):
        x=T.lift(x); out={}
        for a,c in self.c.items():
            for b,d in x.c.items():
                ab=tuple(i+j for i,j in zip(a,b))
                if sum(ab)<=DEG: out[ab]=out.get(ab,0)+c*d
        return T(out)
    __rmul__=__mul__
    def __pow__(self,n):
        out=T.lift(1)
        for _ in range(n): out=out*self
        return out
    def reciprocal(self):
        out={ZERO:1/self.c[ZERO]}
        for a in IND[1:]:
            total=0
            for b,v in self.c.items():
                if b==ZERO or not all(i<=j for i,j in zip(b,a)): continue
                rem=tuple(j-i for i,j in zip(b,a)); total=total+v*out.get(rem,0)
            out[a]=-total/self.c[ZERO]
        return T(out)

def run(nh,nt,nw):
    start=time.monotonic(); hh,wh=roots_legendre(nh); ww,vw=roots_legendre(nw)
    h=hh[:,None,None]; th=(np.arange(nt)+.5)*2*np.pi/nt
    v2=(1-h*h)*np.cos(th)[None,:,None]**2; w=(ww[None,None,:]+1)/2
    weights=wh[:,None,None]*vw[None,None,:]/(4*nt)
    tf=lambda x:4*x*x/(1+x*x)**2
    rc=3/4; tc=tf(1/8); qc=(512/2559)**2
    hr=1/128; ht=max(tc-tf(15/128),tf(17/128)-tc); hq=max(qc-1/25,(256/1279)**2-qc)
    R=T({ZERO:rc,(1,0,0):hr}); t=T({ZERO:tc,(0,1,0):ht}); q=T({ZERO:qc,(0,0,1):hq})
    U,D,S=polys(R,t,q,h,v2,w)
    F=U*(R*R*D*S).reciprocal()
    coeffs={str(a):float(np.sum(F.c.get(a,0)*weights)) for a in IND}
    by_order={k:sum(abs(coeffs[str(a)]) for a in IND if sum(a)==k) for k in range(1,5)}
    raw_by_order={k:float(sum(np.sum(abs(F.c.get(a,0))*weights) for a in IND if sum(a)==k)) for k in range(1,5)}
    return {'rule':[nh,nt,nw],'normalizing_widths':[hr,ht,hq],'coefficients':coeffs,
            'constant':coeffs[str(ZERO)],'sum_absolute_integrated_nonconstant':sum(by_order.values()),
            'by_order_after_integration':by_order,'by_order_before_integration':raw_by_order,
            'seconds':time.monotonic()-start}

if __name__=='__main__':
    print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT',
                     'rules':[run(32,64,16),run(48,96,24)]},indent=2))
