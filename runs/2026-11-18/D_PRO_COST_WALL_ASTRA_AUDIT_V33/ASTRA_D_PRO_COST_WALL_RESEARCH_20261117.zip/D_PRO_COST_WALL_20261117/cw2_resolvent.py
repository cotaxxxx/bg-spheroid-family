"""DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT.
CW2 samples real parameter boxes; no continuous interval upper bound.
"""
import json,time,itertools
import numpy as np
from scipy.special import roots_legendre

def cleared(R,t,q,h,v2,w):
    sig=(1-R)**2+2*R*(1-h); k=1-R*h; d=1-q
    aa=(h-R)**2
    uc=(1-t)*v2+t*aa; vc=(1-t)*v2-t*aa
    ac=q*sig+d*uc; B0=1-d*((1-t)*v2+t*h*h)
    cross=(h-R)*h*v2
    p=ac*B0-4*d*d*t*(1-t)*cross
    pt=d*(aa-v2)*B0-ac*d*(h*h-v2)-4*d*d*(1-2*t)*cross
    c=q*q*sig*sig+2*q*d*sig*uc+d*d*vc*vc
    ct=2*q*d*sig*(aa-v2)+2*d*d*vc*(-v2-aa)
    bs=q+d*(1-h*h-v2); ub=(1-t)*h*h+t*v2; vb=(1-t)*h*h-t*v2
    b=bs*bs+2*bs*d*ub+d*d*vb*vb
    bt=2*bs*d*(v2-h*h)+2*d*d*vb*(-h*h-v2)
    delta=c*b; dt=ct*b+c*bt
    a=k*k*(1-w*w)
    ss=q*q*a*a+2*q*a*w*w*p+w**4*delta
    nn=q*a*dt/2+w*w*(p*dt-delta*pt)
    if np.any(delta<=0) or np.any(ss<=0): raise ArithmeticError('nonpositive denominator')
    f=2*q*k**3*nn/(R*R*delta*ss)
    return f,delta,ss

def run(nh,nt,nw):
    start=time.monotonic()
    h,wh=roots_legendre(nh); ww,vw=roots_legendre(nw)
    h=h[:,None,None]; th=(np.arange(nt)+0.5)*2*np.pi/nt
    v2=(1-h*h)*np.cos(th)[None,:,None]**2
    w=(ww[None,None,:]+1)/2
    weight=wh[:,None,None]*vw[None,None,:]/(4*nt)
    R0,x0,L0=3/4,1/8,2559/512
    t0=4*x0*x0/(1+x0*x0)**2; q0=1/L0**2
    f0,d0,s0=cleared(R0,t0,q0,h,v2,w)
    rd=np.zeros(np.broadcast_shapes(d0.shape,s0.shape)); rs=rd.copy(); fm=rd.copy()
    err={n:0. for n in [2,4,6]}; points=[]
    for R,x,L in itertools.product([95/128,R0,97/128],[15/128,x0,17/128],[1279/256,L0,5.]):
        t=4*x*x/(1+x*x)**2; q=1/L**2
        f,dd,ss=cleared(R,t,q,h,v2,w)
        u=dd/d0-1; v=ss/s0-1
        rd=np.maximum(rd,abs(u)); rs=np.maximum(rs,abs(v)); fm=np.maximum(fm,abs(f))
        val=float(np.sum(f*weight)); row={'input':[R,x,L],'W_same_grid':val,'approximations':{}}
        for n in [2,4,6]:
            approx=f*(1-(-u)**(n+1))*(1-(-v)**(n+1))
            va=float(np.sum(approx*weight))
            row['approximations'][n]=va; err[n]=max(err[n],abs(va-val))
        points.append(row)
    tails={n:float(np.sum(fm*(rd**(n+1)+rs**(n+1)+rd**(n+1)*rs**(n+1))*weight)) for n in [2,4,6]}
    return {'rule':[nh,nt,nw],'centre_W':float(np.sum(f0*weight)),
       'sample_max_relative_delta':float(rd.max()),'sample_max_relative_s':float(rs.max()),
       'sample_abs_integral_envelope':float(np.sum(fm*weight)),
       'same_grid_max_integral_errors':err,'sampled_weighted_tail_estimates':tails,
       'points':points,'seconds':time.monotonic()-start}

if __name__=='__main__':
    print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT',
                     'rules':[run(64,128,16),run(96,256,32)]},indent=2))
