DIAGNOSTIC_ONLY / NOT_EVIDENCE

The first CW5 Arb microbenchmark failed before evaluation because the flint venv has no NumPy. The R1 driver loads only the unchanged pure-polynomial function using AST; inputs, precision and timing repetitions are unchanged. Original source and traceback remain. No dependency or R3 source was modified.
