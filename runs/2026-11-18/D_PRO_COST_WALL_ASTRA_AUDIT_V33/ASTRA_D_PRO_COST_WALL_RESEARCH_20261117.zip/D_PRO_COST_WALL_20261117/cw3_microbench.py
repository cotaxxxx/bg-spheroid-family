"""DIAGNOSTIC_ONLY / NOT_EVIDENCE: local jet costs, not integral times."""
import sys,time,json,statistics
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
from flint import arb,fmpq as Q,ctx
from prolate_r1.density import Domain,evaluate

shapes=[(('u',),(6,)),(('u','x'),(6,1)),(('u','x'),(6,3)),
        (('u','x'),(6,4)),(('u','R','x','lam'),(6,1,1,1)),
        (('u','R','x','lam'),(6,1,2,1))]
out=[]
with ctx.workprec(128):
    R,L=Q(3,4),Q(2559,512); dom=Domain((R,R),(L,L))
    p=(arb(R),arb(Q(1,8)),arb(L))
    for names,orders in shapes:
        def run(): return evaluate(arb(Q(1,2)),arb(Q(1,3)),p,dom,names,orders,'W')
        j=run()[0]; times=[]
        for _ in range(3):
            st=time.perf_counter(); run(); times.append(time.perf_counter()-st)
        out.append({'active':names,'orders':orders,'coefficients':len(j.c),
                    'seconds':times,'median_seconds':statistics.median(times)})
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE', 'timings':out},indent=2))
