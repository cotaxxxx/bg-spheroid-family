"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Conditional ideal 12-core budgets."""
from fractions import Fraction
import json
rows=[]
for N in [196608,49152,24576,6144,3072,48]:
    rows.append({'boxes':N,'ideal_hours':{str(t):str(Fraction(N*t,12*3600)) for t in [20,60,300,2729]}})
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE',
 'assumption':'CPU seconds per box; 12 fully utilized cores, no overhead. Not measured forecasts.',
 'rows':rows,'seven_day_average_seconds_budget':str(Fraction(7*86400*12,196608))},indent=2))
