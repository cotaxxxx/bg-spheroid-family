# CW5: integrate signed total-degree coefficients
DIAGNOSTIC_ONLY / NOT_EVIDENCE / NONRIGOROUS_FLOAT

Designed after CW4. No prior result is overwritten.
Use the full W kernel U/(R² delta s), total-degree-four polynomial arithmetic
in normalized (R,t,q) displacement; integrate 35 signed coefficients BEFORE
taking their absolute ranges. Rational arithmetic formulas, float64 values.
Rules: (h,azimuth,w)=(32,64,16),(48,96,24). Same centre and actual box 2;
normalization widths are maximum distances from that centre to endpoints.
Record constant coefficient, sum absolute nonconstant integrated coefficients,
and pointwise coefficient L1 before integration. No certification claim.
Limit 120 seconds. No grid tuning.

Also extend CW4's majorant by the exact R^-2 factor using
A_R(z)=2 h_R/Rc z+(h_R/Rc)^2 z². This modifies the diagnostic candidate;
CW4 output remains the earlier bound for J=R²W divided by R_lower².
Both rules and orders 2,4,6 retained.

Finally compare local algebra timings of the new rational density against CW3
using matching rectangular jet sizes, adding fixed w=1/2. This is not a full
three-dimensional integration benchmark. One warmup and three timings each.
