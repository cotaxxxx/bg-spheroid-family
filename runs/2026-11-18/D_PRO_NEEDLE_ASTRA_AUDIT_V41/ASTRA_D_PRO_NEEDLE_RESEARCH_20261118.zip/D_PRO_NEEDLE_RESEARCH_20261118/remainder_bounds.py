"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Outward evaluation of the proved C0 bound."""
from flint import arb,fmpq as Q,ctx
import json
ctx.prec=128
rows=[];m=Q(1,2)
for lam,h in [(5,Q(1,4)),(10,Q(1,4)),(100,Q(1,5)),(1000,Q(1,10)),(10**6,Q(1,100)),(10**12,Q(1,10000))]:
 eps=Q(1,lam);assert eps<=h<=m/2 and eps<=Q(1,2)
 p=arb.pi()
 bound=12*arb(eps/h**2)*arb(2/eps).log()+4*p*p*arb(eps**2/h**3)+2*p*p*arb(eps/h)
 bound+=80*p*arb(1/m**4)*(arb(h)+arb(eps**2)*(arb(2).sqrt()*arb(h/(m*eps))).asinh())
 bound+=30*p*arb(h/m**2)+8*arb(eps/h)+4*p*arb(eps**2/h**2)
 R=arb(eps)*bound
 rows.append({'lambda':lam,'m':str(m),'h':str(h),'R_absolute_upper_exact':str(R.upper().fmpq()),'R_absolute_upper_display':float(R.upper())})
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','applies_to':'C0 energy remainder on |q|<=1-m, NOT gradient remainder','rows':rows},indent=2))
