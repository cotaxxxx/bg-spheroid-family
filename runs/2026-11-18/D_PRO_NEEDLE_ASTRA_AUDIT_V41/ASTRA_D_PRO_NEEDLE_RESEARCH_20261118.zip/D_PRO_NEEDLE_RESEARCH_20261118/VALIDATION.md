# Validation record
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

- Pinned input manifest: 8/8 byte hashes match after restoring the exact fetched newline endings. No source content was edited.
- SymPy exact identities: 5/5 exact zero or exact expected coefficient.
- Numerical identities, first plan: 8/11 within 1e-25; the three inverse-square-root endpoint integrals missed this stringent tolerance by approximately 6e-20. Original results retained.
- Endpoint-regularized second plan: 3/3 within the same tolerance after the exact substitution mu=sin(theta).
- Primitive E: initial coarse polar-layer plan retained. Refined independent plan includes all decimal polar scales. The repeated off-axis case at lambda=10000 differs by approximately 2.8e-17 in E between the two fixed orders. This is not a rigorous error bar.
- Centre: five fixed lambda values, exact one-dimensional formulas evaluated numerically. At lambda=5 the two-term asymptotic radial Hessian has the opposite sign to the direct numerical Hessian.
- Explicit C0 remainder formula: six fixed evaluations with python-flint 0.8.0, 128-bit Arb, exact rational upper endpoints recorded. These bounds do not bound derivatives.
- No full-domain sign run, external-PC operation, repository write, or existing evidence modification.

Independent mathematical audit is still required. In particular, the compact C2 remainder has no numerical constant, and the tip/contact layer estimates needed for a global Lambda0 are not supplied.
