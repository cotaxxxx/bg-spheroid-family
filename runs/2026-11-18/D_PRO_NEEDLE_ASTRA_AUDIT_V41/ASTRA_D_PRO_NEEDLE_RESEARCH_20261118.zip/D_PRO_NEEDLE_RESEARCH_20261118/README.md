# D-PRO needle-limit research package

2026-11-18 — **DIAGNOSTIC_ONLY / NOT_EVIDENCE**

主文書は `ASTRA_D_PRO_NEEDLE_REPORT_20261118.md`。
a(q), b(q), explicit C0 remainder, compact-interior differentiated asymptotics,
centre second correction, and unresolved tip/contact layers are discussed.
No global numerical threshold Lambda0 is established.

## 内容

- `inputs/`: pinned source copies, unchanged, checked against their manifest.
- `SOURCE_HASH_CHECK.json`: all eight source checks.
- `PLAN*.md`: plans fixed before their respective numerical runs.
- `diagnostics*.py`, `DIAGNOSTICS*.json`, logs: primitive two-dimensional E.
- `centre_checks.py`, `CENTRE_RESULTS.json`, log: exact one-dimensional centre formulas, nonrigorous numerical integration.
- `algebra_checks.py`, `ALGEBRA_RESULTS.json`: five exact symbolic identities.
- `identity_checks*.py`, `IDENTITY_RESULTS*.json`: fixed numerical identity checks; original endpoint failures retained.
- `remainder_bounds.py`, `REMAINDER_BOUND_VALUES.json`: outward Arb evaluation of the stated C0 bound, not a gradient bound.
- `ENVIRONMENT.json`: versions actually used.
- `SHA256SUMS`: SHA-256 of all package files except this manifest itself.

## 再実行

封印原本を別フォルダへコピーしてから実行する。スクリプトは同じフォルダの結果JSONを生成するため、原本内では再実行しない。

```bash
python diagnostics_r1.py && python centre_checks.py && python algebra_checks.py && python identity_checks.py && python identity_checks_r1.py
```

Arb上界はpython-flint 0.8.0環境で `python remainder_bounds.py`。
その他はmpmathとSymPyを使用する。完全な証明checkerではない。

## 範囲

GitHub、既存証拠、既存producer、STATE、外部PCは変更していない。
このパッケージの解析も独立監査前であり、研究工程の採用状態を変更しない。
入力原資料に元から存在する表示ラベル・正規化の誤記は原本のまま保存し、報告書で指摘している。
