"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Needle matching and primitive 2-D checks."""
import json,time
from pathlib import Path
import mpmath as mp
mp.mp.dps=30
PI=mp.pi

def coefficients(r,z):
 r,z=mp.mpf(r),mp.mpf(z);S=mp.sqrt(1-z*z);chi=S*S;c=chi+r*r/2
 def inner(phi):
  ell=S-r*mp.cos(phi);a=mp.sqrt(chi+r*r-2*r*S*mp.cos(phi))
  return S*ell*(ell*(1+mp.log(2))+a*mp.log(a)-(a+ell)*mp.log(a+ell))
 B=PI*(S*c*(mp.log(2*chi)-1)+S+(c+1)*z*mp.asin(z))+mp.quad(inner,[0,PI/4,PI/2,3*PI/4,PI])
 return PI*S*c,B

def primitive(lam,r,z,nmu=24,nphi=48):
 lam,r,z=map(mp.mpf,[lam,r,z]);xn,xw=mp.gauss_quadrature(nmu,'legendre');pn,pw=mp.gauss_quadrature(nphi,'legendre')
 phis=[((x+1)*PI/2,ww*PI/2) for x,ww in zip(pn,pw)]
 cuts=[mp.mpf(-1),mp.mpf(1),z]
 for d in [mp.mpf(1),mp.mpf('0.1'),mp.mpf('0.01'),1/lam,1/(10*lam)]:
  cuts += [max(-mp.mpf(1),min(mp.mpf(1),z+sg*d)) for sg in [-1,1]]
 for d in [mp.mpf('0.1'),mp.mpf('0.01'),1/lam**2,1/(10*lam**2)]:cuts += [-1+d,1-d]
 cuts=sorted(set(cuts));total=mp.mpf(0)
 for lower,upper in zip(cuts,cuts[1:]):
  mid=(lower+upper)/2;half=(upper-lower)/2
  for x,weight in zip(xn,xw):
   mu=mid+half*x;s=mp.sqrt(1-mu*mu);B=1-mu*mu+mu*mu/lam**2
   for phi,pweight in phis:
    k=1-z*mu-r*s*mp.cos(phi)
    D=mp.sqrt(s*s+r*r-2*r*s*mp.cos(phi)+lam*lam*(mu-z)**2)
    gamma=k/(D*mp.sqrt(B))
    if gamma<0 or gamma>1:raise ArithmeticError('gamma outside geometric range')
    total+=half*weight*pweight*k*mp.acos(gamma)**2
 return total/(2*PI)

if __name__=='__main__':
 root=Path(__file__).parent;rows=[];start=time.monotonic()
 cases=[(r,z,lam,24,48) for r,z in [('0.5','0'),('0.5','0.5'),('0','0.8')] for lam in [100,1000]]+ [('0.5','0.5',1000,32,64)]
 for r,z,lam,nm,np in cases:
  st=time.monotonic();A,B=coefficients(r,z);E=primitive(lam,r,z,nm,np);D=PI**2/4-E
  row={'q':[r,z],'lambda':lam,'grid':[nm,np],'E':mp.nstr(E,28),'a':mp.nstr(A,28),'b':mp.nstr(B,28),'measured_b':mp.nstr(lam*D-A*mp.log(lam),28),'scaled_residual':mp.nstr(lam*D-A*mp.log(lam)-B,28),'seconds':time.monotonic()-st}
  rows.append(row);print(json.dumps(row),flush=True)
  (root/'DIAGNOSTICS.json').write_text(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','rows':rows},indent=2)+'\n')
  if time.monotonic()-start>600:break
