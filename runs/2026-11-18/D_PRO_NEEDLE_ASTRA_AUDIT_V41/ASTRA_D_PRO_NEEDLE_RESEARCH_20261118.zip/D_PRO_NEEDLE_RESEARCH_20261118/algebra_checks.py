"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact algebra supporting the derivation."""
import sympy as s,json
u,c,z,mu=s.symbols('u c z mu',real=True)
A=s.sqrt(1+u*u-2*u*c);L=1-u*c
series=s.series(L*(A*s.log(A)-(A+L)*s.log(A+L)),u,0,5).removeO().expand()
mean=0
for j in range(5):
 p=s.Poly(series.coeff(u,j),c)
 coeff=sum(v*s.binomial(n[0],n[0]//2)/2**n[0] for n,v in p.terms() if n[0]%2==0)
 mean+=s.simplify(coeff)*u**j
beq=s.simplify(1+(1+u*u/2)*s.log(4)+mean)
expected=1-(3+s.log(2))*u*u/4+(7+6*s.log(2))*u**4/128
chi=1-z*z;S=s.sqrt(chi)
baxis=S+(2-z*z)*z*s.asin(z)+S**3*s.log(S)
baxis_d=(2-3*z*z)*s.asin(z)-3*z*S*s.log(S)
checks={'outer_identity':s.expand((1-z*mu)**2-(chi*(1-mu*mu)+(mu-z)**2))==0,'b_equator_series':s.simplify(beq-expected)==0,'b_axis_derivative':s.simplify(s.diff(baxis,z)-baxis_d)==0,'b_axis_hessian_at_zero':s.limit(s.diff(baxis,z,2),z,0)==2}
plane=s.series((1-u*c)**2/s.sqrt(1+u*u-2*u*c),u,0,3).removeO().expand()
p=s.Poly(plane.coeff(u,2),c);avg=s.simplify(sum(v*s.binomial(n[0],n[0]//2)/2**n[0] for n,v in p.terms() if n[0]%2==0));checks['oblate_radial_second_coefficient']=avg==-s.Rational(1,4)
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','checks':checks,'all_zero_or_exact':all(checks.values()),'b_equatorial_div_pi_series':str(expected)},indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
