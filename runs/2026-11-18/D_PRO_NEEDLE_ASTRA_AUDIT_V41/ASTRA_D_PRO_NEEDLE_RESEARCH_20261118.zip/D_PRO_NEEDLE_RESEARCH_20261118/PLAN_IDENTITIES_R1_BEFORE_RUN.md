# Endpoint-regularized identity check
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

The first identity diagnostic has 8/11 comparisons within 1e-25. Three direct
mu integrals with inverse-square-root endpoints differ by 5.6e-20 to 7.1e-20.
Preserve those results. New check of exactly those three integrals: use the
exact substitution mu=sin(theta), integrate abs(sin(theta)-z) on
[-pi/2,asin(z),pi/2]. Same z=0,1/2,4/5, precision 35 digits and tolerance 1e-25.
No changes to the theorem or threshold. This is numerical quadrature diagnosis,
not a new analytic proof or interval evidence.
