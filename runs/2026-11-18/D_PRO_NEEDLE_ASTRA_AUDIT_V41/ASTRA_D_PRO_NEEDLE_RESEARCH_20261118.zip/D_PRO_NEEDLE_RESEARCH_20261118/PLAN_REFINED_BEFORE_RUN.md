# Needle diagnostic R1: resolve the polar endpoint layers
DIAGNOSTIC_ONLY / NOT_EVIDENCE / 2026-11-18

The first fixed Gauss grids differed by about 1.4e-6 in E at the repeated case.
Preserve them; do not claim those digits as accurate. New fixed plan: all decimal
polar-distance scales 10^-j for 1<=j<=ceil(2 log10(lambda))+2; all decimal scales
about mu=z through ceil(log10(lambda))+2. Same primitive E integrand, 30 digits.
Three points (1/2,0),(1/2,1/2),(0,4/5), lambda=1000,10000; 24x48 nodes.
Repeat (1/2,1/2), lambda=10000 with 32x64 nodes. No changes to formulas a,b.

Source note: the pinned chat_needle_offcentre_probe2.py loops over 1000,10000,
100000, but its printed label says 1e2,1e3,1e4. Interpret those logs according
to the actual source loop, not the stale display label. Do not alter source.
