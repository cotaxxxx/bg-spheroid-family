# Needle limit diagnostics
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Fixed formulas are derived in the report. Numerical checks do not establish
uniform derivative bounds or a global threshold. Original 2-D integrand only
for reference E, with mpmath Gauss-Legendre quadrature and fixed split layers.
30 decimal digits. Three fixed points (rho,z)=(1/2,0),(1/2,1/2),(0,4/5),
lambda=100,1000. 24 Gauss points per mu segment and 48 azimuth points on [0,pi],
using reflection. Mu splits: z, z±{1,1/10,1/100,1/lambda,1/(10lambda)},
clipped to [-1,1], and polar splits ±(1-{1/10,1/100,1/lambda^2,1/(10lambda^2)}).
One refinement at (1/2,1/2), lambda=1000: 32 mu and 64 azimuth nodes.
Record E, lambda*defect-a*log(lambda), analytic b, residual, timing. No sign-based
sample selection. Six primary cases; maximum 600 seconds.

Separately use exact centre 1-D representations at lambda=5,10,100,1000,10000
for centre energy and radial Hessian. Verify the new second coefficient by
subtracting the predicted log(lambda)/lambda^2 term. mpmath 40 digits, split
at inverse-lambda scales. Numeric only, not Arb evidence.
