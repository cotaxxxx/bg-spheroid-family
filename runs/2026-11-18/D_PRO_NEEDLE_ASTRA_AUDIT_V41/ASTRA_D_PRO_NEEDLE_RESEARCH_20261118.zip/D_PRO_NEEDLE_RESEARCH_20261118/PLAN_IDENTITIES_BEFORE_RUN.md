# Final identity cross-checks
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Fixed 35-digit mpmath checks, not interval evidence. Compare the regularized
inner integral J with its elementary formula for (ell,d)=(1,1),(1/2,1),
(3/4,5/4). Integrate [0,1] directly and on [1,infinity] subtract pi*ell/x.
Compare the two outer identities N11 at z=0,1/2,4/5. Compare b_rhorho on
the axis at z=0,1/2 against direct mpmath differentiation of the angular
formula. Tolerance 1e-25 for these diagnostic comparisons. No parameter
search and no sign selection. Maximum 120 seconds.
