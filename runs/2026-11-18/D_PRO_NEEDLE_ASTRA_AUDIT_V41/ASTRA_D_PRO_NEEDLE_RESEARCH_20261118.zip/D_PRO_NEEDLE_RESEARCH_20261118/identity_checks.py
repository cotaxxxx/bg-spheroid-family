"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed analytic-identity diagnostics."""
import mpmath as mp
import json,time
from pathlib import Path
from diagnostics import coefficients
mp.mp.dps=35
pi=mp.pi
def F(y):return pi*mp.asin(y)-mp.asin(y)**2
def J(l,d):
    # Compactify the regularized infinite tail, with its value at v=0.
    def tail(v):
        if not v:return -l*l
        y=l*v/mp.sqrt(1+d*d*v*v)
        # Algebraically remove the linear cancellation before division.
        linear=-pi*l*d*d*v/(mp.sqrt(1+d*d*v*v)*(1+mp.sqrt(1+d*d*v*v)))
        return linear+pi*(mp.asin(y)-y)/(v*v)-(mp.asin(y)/v)**2
    return mp.quad(lambda x:F(l/mp.sqrt(x*x+d*d)),[0,1])+mp.quad(tail,[0,mp.mpf('0.5'),1])
rows=[];start=time.monotonic()
def record(name,actual,expected):
    error=abs(actual-expected)
    rows.append({'name':name,'actual':mp.nstr(actual,30),'expected':mp.nstr(expected,30),'error':mp.nstr(error,8),'within_diagnostic_tolerance':bool(error<mp.mpf('1e-25'))})
for ls,ds in [('1','1'),('0.5','1'),('0.75','1.25')]:
    l,d=mp.mpf(ls),mp.mpf(ds)
    expected=pi*(l*(1+mp.log(2))+d*mp.log(d)-(d+l)*mp.log(d+l))
    record('inner_'+ls+'_'+ds,J(l,d),expected)
for zs in ['0','0.5','0.8']:
    z=mp.mpf(zs);S=mp.sqrt(1-z*z)
    # Rationalize the removable numerator at mu=z.
    def f(mu):
        if mu==z:return mp.mpf(0)  # one point does not affect the integral
        return -mp.sign(mu-z)*(mu+z)/(mp.sqrt(1-mu*mu)+S)
    record('outer_s_'+zs,mp.quad(f,[-1,z,1]),S*mp.log(4*S*S)-2*S+2*z*mp.asin(z))
    record('outer_distance_'+zs,mp.quad(lambda u:abs(u-z)/mp.sqrt(1-u*u),[-1,z,1]),2*(S+z*mp.asin(z)))
for zs in ['0','0.5']:
    z=mp.mpf(zs);S=mp.sqrt(1-z*z)
    expected=pi*(S*mp.log(S)-(3+mp.log(2))*S/2+z*mp.asin(z))
    record('axis_radial_hessian_'+zs,mp.diff(lambda r:coefficients(r,z)[1],mp.mpf(0),2),expected)
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','all_within_tolerance':all(x['within_diagnostic_tolerance'] for x in rows),'seconds':time.monotonic()-start,'rows':rows}
Path(__file__).with_name('IDENTITY_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
