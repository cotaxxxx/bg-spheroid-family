"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact 1-D centre formulas, numeric integrals."""
import mpmath as mp,json,time
from pathlib import Path
mp.mp.dps=40

def H(lam):
 lam=mp.mpf(lam)
 def f(mu):
  s2=1-mu*mu;D2=s2+lam*lam*mu*mu
  gamma=1/mp.sqrt(1+(lam-1/lam)**2*mu*mu*s2)
  y=(1-gamma)/2
  fp=2*mp.hyp2f1(1,1,mp.mpf('1.5'),y)
  fpp=-mp.mpf(2)/3*mp.hyp2f1(2,2,mp.mpf('2.5'),y)
  return -(fp*gamma*(s2-2*s2/D2+mp.mpf('1.5')*s2/D2**2-1/D2)+fpp*gamma*gamma*s2*(1/D2-1)**2/2)
 cuts=sorted(set([mp.mpf(0),mp.mpf(1),1/lam,mp.mpf('0.1'),mp.mpf('0.5'),1-1/lam**2]))
 return mp.quad(f,cuts)
def defect(lam):
 t=lam-1/lam
 return mp.quad(lambda u:mp.pi**2/4-mp.atan(t*u*mp.sqrt(1-u*u))**2,[0,1/lam,mp.mpf('0.1'),mp.mpf('0.5'),1-1/lam**2,1])
if __name__=='__main__':
 root=Path(__file__).parent;rows=[]
 c=mp.mpf('0.5')+mp.log(2)+mp.pi**2/8
 for L in [5,10,100,1000,10000]:
  st=time.monotonic();lam=mp.mpf(L);D=defect(lam);h=H(lam)
  A=mp.pi*(mp.log(lam)+1)/lam-(mp.log(lam)+c)/lam**2
  pred=-mp.pi/lam*(mp.log(lam)-(3+mp.log(2))/2)
  row={'lambda':L,'defect':mp.nstr(D,34),'second_order_defect':mp.nstr(A,34),'second_residual_lambda_squared':mp.nstr(lam**2*(D-A),24),'H_centre':mp.nstr(h,32),'H_two_term':mp.nstr(pred,32),'H_constant_inferred':mp.nstr(lam*h/mp.pi+mp.log(lam),24),'seconds':time.monotonic()-st}
  rows.append(row);print(json.dumps(row),flush=True)
 out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','rows':rows,'centre_hessian_two_term_zero':mp.nstr(mp.exp((3+mp.log(2))/2),30),'second_order_constant':mp.nstr(c,30)}
 (root/'CENTRE_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
