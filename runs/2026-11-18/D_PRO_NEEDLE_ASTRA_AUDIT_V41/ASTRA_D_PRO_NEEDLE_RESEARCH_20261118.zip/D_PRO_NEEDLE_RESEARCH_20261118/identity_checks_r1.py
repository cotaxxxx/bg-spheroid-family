"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Endpoint-regularized fixed checks."""
import mpmath as mp,json
from pathlib import Path
mp.mp.dps=35
rows=[]
for zs in ['0','0.5','0.8']:
    z=mp.mpf(zs)
    actual=mp.quad(lambda th:abs(mp.sin(th)-z),[-mp.pi/2,mp.asin(z),mp.pi/2])
    expected=2*(mp.sqrt(1-z*z)+z*mp.asin(z))
    err=abs(actual-expected)
    rows.append({'z':zs,'actual':mp.nstr(actual,30),'expected':mp.nstr(expected,30),'error':mp.nstr(err,8),'within_diagnostic_tolerance':bool(err<mp.mpf('1e-25'))})
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','all_within_tolerance':all(x['within_diagnostic_tolerance'] for x in rows),'rows':rows}
Path(__file__).with_name('IDENTITY_RESULTS_R1.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
