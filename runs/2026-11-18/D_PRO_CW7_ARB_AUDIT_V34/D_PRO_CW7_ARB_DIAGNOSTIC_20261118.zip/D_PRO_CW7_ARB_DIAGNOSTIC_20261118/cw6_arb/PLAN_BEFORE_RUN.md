# CW6: first outward-rounded total-degree model pilot
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Separate from all sealed CW1--CW5 and R1--R3 files. No repository or remote-PC writes.
Target: R3 box 2 only. Centre (R,t,q)=(3/4,256/4225,(512/2559)^2),
q=lambda^-2; outer displacement radii are exact rational maxima to the stated
box endpoints. Total external degree 4 (35 coefficients). python-flint 0.8.0,
Arb 128-bit. No NumPy/SciPy in the enclosure implementation.

Spatial coordinates h in [-1,1], theta=pi*v/2, v,w in [0,1]. The fourfold
azimuth symmetry gives integration weight dh*dv*dw/2. No cap is removed:
R<=97/128<1, so the contact point is absent. Initial mesh 16*16*16.
Each cell is checked for positive constant denominators and for each of the
three finite denominator majorants A_j(1)<=3/4. A failed check bisects the
longest normalized coordinate (h span/2, v span, w span), ties h,v,w.
Maximum depth 18; maximum final leaves 65536. No sign-based selection.

First baseline: interval Riemann integration of the 35 signed coefficient
functions, plus the outward-rounded algebraic total-degree tail on each cell.
This deliberately isolates the validity of the algebraic majorant; it is NOT
claimed to be an efficient spatial quadrature. A narrow result is not assumed.
Coefficient intervals are summed before polynomial range bounding.

Hard pilot CPU wall budget 420 seconds (checked between cells). Atomic progress
summary and append-only cell JSONL every 64 cells. Any interruption, limit,
nonfinite arithmetic, or uncovered cell means no whole-box W enclosure.
Resume uses the same source, plan, precision and deterministic traversal;
no partial-domain integral is labeled a full-domain result.

Criteria: complete coverage; finite denominators and contraction bounds;
constant-kernel normalization 1; coefficient algebra regression; width target
halfwidth <=3/10, solely a diagnostic comparison. Failure remains failure.
Record exact dyadic/rational enclosure endpoints, coefficient integration
radii, polynomial variation bound, integrated tail bound, leaf count, time,
and peak process RSS. Do not interpret containment of approximate reference
values as proof of the implementation. No global sign run.
