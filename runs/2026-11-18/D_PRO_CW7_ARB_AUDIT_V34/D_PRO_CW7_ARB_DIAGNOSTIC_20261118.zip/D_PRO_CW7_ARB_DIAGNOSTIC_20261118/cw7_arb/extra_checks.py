"""DIAGNOSTIC_ONLY / NOT_EVIDENCE: exact positive identities and inverse edge case."""
from flint import arb,fmpq as Q,ctx
from validator import positive,ball
import json
ctx.prec=128
lo,hi=positive(ball(Q(1,10**40),Q(1)),Q(1,10**40))
inv=ball(1/hi,1/lo)
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','wide_inverse_finite':inv.is_finite(),'wide_inverse_contains_reciprocal_endpoints':inv.contains(arb(1/lo)) and inv.contains(arb(1/hi))},indent=2))

raise SystemExit(0 if inv.is_finite() and inv.contains(arb(1/lo)) and inv.contains(arb(1/hi)) else 1)
