"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Algebra and enclosure plumbing tests."""
import itertools,json,math,time,traceback
from flint import arb,arb_poly,fmpq as Q,ctx
import validator as v
ctx.prec=128
results=[]
def test(name,fn):
    st=time.monotonic()
    try: fn(); results.append({'name':name,'result':'PASS','seconds':time.monotonic()-st})
    except Exception: results.append({'name':name,'result':'FAIL','traceback':traceback.format_exc()})
def check(c):
    if not c: raise AssertionError('failed')
def normal(): check(sum((v.weight(c) for c in v.initial()),Q(0))==1)
def reciprocal():
    den=v.T({v.Z:arb(1),(1,0,0):arb(-1),(0,1,0):arb(-2),(0,0,1):arb(-3)})
    inv=den.reciprocal(Q(1))
    for a in v.IND:
        exact=Q(math.factorial(sum(a)),math.prod(math.factorial(j) for j in a))*2**a[1]*3**a[2]
        check(inv.c[a].contains(arb(exact)))
def exact_reconstruction():
    # Difference rational identities checked exactly, independent of interval recurrences.
    for R,t,q,h,v2,w in [(Q(3,4),v.TC,v.QC,Q(-1,3),Q(2,9),Q(1,2)),(Q(1,2),Q(0),Q(1,25),Q(2,3),Q(1,7),Q(3,4))]:
        U,D,S=v.polys(R,t,q,h,v2,w)
        P=(D,)  # The reference uses direct reflected geometry below.
        sig=1+R*R-2*R*h;k=1-R*h;a0=k*k/sig;d=1-q;aa=(h-R)**2
        uc=(1-t)*v2+t*aa;ac=q*sig+d*uc;B0=1-d*((1-t)*v2+t*h*h)
        p=ac*B0-4*d*d*t*(1-t)*(h-R)*h*v2
        pt=d*(aa-v2)*B0-ac*d*(h*h-v2)-4*d*d*(1-2*t)*(h-R)*h*v2
        # Differentiate exact polynomial t using arb_poly and compare supplied numerator.
        polyU,polyD,polyS=v.polys(arb_poly([arb(R)]),arb_poly([arb(t),arb(1)]),arb_poly([arb(q)]),arb(h),arb(v2),arb(w))
        dt=polyD[1]
        oldA=arb(a0*(1-w*w)); oldP=arb(p/(q*sig)); oldDelta=arb(D/(q*q*sig*sig)); oldPt=arb(pt/(q*sig)); oldDt=dt/arb(q*q*sig*sig)
        oldSS=oldA**2+2*oldA*arb(w*w)*oldP+arb(w**4)*oldDelta
        oldN=oldA*oldDt/2+arb(w*w)*(oldP*oldDt-oldDelta*oldPt)
        oldK=arb(2*k*a0/(R*R))*oldN/(oldDelta*oldSS)
        check(oldK.contains(arb(U/(R*R*D*S))))
def symmetry_sphere():
    for t in [Q(0),Q(1,3),Q(1)]:
        u,d,s=v.polys(Q(3,4),t,Q(1),Q(-1,3),Q(1,7),Q(1,2)); check(u==0 and d>0 and s>0)
def coefficient_tail():
    # At one exact spatial point, all 8 normalized-parameter corners, independent direct evaluations.
    h=arb(Q(-1,3));v2=arb(Q(2,9));w=arb(Q(1,2))
    variables=[v.T({v.Z:arb(c),tuple(int(i==j) for i in range(3)):arb(r)}) for j,(c,r) in enumerate(zip(v.CENTRE,v.RAD))]
    u,d,s=v.polys(*variables,h,v2,w);f=u*(variables[0]**2*d*s).reciprocal(Q(1,10**12))
    for e in itertools.product([-1,1],repeat=3):
        p=[c+ee*r for c,r,ee in zip(v.CENTRE,v.RAD,e)]
        un,dn,sn=v.polys(*map(arb,p),h,v2,w);exact=un/(arb(p[0])**2*dn*sn)
        trunc=sum((c*math.prod(ee**a for ee,a in zip(e,alpha)) for alpha,c in f.c.items()),arb(0))
        # This is a diagnostic finite-point regression, not a box tail proof.
        check((exact-trunc).abs_upper()<arb(Q(1,100)))
def rational_inputs():
    import ast,pathlib
    tree=ast.parse(pathlib.Path(v.__file__).read_text())
    check(not any(isinstance(n,ast.Constant) and isinstance(n.value,float) for n in ast.walk(tree)))
for name,fn in [('constant_kernel_normalization',normal),('35_exact_reciprocal_coefficients',reciprocal),('rational_kernel_reconstruction',exact_reconstruction),('sphere_numerator_zero',symmetry_sphere),('fixed_corner_Taylor_regression',coefficient_tail),('no_float_literals_in_validator',rational_inputs)]: test(name,fn)
print(json.dumps({'status':v.STATUS,'results':results,'all_pass':all(x['result']=='PASS' for x in results)},indent=2))

raise SystemExit(0 if all(x["result"]=="PASS" for x in results) else 1)
