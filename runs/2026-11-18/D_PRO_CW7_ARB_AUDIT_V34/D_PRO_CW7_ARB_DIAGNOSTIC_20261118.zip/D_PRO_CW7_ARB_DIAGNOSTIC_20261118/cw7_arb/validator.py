"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Outward-rounded CW7 research prototype."""
import argparse, hashlib, itertools, json, os, resource, time, traceback
from pathlib import Path
import flint
from flint import arb, arb_poly, fmpq as Q, ctx
STATUS='DIAGNOSTIC_ONLY / NOT_EVIDENCE'
DEG=4
IND=sorted((a for a in itertools.product(range(5),repeat=3) if sum(a)<=4),key=lambda a:(sum(a),a))
Z=(0,0,0)
RC=Q(3,4); TC=Q(256,4225); QC=Q(512,2559)**2
TF=lambda x:4*x*x/(1+x*x)**2
RAD=(Q(1,128),max(TC-TF(Q(15,128)),TF(Q(17,128))-TC),max(QC-Q(1,25),Q(256,1279)**2-QC))
CENTRE=(RC,TC,QC)

def ball(lo,hi): return arb(lo).union(arb(hi))
def lo(x): return x.lower().fmpq()
def hi(x): return x.upper().fmpq()
def mag(x): return max(abs(lo(x)),abs(hi(x)))
def ser(x): return [str(lo(x)),str(hi(x))]
def deser(x): return ball(Q(x[0]),Q(x[1]))
def positive(x,lower):
    if not x.is_finite(): raise ArithmeticError('nonfinite expression')
    lower=max(lower,lo(x))
    if lower<=0 or lower>hi(x): raise ArithmeticError('empty/nonpositive proven denominator')
    return lower,hi(x)

def polys(R,t,q,h,v2,w):
    """Reused CW4 polynomial identities, with the sole float 1/2 made exact."""
    sig=(1-R)**2+2*R*(1-h); k=1-R*h; d=1-q
    aa=(h-R)**2; uc=(1-t)*v2+t*aa; vc=(1-t)*v2-t*aa
    ac=q*sig+d*uc; B0=1-d*((1-t)*v2+t*h*h)
    cross=(h-R)*h*v2
    pp=ac*B0-4*d*d*t*(1-t)*cross
    pt=d*(aa-v2)*B0-ac*d*(h*h-v2)-4*d*d*(1-2*t)*cross
    c=q*q*sig*sig+2*q*d*sig*uc+d*d*vc*vc
    ct=2*q*d*sig*(aa-v2)+2*d*d*vc*(-v2-aa)
    bs=q+d*(1-h*h-v2); ub=(1-t)*h*h+t*v2; vb=(1-t)*h*h-t*v2
    b=bs*bs+2*bs*d*ub+d*d*vb*vb
    bt=2*bs*d*(v2-h*h)+2*d*d*vb*(-h*h-v2)
    delta=c*b; dt=ct*b+c*bt
    a=k*k*(1-w*w)
    ss=q*q*a*a+2*q*a*w*w*pp+w**4*delta
    nn=q*a*dt*Q(1,2)+w*w*(pp*dt-delta*pt)
    return 2*q*k**3*nn,delta,ss

class T:
    def __init__(self,c): self.c=c
    @staticmethod
    def lift(x): return x if isinstance(x,T) else T({Z:arb(x)})
    def __add__(self,x):
        x=T.lift(x); return T({a:self.c.get(a,arb(0))+x.c.get(a,arb(0)) for a in self.c.keys()|x.c.keys()})
    __radd__=__add__
    def __neg__(self): return T({a:-v for a,v in self.c.items()})
    def __sub__(self,x): return self+-T.lift(x)
    def __rsub__(self,x): return T.lift(x)+-self
    def __mul__(self,x):
        x=T.lift(x); out={}
        for a,c in self.c.items():
            for b,d in x.c.items():
                ab=tuple(i+j for i,j in zip(a,b))
                if sum(ab)<=4: out[ab]=out.get(ab,arb(0))+c*d
        return T(out)
    __rmul__=__mul__
    def __pow__(self,n):
        out=T.lift(1)
        for _ in range(n): out=out*self
        return out
    def reciprocal(self,lower):
        denlo,denhi=positive(self.c[Z],lower); inv=ball(1/denhi,1/denlo)
        if not inv.is_finite(): raise ArithmeticError('reciprocal failed')
        out={Z:inv}
        for a in IND[1:]:
            total=arb(0)
            for b,v in self.c.items():
                if b==Z or not all(i<=j for i,j in zip(b,a)): continue
                rem=tuple(j-i for i,j in zip(b,a))
                total+=v*out.get(rem,arb(0))
            out[a]=-total*inv
        return T(out)

def conv(a,b,n):
    return [sum((a[j]*b[k-j] for j in range(max(0,k-len(b)+1),min(k,len(a)-1)+1)),arb(0)) for k in range(n+1)]
def inv_major(a,n):
    out=[arb(1)]
    for k in range(1,n+1): out.append(sum((a[j]*out[k-j] for j in range(1,min(k,len(a)-1)+1)),arb(0)))
    return out

def geom(cell):
    h,v,w=(ball(Q(a),Q(b)) for a,b in cell[:3])
    v2=(1-h**2).nonnegative_part()*(arb.pi()*v/2).cos()**2
    sig=(1-arb(RC))**2+2*arb(RC)*(1-h)
    siglow=max((1-RC)**2,lo(sig)); klow=max(1-RC,lo(1-arb(RC)*h))
    dlower=QC**4*siglow**2
    slower=QC**2*min(klow**2,QC*siglow)**2
    # Independent positive identities at the outer centre (all bounds exact).
    rr,tt,qq=map(arb,CENTRE); dd=1-qq
    yy=(1-h**2).nonnegative_part()*(arb.pi()*v/2).sin()**2
    aa=(h-rr)**2; uc=(1-tt)*v2+tt*aa; vc=(1-tt)*v2-tt*aa
    bs=qq+dd*yy; ub=(1-tt)*h**2+tt*v2; vb=(1-tt)*h**2-tt*v2
    cp=qq**2*sig**2+2*qq*dd*sig*uc+dd**2*vc**2
    bp=bs**2+2*bs*dd*ub+dd**2*vb**2
    cl=max(QC**2*siglow**2,lo(cp)); bl=max(QC**2,lo(bp))
    dlower=max(dlower,cl*bl)
    pp=bs*(qq*sig+dd*uc)+qq*sig*dd*ub+dd**2*(tt*(1-tt)*(h*(h-rr)-v2)**2+v2*((1-tt)*h-tt*(h-rr))**2)
    pl=max(QC**2*siglow,lo(pp))
    al=max(Q(0),lo((1-rr*h)**2*(1-w**2)))
    w2l=max(Q(0),lo(w**2))
    slower=max(slower,QC**2*al**2+2*QC*al*w2l*pl+w2l**2*dlower)
    return h,v2,w,dlower,slower

def evaluate(cell,coefficients=True):
    h,v2,w,dlower,slower=geom(cell)
    R,t,q=(arb_poly([arb(c),ball(-r,r)]) for c,r in zip(CENTRE,RAD))
    U,D,S=polys(R,t,q,h,v2,w)
    d0lo,d0hi=positive(D[0],dlower); s0lo,s0hi=positive(S[0],slower)
    # All majorant constants are exact rational upper bounds, not interval subtraction.
    ad=[arb(0)]+[arb(mag(x)/d0lo) for x in D.coeffs()[1:]]
    ass=[arb(0)]+[arb(mag(x)/s0lo) for x in S.coeffs()[1:]]
    r=RAD[0]/RC; ar=list(map(arb,[Q(0),2*r,r*r]))
    sums=[sum(a,arb(0)) for a in (ar,ad,ass)]
    if any(hi(x)>Q(3,4) for x in sums): return None
    ms=[arb(mag(x)) for x in U.coeffs()]
    full=sum(ms,arb(0))
    for asum in sums: full=full/(1-asum)
    g=ms
    for a in (ar,ad,ass): g=conv(g,inv_major(a,4),4)
    tail=(full-sum(g,arb(0)))/arb(RC**2*d0lo*s0lo)
    if not tail.is_finite() or hi(tail)<0: raise ArithmeticError('invalid majorant tail')
    result={'tail':max(Q(0),hi(tail)),'a_max':max(hi(x) for x in sums)}
    if coefficients:
        vars=[]
        for j,(c,radius) in enumerate(zip(CENTRE,RAD)):
            a=tuple(int(i==j) for i in range(3)); vars.append(T({Z:arb(c),a:arb(radius)}))
        u,d,s=polys(*vars,h,v2,w)
        den=vars[0]**2*d*s
        f=u*(vars[0]**2).reciprocal(RC**2)*d.reciprocal(d0lo)*s.reciprocal(s0lo)
        vals=[f.c.get(a,arb(0)) for a in IND]
        if not all(x.is_finite() for x in vals): raise ArithmeticError('nonfinite coefficient')
        result['coeff']=vals
    return result

def weight(c): return (Q(c[0][1])-Q(c[0][0]))*(Q(c[1][1])-Q(c[1][0]))*(Q(c[2][1])-Q(c[2][0]))/2

def split(c):
    spans=[(Q(b)-Q(a))/(2 if j==0 else 1) for j,(a,b) in enumerate(c[:3])]
    j=max(range(3),key=lambda i:spans[i]); a,b=map(Q,c[j]); mid=(a+b)/2
    left=list(c); right=list(c); left[j]=[str(a),str(mid)]; right[j]=[str(mid),str(b)]
    left[3]=right[3]=c[3]+1
    return left,right

def initial():
    return [[ [str(-1+Q(i,8)),str(-1+Q(i+1,8))], [str(Q(j,16)),str(Q(j+1,16))], [str(Q(k,16)),str(Q(k+1,16))],0]
            for i in range(16) for j in range(16) for k in range(16)]

def pins():
    root=Path(__file__).parent
    return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['validator.py','PLAN_BEFORE_RUN.md']}

def save(path,data):
    temp=path.with_suffix('.tmp'); temp.write_text(json.dumps(data,indent=2)+'\n'); os.replace(temp,path)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default='cw7_run'); ap.add_argument('--resume',action='store_true'); ap.add_argument('--seconds',type=int,default=420); args=ap.parse_args()
    ctx.prec=128
    if flint.__version__!='0.8.0': raise RuntimeError('python-flint 0.8.0 required')
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True); ck=out/'checkpoint.json'
    if args.resume:
        state=json.loads(ck.read_text())
        if state['pins']!=pins(): raise RuntimeError('source/plan pin mismatch')
        pending=state['pending']; total=[deser(x) for x in state['coefficients']]; tail=Q(state['tail_upper']); covered=Q(state['covered']); done=state['leaves']; prior=state['seconds']; max_a=Q(state['max_A']); splits=state['splits']
    else:
        if ck.exists(): raise RuntimeError('use --resume or a new output directory')
        pending=initial(); total=[arb(0) for a in IND]; tail=Q(0); covered=Q(0); done=0; prior=0; max_a=Q(0); splits=0
    start=time.monotonic(); reason='COMPLETE'; error=None
    def checkpoint():
        state={'status':STATUS,'pins':pins(),'pending':pending,'coefficients':[ser(x) for x in total], 'tail_upper':str(tail),'covered':str(covered),'leaves':done,'splits':splits,'max_A':str(max_a),'seconds':prior+time.monotonic()-start}
        save(ck,state)
        with (out/'progress.jsonl').open('a') as fh: fh.write(json.dumps({k:state[k] for k in ['status','leaves','splits','covered','seconds']})+'\n')
    try:
        while pending:
            if time.monotonic()-start>=args.seconds: reason='TIME_LIMIT'; break
            c=pending[-1]
            result=evaluate(c)
            if result is None:
                if c[3]>=18 or done+len(pending)+1>65536: reason='MESH_LIMIT'; break
                pending.pop(); pending.extend(split(c)); splits+=1; continue
            wt=weight(c)
            total=[a+b*arb(wt) for a,b in zip(total,result['coeff'])]
            tail+=wt*result['tail']; covered+=wt; max_a=max(max_a,result['a_max']); done+=1; pending.pop()
            if done%64==0: checkpoint()
    except Exception:
        reason='ERROR'; error=traceback.format_exc()
    checkpoint()
    full=not pending and covered==1 and reason=='COMPLETE'
    summary={'status':STATUS,'reason':reason,'complete_coverage':full,'covered_measure':str(covered),'pending_cells':len(pending),'leaves':done,'splits':splits,'seconds':prior+time.monotonic()-start,'peak_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'flint':flint.__version__,'precision':128,'traceback':error}
    if full:
        variation=sum((mag(x) for x in total[1:]),Q(0))
        enclosure=total[0]+ball(-variation-tail,variation+tail)
        hw=(hi(enclosure)-lo(enclosure))/2
        summary.update({'W':ser(enclosure),'constant_coefficient':ser(total[0]),'integrated_coefficients':[{'alpha':a,'interval':ser(x)} for a,x in zip(IND,total)],'polynomial_variation_bound':str(variation),'tail_upper':str(tail),'halfwidth':str(hw),'width_target':'3/10','width_result':'PASS' if hw<=Q(3,10) else 'FAIL','max_A':str(max_a)})
    save(out/'result.json',summary); print(json.dumps(summary if not full else {k:v for k,v in summary.items() if k!='integrated_coefficients'},indent=2))
if __name__=='__main__': main()
