# CW7-L: local cross-checks after the spatial pilot has begun
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE
No changes to CW7's mesh or thresholds. These are point checks, not integration.
Fixed spatial points (h,v,w): (-1/2,1/4,1/4), (0,1/2,1/2),
(7/8,3/4,3/4). At each, compare the new rational kernel with a separately
constructed C_+B_+, C_-B_- geometry and its t derivatives, at all eight
normalized-parameter cube corners and at its centre. Use Arb 128 bit.
Check the total-degree-four remainder bound against the direct value at those
corners. Record complete intervals; require interval intersection and finite
conservative remainder inclusion. No conclusion from signs and no grid tuning.
Also test exact geometric-series tail 1/16 and positive endpoint inversion
of [10^-40,1].
