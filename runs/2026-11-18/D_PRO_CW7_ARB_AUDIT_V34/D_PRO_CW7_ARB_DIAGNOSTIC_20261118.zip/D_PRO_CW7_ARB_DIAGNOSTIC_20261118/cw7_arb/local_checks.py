"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed independent-geometry spot checks."""
from flint import arb,fmpq as Q,ctx
import itertools,json
import validator as v
ctx.prec=128

def pair_kernel(R,t,q,h,v2,w):
    sig=1+R**2-2*R*h;k=1-R*h;a0=k*k/sig
    st=t.sqrt();ct=(1-t).sqrt();vv=v2.sqrt();ss=sig.sqrt()
    total=arb(0)
    for sign in [-1,1]:
        mz=(st*(h-R)+sign*ct*vv)/ss
        mz_t=((h-R)/(2*st)-sign*vv/(2*ct))/ss
        zz=st*h+sign*ct*vv
        zz_t=h/(2*st)-sign*vv/(2*ct)
        C=1+(1/q-1)*mz*mz; B=1-(1-q)*zz*zz
        Cp=2*(1/q-1)*mz*mz_t; Bp=-2*(1-q)*zz*zz_t
        P=C*B;Pt=Cp*B+C*Bp
        total+=Pt/(P*(a0*(1-w*w)+P*w*w))
    return k*a0/(R*R)*total

points=[(Q(-1,2),Q(1,4),Q(1,4)),(Q(0),Q(1,2),Q(1,2)),(Q(7,8),Q(3,4),Q(3,4))]
rows=[]
for h,vv,w in points:
    cell=[[str(x),str(x)] for x in [h,vv,w]]+[0]
    ev=v.evaluate(cell)
    if ev is None: raise ArithmeticError('point majorant unavailable')
    for e in [(0,0,0)]+list(itertools.product([-1,1],repeat=3)):
        R,t,q=[arb(c+ee*r) for c,r,ee in zip(v.CENTRE,v.RAD,e)]
        hh=arb(h);ww=arb(w);v2=(1-hh*hh)*(arb.pi()*arb(vv)/2).cos()**2
        U,D,S=v.polys(R,t,q,hh,v2,ww);new=U/(R*R*D*S)
        old=pair_kernel(R,t,q,hh,v2,ww)
        trunc=sum((a*int(__import__('math').prod(ee**j for ee,j in zip(e,alpha))) for alpha,a in zip(v.IND,ev['coeff'])),arb(0))
        diff=new-trunc
        covered=v.mag(diff)<=ev['tail']
        rows.append({'spatial_point':list(map(str,[h,vv,w])),'external_corner':e,'new':v.ser(new),'geometry':v.ser(old),'overlap':new.overlaps(old),'residual_abs_upper':str(v.mag(diff)),'majorant_tail_upper':str(ev['tail']),'residual_contained':covered})
a=[arb(0),arb(Q(1,2))];seq=v.inv_major(a,4);tail=1/(1-sum(a,arb(0)))-sum(seq,arb(0))
out={'status':v.STATUS,'rows':rows,'geometric_series_tail_contains_1_over_16':tail.contains(arb(Q(1,16))),'all_pass':all(r['overlap'] and r['residual_contained'] for r in rows)}
print(json.dumps(out,indent=2))

raise SystemExit(0 if out["all_pass"] and out["geometric_series_tail_contains_1_over_16"] else 1)
