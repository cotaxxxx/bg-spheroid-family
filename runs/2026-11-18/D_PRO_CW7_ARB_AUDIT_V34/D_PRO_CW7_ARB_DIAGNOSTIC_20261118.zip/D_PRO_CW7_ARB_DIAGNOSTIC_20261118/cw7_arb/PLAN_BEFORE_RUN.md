# CW7: positive-endpoint inverses and positive-form denominator bounds
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

New diagnostic after CW6 stopped with reciprocal failed; preserve CW6 unchanged.
Same exact box, centre, external degree four, 128-bit Arb, initial 16^3 grid,
contraction threshold 3/4, deterministic bisection, depth 18, maximum 65536
leaves, halfwidth criterion 3/10, and wall budget 420 seconds.

Change 1: positivity is represented by exact rational lower/upper endpoints.
Build inverse interval as union(1/upper,1/lower), not reciprocal of an Arb ball
that can extend below zero because its radius has finite precision.

Change 2: independently bound the constant denominators by their positive-form
identities. Compute y^2=(1-h^2)sin^2(theta) separately, rather than subtracting
v^2 from 1-h^2. Use positive-form c,b,p,s and geometric lower bounds; intersect
these bounds with the natural interval evaluation. Reciprocals of R^2,delta,s
are composed separately in the external Taylor algebra.

No exploratory tuning of degree, accuracy threshold, or box. The spatial
quadrature is still the baseline interval Riemann sum, not an efficient final
producer. Any resource limit or exception returns OPEN without whole-box W.
Record tests, tracebacks, complete-domain status, exact enclosures, tail,
coefficient radii, time and peak RSS. Progress snapshots permit exact replay.
