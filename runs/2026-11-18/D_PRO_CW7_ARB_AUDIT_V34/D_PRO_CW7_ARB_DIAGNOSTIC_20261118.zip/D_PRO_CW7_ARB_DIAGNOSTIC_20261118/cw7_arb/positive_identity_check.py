"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact symbolic identity, not interval audit."""
import sympy as s,json
R,t,q,h,v=s.symbols('R t q h v');sig=1+R**2-2*R*h;d=1-q;aa=(h-R)**2
uc=(1-t)*v+t*aa;bs=q+d*(1-h*h-v);ub=(1-t)*h*h+t*v
ac=q*sig+d*uc;B0=1-d*((1-t)*v+t*h*h)
p=ac*B0-4*d*d*t*(1-t)*(h-R)*h*v
positive=bs*ac+q*sig*d*ub+d*d*(t*(1-t)*(h*(h-R)-v)**2+v*((1-t)*h-t*(h-R))**2)
print(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','p_positive_identity_exact_zero':s.expand(p-positive)==0}))

raise SystemExit(0 if s.expand(p-positive)==0 else 1)
