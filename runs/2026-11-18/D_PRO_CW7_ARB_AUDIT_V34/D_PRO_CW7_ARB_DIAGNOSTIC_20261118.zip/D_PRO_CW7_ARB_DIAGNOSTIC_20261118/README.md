# D-PRO CW6/CW7 Arb research prototype
DIAGNOSTIC_ONLY / NOT_EVIDENCE

Requires Python 3.12 and python-flint==0.8.0 (tested Python 3.12.14).
No NumPy or SciPy is needed for the validator and tests. SymPy 1.14.0 was used
only to verify the positive polynomial identity recorded in the report.
No whole-box enclosure was obtained. Do not start a global run from this code.

From the extracted archive root, using a Python with python-flint 0.8.0:

```sh
PYTHONDONTWRITEBYTECODE=1 python cw7_arb/tests.py && PYTHONDONTWRITEBYTECODE=1 python cw7_arb/local_checks.py && PYTHONDONTWRITEBYTECODE=1 python cw7_arb/extra_checks.py
```

To reproduce the bounded CW7 pilot in a NEW output folder:

```sh
PYTHONDONTWRITEBYTECODE=1 python cw7_arb/validator.py --output replay_cw7 --seconds 420
```

To resume its own saved state (not recommended as a route to the target width):

```sh
PYTHONDONTWRITEBYTECODE=1 python cw7_arb/validator.py --output replay_cw7 --resume --seconds 420
```

The archived outputs are immutable research records; do not use them as output
directories for new trials. Use fresh directories. Resuming may widen Arb balls
slightly when deserializing rational endpoints; inclusion is preserved.

The source and pre-run plan SHA pins must match to resume. Checkpoints are
trusted local state, not independently authenticated evidence. `result.json`
contains a full-domain W enclosure only on complete coverage. An incomplete
result contains no such enclosure. `progress.jsonl` records aggregate progress
at every 64 completed leaves, and at termination, not every individual cell.

CW6's exception and partial checkpoint are retained. CW7 is a separate revision,
not an overwrite. Both use signed coefficient integration before taking absolute
values. The spatial Riemann integration is a validity baseline with poor width.

Files `SOURCE_HASHES.json`, `SHA256SUMS`, and the report identify the inputs and
outputs. SHA256SUMS covers all package files except itself. The ZIP's own hash
is stored beside the ZIP; it cannot be included inside itself.
