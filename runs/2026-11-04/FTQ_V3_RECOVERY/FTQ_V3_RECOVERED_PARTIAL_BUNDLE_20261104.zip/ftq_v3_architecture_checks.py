"""Exact V3 architecture checks only. No LP solves or production boxes."""
from fractions import Fraction as Q
from math import prod
import json
from ftq_algebra import var
t,g,k,n,lam,w,S,Z2,Y,u=map(var,range(10))
K=k*k
ET=4*w*w*g*g*K-lam*lam*S
EJ=S*K-S+(1-lam*lam)*Z2
EN=S*K*n-Y
Ez=4*w*w*g*g*K*(1-K)-lam*lam*(1-lam*lam)*Z2
Ey=4*w*w*g*g*K*K*n-lam*lam*Y
assert not(Ez-((1-K)*ET-lam*lam*EJ))
assert not(Ey-(K*n*ET+lam*lam*EN))
EG=2*w*k*g-lam*u
assert not(ET-(2*w*k*g+lam*u)*EG-lam*lam*(u*u-S))
Qdir=K*(1-(1-lam*lam)*n)-lam*lam
assert not(S*Qdir-(1-lam*lam)*(S-Z2-Y)-(EJ-(1-lam*lam)*EN))
R,Z,vx,vz=map(var,range(4))
assert not((R*R+Z*Z)*(vx*vx+vz*vz)-(R*vx+Z*vz)**2-(Z*vx-R*vz)**2)
# Back to active variables t,g,k,n. Representative rational coefficients do not
# depend on any diagnostic; they only verify the symbolic degree envelopes.
t,g,k,n=map(var,range(4));K=k*k;T=g*g*K
alpha=Q(1);ll2=Q(4,25)
qs=[K*(1-(1-ll2)*n)-ll2,1-K*n-alpha*T,T,T*-1+1,T*(1-K),1-T*(1-K),T*K*n,1-T*K*n]
def degree(p):return tuple(max(idx[j] for idx in p) for j in range(4))
qd=[degree(p) for p in qs]
expected=[(0,0,2,1),(0,2,2,1),(0,2,2,0),(0,2,2,0),(0,2,4,0),(0,2,4,0),(0,2,4,1),(0,2,4,1)]
assert qd==expected
beta=(0,2,2,1);residual=(4,4,6,2)
c=1-t*t;A=1+t*t+c*g;f=A*(1-n)-(2*A-g*c)*n*(1-2*K)**2
targets=[(K*f,k**0),(g,K*K*A*A),(g*f,K*A*A)]
for p,d in targets:
    assert all(x<=y for x,y in zip(degree(p),residual))
    assert all(x<=y for x,y in zip(degree(d),residual))
assert all(all(x+b<=r for x,b,r in zip(q,beta,residual)) for q in qd)
def vq1(k,n):return k*k*(1-Q(21,25)*n)-Q(4,25)
def vq2(k,n,g):return 1-k*k*(n+g*g)
assert vq1(Q(2,5),Q(1,2))<0<vq2(Q(2,5),Q(1,2),0)
assert vq1(1,1)==0 and vq2(1,1,1)<0
nb=prod(x+1 for x in beta);nr=prod(x+1 for x in residual)
data={'mode':'ARCHITECTURE ONLY / NO PRODUCTION / NO SOLVER RUN',
'exact_identity_checks':'difference=0: ET, Ez, Ey, directional identity, Gram identity',
'joint_inequality_count':8,'reduced_equality_count':0,'lifted_equality_count':6,
'active_order':['t','gamma','k','n'],'constraint_tensor_degrees':qd,
'multiplier_tensor_degree':beta,'coefficients_per_multiplier':nb,'multiplier_count':8,
'nonnegative_multiplier_unknowns':8*nb,'LP_non_slack_variables':8*nb+1,
'residual_tensor_degree':residual,'residual_coefficients':nr,
'LP_inequalities':nr,'LPs_per_branch':3,'LPs_for_1024_branches':3072,
'target_certificate_rationals_without_dual':8*nb+nr+1,
'target_certificate_rationals_with_dual':8*nb+2*nr+1,
'branch_certificate_rationals_with_dual':3*(8*nb+2*nr+1),
'all_branches_certificate_rationals_with_dual':1024*3*(8*nb+2*nr+1),
'H_dense_entries_per_branch':nr*8*nb,
'H_unique_entries_using_t_independence':prod(x+1 for x in residual[1:])*8*nb,
'physical_projection_equality_claim':False,
'certificate_mechanism':'nonnegative Bernstein polynomial multipliers + exact Bernstein residual + exact LP dual',
'whole_face_m0':'UNPROVED'}
print(json.dumps(data,indent=2))
open('ftq_v3_architecture_checks_result.json','w').write(json.dumps(data,indent=2))
