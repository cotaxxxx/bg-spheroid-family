"""Architecture reference recipe; no production, scan, or coefficient evaluation.

Input physical box (tau,mu,s,lambda,t), folded s in [0,1], epsilon +/-1.
Output active box (t,gamma,k,nu_hat) and exact enclosure trace.
"""
from fractions import Fraction as F
from math import isqrt

def I(a,b=None):return (F(a),F(a if b is None else b))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def sub(a,b):return (a[0]-b[1],a[1]-b[0])
def mul(a,b):
    z=[x*y for x in a for y in b];return (min(z),max(z))
def div(a,b):
    assert b[0]>0
    return mul(a,(1/b[1],1/b[0]))
def sq(a):return (F(0) if a[0]<=0<=a[1] else min(x*x for x in a),max(x*x for x in a))
def cut(a,b):
    out=(max(a[0],b[0]),min(a[1],b[1]));assert out[0]<=out[1];return out
def root(a):
    assert a[0]>=0
    def ep(x,up):
        n=isqrt((x.numerator<<64)//x.denominator)
        if up and F(n*n,1<<64)!=x:n+=1
        return F(n,1<<32)
    ans=(ep(a[0],False),ep(a[1],True))
    assert ans[0]**2<=a[0] and ans[1]**2>=a[1]
    return ans

def enclosure(bounds,epsilon):
    assert epsilon in (1,-1)
    tau,mu,s,lam,t=tuple(tuple(map(F,x)) for x in bounds)
    R=lambda x:(1-x*x)/(1+x*x)
    Z=lambda x:2*x/(1+x*x)
    rr=(R(tau[1]),R(tau[0]));zz=(Z(tau[0]),Z(tau[1]))
    mu2=sq(mu);a2=sub(I(1),mu2);aa=cut(root(a2),I(0,1))
    se=mul(I(epsilon),s)
    X=sub(mul(aa,se),rr);x2=sq(X)
    y2=mul(a2,sub(I(1),sq(s)))
    delta=sub(mu,zz);d2=sq(delta);lam2=sq(lam)
    Sdot=mul(I(2),sub(sub(I(1),mul(mul(rr,aa),se)),mul(zz,mu)))
    Ssos=add(add(x2,y2),d2)
    S=cut(cut(Sdot,Ssos),I(0,4))
    # Cauchy geometry: S>=R^2(1-s^2); for epsilon=-1, S>=2(1-Z).
    transverse=rr[0]**2*(1-s[1]**2)
    negative_cosine=2*(1-zz[1]) if epsilon==-1 else F(0)
    S=cut(S,(max(S[0],transverse,negative_cosine),F(4)))
    assert S[1]>0
    zeta_lo=d2[0]/S[1]
    zeta_hi=min(F(1),d2[1]/S[0]) if S[0]>0 else F(1)
    zeta=cut((zeta_lo,zeta_hi),I(0,1))
    J=(1-(1-lam[0]**2)*zeta[1],1-(1-lam[1]**2)*zeta[0])
    k=cut(root(J),(lam[0],F(1)))
    e2=add(x2,mul(lam2,d2))
    # Shared y2 kept in numerator and denominator: monotonic y/(y+e).
    dl=y2[0]+e2[1];dh=y2[1]+e2[0]
    nlo=y2[0]/dl if dl>0 else F(0)
    nhi=y2[1]/dh if dh>0 else F(1)
    directional=(1-zeta[0])/(1-(1-lam[0]**2)*zeta[0])
    nhat=cut((nlo,min(nhi,directional)),I(0,1))
    w2=(lam[0]**2+(1-lam[0]**2)*mu2[0],lam[1]**2+(1-lam[1]**2)*mu2[1])
    w=cut(root(w2),(lam[0],F(1)));u=cut(root(S),I(0,2))
    gamma_raw=div(mul(lam,u),mul(I(2),mul(w,k)))
    # sqrt(S)>=S/2 on [0,4], w*k<=1: strict positivity cannot be lost to root rounding.
    rescue=lam[0]*S[0]/4
    gamma=cut((max(gamma_raw[0],rescue),gamma_raw[1]),I(0,1))
    trace=dict(R=rr,Z=zz,mu2=mu2,a2=a2,a=aa,X=X,x2=x2,y2=y2,delta=delta,delta2=d2,S_dot=Sdot,S_sos=Ssos,S=S,transverse_bound=transverse,negative_cosine_bound=negative_cosine,zeta=zeta,J=J,k=k,e2=e2,nu_lower_ratio=nlo,nu_upper_ratio=nhi,nu_directional_upper=directional,nu_hat=nhat,w2=w2,w=w,u=u,gamma_raw=gamma_raw,gamma_rescue=rescue,gamma=gamma)
    return (t,gamma,k,nhat),trace
