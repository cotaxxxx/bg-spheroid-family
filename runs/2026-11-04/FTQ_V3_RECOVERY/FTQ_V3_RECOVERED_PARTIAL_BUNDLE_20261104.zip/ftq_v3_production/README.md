# FT_q V3 exact production — μ16 / P-only

Judge authorization: 2026-10-17 JST.

Scope: 2048 folded physical boxes, 4096 epsilon branches, P-only.
Fixed Q1–Q8, multiplier degree (0,2,2,1), residual degree (4,4,6,2).
Weights: 1/192 and 1/96. Parameter aggregation: minimum of 16 sums.

## Entry points

- `setup_run.py`: hash checks and deterministic physical manifest.
- `producer.py`: fixed float-basis discovery, exact rational reconstruction,
  exact primal/dual validation; exact Bland simplex fallback (20000 pivots).
- `checker.py`, `checker_math.py`: independent interval and coefficient implementation.
- `checker_stream.py`: independently check completed branches during production.
- `finalize_checker.py`: verify all branch identities and coverage are present,
  then aggregate checked lower bounds using μ16 weights.
- `summarize.py`: producer aggregate and exact comparison with checker output.

From this directory's parent, run:

```sh
python3 ftq_v3_production/setup_run.py
python3 ftq_v3_production/producer.py
python3 ftq_v3_production/checker.py
python3 ftq_v3_production/summarize.py
```

Existing branch records are immutable completion checkpoints; producer skips them.
For a fully fresh recomputation use a separate copy without `certificates/*.json.gz`.
Do not delete existing evidence or alter fixed source files.

Certificates store sparse nonzero multiplier and dual entries; all missing entries
are exact zeros. All 525 residuals are specified by the exact reconstruction
`b_i=n_i-ell*d_i-sum(H_i,qalpha*a_qalpha)`. Producer and independent checker rebuild
this data and establish nonnegativity. Hashes supplement, not replace, exact checks.

The independent checker is a separate implementation by the same assistant in
the same runtime. It does NOT replace the required external chat recomputation.

No Git commit/push. No D5 access. FT_q remains PARTIAL until Judge adoption.
See `result.json` when present for final exact aggregate and completeness status.
An archive labelled CHECKPOINT/INCOMPLETE is not a final production certificate.
