"""Exact polynomial algebra and analytic beta-series bounds; no parameter sampling."""
from fractions import Fraction as F
from math import comb,ceil
import json
from pathlib import Path
NVAR=12 # x,z,b,mu,lambda,q; Laurent exponents allowed
class P(dict):
 def __add__(a,b):
  if not isinstance(b,P): b=P({(0,)*NVAR:F(b)})
  d=P(a)
  for k,v in b.items(): d[k]=d.get(k,F(0))+v
  return P({k:v for k,v in d.items() if v})
 __radd__=__add__
 def __neg__(a):return P({k:-v for k,v in a.items()})
 def __sub__(a,b):return a+-b
 def __rsub__(a,b):return -a+b
 def __mul__(a,b):
  if not isinstance(b,P):return P({k:v*F(b) for k,v in a.items() if v*F(b)})
  d=P()
  for k,v in a.items():
   for l,w in b.items():
    h=tuple(i+j for i,j in zip(k,l));d[h]=d.get(h,F(0))+v*w
  return P({k:v for k,v in d.items() if v})
 __rmul__=__mul__
 def __truediv__(a,b):return a*F(1,b)
 def __pow__(a,n):
  if n<0:
   assert len(a)==1
   k,v=next(iter(a.items()));return P({tuple(i*n for i in k):v**n})
  out=P({(0,)*NVAR:F(1)})
  for _ in range(n):out=out*a
  return out
def var(i):return P({tuple(int(j==i) for j in range(NVAR)):F(1)})
