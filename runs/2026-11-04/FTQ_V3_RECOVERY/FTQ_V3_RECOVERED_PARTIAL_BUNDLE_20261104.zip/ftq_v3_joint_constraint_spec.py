"""Frozen-candidate V3 constraints; callable specification, no production loop.
Receives the unchanged V2 geometry trace and physical lambda interval.
"""
from fractions import Fraction as F
from ftq_algebra import var

MULTIPLIER_DEGREE=(0,2,2,1)
RESIDUAL_DEGREE=(4,4,6,2)
TARGET_ORDER=('B','physical_weight','physical_product')

def constraints(trace,lambda_bounds):
    lo,hi=map(F,lambda_bounds)
    assert F(2,5)<=lo<=hi<=F(93,200)
    Slo,Shi=map(F,trace['S'])
    dzlo,dzhi=map(F,trace['delta2'])
    ylo,yhi=map(F,trace['y2'])
    vlo,vhi=map(F,trace['w2'])
    assert vlo>0 and min(Slo,dzlo,ylo)>=0
    alpha=max(F(1),vlo/(hi*hi))
    LT=lo*lo*Slo/(4*vhi);UT=hi*hi*Shi/(4*vlo)
    LZ=lo*lo*(1-lo*lo)*dzlo/(4*vhi)
    UZ=hi*hi*(1-hi*hi)*dzhi/(4*vlo)
    LY=lo*lo*ylo/(4*vhi);UY=hi*hi*yhi/(4*vlo)
    t,g,k,n=map(var,range(4));K=k*k;T=g*g*K
    q=[K*(1-(1-lo*lo)*n)-lo*lo,
       1-K*n-alpha*T,
       T-LT,UT-T,
       T*(1-K)-LZ,UZ-T*(1-K),
       T*K*n-LY,UY-T*K*n]
    constants={'lambda_lower_squared':lo*lo,'alpha':alpha,'LT':LT,'UT':UT,'LZ':LZ,'UZ':UZ,'LY':LY,'UY':UY}
    return q,constants

def targets():
    t,g,k,n=map(var,range(4));c=1-t*t;A=1+t*t+c*g
    f=A*(1-n)-(2*A-g*c)*n*(1-2*k*k)**2
    return [(k*k*f,k**0),(g,k**4*A*A),(g*f,k*k*A*A)]
