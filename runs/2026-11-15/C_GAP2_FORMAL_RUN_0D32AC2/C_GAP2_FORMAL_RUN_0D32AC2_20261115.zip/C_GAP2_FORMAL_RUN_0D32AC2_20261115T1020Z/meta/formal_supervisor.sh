#!/usr/bin/env bash
# C GAP2 v4-r2 formal-run supervisor: one-shot, NO resume, NEVER alters sources/seals/USB.
# Starts AFTER the already authorized producer and checker have been launched.
set -euo pipefail
ROOT=/home/daybreak/C_GAP2_FORMAL_RUN_0D32AC2_20261115T1020Z
REPO=/home/daybreak/GAP2_IMPL_V4R2_20261115
FAMILY=/home/daybreak/bg-spheroid-family
PY=/home/daybreak/.pyenv/versions/3.11.16/bin/python
HEAD=0d32ac2a0325f41998adebf922a57ed50cf3ba59
JUDGE=f737fa582652b87f8d3ebbb87e1a0ef81709d22df8b55fa206b800b90e116e6f
P_PID=1356010
C_PID=1356705
EVIDENCE_BRANCH=evidence/c-gap2-run-0d32ac2-20261115
WD=/home/daybreak/C_GAP2_RUN_EVIDENCE_WT_0D32AC2_20261115
RULING="$ROOT/meta/JUDGE_RULING_C_GAP2_FREEZE_AND_RUN_20261115.md"
REPORT="$ROOT/meta/run_final_report.txt"
LOG="$ROOT/meta/formal_supervisor.log"
echo "SUPERVISOR_STARTED $(date -u +%FT%TZ) NO_AUTORESTART" | tee -a "$LOG"
test -d "$ROOT"
test -f "$RULING"
test "$(sha256sum "$RULING" | cut -d' ' -f1)" = "$JUDGE"
test "$(git -C "$REPO" rev-parse HEAD)" = "$HEAD"
test -z "$(git -C "$REPO" status --porcelain)"
test -f "$ROOT/producer/ledger.jsonl"
test -f "$ROOT/checker/ledger.jsonl"

active() {
  local pid=$1
  local role=$2
  ps -p "$pid" -o args= 2>/dev/null | grep -q "gap2_${role}.driver --execute"
}
state() {
  local role=$1
  local path="$ROOT/$role/manifest.json"
  if [[ ! -f "$path" ]]; then echo MISSING; return;fi
  "$PY" -c 'import json,sys; print(json.load(open(sys.argv[1]))["status"])' "$path" 2>/dev/null || echo MALFORMED
}
check_pin() {
  local label=$1
  {
    printf 'STEP=%s UTC=%s\nHEAD=' "$label" "$(date -u +%FT%TZ)"
    git -C "$REPO" rev-parse HEAD
    echo 'git status --porcelain'
    git -C "$REPO" status --porcelain
    echo '---'
  } >>"$ROOT/meta/pre_step_head_status.log"
  test "$(git -C "$REPO" rev-parse HEAD)" = "$HEAD"
  test -z "$(git -C "$REPO" status --porcelain)"
}
archive() {
  local verdict=$1
  echo "VERDICT=$verdict" | tee -a "$REPORT" "$LOG"
  printf 'ENDED_UTC=%s\n' "$(date -u +%FT%TZ)" | tee -a "$REPORT" "$LOG"
  echo "PRODUCER_MANIFEST=$(state producer)" >>"$REPORT"
  echo "CHECKER_MANIFEST=$(state checker)" >>"$REPORT"
  echo "HEAD=$HEAD" >>"$REPORT"
  echo "JUDGE_RULING_SHA256=$JUDGE" >>"$REPORT"
  echo "PRODUCER_LOGS=$ROOT/logs/producer.stdout,$ROOT/logs/producer.stderr" >>"$REPORT"
  echo "CHECKER_LOGS=$ROOT/logs/checker.stdout,$ROOT/logs/checker.stderr" >>"$REPORT"
  echo "PYTHON=$("$PY" --version 2>&1)" >>"$REPORT"
  echo "FLINT=$("$PY" -c 'import flint;print(flint.__version__)')" >>"$REPORT"
  echo "COMPARISON=$(test -f "$ROOT/comparison.json" && echo AVAILABLE || echo NOT_RUN)" >>"$REPORT"
  (cd "$ROOT" && find . -type f ! -name SHA256SUMS.txt -print0 | sort -z | xargs -0 -r sha256sum > SHA256SUMS.txt)
  local zip="$ROOT.zip"
  (cd /home/daybreak && zip -q -r "$zip" "$(basename "$ROOT")")
  sha256sum "$zip" > "$zip.sha256"
  echo "ZIP=$zip" | tee -a "$LOG"
  echo "ZIP_SHA256=$(cut -d' ' -f1 "$zip.sha256")" | tee -a "$LOG"
  echo "ZIP_BYTES=$(stat -c %s "$zip")" | tee -a "$LOG"
  echo "ZIP_TEST=$(unzip -tq "$zip" | tail -1)" | tee -a "$LOG"
  # Register immutable results on a separate evidence branch, never on main.
  local base=9f16bd01c8a104e45ce9b1fad74491569cd46de6
  test ! -e "$WD"
  if git -C "$FAMILY" ls-remote --exit-code origin "refs/heads/$EVIDENCE_BRANCH" >/dev/null 2>&1;then
    echo 'EVIDENCE_BRANCH_COLLISION: preserve local ZIP, do not overwrite' | tee -a "$LOG"
    return 2
  fi
  git -C "$FAMILY" worktree add -b "$EVIDENCE_BRANCH" "$WD" "$base"
  local dst="$WD/runs/2026-11-15/C_GAP2_FORMAL_RUN_0D32AC2"
  mkdir -p "$dst"
  cp "$zip" "$dst/C_GAP2_FORMAL_RUN_0D32AC2_20261115.zip"
  sed 's@  .*@  C_GAP2_FORMAL_RUN_0D32AC2_20261115.zip@' "$zip.sha256" >"$dst/SHA256SUMS.txt"
  cp "$REPORT" "$dst/RUN_VERDICT.txt"
  (cd "$dst" && sha256sum -c SHA256SUMS.txt)
  git -C "$WD" add runs/2026-11-15/C_GAP2_FORMAL_RUN_0D32AC2
  git -C "$WD" diff --cached --check
  git -C "$WD" -c user.name='ChatGPT Dig' -c user.email='dig@users.noreply.github.com' commit -m "evidence: C gap2 formal run $verdict (not Judge accepted)"
  git -C "$WD" push -u origin "$EVIDENCE_BRANCH"
  echo "EVIDENCE_COMMIT=$(git -C "$WD" rev-parse HEAD)" | tee -a "$LOG"
  echo "EVIDENCE_BRANCH=$EVIDENCE_BRANCH" | tee -a "$LOG"
}

failed=''
pass_p=0
pass_c=0
while :; do
  p=$(state producer)
  c=$(state checker)
  if [[ "$p" == "CANDIDATE_NOT_JUDGE_ACCEPTED" ]]; then pass_p=1;fi
  if [[ "$c" == "CANDIDATE_NOT_JUDGE_ACCEPTED" ]]; then pass_c=1;fi
  if [[ "$p" == ABORT* || "$p" == MALFORMED ]];then failed="producer status $p";break;fi
  if [[ "$c" == ABORT* || "$c" == MALFORMED ]];then failed="checker status $c";break;fi
  if ! active "$P_PID" producer && [[ "$pass_p" -eq 0 ]];then failed="producer exited without successful manifest ($p)";break;fi
  if ! active "$C_PID" checker && [[ "$pass_c" -eq 0 ]];then failed="checker exited without successful manifest ($c)";break;fi
  if [[ "$pass_p" -eq 1 && "$pass_c" -eq 1 ]];then break;fi
  echo "PENDING_UTC=$(date -u +%FT%TZ) producer=$p checker=$c producer_records=$(wc -l < "$ROOT/producer/ledger.jsonl") checker_records=$(wc -l < "$ROOT/checker/ledger.jsonl")" >> "$LOG"
  sleep 20
done

if [[ -n "$failed" ]];then
  echo "STOPPED_FIRST_FAILURE: $failed" | tee -a "$REPORT" "$LOG"
  if active "$P_PID" producer; then kill -TERM "$P_PID" || :;fi
  if active "$C_PID" checker; then kill -TERM "$C_PID" || :;fi
  sleep 2
  archive STOPPED_NOT_EVIDENCE
  exit 2
fi

echo "BOTH_MANIFESTS_SUCCESSFUL $(date -u +%FT%TZ)" | tee -a "$REPORT" "$LOG"
check_pin cross_lineage_compare
echo "COMPARISON_STARTED=$(date -u +%FT%TZ)" >> "$REPORT"
set +e
/usr/bin/time -p -o "$ROOT/logs/compare.time" "$PY" -m gap2_analysis.lineage_compare --producer-run "$ROOT/producer" --checker-run "$ROOT/checker" --judge-ruling-sha256 "$JUDGE" --output "$ROOT/comparison.json" >"$ROOT/logs/compare.stdout" 2>"$ROOT/logs/compare.stderr"
rc=$?
set -e
echo "COMPARISON_EXIT=$rc" >>"$REPORT"
if [[ "$rc" -ne 0 ]];then
  echo "STOPPED_COMPARISON_FAILURE" | tee -a "$REPORT" "$LOG"
  archive COMPARISON_FAILED_NOT_EVIDENCE
  exit 3
fi
grep -q 'COMPARE_PASS_NOT_JUDGE_CLOSED' "$ROOT/logs/compare.stdout" || { echo "COMPARE_STATUS_MISSING" | tee -a "$REPORT"; archive COMPARISON_INVALID_NOT_EVIDENCE;exit 4; }
echo "COMPARISON_PASS_NOT_JUDGE_CLOSED" >>"$REPORT"
archive CANDIDATE_COMPARE_PASS_NOT_JUDGE_ACCEPTED
echo "FINAL_CANDIDATE_STATUS=COMPARE_PASS_NOT_JUDGE_CLOSED"
