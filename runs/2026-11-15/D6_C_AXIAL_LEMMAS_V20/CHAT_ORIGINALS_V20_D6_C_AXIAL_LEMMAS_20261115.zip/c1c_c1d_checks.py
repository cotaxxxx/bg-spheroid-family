"""chat independent checks: C1c lemma 6fba6e4f, C0 transfer 963b03be, C1d lemma 35656381 (sympy exact)."""
import sympy as sp
from fractions import Fraction as Fr
ok={}
mu,t,lam,s=sp.symbols('mu t lam s',real=True)
L=lam**2; a=1-L
q=1-mu**2+lam**2*(mu-t)**2; w2=lam**2+(1-lam**2)*mu**2; A=1-t*mu
ok['L5_factorization']=sp.expand(w2*q-lam**2*A**2-(1-mu**2)*(mu*(1-lam**2)+lam**2*t)**2)==0
ok['L3_q_concave']=sp.expand(sp.diff(q,mu,2)-2*(lam**2-1))==0
f=(a*mu+L*t)**2/(a*mu**2+L)
ok['L5_fprime']=sp.simplify(sp.diff(f,mu)-2*a*L*(a*mu+L*t)*(1-t*mu)/(a*mu**2+L)**2)==0
ok['L5_f(1)']=sp.simplify(f.subs(mu,1)-(a+L*t)**2)==0
# R derivatives via Psi
g=sp.Symbol('g'); Psi=sp.Function('Psi'); R=Psi(1-g**2)
def rep(e):
    return e.replace(lambda x: isinstance(x,sp.Subs), lambda x: sp.Symbol('P%d'%x.expr.args[1][1])).replace(lambda x: isinstance(x,sp.Derivative), lambda x: sp.Symbol('P%d'%len(x.variables)))
P1,P2,P3=sp.symbols('P1 P2 P3')
ok['S3.3_R_g']=sp.expand(rep(sp.diff(R,g))-(-2*g*P1))==0
ok['S3.3_R_gg']=sp.expand(rep(sp.diff(R,g,2))-(4*g**2*P2-2*P1))==0
ok['S3.3_R_ggg']=sp.expand(rep(sp.diff(R,g,3))-(-8*g**3*P3+12*g*P2))==0
# C derivatives: C = R(gamma(t)) gamma'(t)
T=sp.Symbol('T'); G=sp.Function('G')(T); Rf=sp.Function('Rf')
C=Rf(G)*sp.diff(G,T)
def rr(e):
    e=e.replace(lambda x: isinstance(x,sp.Subs), lambda x: sp.Symbol('R%d'%x.expr.args[1][1]))
    e=e.replace(lambda x: isinstance(x,sp.Derivative) and x.expr.func==Rf, lambda x: sp.Symbol('R%d'%sum(c for _,c in x.variable_count)))
    return e
g1,g2,g3,g4=[sp.diff(G,T,k) for k in (1,2,3,4)]
R1,R2,R3=sp.symbols('R1 R2 R3')
Ct=rr(sp.diff(C,T)); Ctt=rr(sp.diff(C,T,2)); Cttt=rr(sp.diff(C,T,3))
RR=Rf(G)
ok['S3.6_C_t']=sp.expand(Ct-(R1*g1**2+RR*g2))==0
ok['S3.6_C_tt']=sp.expand(Ctt-(R2*g1**3+3*R1*g1*g2+RR*g3))==0
ok['S3.6_C_ttt']=sp.expand(Cttt-(R3*g1**4+6*R2*g1**2*g2+3*R1*g2**2+4*R1*g1*g3+RR*g4))==0
# F_t chain: F_t = s[-mu a2 - 2 A C], with (a2)_t = -2C, A_t=-mu
Cs=sp.Function('Cf')(T); As=1-T*mu
Ft=s*(-mu*sp.Function('a2')(T)-2*As*Cs)
d1=sp.diff(Ft,T).subs(sp.Derivative(sp.Function('a2')(T),T),-2*Cs)
ok['S3.6_dF_t']=sp.simplify(d1-s*(4*mu*Cs-2*As*sp.diff(Cs,T)))==0
d2=sp.diff(s*(4*mu*Cs-2*As*sp.diff(Cs,T)),T); ok['S3.6_d2F_t']=sp.simplify(d2-s*(6*mu*sp.diff(Cs,T)-2*As*sp.diff(Cs,T,2)))==0
d3=sp.diff(s*(6*mu*sp.diff(Cs,T)-2*As*sp.diff(Cs,T,2)),T); ok['S3.6_d3F_t']=sp.simplify(d3-s*(8*mu*sp.diff(Cs,T,2)-2*As*sp.diff(Cs,T,3)))==0
# Lemma 16 constants
x,u,v=sp.symbols('x u v')
ok['L16_1/6']=sp.integrate(sp.integrate(u**2,(v,0,1)),(u,0,1))/2==sp.Rational(1,6) and sp.integrate(1-x**2,(x,0,1))/4==sp.Rational(1,6)
ok['L16_order_swap']=sp.simplify(sp.integrate(u*sp.Rational(1,1),(u,x,1))-(1-x**2)/2)==0
# constants
def box(lmin,lmax,tmax,umax,qmin,crit,Amax):
    L1=Fr(lmin)**2; Lmax=Fr(lmax)**2
    r={}
    r['q_min']=(L1*(1-tmax)**2==qmin)
    r['u_max']=((1-L1*(1-tmax))**2==umax) and umax<1   # (a + tmax L)^2 = (1 - L(1-tmax))^2 at lmin
    r['crit']=(tmax*Lmax/(1-Lmax)==crit) and crit<1
    r['A_max']=(1+tmax==Amax)
    return r
for name,args in {'C1c':(Fr(9,20),Fr(5,8),Fr(1,2),Fr(516961,640000),Fr(81,1600),Fr(25,78),Fr(3,2)),
                  'C0':(Fr(2,5),Fr(83,200),Fr(1,2),Fr(529,625),Fr(1,25),Fr(6889,66222),Fr(3,2)),
                  'C1d':(Fr(5,8),Fr(33,50),Fr(31,32),Fr(4092529,4194304),Fr(25,65536),Fr(33759,45152),Fr(63,32))}.items():
    for k,v in box(*args).items(): ok[f'{name}_{k}']=v
for k_,v in ok.items(): print(('PASS ' if v else 'FAIL ')+k_)
print('ALL_PASS',all(bool(v) for v in ok.values()))
