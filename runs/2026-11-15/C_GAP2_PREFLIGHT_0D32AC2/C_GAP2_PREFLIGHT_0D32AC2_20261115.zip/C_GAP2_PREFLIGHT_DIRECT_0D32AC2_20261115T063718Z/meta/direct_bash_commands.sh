#!/usr/bin/env bash
# C GAP2 NOT_EVIDENCE PREFLIGHT — DIRECT BASH COMMANDS
# Approved candidate 0d32ac2. NO C1b SEALED READ. NO RETRIES.
set -euo pipefail
REPO=/home/daybreak/GAP2_IMPL_V4R2_20261115
FAMILY=/home/daybreak/bg-spheroid-family
HEAD_PIN=0d32ac2a0325f41998adebf922a57ed50cf3ba59
FAMILY_PIN=9f16bd01c8a104e45ce9b1fad74491569cd46de6
B=runs/2026-10-12/C_GAP1_V0_5_RUN4
PY=/home/daybreak/.pyenv/versions/3.11.16/bin/python
OUT=/home/daybreak/C_GAP2_PREFLIGHT_DIRECT_0D32AC2_$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p "$OUT/logs" "$OUT/inputs" "$OUT/outputs" "$OUT/runs" "$OUT/meta"
cp "$0" "$OUT/meta/direct_bash_commands.sh"
printf 'START_UTC=%s\nHEAD_PIN=%s\nTYPE=NOT_EVIDENCE\n' "$(date -u +%FT%TZ)" "$HEAD_PIN" | tee "$OUT/meta/overview.txt"
"$PY" --version 2>&1 | tee "$OUT/meta/python_version.txt"
"$PY" -c 'import flint;print(flint.__version__)' 2>&1 | tee "$OUT/meta/python_flint_version.txt"
printf 'BASH_VERSION=%s\n' "$BASH_VERSION" | tee "$OUT/meta/bash_version.txt"

finish() {
  local code=$?
  trap - EXIT
  set +e
  printf 'END_UTC=%s\nEXIT_CODE=%s\n' "$(date -u +%FT%TZ)" "$code" >> "$OUT/meta/overview.txt"
  if [[ "$code" -eq 0 ]]; then echo 'PREFLIGHT_PASS_NOT_EVIDENCE' >> "$OUT/meta/overview.txt";
  else echo 'STOPPED_ON_FIRST_FAILURE_NOT_EVIDENCE' >> "$OUT/meta/overview.txt"; fi
  (cd "$OUT" && find . -type f ! -name SHA256SUMS.txt -print0 | sort -z | xargs -0 -r sha256sum > SHA256SUMS.txt)
  (cd /home/daybreak && zip -q -r "$OUT.zip" "$(basename "$OUT")")
  sha256sum "$OUT.zip" > "$OUT.zip.sha256"
  printf '\nOUTPUT_DIR=%s\nEVIDENCE_ZIP=%s\nZIP_SHA256=%s\nFINAL_EXIT=%s\n' "$OUT" "$OUT.zip" "$(cut -d' ' -f1 < "$OUT.zip.sha256")" "$code"
  exit "$code"
}
trap finish EXIT

pin() {
  local label=$1
  {
    printf 'STEP=%s UTC=%s\n' "$label" "$(date -u +%FT%TZ)"
    echo 'GIT_HEAD:'
    git -C "$REPO" rev-parse HEAD
    echo 'GIT_STATUS_PORCELAIN:'
    git -C "$REPO" status --porcelain
    echo '---'
  } | tee -a "$OUT/meta/pre_step_head_status.log"
  [[ "$(git -C "$REPO" rev-parse HEAD)" == "$HEAD_PIN" ]]
  [[ -z "$(git -C "$REPO" status --porcelain)" ]]
}

run_step() {
  local label=$1
  shift
  pin "$label"
  local stdout_log="$OUT/logs/$label.stdout"
  local stderr_log="$OUT/logs/$label.stderr"
  local fifo_o="$OUT/meta/$label.stdout.pipe"
  local fifo_e="$OUT/meta/$label.stderr.pipe"
  mkfifo "$fifo_o" "$fifo_e"
  tee "$stdout_log" < "$fifo_o" &
  local pid_o=$!
  tee "$stderr_log" < "$fifo_e" >&2 &
  local pid_e=$!
  local begin=$(date +%s)
  printf 'START %s %s COMMAND:' "$label" "$(date -u +%FT%TZ)" | tee -a "$OUT/meta/step_times.log"
  printf ' %q' "$@" | tee -a "$OUT/meta/step_times.log"
  printf '\n' | tee -a "$OUT/meta/step_times.log"
  local rc
  set +e
  "$@" > "$fifo_o" 2> "$fifo_e"
  rc=$?
  wait "$pid_o"
  local rc_o=$?
  wait "$pid_e"
  local rc_e=$?
  set -e
  rm -f "$fifo_o" "$fifo_e"
  printf 'END %s %s SECONDS=%s EXIT=%s TEE_EXIT=%s,%s\n' "$label" "$(date -u +%FT%TZ)" "$(( $(date +%s) - begin ))" "$rc" "$rc_o" "$rc_e" | tee -a "$OUT/meta/step_times.log"
  if [[ "$rc" -ne 0 || "$rc_o" -ne 0 || "$rc_e" -ne 0 ]]; then
    printf 'STOP_FIRST_FAILURE: %s exit=%s tee=%s,%s\n' "$label" "$rc" "$rc_o" "$rc_e" | tee -a "$OUT/meta/overview.txt"
    exit 5
  fi
}

cd "$REPO"
pin 00_preflight_start
echo '=== OTHER ACTIVE HEAVY MATH PROCESSES ===' | tee "$OUT/meta/process_check.txt"
ps -eo pid,ppid,stat,%cpu,args | grep -Ei 'd5_general|d5_plan|plan_b|b7_v5|b7_box|ftq_4096' | grep -vE '(grep -Ei|direct_bash_commands)' | tee -a "$OUT/meta/process_check.txt" || true

# Step 0: public run4 original from frozen family commit; SHA-256 verify before use
[[ "$(git -C "$FAMILY" rev-parse "$FAMILY_PIN")" == "$FAMILY_PIN" ]]
mkdir -p "$OUT/inputs/run4/producer" "$OUT/inputs/run4/checker"
git -C "$FAMILY" show "$FAMILY_PIN:$B/SHA256SUMS.txt" > "$OUT/inputs/SHA256SUMS_public.txt"
git -C "$FAMILY" show "$FAMILY_PIN:$B/run4/producer/ledger.jsonl" > "$OUT/inputs/run4/producer/ledger.jsonl"
git -C "$FAMILY" show "$FAMILY_PIN:$B/run4/checker/ledger.jsonl" > "$OUT/inputs/run4/checker/ledger.jsonl"
awk '$2=="./run4/producer/ledger.jsonl" || $2=="./run4/checker/ledger.jsonl" {print}' "$OUT/inputs/SHA256SUMS_public.txt" > "$OUT/inputs/SHA256SUMS_run4_ledgers.txt"
[[ "$(wc -l < "$OUT/inputs/SHA256SUMS_run4_ledgers.txt")" -eq 2 ]]
run_step 00_run4_input_SHA256 env RUN_DIR="$OUT/inputs" bash -c 'cd "$RUN_DIR";sha256sum -c SHA256SUMS_run4_ledgers.txt'
sha256sum "$OUT/inputs/run4/producer/ledger.jsonl" "$OUT/inputs/run4/checker/ledger.jsonl" > "$OUT/meta/public_run4_ledger_sha256.txt"

# Step 1: purely static
run_step 01_static_producer "$PY" -m gap2_producer.driver --static-preflight
run_step 02_static_checker "$PY" -m gap2_checker.driver --static-preflight

# Step 2: run4 regression, both lineages
run_step 03_run4_regression_producer "$PY" -m gap2_analysis.run4_regression --role producer --run4-ledger "$OUT/inputs/run4/producer/ledger.jsonl"
run_step 04_run4_regression_checker "$PY" -m gap2_analysis.run4_regression --role checker --run4-ledger "$OUT/inputs/run4/checker/ledger.jsonl"

# Step 3: synthetic variable-t_e gates
run_step 05_synthetic_producer "$PY" -m gap2_analysis.synthetic_preflight --role producer --output "$OUT/outputs/synthetic_producer.json"
run_step 06_synthetic_checker "$PY" -m gap2_analysis.synthetic_preflight --role checker --output "$OUT/outputs/synthetic_checker.json"
run_step 07_synthetic_compare "$PY" -m gap2_analysis.synthetic_preflight --compare --producer "$OUT/outputs/synthetic_producer.json" --checker "$OUT/outputs/synthetic_checker.json" --output "$OUT/outputs/synthetic_compare.json"

# Step 4: full real driver with two synthetic parents, successful and forced ABORT
run_step 08_end2end_producer "$PY" -m gap2_analysis.end_to_end_preflight --role producer --run-dir "$OUT/runs/producer_normal"
run_step 09_end2end_checker "$PY" -m gap2_analysis.end_to_end_preflight --role checker --run-dir "$OUT/runs/checker_normal"
run_step 10_end2end_producer_ABORT "$PY" -m gap2_analysis.end_to_end_preflight --role producer --force-abort --run-dir "$OUT/runs/producer_abort"
run_step 11_end2end_checker_ABORT "$PY" -m gap2_analysis.end_to_end_preflight --role checker --force-abort --run-dir "$OUT/runs/checker_abort"
run_step 12_end2end_compare "$PY" -m gap2_analysis.end_to_end_preflight --compare --producer-run "$OUT/runs/producer_normal" --checker-run "$OUT/runs/checker_normal" --output "$OUT/outputs/end2end_compare.json"
echo 'ALL_PRE-FREEZE_PREFLIGHT_STEPS_PASSED_NOT_EVIDENCE' | tee -a "$OUT/meta/overview.txt"
