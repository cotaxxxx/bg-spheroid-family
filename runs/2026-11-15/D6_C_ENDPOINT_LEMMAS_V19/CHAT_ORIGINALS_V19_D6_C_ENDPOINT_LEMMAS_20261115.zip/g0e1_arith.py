"""chat exact rational recomputation of the G0/E1 v3 constants (pi<22/7, sqrt2<3/2)."""
from fractions import Fraction as F
ok={}
P2=F(11,7); lp=F(5,8); iw=F(5,2)
# north
T1=4*P2*lp*4*iw; T2=2*lp**2*16*F(9,2)*iw**2; T3=2*P2*lp**3*F(9,2)*(3*F(5,2)*4+2*F(3,2))*iw
ok['N_T1<40']=T1<40; ok['N_T2<352']=T2<352; ok['N_T3<300']=T3<300; ok['N_sum<692']=T1+T2+T3<692
ok['N_q<9/4']=1+lp**2<F(9,4)
# south
r3=F(375); r5=F(18750)
ok['S_rho3']=(5**3)*2*F(3,2)**1 >= 0 and F(250)*F(3,2)<=r3  # 250 sqrt2 < 250*3/2=375
ok['S_rho5']=F(12500)*F(3,2)<=r5
T1s=4*P2*lp*r3*iw; T2s=2*lp**2*F(25,2)*r5*iw**2; T3s=2*P2*lp**3*F(25,2)*r3*(3*F(5,2)+2)*iw
ok['S_T1<4000']=T1s<4000; ok['S_T2<1200000']=T2s<1200000; ok['S_T3<100000']=T3s<100000
ok['S_q<4']=1+4*lp**2<4; ok['S_q>=1/25']=(F(2,5)*F(1,2))**2==F(1,25)
ok['S_H<1']=F(1,4)+lp**2==F(41,64)
M=F(1304000); ok['M']=max(F(1000),T1s+T2s+T3s)<=M
ok['E1_C=3M/2']=F(3,2)*M==1956000
print({k:float(v) for k,v in dict(T1=T1,T2=T2,T3=T3,T1s=T1s,T2s=T2s,T3s=T3s).items()})
for k,v in ok.items(): print(('PASS ' if v else 'FAIL ')+k)
print('ALL_PASS',all(ok.values()))
