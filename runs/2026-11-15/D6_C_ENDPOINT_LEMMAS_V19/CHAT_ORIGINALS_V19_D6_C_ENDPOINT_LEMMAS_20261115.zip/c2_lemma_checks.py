"""chat independent checks of MONOTONE_TUBE_C2_INTERCHANGE_LEMMA (blob 7cb9b809) §1-§4. sympy exact + mpmath numeric (diagnostic)."""
import sympy as sp, mpmath as mm, random
ok={}
s,lam,w,dl=sp.symbols('s lam w delta',positive=True)
t=1-dl; mu=1-s**2; d=t-mu; A=1-t*mu; q=s**2*(2-s**2)+lam**2*d**2
H=(1-s**2)*(2-s**2)+lam**2*(2*s**2-2*dl-s**4+dl*s**2)
N=-mu*q-A*lam**2*d
ok['S1_N=-s^2H']=sp.expand(N+s**2*H)==0
T=sp.Symbol('T'); # differentiate in t = 1-delta  => d/dt = -d/d delta
Nt=-sp.diff(N,dl)
ok['S2_N_t']=sp.expand(Nt-(-lam**2*s**2*(2-s**2)))==0
gt=lam*N/(w*q**sp.Rational(3,2)); gtt=-sp.diff(gt,dl)
ok['S2_gamma_tt']=sp.simplify(gtt-lam**3*s**2*(3*d*H-(2-s**2)*q)/(w*q**sp.Rational(5,2)))==0
# G_t from differentiating F_t = s[-mu alpha^2 - 2 A R gamma_t] with alpha^2' = -2 R gamma_t, R' = R_g gamma_t
R,Rg,g1,g2=sp.symbols('R R_g g1 g2')
At=-sp.diff(A,dl)
Gt_formal=s*(-mu*(-2*R*g1) - 2*At*R*g1 - 2*A*(Rg*g1*g1) - 2*A*R*g2)
ok['S2_G_t']=sp.expand(Gt_formal-s*(4*mu*R*g1-2*A*(Rg*g1**2+R*g2)))==0
# §3 scaled identity
rho=s/sp.sqrt(q); phi=d/sp.sqrt(q); Ah=A/sp.sqrt(q)
ok['S3_constraint']=sp.simplify(rho**2*(2-s**2)+lam**2*phi**2-1)==0
ok['S3_Ahat']=sp.simplify(Ah-((2-s**2)*s*rho-(1-s**2)*phi))==0
T1=-4*(1-s**2)*R*lam*rho**3*H/w; T2=-2*Rg*lam**2*H**2*Ah*rho**5/w**2; T3=-2*R*lam**3*Ah*rho**3*(3*phi*H-(2-s**2)*sp.sqrt(q))/w
Gt=s*(4*mu*R*gt-2*A*(Rg*gt**2+R*gtt))
ok['S3_T1+T2+T3=G_t']=sp.simplify(Gt-(T1+T2+T3))==0
# R_gamma formula
gg=sp.Symbol('gamma',positive=True); Rf=sp.acos(gg)/sp.sqrt(1-gg**2)
ok['S2_R_gamma']=sp.simplify(sp.diff(Rf,gg)-(gg*Rf-1)/(1-gg**2))==0
# §4 constants (just evaluate the coarse bounds)
lm,lp=sp.Rational(5,8),sp.Rational(33,50)
MN=4*(sp.pi/2)*lp*4/lm+2*lp**2*16*(2+1/lm)/lm**2+2*(sp.pi/2)*lp**3*(2+1/lm)*(12/lm+2*sp.sqrt(2))/lm
print('M_N =',sp.N(MN,10))
# numeric DIAGNOSTIC: d/dt int F_t = int G_t, and |G_t| <= M_N on north half
mm.mp.dps=30
def vals(tv,lv,sv):
    muv=1-sv*sv; Av=1-tv*muv; dv=tv-muv; qv=sv*sv*(2-sv*sv)+lv*lv*dv*dv; wv=mm.sqrt(lv*lv*(1-muv*muv)+muv*muv)
    g=min(lv*Av/(wv*mm.sqrt(qv)),mm.mpf(1)); al=mm.acos(g); u=1-g*g
    Rv=al/mm.sin(al) if u>mm.mpf('1e-20') else 1+u/6
    Rgv=(g*Rv-1)/u if u>mm.mpf('1e-12') else -mm.mpf(1)/3
    Hv=(1-sv*sv)*(2-sv*sv)+lv*lv*(2*sv*sv-2*(1-tv)-sv**4+(1-tv)*sv*sv)
    gtv=lv*(-sv*sv*Hv)/(wv*qv**1.5); gttv=lv**3*sv*sv*(3*dv*Hv-(2-sv*sv)*qv)/(wv*qv**2.5)
    Ft=sv*(-muv*al**2-2*Av*Rv*gtv); Gt=sv*(4*muv*Rv*gtv-2*Av*(Rgv*gtv**2+Rv*gttv))
    return Ft,Gt
errs=[]
for tv,lv in [(mm.mpf(63)/64+mm.mpf('0.001'),mm.mpf('0.63')),(mm.mpf('0.999'),mm.mpf('0.65')),(mm.mpf('0.7'),mm.mpf('0.5'))]:
    h=mm.mpf('1e-7')
    fd=(mm.quad(lambda sv: vals(tv+h,lv,sv)[0],[0,1,mm.sqrt(2)])-mm.quad(lambda sv: vals(tv-h,lv,sv)[0],[0,1,mm.sqrt(2)]))/(2*h)
    it=mm.quad(lambda sv: vals(tv,lv,sv)[1],[0,mm.mpf('0.01'),1,mm.sqrt(2)])
    errs.append(abs(fd-it)); print('t',mm.nstr(tv,6),'lam',lv,'FD',mm.nstr(fd,12),'int G_t',mm.nstr(it,12))
ok['S6_numeric d/dt g = int G_t (DIAGNOSTIC)']=max(errs)<1e-6
random.seed(7); worst=0
for _ in range(400):
    tv=mm.mpf(63)/64+mm.mpf(random.random())/64*mm.mpf('0.999999'); lv=mm.mpf(random.uniform(0.625,0.66)); sv=mm.mpf(random.random())
    worst=max(worst,abs(vals(tv,lv,sv)[1]))
print('DIAGNOSTIC max |G_t| north half (400 pts) =',mm.nstr(worst,6),' M_N =',sp.N(MN,6))
ok['S4_north_majorant (DIAGNOSTIC)']=worst<float(MN)
for k_,v in ok.items(): print(('PASS ' if v else 'FAIL ')+k_)
print('ALL_PASS',all(bool(v) for v in ok.values()))
