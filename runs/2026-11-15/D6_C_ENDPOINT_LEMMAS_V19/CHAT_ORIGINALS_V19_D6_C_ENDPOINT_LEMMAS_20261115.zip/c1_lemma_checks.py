"""chat independent checks of OBLATE_ENDPOINT_C1_LEMMA (blob 5afa815f). sympy exact identities + mpmath numeric (diagnostic) checks."""
import sympy as sp, mpmath as mm, random
ok={}
s,t,lam,mu,x,dl,e=sp.symbols('s t lam mu x delta e',real=True)
a=1-lam**2
# §1 substitution
A_mu=1-t*mu; q_mu=1-mu**2+lam**2*(mu-t)**2
sub={mu:1-s**2, t:1-dl}
A=sp.expand(A_mu.subs(sub)); q=sp.expand(q_mu.subs(sub)); d=s**2-dl
ok['S1_A']=sp.expand(A-(dl+(1-dl)*s**2))==0
ok['S1_q']=sp.expand(q-(s**2*(2-s**2)+lam**2*d**2))==0
# gamma_t and N
w=sp.Symbol('w',positive=True)
gam=lam*A_mu/(w*sp.sqrt(q_mu))
gt=sp.diff(gam,t)
N=-mu*q_mu-lam**2*A_mu*(t-mu)
ok['S1_gamma_t']=sp.simplify(gt-lam*N/(w*q_mu**sp.Rational(3,2)))==0
# Lemma 1 (i)
H=(1-x)*(2-x)+lam**2*(2-x)*(x-dl)
ok['L1i_N=-s^2H']=sp.expand(N.subs(sub).subs(s**2,x) if False else sp.expand(N.subs(sub))-(-s**2*H.subs(x,s**2)))==0
# Lemma 1 (iii)
w2=lam**2*(1-mu**2)+mu**2
ok['L1iii_1-gamma^2']=sp.simplify((1-lam**2*A_mu**2/(w2*q_mu))-(1-mu**2)*((1-lam**2)*mu+lam**2*t)**2/(w2*q_mu))==0
# §4 endpoint algebra (delta=0)
qh=2-a*s**2; w2s=sp.expand(w2.subs(mu,1-s**2))
ok['S4_q=s^2 qhat']=sp.expand(q.subs(dl,0)-s**2*qh)==0
ok['S4_w2']=sp.expand(w2s-(1-2*a*s**2+a*s**4))==0
ok['S4_id1']=sp.expand((1-s**2)*qh+lam**2*s**2-(2-s**2)*(1-a*s**2))==0
ok['S4_id2']=sp.expand(w2s*qh-lam**2*s**2-(2-s**2)*(1-a*s**2)**2)==0
Hend=H.subs({dl:0,x:s**2})
sp_pos=sp.Symbol('s',positive=True)
ok['S4_A_gamma_t']=sp.simplify((s**2*lam*(-s**2*Hend)/(w*(s**2*qh)**sp.Rational(3,2)) - (-lam*s*(2-s**2)*(1-a*s**2)/(w*qh**sp.Rational(3,2)))).subs(s,sp_pos))==0
ok['S4_qhat>=2lam^2']=sp.expand(qh.subs(s**2,2)-2*lam**2)==0
# Lemma 4 (i): h(e)=(2-e)(1-a e)^2/e, numerator of h'
h=(2-e)*(1-a*e)**2/e
num=sp.factor(sp.together(sp.diff(h,e))*e**2)
ok['L4i_h_prime_numerator']=sp.expand(num-(-(1-a*e)*(2+2*a*e*(1-e))))==0
ok['L4i_h(1)=lam^4']=sp.expand(h.subs(e,1)-lam**4)==0
# numeric (DIAGNOSTIC): Lemma 3 representation, Lemma 5 limit, Lemma 2 majorant
mm.mp.dps=30
def parts(tv,lv,sv):
    muv=1-sv*sv; Av=1-tv*muv; qv=1-muv*muv+lv*lv*(muv-tv)**2; wv=mm.sqrt(lv*lv*(1-muv*muv)+muv*muv)
    g=lv*Av/(wv*mm.sqrt(qv)); g=min(g,mm.mpf(1))
    al=mm.acos(g); R=al/mm.sin(al) if al>0 else mm.mpf(1)
    Nv=-muv*qv-lv*lv*Av*(tv-muv); gtv=lv*Nv/(wv*qv**1.5)
    return Av,al,R,gtv,muv
def E(tv,lv): return mm.quad(lambda sv: sv*parts(tv,lv,sv)[0]*parts(tv,lv,sv)[1]**2,[0,1,mm.sqrt(2)])
def Ft(tv,lv,sv):
    Av,al,R,gtv,muv=parts(tv,lv,sv); return sv*(-muv*al**2-2*Av*R*gtv)
def Fob(lv,sv):
    av=1-lv*lv; qh=2-av*sv*sv; w2=1-2*av*sv*sv+av*sv**4; wv=mm.sqrt(w2); u=(2-sv*sv)*(1-av*sv*sv)**2/(w2*qh)
    Phi=mm.asin(mm.sqrt(u))**2; Psi=mm.asin(mm.sqrt(u))/mm.sqrt(u) if u>0 else mm.mpf(1)
    return -sv*(1-sv*sv)*Phi+2*lv*sv*sv*(2-sv*sv)*(1-av*sv*sv)*Psi/(wv*qh**1.5)
errs=[]
for tv,lv in [(0.6,0.45),(0.9,0.55),(0.97,0.62)]:
    tv=mm.mpf(tv); lv=mm.mpf(lv); hh=mm.mpf('1e-6')
    fd=(E(tv+hh,lv)-E(tv-hh,lv))/(2*hh); it=mm.quad(lambda sv: Ft(tv,lv,sv),[0,1,mm.sqrt(2)])
    errs.append(abs(fd-it))
ok['L3_numeric dE/dt = int F_t (3 pts, DIAGNOSTIC)']=max(errs)<1e-8
lims=[]
for lv in [0.45,0.6]:
    lv=mm.mpf(lv); Bob=mm.quad(lambda sv: Fob(lv,sv),[0,1,mm.sqrt(2)])
    near=mm.quad(lambda sv: Ft(1-mm.mpf('1e-7'),lv,sv),[0,mm.mpf('1e-3'),1,mm.sqrt(2)])
    lims.append(abs(Bob-near)); print('lam',lv,'B_ob',mm.nstr(Bob,12),'int F_t at t=1-1e-7',mm.nstr(near,12))
ok['L5_numeric limit (DIAGNOSTIC)']=max(lims)<1e-4
random.seed(5); worst=0
lm,lp=mm.mpf(2)/5,mm.mpf(5)/8
for _ in range(400):
    tv=mm.mpf(random.uniform(0.5,0.999999)); lv=mm.mpf(random.uniform(0.4,0.625)); sv=mm.mpf(random.uniform(0,1.41421))
    if sv<=1: M=(mm.pi**2/4)*sv+mm.pi*sv*(lp/lm)*4*(2/(3*mm.sqrt(3)*lm)+2*sv)
    else: M=(mm.pi**2/4)*sv+mm.pi*sv*32*lp/lm**4
    worst=max(worst,abs(Ft(tv,lv,sv))/M)
print('DIAGNOSTIC max |F_t|/M over 400 random points =',mm.nstr(worst,5))
ok['L2_majorant (400 random pts, DIAGNOSTIC)']=worst<1
for k_,v in ok.items(): print(('PASS ' if v else 'FAIL ')+k_)
print('ALL_PASS',all(bool(v) for v in ok.values()))
