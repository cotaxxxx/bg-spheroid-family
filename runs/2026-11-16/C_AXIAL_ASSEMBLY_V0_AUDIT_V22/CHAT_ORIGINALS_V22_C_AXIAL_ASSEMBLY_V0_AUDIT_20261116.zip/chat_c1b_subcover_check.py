#!/usr/bin/env python3
"""chat independent check of the C1b per-slab t sub-cover on (1/2, 31/32] (sealed ledgers).
For every ACCEPT slab [l0,l1] (both lineages):
  left exterior : true L / L_MONO boxes cover [l0,l1] x [1/2, t_minus]      (g > 0)
  left wall     : true LEFT points at t_minus cover [l0,l1]                 (g(t_minus) > 0)
  tube          : true GT boxes + corner boxes cover [l0,l1] x [t_minus, t_plus]  (G_t < 0)
  right wall    : unclamped: true RIGHT points at t_plus cover [l0,l1]      (g(t_plus) < 0)
  right exterior: unclamped, t_plus < 31/32: true R / R_MONO cover [t_plus, 31/32] (g < 0)
  clamped       : t_plus = 1 (wall = B_ob < 0 from the B_ob subgate)
Usage: python3 -I chat_c1b_subcover_check.py <sealed_root>
"""
import json, sys, collections
from fractions import Fraction as F
TMID, HALF = F(31, 32), F(1, 2)
def cover(ll, lr, t0, t1, boxes):
    if t0 >= t1: return True
    xs = sorted({ll, lr} | {b[2] for b in boxes} | {b[3] for b in boxes}); xs = [x for x in xs if ll <= x <= lr]
    for a, b in zip(xs, xs[1:]):
        reach = t0
        for p, q in sorted((p, q) for p, q, l0, l1 in boxes if l0 <= a and b <= l1):
            if p > reach: break
            reach = max(reach, q)
        if reach < t1: return False
    return True
def lcover(ll, lr, ivs):
    reach = ll
    for a, b in sorted(ivs):
        if a > reach: return False
        reach = max(reach, b)
    return reach >= lr
root = sys.argv[1]; allok = True
for ph in ('phase1_v212s_seal_20260918T222551Z', 'phase2_v212s_seal_20260920T140743Z'):
    L = [json.loads(l) for l in open(f'{root}/{ph}/ledger.jsonl', 'rb').read().splitlines()]
    acc = [r['payload'] for r in L if r['record_type'] == 'slab_record' and r['payload']['decision'] == 'ACCEPT']
    bad = collections.Counter(); n = collections.Counter()
    for p in acc:
        res = p['result']; ll, lr = F(p['lambda_lo']), F(p['lambda_hi']); tm, tp = F(res['t_minus']), F(res['t_plus'])
        gs = res['tube_guards'] + res['exterior_guards']
        box = lambda ks: [(F(g['t_lo']), F(g['t_hi']), F(g['lambda_lo']), F(g['lambda_hi'])) for g in gs if g['kind'] in ks and g['truth'] is True]
        pts = lambda k, t: [(F(g['lambda_lo']), F(g['lambda_hi'])) for g in gs if g['kind'] == k and g['truth'] is True and F(g['t_lo']) == F(g['t_hi']) == t]
        bad['t_minus<1/2 or t_minus>=t_plus'] += not (HALF <= tm < tp)
        bad['left_exterior'] += not cover(ll, lr, HALF, tm, box(('L', 'L_MONO')))
        bad['left_wall'] += not lcover(ll, lr, pts('LEFT', tm))
        bad['tube'] += not cover(ll, lr, tm, tp, box(('GT',)) + [tuple(map(F, c)) for c in res['corner_boxes']])
        if res['right_clamp']:
            n['clamped'] += 1; bad['clamped_t_plus!=1'] += tp != 1
        else:
            n['unclamped'] += 1
            bad['right_wall'] += not lcover(ll, lr, pts('RIGHT', tp))
            if tp < TMID:
                n['right_exterior_needed'] += 1
                bad['right_exterior'] += not cover(ll, lr, tp, TMID, box(('R', 'R_MONO')))
    ok = len(acc) == 159 and sum(bad.values()) == 0
    allok &= ok
    print(('PASS ' if ok else 'FAIL ') + ph[:6], 'accepted', len(acc), dict(n), 'failures', {k: v for k, v in bad.items() if v} or 0)
print('SUMMARY', 'ALL_PASS' if allok else 'FAIL'); sys.exit(0 if allok else 1)
