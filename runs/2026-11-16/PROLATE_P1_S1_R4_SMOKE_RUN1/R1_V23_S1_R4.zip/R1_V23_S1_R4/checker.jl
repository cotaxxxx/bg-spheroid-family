# Independent rational-only S1 smoke ledger checker. NO CERTIFICATION.
module R1CheckerS1
using SHA
const Rat=Rational{BigInt}
R(a::Integer,b::Integer=1)=BigInt(a)//BigInt(b)
struct BadLedger <: Exception
    msg::String
end
Base.showerror(io::IO,e::BadLedger)=print(io,"CERTIFICATE_FAILED: ",e.msg)
req(x,msg)=x || throw(BadLedger(msg))
function parseR(s)::Rat
    p=split(s,'/');req(length(p)==2,"fraction syntax")
    a=parse(BigInt,p[1]);b=parse(BigInt,p[2]);req(b>0,"denominator")
    a//b
end
function pair(s)
    p=split(s,',');req(length(p)==2,"interval syntax")
    a,b=parseR.(p);req(a<=b,"interval reversed");(a,b)
end
function atan_bounds(q,N)
    s=R(0);x=R(1,q)
    for k in 0:N
        t=x^(2*k+1)/BigInt(2*k+1)
        s+=iseven(k) ? t : -t
    end
    e=x^(2*N+3)/BigInt(2*N+3)
    iseven(N) ? (s-e,s) : (s,s+e)
end
function pi_bounds(N)
    a=atan_bounds(5,N);b=atan_bounds(239,N)
    (16*a[1]-4*b[2],16*a[2]-4*b[1])
end
function sum_interval(a,b)
    (a[1]+b[1],a[2]+b[2])
end
function multiply(a,b)
    vals=(a[1]*b[1],a[1]*b[2],a[2]*b[1],a[2]*b[2])
    (minimum(vals),maximum(vals))
end
function cell_from_rationals(cs,cn,ul,uh,vl,vh)
    n=length(cs)-1
    req(n>=0&&ul<uh&&vl<vh,"cell geometry")
    h=(uh-ul)/R(2)
    B=factorial(big(n+1))*max(abs(cn[1]),abs(cn[2]))
    s=(R(0),R(0))
    for j in 0:n
        if iseven(j)
            f=R(2)*h^(j+1)/BigInt(j+1)
            s=sum_interval(s,multiply(cs[j+1],(f,f)))
        end
    end
    rem=R(2)*B*h^(n+2)/factorial(big(n+2))
    (B,rem,multiply((s[1]-rem,s[2]+rem),(vh-vl,vh-vl)))
end
function check_rectangles(rects)
    xs=sort(unique(vcat([R(0),R(1)], [r[1] for r in rects],[r[2] for r in rects])))
    ys=sort(unique(vcat([R(0),R(1)], [r[3] for r in rects],[r[4] for r in rects])))
    req(first(xs)==R(0)&&last(xs)==R(1)&&first(ys)==R(0)&&last(ys)==R(1),"outside domain")
    for i in 1:length(xs)-1,j in 1:length(ys)-1
        a,b=xs[i],xs[i+1];c,d=ys[j],ys[j+1]
        req(count(r->r[1]<=a&&b<=r[2]&&r[3]<=c&&d<=r[4],rects)==1,"overlap/gap")
    end
end
# Tier gate calculations are deliberately diagnostic only, never PASS/CERTIFIED.
function diagnostic_gate(x,op,threshold)
    op==">" && return x[1]>threshold
    op=="<" && return x[2]<threshold
    op==">=" && return x[1]>=threshold
    throw(BadLedger("unknown comparison"))
end
function check_s1_ledger(path::String)
    lines=readlines(path);req(length(lines)>=4,"short ledger")
    header=split(lines[1],'\t');req(length(header)==10&&header[1]=="S1R4","header")
    nu,nv,n,K,piN=parse.(Int,header[2:6]);req(nu>0&&nv>0&&n>=0&&K>=1&&piN>=0,"settings")
    L,H=parseR.(header[7:8]);req(R(47,10)<=L<=H<=R(19,4),"lambda")
    req((parseR(header[9]),parseR(header[10]))==pi_bounds(piN),"pi bounds")
    rects=NTuple{4,Rat}[];seen=Set{Tuple{Int,Int}}();total=(R(0),R(0));count=0
    for line in lines[2:end-2]
        f=split(line,'\t');req(length(f)==12+n&&f[1]=="CELL","cell columns")
        i,j=parse.(Int,f[2:3]);req(0<=i<nu&&0<=j<nv,"cell indices")
        req(!((i,j) in seen),"duplicate cell");push!(seen,(i,j))
        ul,uh,vl,vh=parseR.(f[4:7]);req((ul,uh,vl,vh)==(R(i,nu),R(i+1,nu),R(j,nv),R(j+1,nv)),"mesh")
        push!(rects,(ul,uh,vl,vh))
        cn=pair(f[8]);B=parseR(f[9]);rem=parseR(f[10]);claim=pair(f[11]);cs=pair.(f[12:end])
        b,r,val=cell_from_rationals(cs,cn,ul,uh,vl,vh)
        req((b,r,val)==(B,rem,claim),"cell Taylor mismatch")
        total=sum_interval(total,val);count+=1
    end
    req(count==nu*nv,"missing cells");check_rectangles(rects)
    last=split(lines[end-1],'\t');req(length(last)==2&&last[1]=="TOTAL","total syntax")
    req(pair(last[2])==total,"total mismatch")
    req(lines[end]=="STATUS\tSMOKE_ONLY_NOT_CERTIFIED","status")
    println("LEDGER_ARITHMETIC_OK (not I3): ",path," cells=",count)
    println("Q enclosure rational = ",total," ; NOT_CERTIFIED")
    total
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    try
        length(ARGS)==1||error("usage: julia checker.jl ledger.tsv")
        R1CheckerS1.check_s1_ledger(ARGS[1])
    catch e
        showerror(stderr,e);println(stderr);exit(2)
    end
end
