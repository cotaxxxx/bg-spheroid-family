# S1 R4 candidate. R1 SHA 1e53f74e2ba09bd9cf7207ed0ef153dd9e3a63b252185191153be75cea212241
# NOT_FROZEN / NO_CERTIFICATION_RUN. Only smoke enclosure, no sign certification.
module R1ProducerS1
using IntervalArithmetic, SHA
const Rat=Rational{BigInt}
R(a::Integer,b::Integer=1)=BigInt(a)//BigInt(b)
const BITS=256
struct StopS1 <: Exception
    code::String
    reason::String
end
Base.showerror(io::IO,e::StopS1)=print(io,e.code,": ",e.reason)
stop(c,s)=throw(StopS1(c,s))
function check(x)
    typeof(x)===Interval{BigFloat} || stop("GUARANTEE_FAILED","type $(typeof(x))")
    isguaranteed(x)===true || stop("GUARANTEE_FAILED","unguaranteed")
    a,b=inf(x),sup(x)
    (isfinite(a)&&isfinite(b)&&a<=b) || stop("GUARANTEE_FAILED","invalid interval")
    (precision(a)>=BITS && precision(b)>=BITS) || stop("GUARANTEE_FAILED","precision")
    x
end
iv(x::Rat)=check(interval(BigFloat,x))
function range(a::Rat,b::Rat)
    a<=b || stop("CERTIFICATE_FAILED","reversed")
    check(hull(iv(a),iv(b)))
end
plus(a,b)=check(a+b)
minus(a,b)=check(a-b)
times(a,b)=check(a*b)
divide(a,b)=(in_interval(0,b)&&stop("GUARANTEE_FAILED","zero divisor");check(a/b))
sqrtiv(a)=(inf(a)>0||stop("GUARANTEE_FAILED","sqrt domain");check(sqrt(a)))
function atanbounds(q::Int,N::Int)
    s=R(0);x=R(1,q)
    for k in 0:N
        term=x^(2*k+1)/BigInt(2*k+1)
        s+=iseven(k) ? term : -term
    end
    rem=x^(2*N+3)/BigInt(2*N+3)
    iseven(N) ? (s-rem,s) : (s,s+rem)
end
function pibounds(N::Int)
    a,b=atanbounds(5,N),atanbounds(239,N)
    (16*a[1]-4*b[2],16*a[2]-4*b[1])
end
struct Jet
    c::Vector{Interval{BigFloat}}
    function Jet(c::Vector{Interval{BigFloat}})
        isempty(c)&&stop("CERTIFICATE_FAILED","empty jet")
        foreach(check,c);new(c)
    end
end
ord(a::Jet)=length(a.c)-1
function constant(x,n::Int)
    Jet([i==1 ? check(x) : iv(R(0)) for i in 1:n+1])
end
constant(x::Rat,n::Int)=constant(iv(x),n)
function varjet(x,n::Int)
    n>=1||stop("CERTIFICATE_FAILED","order")
    a=constant(x,n).c;a[2]=iv(R(1));Jet(a)
end
function compatible(a,b)
    ord(a)==ord(b)||stop("CERTIFICATE_FAILED","jet order")
end
Base.:+(a::Jet,b::Jet)=(compatible(a,b);Jet([plus(x,y) for (x,y) in zip(a.c,b.c)]))
Base.:-(a::Jet,b::Jet)=(compatible(a,b);Jet([minus(x,y) for (x,y) in zip(a.c,b.c)]))
Base.:-(a::Jet)=Jet([check(-x) for x in a.c])
function Base.:*(a::Jet,b::Jet)
    compatible(a,b);n=ord(a);v=Interval{BigFloat}[]
    for k in 0:n
        s=iv(R(0))
        for j in 0:k
            s=plus(s,times(a.c[j+1],b.c[k-j+1]))
        end
        push!(v,s)
    end
    Jet(v)
end
function invjet(a::Jet)
    in_interval(0,a.c[1])&&stop("GUARANTEE_FAILED","inverse constant zero")
    n=ord(a);v=Vector{Interval{BigFloat}}(undef,n+1)
    v[1]=divide(iv(R(1)),a.c[1])
    for k in 1:n
        s=iv(R(0))
        for j in 1:k
            s=plus(s,times(a.c[j+1],v[k-j+1]))
        end
        v[k+1]=divide(check(-s),a.c[1])
    end
    Jet(v)
end
Base.:/(a::Jet,b::Jet)=a*invjet(b)
function sqrtjet(a::Jet)
    inf(a.c[1])>0||stop("GUARANTEE_FAILED","sqrt constant")
    n=ord(a);v=Vector{Interval{BigFloat}}(undef,n+1)
    v[1]=sqrtiv(a.c[1]);two=iv(R(2))
    for k in 1:n
        s=iv(R(0))
        for j in 1:k-1
            s=plus(s,times(v[j+1],v[k-j+1]))
        end
        v[k+1]=divide(minus(a.c[k+1],s),times(two,v[1]))
    end
    Jet(v)
end
# Differential identities sin'=cos*f', cos'=-sin*f'. Coefficients enclose
# derivatives at all allowed constant interval inputs; I3 must audit IA trig.
function sincosjet(f::Jet)
    n=ord(f);s=Vector{Interval{BigFloat}}(undef,n+1);c=similar(s)
    s[1]=check(sin(f.c[1]));c[1]=check(cos(f.c[1]))
    for k in 1:n
        ss=iv(R(0));cc=iv(R(0))
        for j in 1:k
            factor=iv(R(j,k))
            ss=plus(ss,times(factor,times(f.c[j+1],c[k-j+1])))
            cc=minus(cc,times(factor,times(f.c[j+1],s[k-j+1])))
        end
        s[k+1]=ss;c[k+1]=cc
    end
    Jet(s),Jet(c)
end
# A(1-x)=sum_{k>=1} a_k x^k; a_1=2, a_{k+1}=a_k*k^2/((k+1)(2k+1)).
# d^d A/dc^d=(-1)^d sum_{k>=d} (k)_d a_k x^(k-d).
# Coefficient tail: for |t|<=rho, |x(t)|<=q<1, a_k<=2,
# |sum_{k>K} (k)_d a_k x(t)^(k-d)| <= 2 sum_{k>K} k^d q^(k-d).
# Cauchy then bounds each omitted t^j coefficient by tail/rho^j.
# The finite polynomial is evaluated by interval convolutions. I3 OPEN:
# proof of complex-disk majorant, IA transcendental enclosure, and all bounds.
function aseries_derivative(x::Jet,d::Int;K::Int=128,rho::Rat=R(1,64))
    n=ord(x);d in 0:2||stop("CERTIFICATE_FAILED","A derivative")
    # Rational upper bounds on coefficient magnitudes; avoid trusting a point value.
    q=R(0)
    for j in 0:n
        a,b=Rat(inf(x.c[j+1])),Rat(sup(x.c[j+1]))
        q+=max(abs(a),abs(b))*rho^j
    end
    q<R(1)||stop("ENDPOINT_REGULARITY_OPEN","series disk |1-c| >= 1")
    K>=d||stop("CERTIFICATE_FAILED","K")
    coeff=R(2);power=constant(R(1),n);out=constant(R(0),n)
    # power tracks x^(k-d), initialized at k=d below
    # polynomial in x, including d=0 (constant term k=0 is zero)
    if d==0
        power=x
    end
    for k in 1:K
        if k==d
            power=constant(R(1),n)
        elseif k>d
            power=power*x
        end
        if k>=d
            factor=coeff*prod(BigInt(k-j) for j in 0:d-1)*(iseven(d) ? R(1) : R(-1))
            out=out+constant(factor,n)*power
        end
        coeff*=R(k*k,(k+1)*(2*k+1))
    end
    # Tail sum via ratio bound k^d q^(k-d). For k>=K+1,
    # ratio <= q*((K+2)/(K+1))^d; exact rational.
    k=K+1
    ratio=q*R((K+2)^d,(K+1)^d)
    ratio<R(1)||stop("ENDPOINT_REGULARITY_OPEN","tail ratio")
    tail=R(2)*BigInt(k)^d*q^(k-d)/(R(1)-ratio)
    vals=Interval{BigFloat}[]
    for j in 0:n
        e=iv(tail/rho^j)
        push!(vals,plus(out.c[j+1],range(-tail/rho^j,tail/rho^j)))
    end
    Jet(vals)
end
# Return A, A', A'' as interval jets. Series is used even away from c=1:
# it is the analytic continuation from R1 §3 and avoids unstable 0/0.
# Switching rule: when disk q<1 use series; otherwise stop OPEN (no unsafe acos).
function Ajet(c::Jet;K::Int=128)
    x=constant(R(1),ord(c))-c
    (aseries_derivative(x,0;K=K),aseries_derivative(x,1;K=K),aseries_derivative(x,2;K=K))
end
# Smooth angular variables: w=cos(pi*u), phi=2*pi*v, Jacobian
# |dw dphi|=2*pi^2*sin(pi*u) du dv; prefactor Q = pi/2.
# R1 G2(beta,gamma) with beta=gamma=sin(pi*u)*cos(2*pi*v).
function qintegrand(U::Jet,V,lambda::Jet,piI;K::Int=128)
    n=ord(U);p=constant(piI,n)
    su,cu=sincosjet(p*U)
    _,cv=sincosjet(constant(times(iv(R(2)),times(piI,V)),n))
    beta=su*cv;w=cu
    one=constant(R(1),n)
    S=one+(lambda*lambda-one)*(w*w)
    ni=sqrtjet(one-w*w+(w*w)/(lambda*lambda))
    c0=one/(ni*sqrtjet(S))
    A,A1,A2=Ajet(c0;K=K)
    c1=(beta/S-beta)*c0
    c2=(-one/S+constant(R(3),n)*beta*beta/(S*S)-constant(R(2),n)*beta*beta/S)*c0
    G=A2*c1*c1+A1*c2-constant(R(2),n)*beta*A1*c1
    G*su*constant(divide(piI,iv(R(2))),n)
end
# NOTE: c1 and c2 must follow R1: gamma=beta, c1=(gamma/S-beta)*c0,
# c2=(-1/S+3 gamma^2/S^2-2 beta gamma/S)*c0.
# Center jet yields Taylor coefficients, whole-cell jet gives derivative B.
function rational_interval(x)
    check(x)
    (Rat(inf(x)),Rat(sup(x)))
end
fmt(x::Rat)=string(numerator(x),"/",denominator(x))
fmtpair(x)=fmt(x[1])*","*fmt(x[2])
function integrate_cell(ulo::Rat,uhi::Rat,vlo::Rat,vhi::Rat,L::Rat,H::Rat,piI,n::Int,K::Int)
    m=(ulo+uhi)/R(2);h=(uhi-ulo)/R(2)
    v=range(vlo,vhi);lam=constant(range(L,H),n+1)
    center=qintegrand(varjet(iv(m),n+1),v,lam,piI;K=K)
    whole=qintegrand(varjet(range(ulo,uhi),n+1),v,lam,piI;K=K)
    # interval-jet coefficient of order n+1 over the entire cell
    # encloses h^(n+1)/(n+1)! if every primitive jet rule is sound.
    cn=rational_interval(whole.c[n+2]);B=factorial(big(n+1))*max(abs(cn[1]),abs(cn[2]))
    s=(R(0),R(0))
    coeff=[]
    for j in 0:n
        cj=rational_interval(center.c[j+1]);push!(coeff,cj)
        if iseven(j)
            a=R(2)*h^(j+1)/BigInt(j+1)
            s=(s[1]+cj[1]*a,s[2]+cj[2]*a)
        end
    end
    rem=R(2)*B*h^(n+2)/factorial(big(n+2))
    value=((s[1]-rem)*(vhi-vlo),(s[2]+rem)*(vhi-vlo))
    (coeff,cn,B,rem,value)
end
# Ledger TSV: canonical rational strings; all cell data are independently
# recomputed by checker, which does not trust producer claims or PASS strings.
function run_s1_smoke(lambda_lo::Rat,lambda_hi::Rat;
        path::String="s1_ledger.tsv",nu::Int=4,nv::Int=4,n::Int=2,K::Int=128,piN::Int=80)
    R(47,10)<=lambda_lo<=lambda_hi<=R(19,4)||stop("CERTIFICATE_FAILED","lambda box")
    nu>0&&nv>0&&n>=0||stop("CERTIFICATE_FAILED","grid")
    setprecision(BigFloat,BITS) do
        plo,phi=pibounds(piN);p=range(plo,phi)
        rows=String[]
        push!(rows,"S1R4\t"*string(nu)*"\t"*string(nv)*"\t"*string(n)*"\t"*string(K)*"\t"*string(piN)*"\t"*fmt(lambda_lo)*"\t"*fmt(lambda_hi)*"\t"*fmt(plo)*"\t"*fmt(phi))
        total=(R(0),R(0))
        for i in 0:nu-1,j in 0:nv-1
            ul,uh=R(i,nu),R(i+1,nu);vl,vh=R(j,nv),R(j+1,nv)
            cs,cn,B,rem,val=integrate_cell(ul,uh,vl,vh,lambda_lo,lambda_hi,p,n,K)
            total=(total[1]+val[1],total[2]+val[2])
            fields=["CELL",string(i),string(j),fmt(ul),fmt(uh),fmt(vl),fmt(vh),fmtpair(cn),fmt(B),fmt(rem),fmtpair(val)]
            append!(fields,fmtpair.(cs))
            push!(rows,join(fields,'\t'))
        end
        push!(rows,"TOTAL\t"*fmtpair(total))
        push!(rows,"STATUS\tSMOKE_ONLY_NOT_CERTIFIED")
        open(path,"w") do io
            for line in rows println(io,line) end
        end
        println("S1 SMOKE ledger=",path," enclosure=",fmtpair(total)," NOT_CERTIFIED")
        total
    end
end
function main(args=ARGS)
    length(args)>=3 || stop("CERTIFICATE_FAILED","usage: julia producer.jl L H ledger.tsv [nu nv]")
    parseR(s)=begin
        p=split(s,'/');length(p)==2 ? parse(BigInt,p[1])//parse(BigInt,p[2]) : parse(BigInt,s)//BigInt(1)
    end
    run_s1_smoke(parseR(args[1]),parseR(args[2]);path=args[3],nu=length(args)>3 ? parse(Int,args[4]) : 4,nv=length(args)>4 ? parse(Int,args[5]) : 4)
end
end
if abspath(PROGRAM_FILE)==@__FILE__
    try R1ProducerS1.main() catch e
        showerror(stderr,e);println(stderr);exit(2)
    end
end
