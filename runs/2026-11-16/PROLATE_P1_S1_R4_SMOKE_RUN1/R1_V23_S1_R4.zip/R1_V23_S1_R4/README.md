# S1 R4 implementation candidate — source sealed only

R1 SHA-256: `1e53f74e2ba09bd9cf7207ed0ef153dd9e3a63b252185191153be75cea212241` (R1 is unchanged).

Target Julia 1.10.13, IntervalArithmetic.jl 1.0.10, isolated depot, 256-bit BigFloat. No TaylorSeries, Arb, FLINT or Arblib. Dependencies are NOT installed/tested here; no Project/Manifest replacement is included. Reuse the contract's preexisting V1 environment; Project/Manifest SHA have not been verified here.

Run in the authorized Julia environment for a single box (smoke, no sign certification):

```
julia --project=. producer.jl 47/10 47/10 s1_ledger.tsv 4 4
julia --project=. checker.jl s1_ledger.tsv
```

The producer exports `R1ProducerS1.run_s1_smoke(lambda_lo::Rational{BigInt},lambda_hi::Rational{BigInt}; path,nu,nv,n,K,piN)`.

All numerical bounds are written as exact rational endpoints in TSV. Checker independently recalculates π bounds, cell remainders, cover, sum. Output deliberately says `NOT_CERTIFIED`; no Tier A/B PASS. Julia runtime behavior, IA APIs, and mathematical enclosures are not yet I3-audited. Failures stop without automatic rerun. See UNCERTAINTIES.md.
