# S1 R4 SHA-256 manifest

SHA-256 computed from actual on-disk file bytes; no Julia run performed.

- `CHANGELOG.md` (1007 bytes): `e5cf47ec8542dcbd2ffa364b7c48d3a84580b5416b2b0a6a96df600556c07695`
- `README.md` (1150 bytes): `364b086927681ca77573fe063f1482c12ac7fcb9021d0a99a2ce897a2ea13280`
- `UNCERTAINTIES.md` (3061 bytes): `b9d3c4e4ea9a653b06bedc22e1147bb406d929e27907e693a2c5c00f6ed98ac0`
- `checker.jl` (4106 bytes): `ba58da006bc9809da11f665aa85b42e4cc6de39233124afba9d89474bd7dc4b7`
- `producer.jl` (10187 bytes): `a8ef4993fa3258298f5654adb0b21c91d040e32751e7b857d49646dc71d70ca3`
