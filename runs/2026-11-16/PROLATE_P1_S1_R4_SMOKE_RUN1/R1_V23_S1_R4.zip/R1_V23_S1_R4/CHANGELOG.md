# R3 -> S1 R4 changes

- Preserved R1 and R3 files; created a new R4 directory.
- Replaced incomplete Ajet stub with an analytic `A(1-x)` power-series composition and rational majorant for truncated-series coefficient tails; used same analytic branch throughout its convergence domain, stopping if q>=1.
- Implemented interval Taylor jets for sin/cos, sqrt, reciprocal, product and rational coefficients, with BigFloat type/precision/guarantee checks.
- Implemented R1 Q angular integrand using w=cos(pi*u), phi=2*pi*v, and Jacobian pi/2 factor.
- Implemented whole-cell n+1 derivative coefficient bound B, center-cell Taylor quadrature and direct interval v enclosure.
- Added Machin rational pi bounds and TSV rational certificate ledger for one lambda box.
- Added independent rational-only checker for cell arithmetic, pi bounds, rectangle cover, total.
- Added `run_s1_smoke`, CLI entry points and explicit NOT_CERTIFIED status.
- Added audit uncertainty inventory. Julia execution and I3 remain OPEN.
