#!/usr/bin/env python3
"""chat independent L0(c)(d) for C gap 2 (does not import any Dig code).

Usage: python3 -I chat_l0_independent.py <sealed_root> <out_parents.json>

Checks
  S1  SHA-256 of the 4 sealed files equals the frozen pins.
  S2  Both C1b ledgers: own re-implementation of the SHA-256 chain
      (sequence, prev hash, record hash over canonical JSON).
  S3  Each ledger: tree of attempted slabs is consistent (every REFINE has
      both children attempted later, ACCEPT leaves are exactly the leaves),
      ACCEPT count 159, right-clamped 35, unclamped 124, leaves tile
      [9/20, 5/8] without gap or overlap, clamped => t_plus = 1,
      unclamped => t_plus < 1 and lambda_hi <= 931/1600.
  S4  Producer and checker ACCEPT sets, clamp flags and t_plus agree.
  S5  Replay: ACCEPT set and t_plus agree with phase1 checker_replay_exact.
  S6  Right exterior: for every unclamped leaf with t_plus < 31/32, in BOTH
      lineages, the closed boxes of kind R / R_MONO with truth=True cover
      [lambda_lo, lambda_hi] x [t_plus, 31/32] (own sweep algorithm).
  S7  Emit the 124 parents (id, lambda, t_plus, t_e = max(31/32, t_plus)).
"""
import hashlib, json, sys
from fractions import Fraction as F
from pathlib import Path

PINS = {
    "phase1_v212s_seal_20260918T222551Z/ledger.jsonl":
        "1e46da3a4ef38409fa1c2130f81cf1125a672b6e44e714f2028a9708cea64b5f",
    "phase2_v212s_seal_20260920T140743Z/ledger.jsonl":
        "09caf7b9da493aecc922f73f795bc3f4c4321b6cb0598d5b2b08f6c066b76b38",
    "phase1_v212s_seal_20260918T222551Z/checker_replay_exact.jsonl":
        "c31af672d12981ca08c15464439b8ca81c75f7dd2dd801ad3c78dbbfdffc5b69",
    "c1b_receipt_extract.json":
        "8a332e568838b673c6d45ae934a47794cce3b9e1bb7cad9128dd7a3fcdfde81b",
}
TMID = F(31, 32); LLO, LHI = F(9, 20), F(5, 8); UHI = F(931, 1600)
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (" :: " + detail if detail else ""))
    return ok


def canon(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def chain(path):
    recs, prev = [], "0" * 64
    raw = path.read_bytes()
    ok = raw.endswith(b"\n")
    for i, line in enumerate(raw.splitlines()):
        r = json.loads(line)
        body = {"sequence": r["sequence"], "record_type": r["record_type"],
                "prev_sha256": r["prev_sha256"], "payload": r["payload"]}
        h = hashlib.sha256(canon(body)).hexdigest()
        ok &= (r["sequence"] == i and r["prev_sha256"] == prev and r["record_sha256"] == h)
        prev = r["record_sha256"]; recs.append(r)
    return ok, recs


def tree(recs, tag):
    slabs = [r["payload"] for r in recs if r["record_type"] == "slab_record"]
    node = {}
    for p in slabs:
        k = (int(p["coarse_index"]), int(p["refinement_depth"]), F(p["lambda_lo"]), F(p["lambda_hi"]))
        if k in node:
            check(f"S3[{tag}] no duplicate node", False, str(k)); return None
        node[k] = p
    ok = True
    for (c, d, a, b), p in node.items():
        if p["decision"] == "REFINE":
            m = (a + b) / 2
            ok &= (c, d + 1, a, m) in node and (c, d + 1, m, b) in node
        elif p["decision"] != "ACCEPT":
            ok = False
        if d > 0:  # parent must exist and be REFINE
            par = [k for k in node if k[0] == c and k[1] == d - 1 and k[2] <= a and b <= k[3]]
            ok &= len(par) == 1 and node[par[0]]["decision"] == "REFINE"
    check(f"S3[{tag}] REFINE/ACCEPT tree consistent (nodes {len(node)})", ok)
    acc = {k: p for k, p in node.items() if p["decision"] == "ACCEPT"}
    iv = sorted((k[2], k[3]) for k in acc)
    tiles = iv[0][0] == LLO and iv[-1][1] == LHI and all(x[1] == y[0] for x, y in zip(iv, iv[1:]))
    clamped = [k for k, p in acc.items() if p["result"]["right_clamp"] is True]
    good = all((F(p["result"]["t_plus"]) == 1) if p["result"]["right_clamp"] is True else
               (p["result"]["right_clamp"] is False and F(p["result"]["t_plus"]) < 1 and k[3] <= UHI)
               for k, p in acc.items())
    check(f"S3[{tag}] counts accepted={len(acc)} clamped={len(clamped)} unclamped={len(acc)-len(clamped)}",
          (len(acc), len(clamped)) == (159, 35))
    check(f"S3[{tag}] ACCEPT leaves tile [9/20,5/8]", tiles)
    check(f"S3[{tag}] clamp/t_plus/domain consistent", good)
    return acc


def cover(ll, lr, tp, boxes):
    """Own sweep: split lambda by all box edges; for each lambda strip, the
    t-intervals of boxes spanning the strip must cover [tp, 31/32]."""
    xs = sorted({ll, lr} | {b[2] for b in boxes} | {b[3] for b in boxes})
    xs = [x for x in xs if ll <= x <= lr]
    for a, b in zip(xs, xs[1:]):
        segs = sorted((t0, t1) for (t0, t1, l0, l1) in boxes if l0 <= a and b <= l1)
        reach = tp
        for t0, t1 in segs:
            if t0 > reach:
                break
            reach = max(reach, t1)
        if reach < TMID:
            return False
    return True


def guards(p, tp):
    out, ok = [], True
    for g in p["result"].get("exterior_guards") or []:
        if g.get("kind") in ("R", "R_MONO") and g.get("truth") is True:
            t0, t1, l0, l1 = F(g["t_lo"]), F(g["t_hi"]), F(g["lambda_lo"]), F(g["lambda_hi"])
            ok &= tp <= t0 < t1 <= TMID and l0 < l1
            out.append((t0, t1, l0, l1))
    return ok, out


def main():
    root, outp = Path(sys.argv[1]), Path(sys.argv[2])
    for rel, pin in PINS.items():
        check(f"S1 sha {rel}", hashlib.sha256((root / rel).read_bytes()).hexdigest() == pin)
    okp, rp = chain(root / "phase1_v212s_seal_20260918T222551Z/ledger.jsonl")
    okc, rc = chain(root / "phase2_v212s_seal_20260920T140743Z/ledger.jsonl")
    check(f"S2 producer chain ({len(rp)} records)", okp)
    check(f"S2 checker chain ({len(rc)} records)", okc)
    for tag, rs in (("producer", rp), ("checker", rc)):
        ends = [r for r in rs if r["record_type"] == "segment_end"]
        check(f"S2[{tag}] terminal segment_end not ABORT",
              len(ends) >= 1 and all(e["payload"].get("reason") != "ABORT" for e in ends))
    ap, ac = tree(rp, "producer"), tree(rc, "checker")
    check("S4 same ACCEPT set", set(ap) == set(ac))
    check("S4 same clamp and t_plus",
          all(ap[k]["result"]["right_clamp"] == ac[k]["result"]["right_clamp"] and
              F(ap[k]["result"]["t_plus"]) == F(ac[k]["result"]["t_plus"]) for k in ap))
    rep = [json.loads(l) for l in (root / "phase1_v212s_seal_20260918T222551Z/checker_replay_exact.jsonl").read_bytes().splitlines()]
    ra = {(int(x["coarse_index"]), int(x["refinement_depth"]), F(x["lambda_lo"]), F(x["lambda_hi"])): x
          for x in rep if x.get("decision") == "ACCEPT"}
    check(f"S5 replay ACCEPT set = ledger ({len(ra)})", set(ra) == set(ap))
    check("S5 replay t_plus = ledger", all(F(ra[k]["t_plus"]) == F(ap[k]["result"]["t_plus"]) for k in ap))
    parents, ext_need, ext_ok, nbox = [], 0, True, [0, 0]
    for k in sorted(ap, key=lambda k: (k[2], k[3])):
        if ap[k]["result"]["right_clamp"]:
            continue
        tp = F(ap[k]["result"]["t_plus"])
        if tp < TMID:
            ext_need += 1
            for i, src in enumerate((ap[k], ac[k])):
                okg, bx = guards(src, tp)
                nbox[i] += len(bx)
                if not (okg and bx and cover(k[2], k[3], tp, bx)):
                    ext_ok = False; print("  exterior open:", k, i)
        c, d, a, b = k
        parents.append({"parent_id": f"{c}:{d}:{a}:{b}", "coarse_index": c, "c1b_original_depth": d,
                        "lambda_lo": str(a), "lambda_hi": str(b), "t_plus": str(tp),
                        "t_e": str(max(TMID, tp))})
    check(f"S6 right exterior closed in both lineages ({ext_need} parents need it; "
          f"true R/R_MONO boxes producer {nbox[0]}, checker {nbox[1]})", ext_ok)
    check("S7 unclamped parents = 124", len(parents) == 124)
    te = [F(p["t_e"]) for p in parents]
    print("  t_e: min", min(te), "max", max(te), "count(t_e=31/32)", sum(x == TMID for x in te),
          "N range", sorted({-(-(512 * (1 - x)).numerator // (512 * (1 - x)).denominator) for x in te}))
    outp.write_text(json.dumps(parents, indent=1, ensure_ascii=False) + "\n")
    n_fail = sum(not r[1] for r in results)
    print(f"SUMMARY {len(results) - n_fail}/{len(results)} PASS")
    sys.exit(1 if n_fail else 0)


main()
