#!/usr/bin/env python3
"""chat independent acceptance of a C gap 2 formal run (no Dig code imported).

Usage:
  python3 -I chat_gap2_accept.py --producer RUN --checker RUN --parents chat_parents_124.json \
      --judge-sha f737... [--compare compare.json]
  python3 -I chat_gap2_accept.py --synthetic --producer RUN --checker RUN   (preflight self-test)

Mathematics checked per ACCEPT leaf Q = [lambda_lo, lambda_hi]:
  for t in [t_e, 1]:  g(t,l) = g(t_e,l) + int_{t_e}^t Gt  <=  U_seed + sum_j dt * max(0, U_j),
  with U_seed >= sup g(t_e, Q), U_j >= sup Gt over [t_j, t_{j+1}] x Q, cells an exact equal
  partition of [t_e, 1] with N = ceil(512 (1 - t_e)).  Success iff U_seed < 0 and the sum < 0.
"""
import argparse, collections, hashlib, json, re, sys
from fractions import Fraction as F
from pathlib import Path

PINS = {
    "phase1_v212s_seal_20260918T222551Z/ledger.jsonl":
        "1e46da3a4ef38409fa1c2130f81cf1125a672b6e44e714f2028a9708cea64b5f",
    "phase2_v212s_seal_20260920T140743Z/ledger.jsonl":
        "09caf7b9da493aecc922f73f795bc3f4c4321b6cb0598d5b2b08f6c066b76b38",
    "phase1_v212s_seal_20260918T222551Z/checker_replay_exact.jsonl":
        "c31af672d12981ca08c15464439b8ca81c75f7dd2dd801ad3c78dbbfdffc5b69",
    "c1b_receipt_extract.json":
        "8a332e568838b673c6d45ae934a47794cce3b9e1bb7cad9128dd7a3fcdfde81b",
}
HEAD = "0d32ac2a0325f41998adebf922a57ed50cf3ba59"
FROZEN = "26d81e1049340d44ef7f08ae8e17d0692983395b"
TMID, MAXD = F(31, 32), 3
results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok)))
    print(("PASS " if ok else "FAIL ") + name + (" :: " + detail if detail else ""))
    return ok


def canon(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def chain(path):
    recs, prev, ok = [], "0" * 64, True
    raw = path.read_bytes()
    ok &= raw.endswith(b"\n")
    for i, line in enumerate(raw.splitlines()):
        r = json.loads(line)
        body = {"sequence": r["sequence"], "record_type": r["record_type"],
                "prev_sha256": r["prev_sha256"], "payload": r["payload"]}
        ok &= (r["sequence"] == i and r["prev_sha256"] == prev and
               r["record_sha256"] == hashlib.sha256(canon(body)).hexdigest())
        prev = r["record_sha256"]; recs.append(r)
    return ok, recs, hashlib.sha256(raw).hexdigest(), len(raw)


NUM = r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?"


def ball(s):
    """(m, r) of an arb ball printed as '[m +/- r]', '[+/- r]' or 'm' (exact)."""
    s = s.strip()
    m = re.fullmatch(r"\[\s*(" + NUM + r")\s*\+/-\s*(" + NUM + r")\s*\]", s)
    if m:
        return F(m.group(1)), F(m.group(2))
    m = re.fullmatch(r"\[\s*\+/-\s*(" + NUM + r")\s*\]", s)
    if m:
        return F(0), F(m.group(1))
    m = re.fullmatch(r"\[?\s*(" + NUM + r")\s*\]?", s)
    if m:
        return F(m.group(1)), F(0)
    raise ValueError("unparsed ball " + s)


def in_ball(x, s):
    """Recorded exact rational x equals the printed upper endpoint ball (decimal print of an exact arf)."""
    m, r = ball(s)
    return abs(x - m) <= r


def partition(te):
    n = -(-(512 * (1 - te)).numerator // (512 * (1 - te)).denominator)
    dt = (1 - te) / n
    return n, dt, [(te + j * dt, te + (j + 1) * dt) for j in range(n)]


def gate(p, te, stats):
    """Return (ok_record, accept_margin or None). Recompute everything exactly."""
    ev = p["evidence"]; ok = True
    n, dt, cells = partition(te)
    ok &= 1 <= n <= 16 and cells[-1][1] == 1 and cells[0][0] == te
    ok &= F(ev["endpoint_seed_t"]) == te and F(p["t_e"]) == te
    boxes = ev["endpoint_gt_boxes"]
    ok &= len(boxes) == n
    if te != TMID:
        ok &= int(ev["endpoint_n_boxes"]) == n and F(ev["endpoint_delta_t"]) == dt
    for j, (b, (a, c)) in enumerate(zip(boxes, cells)):
        ok &= b["j"] == j and (F(b["t_cell"][0]), F(b["t_cell"][1])) == (a, c)
        ok &= b["dispatch"] == ("endpoint_corner_ordinary" if c == 1 else "ordinary")
    if p["decision"] != "ACCEPT":
        stats["refine_reason"][ev["endpoint_reason"]] += 1
        return ok and ev["endpoint_pass"] is False, None
    ok &= ev["endpoint_pass"] is True and ev["endpoint_reason"] == "PASS"
    seed = F(ev["endpoint_seed_g_upper"])
    ok &= in_ball(seed, ev["endpoint_seed_g"]["upper"])
    total = seed
    contrib = [F(x) for x in ev["endpoint_contributions"]]
    ok &= len(contrib) == n
    for b, cj in zip(boxes, contrib):
        u = F(b["upper"])
        ok &= in_ball(u, b["Gt"]["upper"])
        ok &= cj == max(F(0), u)
        total += dt * cj
        stats["max_U"] = max(stats["max_U"], u)
    cum = F(ev["endpoint_cumulative_mvt_upper"])
    ok &= seed < 0 and total <= cum < 0
    return ok, -total


def lineage(run, tag, parents, args, stats):
    okc, recs, lsha, lbytes = chain(run / "ledger.jsonl")
    check(f"R1[{tag}] SHA-256 chain ({len(recs)} records)", okc)
    types = [r["record_type"] for r in recs]
    allowed = all(t in ("header", "slab_record", "segment_end", "lscpu_raw_trace") for t in types)
    lscpu_pos = all(types[i - 1] in ("header", "segment_end") for i, t in enumerate(types) if t == "lscpu_raw_trace")
    check(f"R1[{tag}] record types/order {dict(collections.Counter(types))}",
          allowed and lscpu_pos and types[0] == "header" and
          [t for t in types if t != "lscpu_raw_trace"][-1] == "segment_end" and types.count("segment_end") == 1)
    h = recs[0]["payload"]
    ib = h["identity_before"]
    if args.synthetic:
        parents = h["parents"]
        check(f"R2[{tag}] header synthetic", h["mode"] == "SYNTHETIC_NOT_EVIDENCE")
    else:
        check(f"R2[{tag}] header mode SEALED / lineage / schema",
              h["mode"] == "SEALED" and h["lineage"] == tag and h["schema"] == "C_GAP2_V4R2_RUN_V1")
        check(f"R2[{tag}] Judge ruling SHA", h["judge_ruling_sha256"] == args.judge_sha)
        check(f"R2[{tag}] sealed input SHA = 4 pins", h["sealed_input_sha256"] == PINS)
        check(f"R2[{tag}] parent table = chat independent L0 (124)", h["parents"] == parents)
    check(f"R2[{tag}] identity_before head/frozen/clean",
          ib["head"] == HEAD and ib["frozen_grandparent"] == FROZEN and ib["clean_status"] is True)
    pmap = {p["parent_id"]: p for p in parents}
    nodes = collections.defaultdict(dict)
    order, rec_ok = [], True
    for r in recs:
        if r["record_type"] != "slab_record":
            continue
        p = r["payload"]
        pid = p["parent_slab_id"]
        rec_ok &= pid in pmap and p["lineage"] == tag
        if not order or order[-1] != pid:
            order.append(pid)
        s = p["slab"]
        k = (int(s["refinement_depth"]), F(s["lambda_lo"]), F(s["lambda_hi"]))
        rec_ok &= str(s["coarse_index"]) == str(pmap[pid]["coarse_index"]) and k not in nodes[pid]
        nodes[pid][k] = p
    check(f"R3[{tag}] records belong to declared parents; parents processed once, in header order",
          rec_ok and order == [p["parent_id"] for p in parents])
    tree_ok, gate_ok, margins, depth_hist, leaves = True, True, [], collections.Counter(), {}
    for p in parents:
        pid, te = p["parent_id"], F(p["t_e"])
        lo, hi = F(p["lambda_lo"]), F(p["lambda_hi"])
        nd = nodes.get(pid, {})
        tree_ok &= (0, lo, hi) in nd
        for (d, a, b), q in nd.items():
            tree_ok &= d <= MAXD and q["decision"] in ("ACCEPT", "REFINE")
            if q["decision"] == "REFINE":
                m = (a + b) / 2
                tree_ok &= d < MAXD and (d + 1, a, m) in nd and (d + 1, m, b) in nd
            if d > 0:
                par = [k for k in nd if k[0] == d - 1 and k[1] <= a and b <= k[2]]
                tree_ok &= len(par) == 1 and nd[par[0]]["decision"] == "REFINE"
            g_ok, margin = gate(q, te, stats)
            gate_ok &= g_ok
            if margin is not None:
                margins.append((margin, pid, d, a, b)); depth_hist[d] += 1
        lv = sorted((a, b) for (d, a, b), q in nd.items() if q["decision"] == "ACCEPT")
        leaves[pid] = lv
        tree_ok &= bool(lv) and lv[0][0] == lo and lv[-1][1] == hi and all(x[1] == y[0] for x, y in zip(lv, lv[1:]))
    nrec = sum(len(v) for v in nodes.values())
    check(f"R3[{tag}] lambda trees: REFINE->both children, depth<=3, ACCEPT leaves tile each parent "
          f"(nodes {nrec}, leaves {len(margins)}, leaf depth {dict(sorted(depth_hist.items()))})", tree_ok)
    check(f"R4[{tag}] exact gate arithmetic on all {nrec} nodes (partition, N, dt, dispatch, "
          f"U in printed ball, contrib=max(0,U), seed<0, seed+dt*sum<=recorded<0)", gate_ok)
    seg = [r for r in recs if r["record_type"] == "segment_end"][0]["payload"]
    check(f"R5[{tag}] segment_end COMPLETED, attempted={seg.get('attempted')}",
          seg["reason"] == "COMPLETED" and int(seg["attempted"]) == nrec)
    check(f"R5[{tag}] identity_after == identity_before", seg["identity_after"] == ib)
    man = json.loads((run / "manifest.json").read_text())
    exp_status = "SYNTHETIC_COMPLETE_NOT_EVIDENCE" if args.synthetic else "CANDIDATE_NOT_JUDGE_ACCEPTED"
    check(f"R6[{tag}] manifest status/ledger sha/bytes/counts",
          man["status"] == exp_status and man["reason"] == "COMPLETED" and man["ledger_sha256"] == lsha
          and int(man["ledger_bytes"]) == lbytes and int(man["attempted"]) == nrec
          and int(man["accepted_parent_slabs"]) == len(parents) and man["identity_after"] == ib)
    if not args.synthetic:
        check(f"R6[{tag}] manifest input pins / Judge SHA",
              man["input_sha256"] == PINS and man["judge_ruling_sha256"] == args.judge_sha)
        rc = man.get("receipt_counts") or {}
        inv = {k: (rc.get(k) or {}).get("auxiliary_status") for k in ("accepted", "right_clamped")}
        print(f"  F7[{tag}] inventory:", json.dumps(inv),
              [(c["path"], c["observed_value"]) for k in ("accepted", "right_clamped")
               for c in (rc.get(k) or {}).get("candidates", [])])
    margins.sort()
    print(f"  [{tag}] smallest margins -U_cum:")
    for m, pid, d, a, b in margins[:5]:
        print(f"     {float(m):.6g}  parent {pid} depth {d} [{a},{b}]")
    return leaves, margins, nodes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--producer", required=True); ap.add_argument("--checker", required=True)
    ap.add_argument("--parents"); ap.add_argument("--judge-sha"); ap.add_argument("--compare")
    ap.add_argument("--synthetic", action="store_true")
    args = ap.parse_args()
    parents = None if args.synthetic else json.loads(Path(args.parents).read_text())
    out = {}
    for tag in ("producer", "checker"):
        stats = {"refine_reason": collections.Counter(), "max_U": F(-10**9)}
        out[tag] = lineage(Path(getattr(args, tag)), tag, parents, args, stats)
        print(f"  [{tag}] REFINE reasons {dict(stats['refine_reason'])}, max Gt upper {float(stats['max_U']):.4g}")
    (lp, mp, np_), (lc, mc, nc) = out["producer"], out["checker"]
    same = lp == lc
    agree = all(np_[pid][k]["decision"] == nc[pid][k]["decision"] for pid in np_ for k in np_[pid] if k in nc.get(pid, {}))
    check(f"R7 both lineages cover all parents independently; leaf sets identical={same}, "
          f"decisions on common nodes agree={agree}", set(lp) == set(lc))
    if args.compare:
        cj = json.loads(Path(args.compare).read_text())
        st = cj.get("status") or cj.get("verdict")
        check(f"R8 lineage_compare status {st}",
              st == ("COMPARE_PASS_NOT_JUDGE_CLOSED" if not args.synthetic else st))
    nf = sum(not r[1] for r in results)
    print(f"SUMMARY {len(results) - nf}/{len(results)} PASS")
    sys.exit(1 if nf else 0)


main()
