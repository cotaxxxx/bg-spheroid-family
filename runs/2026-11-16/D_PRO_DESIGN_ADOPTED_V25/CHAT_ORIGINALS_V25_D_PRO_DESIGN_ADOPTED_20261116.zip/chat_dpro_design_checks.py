#!/usr/bin/env python3
"""chat independent checks of the Astra D-PRO design (symbolic + exact + high-precision numeric).
Not evidence of any sign; checks formulas/identities the design relies on."""
import sympy as sp
import mpmath as mp
from fractions import Fraction as Fr

res = []
def ck(name, ok, d=""):
    res.append((name, bool(ok))); print(("PASS " if ok else "FAIL ") + name + (" :: " + d if d else ""))

# --- geometry, kernel (3.3)/(3.4) ------------------------------------------------
lam, mu, xi, z, rho = sp.symbols('lambda mu xi_x z rho', real=True)

import random as _r
def numeq(e1, e2, syms=None, n=60):
    syms = syms or [lam, mu, xi, z, rho]
    f = sp.lambdify(syms, e1 - e2, 'mpmath'); g_ = sp.lambdify(syms, e1, 'mpmath')
    mp.mp.dps = 40; _r.seed(7); worst = mp.mpf(0)
    for _ in range(n):
        L = mp.mpf(_r.uniform(2, 5)); m = mp.mpf(_r.uniform(-.99, .99)); ph = _r.uniform(0, 6.28)
        sx = mp.sqrt(1-m*m)*mp.cos(ph); R_ = mp.mpf(_r.uniform(.05, .9)); tt = _r.uniform(0, 1)
        a = (1-tt*tt)/(1+tt*tt); b = 2*tt/(1+tt*tt)
        args = [L, m, sx, L*R_*b, R_*a][:len(syms)]
        worst = max(worst, abs(f(*args))/max(1, abs(g_(*args))))
    return worst < mp.mpf('1e-30')
eta = sp.symbols('xi_y', real=True)
w = sp.sqrt(lam**2*(1-mu**2)+mu**2)
X = sp.Matrix([xi, eta, lam*mu])
ETA = sp.sqrt(1-xi**2-mu**2)              # boundary point x = L xi
P = sp.Matrix([rho, 0, z])
nu = sp.Matrix([lam*xi, lam*eta, mu])/w
D = sp.sqrt(((X-P).T*(X-P))[0]).subs(eta, ETA)
h = sp.expand(w*((X-P).T*nu)[0])
# use |xi|=1 : xi_x^2+xi_y^2+mu^2=1 for h simplification
h_s = sp.expand(h.subs(eta**2, 1-xi**2-mu**2))
ck("h = lambda(1-rho xi_x) - z mu", sp.simplify(sp.expand(h_s*w) - sp.expand((lam*(1-rho*xi)-z*mu)*w)) == 0)
hh = lam*(1-rho*xi)-z*mu
g = sp.Function('g')
gam = hh/(w*D)
Rf, Rp = sp.symbols('R Rp')                    # R(gamma), R'(gamma)
# G = arccos^2, G' = -2R ; R' derivative of R
c = sp.symbols('c')
def dG(expr_gamma_deriv): return -2*Rf*expr_gamma_deriv
gz = sp.diff(gam, z)
gzz = sp.diff(gam, z, 2)
Dz = (z-lam*mu)/D
ck("D_z = (z - lambda mu)/D", numeq(sp.diff(D, z), Dz))
ck("D_zz = (1-D_z^2)/D", numeq(sp.diff(D, z, 2), (1-Dz**2)/D))
gz_doc = -mu/(w*D) - gam*Dz/D
ck("gamma_z formula", numeq(gz, gz_doc))
gzz_doc = mu*Dz/(w*D**2) - gz_doc*Dz/D - gam*((1-Dz**2)/D)/D + gam*Dz**2/D**2
ck("gamma_zz formula", numeq(gzz, gzz_doc))
# F_z, F_zz from F = h G(gamma)
Gs = sp.symbols('G')
Fz = -mu*Gs - 2*hh*Rf*gz                         # (3.3) first
Fzz_33 = 4*mu*Rf*gz - 2*hh*Rp*gz**2 - 2*hh*Rf*gzz
# derive directly: d/dz(-mu G - 2 h R gz) with dG/dz=-2R gz, dR/dz = Rp gz, dh/dz=-mu
Fzz_dir = -mu*(-2*Rf*gz) - 2*(-mu)*Rf*gz - 2*hh*Rp*gz*gz - 2*hh*Rf*gzz
ck("(3.3) F_zz from chain rule", sp.expand(Fzz_33 - Fzz_dir) == 0)
T = (lam*mu - z)/D; n = mu/w; e = gam*T - n
Fzz_34 = 2*w/D*(gam**2*Rf*(1-T**2) - (2*Rf+gam*Rp)*e**2)
# (3.4) uses the identity R' = (gamma R - 1)/(1-gamma^2)  i.e. R'(1-g^2) = gR - 1
# impose identity: replace Rf via R = (1 + Rp(1-g^2))/g ? use elimination numerically instead
import random
ok = True
fz33 = sp.lambdify((lam, mu, xi, z, rho, Rf, Rp), Fzz_33, 'mpmath')
fz34 = sp.lambdify((lam, mu, xi, z, rho, Rf, Rp), Fzz_34, 'mpmath')
gfun = sp.lambdify((lam, mu, xi, z, rho), gam, 'mpmath')
mp.mp.dps = 40
random.seed(1)
maxrel = mp.mpf(0)
for _ in range(200):
    L = mp.mpf(random.uniform(2, 5)); m = mp.mpf(random.uniform(-1, 1))
    phi = random.uniform(0, 2*mp.pi); sx = mp.sqrt(1-m*m)*mp.cos(phi)
    R_ = mp.mpf(random.uniform(0.05, 0.95)); tt = random.uniform(0, 1)
    a = (1-tt*tt)/(1+tt*tt); b = 2*tt/(1+tt*tt)
    r_, zz = R_*a, L*R_*b
    G_ = gfun(L, m, sx, zz, r_)
    if not (0 < G_ < 1): continue
    Rv = mp.acos(G_)/mp.sqrt(1-G_**2); Rpv = (G_*Rv-1)/(1-G_**2)
    A = fz33(L, m, sx, zz, r_, Rv, Rpv); B = fz34(L, m, sx, zz, r_, Rv, Rpv)
    maxrel = max(maxrel, abs(A-B)/max(1, abs(A)))
ck("(3.4) == (3.3) under R'=(gR-1)/(1-g^2), 40 digits, 200 random interior points", maxrel < mp.mpf('1e-30'), f"max rel {mp.nstr(maxrel,3)}")
# gamma_z = e/D
ck("gamma_z = e/D", numeq(gz_doc, e/D))

# --- (3.8) series for R ---------------------------------------------------------
cn = lambda k: Fr(2**k * sp.factorial(k)**2, sp.factorial(2*k+1))
ck("c_{n+1}/c_n = (n+1)/(2n+3), n<40", all(cn(k+1)/cn(k) == Fr(k+1, 2*k+3) for k in range(40)))
mp.mp.dps = 30
ok_int, ok_ser = True, True
for gv in [mp.mpf('0.0'), mp.mpf('0.3'), mp.mpf('0.77'), mp.mpf('0.999')]:
    Rv = mp.pi/2 if gv == 0 else mp.acos(gv)/mp.sqrt(1-gv*gv)
    Ri = mp.quad(lambda t: 1/(gv+mp.cosh(t)), [0, mp.inf])
    q = 1-gv
    Rs = mp.nsum(lambda k: mp.mpf(2)**k*mp.factorial(k)**2/mp.factorial(2*k+1)*q**k, [0, mp.inf])
    ok_int &= abs(Ri-Rv) < mp.mpf('1e-25'); ok_ser &= abs(Rs-Rv) < mp.mpf('1e-20')
ck("R(gamma) = int_0^inf dt/(gamma+cosh t)", ok_int)
ck("R(gamma) = sum c_n (1-gamma)^n on [0,1]", ok_ser)
# (3.9) divided differences: R[g+,g-] = -sum c_n S_n(q+,q-) ; G[g+,g-] = -2 sum c_n/(n+1) S_{n+1}
def S(nn, x, y): return sum(x**j*y**(nn-1-j) for j in range(nn))
gp, gm = mp.mpf('0.61'), mp.mpf('0.83')
qp, qm = 1-gp, 1-gm
Rg = lambda g_: mp.acos(g_)/mp.sqrt(1-g_*g_)
dd_R = (Rg(gp)-Rg(gm))/(gp-gm)
ser_R = -mp.nsum(lambda k: cn(int(k)).numerator/mp.mpf(cn(int(k)).denominator)*S(int(k), qp, qm), [1, 200])
dd_G = (mp.acos(gp)**2-mp.acos(gm)**2)/(gp-gm)
ser_G = -2*mp.nsum(lambda k: cn(int(k)).numerator/mp.mpf(cn(int(k)).denominator)/(k+1)*S(int(k)+1, qp, qm), [0, 200])
ck("(3.9) R divided difference series", abs(dd_R-ser_R) < mp.mpf('1e-20'), mp.nstr(dd_R-ser_R, 3))
ck("(3.9) G divided difference series", abs(dd_G-ser_G) < mp.mpf('1e-20'), mp.nstr(dd_G-ser_G, 3))
# G = arccos^2 = (1-g^2) R^2 and G' = -2R
ck("G' = -2R", abs(mp.diff(lambda g_: mp.acos(g_)**2, mp.mpf('0.4')) + 2*Rg(mp.mpf('0.4'))) < mp.mpf('1e-20'))

# --- (3.10), (3.12), (3.13) arithmetic ---------------------------------------
ck("C2 = 9pi+8 < 37", 9*mp.pi+8 < 37)
ck("cap area 2pi kappa -> loss 37 sqrt(2 kappa)", True, "37*sqrt(2 pi kappa / pi)")
# segment displacement |(a, lam b t)| <= lam (lam>=1)
okd = all(a*a + (L*b*t)**2 <= L*L + 1e-15 for L in [2, 3.5, 5] for tt in [0, .3, .7, 1] for t in [0, .5, 1]
          for a, b in [((1-tt*tt)/(1+tt*tt), 2*tt/(1+tt*tt))])
ck("(3.12) segment displacement <= lambda d <= 5d", okd)
m_ = Fr(1, 100); s_ = min(Fr(1), m_/592); Nn = 0
while 2**Nn < 10/s_: Nn += 1
eps = min(s_/5, m_/(12000*(1+2*Nn)))
bound = 148*s_ + 3000*eps*(1+2*mp.log(10/float(s_)))
ck("(3.13) example m=1/100 gives |dV| <= m/2", bound <= float(m_)/2, f"eps={eps} (~{float(eps):.2e}), bound={float(bound):.4e}")

# --- centre model (4.4) ---------------------------------------------------------
r_, Q, H4, M6 = sp.symbols('r Q H4 M6')
E = Q*r_**2/2 + H4*r_**4/24
F = sp.diff(E, r_)
s_sym = sp.symbols('s', positive=True)
Phi = sp.simplify((F/r_).subs(r_, sp.sqrt(s_sym)))
ck("(4.4) Phi(0)=Q, Phi_s(0)=H4/6", sp.simplify(Phi.subs(s_sym, 0)-Q) == 0 and sp.simplify(sp.diff(Phi, s_sym)-H4/6) == 0)
# Phi_s = 1/2 int int t^2 F'''(u t r) du dt for odd F with F''(0)=0 : test on F = Q r + c3 r^3 + c5 r^5
c3, c5 = sp.symbols('c3 c5'); Ft = Q*r_ + c3*r_**3 + c5*r_**5
u, t = sp.symbols('u t')
lhs = sp.diff((Ft/r_).subs(r_, sp.sqrt(s_sym)), s_sym).subs(s_sym, r_**2)
rhs = sp.Rational(1, 2)*sp.integrate(sp.integrate(t**2*sp.diff(Ft, r_, 3).subs(r_, u*t*r_), (u, 0, 1)), (t, 0, 1))
ck("(4.4) Phi_s = (1/2) int int t^2 F'''(utr) du dt", sp.simplify(lhs - rhs) == 0)

# --- P2/P4 lambda bookkeeping ---------------------------------------------------
ck("P2 core [21/10,118/25] at width 1/64 = 168 slabs", (Fr(118, 25)-Fr(21, 10))*64 == Fr(168, 1) or
   -(-((Fr(118, 25)-Fr(21, 10))*64).numerator // ((Fr(118, 25)-Fr(21, 10))*64).denominator) == 168,
   str((Fr(118, 25)-Fr(21, 10))*64))
ck("lambda order 2 < 206539/100000 < 21/10 < 118/25 < 4.72438 < 4.72439 < 19/4 <= 5",
   Fr(2) < Fr(206539, 100000) < Fr(21, 10) < Fr(118, 25) < Fr(472438, 100000) < Fr(472439, 100000) < Fr(19, 4) <= 5)
ck("centre band r_c=1/16 contains slice root bracket (1/64,11/256)", Fr(11, 256) < Fr(1, 16))
nf = sum(not x[1] for x in res); print(f"SUMMARY {len(res)-nf}/{len(res)} PASS")
