import sys,subprocess
def queries():
 for j in range(408,680):
  yield (j*1024,(j+1)*1024,2048)
def make(exe):
 qs=list(queries());r=subprocess.run([exe],input=''.join('%s %s %s\n'%q for q in qs),text=True,capture_output=True,check=True)
 out=[]
 for q,line in zip(qs,r.stdout.splitlines(),strict=True):
  a,b,c,d=map(int,line.split())
  label='negative' if b<0 else 'positive' if a>0 else 'increasing' if c>0 else 'open'
  out.append(' '.join(map(str,(*q,a,b,c,d,label))))
 return '\n'.join(out)+'\n'
if __name__=='__main__':print(make(sys.argv[1]),end='')
