from pathlib import Path
import sys,subprocess
p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
for file in sorted(Path('thin').glob('*.tsv')):
 for row in file.read_text().splitlines():
  if not row.endswith(' open'):continue
  vals=row.split()
  for n,k in [(64,32),(128,64),(256,128),(512,256)]:
   q=' '.join(['X',*vals[2:8],str(n),str(k)])
   p.stdin.write(q+'\n');p.stdin.flush();ans=p.stdout.readline().strip()
   if int(ans.split()[0])>0:break
  print(file.stem,vals[0],q,ans,'sign' if int(ans.split()[0])>0 else 'open')
p.stdin.close();assert p.wait()==0
