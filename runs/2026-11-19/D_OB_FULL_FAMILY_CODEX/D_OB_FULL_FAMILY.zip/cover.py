"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Integer outer endpoints in 2^-20."""
import sys,subprocess,itertools
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
U=1<<20
def roots():
 for j in range(4,32):
  for f in 'HZV':
   yield (j,f,(j*U//32,(j+1)*U//32,0,U if f=='H' else 0, U//8 if f=='V' else 0,U//8 if f=='Z' else U))
def run(arg):
 j,f,box=arg
 if f!='H' and j in range(13,20):return
 p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
 todo=[('x',box)];fn=Path(sys.argv[2])/f'{j:02}{f}.tsv'
 with fn.open('w') as o:
  while todo:
   key,b=todo.pop();dep=len(key)-1
   n,k=((32,16) if dep<4 else (64,32) if dep<8 else (128,32)) if f=='H' else (256 if dep<4 else 1024 if dep<10 else 4096,2)
   q=' '.join(map(str,(f,*b,n,k)));p.stdin.write(q+'\n');p.stdin.flush()
   ans=p.stdout.readline().strip()
   if not ans:raise RuntimeError((q,p.poll()))
   if ans=='empty':act='empty'
   else:
    lo,hi,*_=map(int,ans.split())
    if (lo>0 if f=='H' or j>=20 else hi<0):act='sign'
    elif dep>=(10 if f=='H' else 13):act='open'
    else:
     axis=max((0,2,4),key=lambda i:(b[i+1]-b[i])*(4 if i==0 else 1));mid=(b[axis]+b[axis+1])//2
     act='split'+str(axis)
     for side in (1,0):
      c=list(b);c[axis+1-side]=mid;todo.append((key+str(side),tuple(c)))
   print(key,q,ans,act,file=o)
 p.stdin.close();assert p.wait()==0
if __name__=='__main__':
 Path(sys.argv[2]).mkdir(exist_ok=False)
 with ProcessPoolExecutor(6) as pool:list(pool.map(run,sorted(roots(),key=lambda t:(t[1]=='H',-t[0]))))
