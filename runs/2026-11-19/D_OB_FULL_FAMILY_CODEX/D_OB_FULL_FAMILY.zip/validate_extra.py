"""Verify keys, final boxes, sign sense and recompute all supplementary terminal enclosures."""
import sys,subprocess
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
def validate(arg):
 j,phase=arg;stem=f'{j:02}H'
 base={'rim':'thin','recovered':'mixed','salvage':'recovered'}[phase]
 roots={p[0]:tuple(map(int,p[2:8])) for line in (Path(base)/(stem+'.tsv')).read_text().splitlines() if (p:=line.split())[-1]=='open'}
 if phase=='rim':rows=[v[1:] for line in Path('rim.tsv').read_text().splitlines() if (v:=line.split())[0]==stem]
 else:rows=[line.split() for line in (Path(phase)/(stem+'.tsv')).read_text().splitlines()]
 if phase=='salvage':roots={k+':x':b for k,b in roots.items()}
 queries=[];answers=[];miss=[];counts={}
 for key,mode,*v in rows:
  b=tuple(map(int,v[:6]));assert roots.pop(key)==b
  assert mode=='H' or mode=='X' and b[2]>0
  tag=v[-1];counts[tag]=counts.get(tag,0)+1
  if tag.startswith('split'):
   i=int(tag[-1]);assert phase=='salvage' and i in (0,2,4)
   m=(b[i]+b[i+1])//2;assert b[i]<m<b[i+1]
   for side in (0,1):
    c=list(b);c[i+1-side]=m;roots[key+str(side)]=tuple(c)
   continue
  if tag=='empty':assert b[2]**2+b[4]**2>(1<<40)
  else:assert tag==('sign' if int(v[8])>0 else 'open')
  if tag=='open':miss.append((stem,key,*b))
  queries.append(' '.join([mode,*v[:8]]));answers.append(' '.join(v[8:-1]))
 assert not roots
 if queries:
  r=subprocess.run([sys.argv[1]],input='\n'.join(queries)+'\n',text=True,capture_output=True,check=True)
  assert [v.strip() for v in r.stdout.splitlines()]==answers
 return stem,counts,miss
if __name__=='__main__':
 for phase in sys.argv[2:]:
  with ProcessPoolExecutor(5) as pool, open(phase+'.unresolved','w') as o:
   for stem,c,miss in pool.map(validate,[(i,phase) for i in range(8,16)]):
    print(phase,stem,c,flush=True)
    for row in miss:print(*row,file=o)
