"""Refine compact interval. Dyadic cover across the two non-dyadic junctions."""
import cover,sys,subprocess
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
U=cover.U
def tasks():
 for j in range(2,4):
  a=j*U//32;b=(j+1)*U//32
  for f in "H":
   for i in range(4):
    zlo=U//8 if f=='V' else 0
    yield (j*4+i,f,(a+(b-a)*i//4,a+(b-a)*(i+1)//4,0,U if f=='H' else 0,zlo,U//8 if f=='Z' else U))
def run(arg):
 j,f,box=arg

 p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
 todo=[('x',box)];fn=Path(sys.argv[2])/f'{j:02}{f}.tsv'
 with fn.open('w') as o:
  while todo:
   key,b=todo.pop();dep=len(key)-1
   n,k=((32,16) if dep<4 else (64,32) if dep<8 else (128,32) if dep<12 else (256,64) if dep<16 else (512,128)) if f=='H' else (256 if dep<4 else 1024 if dep<10 else 4096,2)
   q=' '.join(map(str,(f,*b,n,k)));p.stdin.write(q+'\n');p.stdin.flush()
   ans=p.stdout.readline().strip()
   if not ans:raise RuntimeError((q,p.poll()))
   if ans=='empty':act='empty'
   else:
    lo,hi,*_=map(int,ans.split())
    if (lo>0 if f=='H' else hi<0):act='sign'
    elif dep>=(18 if f=='H' else 20):act='open'
    else:
     axis=max((0,2,4),key=lambda i:(b[i+1]-b[i])*(4 if i==0 else 1));mid=(b[axis]+b[axis+1])//2;assert b[axis]<mid<b[axis+1]
     act='split'+str(axis)
     for side in (1,0):
      c=list(b);c[axis+1-side]=mid;todo.append((key+str(side),tuple(c)))
   print(key,q,ans,act,file=o)
 p.stdin.close();assert p.wait()==0
if __name__=='__main__':
 Path(sys.argv[2]).mkdir(exist_ok=False)
 with ProcessPoolExecutor(6) as pool:list(pool.map(run,tasks()))
