"""Check exact integer boxes, dyadic tree, every terminal replay and recorded sign."""
import sys,subprocess,json
from pathlib import Path
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
U=1<<20
def check(arg):
 d,file=arg;j=int(file.stem[:-1]);f=file.stem[-1]
 slab=j if d=='leaves' else j//4
 a=slab*U//32;b=(slab+1)*U//32
 if d=='finer':b=min(b,(2*U+4)//5)
 if d!='leaves':a,b=a+(b-a)*(j%4)//4,a+(b-a)*(j%4+1)//4
 root=(a,b,0,U if f=='H' else 0,U//8 if f=='V' else 0,U//8 if f=='Z' else U)
 negative=f!='H' and slab<20
 expect={'x':root};queries=[];answers=[];cnt=Counter();margin=None
 for line in file.read_text().splitlines():
  key,mode,*v=line.split();box=tuple(map(int,v[:6]));act=v[-1]
  assert mode==f and expect.pop(key)==box
  if act.startswith('split'):
   i=int(act[-1]);assert i in (0,2,4);m=(box[i]+box[i+1])//2;assert box[i]<m<box[i+1]
   for side in (0,1):
    ch=list(box);ch[i+1-side]=m;expect[key+str(side)]=tuple(ch)
  else:
   cnt[act]+=1;ans=' '.join(v[8:-1]);queries.append(' '.join([mode,*v[:8]]));answers.append(ans)
   if act=='empty':assert box[2]**2+box[4]**2>U**2
   else:
    lo,hi,_,_=map(int,ans.split());val=-hi if negative else lo
    assert act==('sign' if val>0 else 'open')
    if val>0:margin=val if margin is None else min(margin,val)
 assert not expect
 exe=sys.argv[1] if d in ('leaves','finer') else sys.argv[2]
 r=subprocess.run([exe],input='\n'.join(queries)+'\n',text=True,capture_output=True,check=True)
 assert [s.strip() for s in r.stdout.splitlines()]==answers
 return dict(file=str(file),roots=list(root),counts=dict(cnt),sign_margin_units=margin)
if __name__=='__main__':
 work=[]
 for d in sys.argv[3:]:
  if d=='leaves': labels=[(j,f) for j in range(4,32) for f in 'HVZ' if f=='H' or j<13 or j>=20]
  else:
   ranges={'finer':range(32,52),'low':range(4,32),'window':range(48,64),'thin':range(8,16)}
   labels=[(j,f) for j in ranges[d] for f in ('HVZ' if d=='finer' else 'VZ' if d=='low' and j<16 else 'H')]
  fs=sorted(Path(d).glob('*.tsv'));assert {p.name for p in fs}=={f'{j:02}{f}.tsv' for j,f in labels}
  work += [(d,p) for p in fs]
 with ProcessPoolExecutor(6) as pool:
  for v in pool.map(check,work):print(json.dumps(v),flush=True)
