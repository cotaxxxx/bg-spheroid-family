"""Final dyadic refinement of core boxes unresolved at the tightened grids."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import sys,subprocess
def work(f):
 p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
 with (Path(sys.argv[2])/f.name).open('w') as o:
  for l in f.read_text().splitlines():
   root,_,*v=l.split()
   if v[-1]!='open':continue
   stack=[('',tuple(map(int,v[:6])))]
   while stack:
    key,b=stack.pop()
    modes=([('X',512,128)] if b[2]>0 else [])+[('H',2048,32),('H',4096,64)]
    for mode,n,k in modes:
     q=' '.join(map(str,(mode,*b,n,k)));p.stdin.write(q+'\n');p.stdin.flush();ans=p.stdout.readline().strip()
     if ans=='empty' or int(ans.split()[0])>0:break
    if ans=='empty':act='empty'
    elif int(ans.split()[0])>0:act='sign'
    elif len(key)==6:act='open'
    else:
     i=max((0,2,4),key=lambda i:(b[i+1]-b[i])*(8 if i==0 else 1));act=f'split{i}';m=(b[i]+b[i+1])//2
     for side in (1,0):
      c=list(b);c[i+1-side]=m;stack.append((key+str(side),tuple(c)))
    print(root+':x'+key,q,ans,act,file=o)
 p.stdin.close();assert p.wait()==0
if __name__=='__main__':
 Path(sys.argv[2]).mkdir(exist_ok=False)
 with ProcessPoolExecutor(4) as pool:list(pool.map(work,sorted(Path('recovered').glob('*.tsv'))))
