import numpy as np
from scipy.special import roots_legendre
t,w=roots_legendre(400);u=(t+1)/2;w=w/2
ang=np.pi*u[None,:];wm=w[:,None]*w[None,:]
for l in [0.3,.125,.05,.01,.001,1e-5]:
 def grad(r,z):
  v=np.zeros(2)
  for sign in [-1,1]:
   m=sign*u[:,None];s=np.sqrt(1-m*m);x=s*np.cos(ang);y=s*np.sin(ang);B=np.hypot(s,m/l);D=np.sqrt((x-r)**2+y*y+(l*(m-z))**2);g=np.clip((1-r*x-z*m)/(D*B),0,1);a=np.arccos(g);P=2/np.sinc(a/np.pi);J=g*P-a*a;K=g*g*P
   for i,(xi,ui,fac) in enumerate([(x,(x-r)/D,1),(m,l*(m-z)/D,l)]):v[i]+=np.sum(wm*(xi*J-fac*B*ui*K))/2
  return v
 print(l,[tuple(grad(r,z)) for r,z in [(1,0),(.98,0),(.6,.8),(0,1)]])
