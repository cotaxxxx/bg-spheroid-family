// Original sphere, direct radial gradient, zero-mean constant removed.
I radial(const Outer& p,int nm,int na){
 I acc=0,J0=tb->get(JG,I(0));
 for(int i=0;i<nm;i++){
  I h{double(i)/nm,double(i+1)/nm},m2=sq(h),s=root(1-m2);
  I B=accurate_B(m2,1-m2,p.eps,p.ecc),b=root(B);
  for(const auto& ar:arcs(na)){
   I x=s*ar.c,dx=x-p.r,A=sq(s-p.r)+2*p.r*s*(1-ar.c);
   for(int sign:{-1,1}){
    I mu=sign*h,dz=mu-p.z,D=root(A+sq(p.l*dz));
    I k=meet(1-p.r*x-p.z*mu,(p.delta+A+sq(dz))*.5);
    I g=D.l>0?bound01(k/(D*b)):I(0,1);
    I ux=ratio_unit(dx,D);
    acc=acc+x*(tb->get(JG,g)-J0)-b*ux*tb->get(KG,g);
   }
  }
 }
 return acc/(2.*nm*na);
}
