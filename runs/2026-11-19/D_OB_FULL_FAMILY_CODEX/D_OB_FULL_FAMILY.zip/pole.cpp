#define main original_main
#include "kernel.cpp"
#undef main
int main(){
 setup();tb=std::make_unique<Tables>();int a,b,n;
 while(std::cin>>a>>b>>n){
 I l{a/SCALE,b/SCALE},ep=inv(sq(l)),val=0,der=0;
 for(int i=0;i<n;i++){
 I x{double(i)/n,double(i+1)/n},x2=sq(x),mu=1-2*x2,mu2=sq(mu);
 I B=1+(ep-1)*mu2,C=(1-x2)+sq(l)*x2;
 I T=x/root(C),g=bound01(T/root(B)),M=sq(l)*root(B)*T;
 I K=tb->get(KG,g),Q=tb->get(QV,g);
 I A=mu2*ep/(l*B),V=l*x2/C;
 I weight=I(2*i+1)/(double(n)*n);
 val=val+weight*(mu*tb->get(JG,g)+M*K);
 der=der+weight*((mu+M*g)*Q*g*(A-V)+M*(2/l-A-V)*K);
 }
 for(I y:{val,der}) std::cout<<(long long)std::floor(y.l*0x1p36)<<' '<<(long long)std::ceil(y.h*0x1p36)<<' ';
 std::cout<<std::endl;
 }
}
