"""Replay every supplementary terminal using its recorded grid and verify geometry."""
import sys,subprocess,json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
U=1<<20
def job(arg):
 d,f=arg;j=int(f.stem[:-1])
 root=(j*U//(128 if d=='thin' else 256),(j+1)*U//(128 if d=='thin' else 256),0,U,0,U)
 stack={'x':root};term=[];expected=[];counts={}
 for line in f.read_text().splitlines():
  key,mode,*v=line.split();box=tuple(map(int,v[:6]));assert stack.pop(key)==box
  assert mode=='H' or mode=='X' and box[2]>0
  act=v[-1]
  if act.startswith('split'):
   axis=int(act[-1]);assert axis in (0,2,4)
   m=(box[axis]+box[axis+1])//2;assert box[axis]<m<box[axis+1]
   for side in (0,1):
    c=list(box);c[axis+1-side]=m;stack[key+str(side)]=tuple(c)
  else:
   if act=='empty':assert box[2]**2+box[4]**2>U**2
   else:assert act==('sign' if int(v[8])>0 else 'open')
   term.append(' '.join([mode,*v[:8]]));expected.append(' '.join(v[8:-1]));counts[act]=counts.get(act,0)+1
 assert not stack
 out=subprocess.run([sys.argv[1]],input='\n'.join(term)+'\n',text=True,capture_output=True,check=True)
 assert [s.strip() for s in out.stdout.splitlines()]==expected
 return [str(f),counts]
if __name__=='__main__':
 with ProcessPoolExecutor(4) as pool:
  for val in pool.map(job,[(d,Path(d)/f'{j:02}H.tsv') for d in sys.argv[2:] for j in range(8,16)]):print(json.dumps(val),flush=True)
