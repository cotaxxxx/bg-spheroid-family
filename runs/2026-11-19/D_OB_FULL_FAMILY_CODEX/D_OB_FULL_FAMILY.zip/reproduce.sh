#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
for f in BEFORE*.sha256; do sha256sum --quiet -c "$f"; done
src=$PWD
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
cp ./*.py ./*.cpp ./*.hpp ./*.inc "$tmp/"
cd "$tmp"
fp=(-std=c++20 -O3 -ffp-contract=off -fno-fast-math -frounding-math)
for f in map graded pole rim pole_prec;do g++ "${fp[@]}" "$f.cpp" -o "$f"; done
python3 cover.py ./map leaves
python3 refine.py ./map finer
python3 low.py ./graded low
python3 window.py ./graded window
python3 thin.py ./graded thin
python3 mixed.py ./rim mixed
python3 recover.py ./rim recovered
python3 salvage.py ./rim salvage
python3 rim.py ./rim > rim.tsv
python3 pole.py ./pole > pole.tsv
for d in leaves finer low window thin mixed recovered salvage; do diff -qr "$src/$d" "$d"; done
cmp "$src/rim.tsv" rim.tsv
cmp "$src/pole.tsv" pole.tsv
python3 bracket.py ./pole_prec > bracket.log
cmp "$src/bracket.log" bracket.log
python3 checker.py ./map ./graded leaves finer low window
python3 optional_check.py ./rim thin mixed
python3 validate_extra.py ./rim rim recovered salvage
for f in rim.unresolved salvage.unresolved; do cmp "$src/$f" "$f"; done
