"""Exact identities used for the axis, centre, and equatorial rim."""
import sympy as S
m,z,l=sym=S.symbols('m z l',real=True)
s2=1-m*m;d2=s2+l*l*(m-z)**2;k=1-m*z;R=m-l*l*(m-z)
assert S.expand(m*d2-k*l*l*(m-z)-s2*R)==0
C=1-(1-l*l)*m*m;B=1+(1/l**2-1)*m*m
assert S.factor(m*(-S.diff(C,m)/(2*C)-S.diff(B,m)/(2*B))+1-1/B-(1-l*l)*m*m/C)==0
x=S.symbols('x');y2=1-m*m-x*x;k=1-x;R2=k*k+y2;D2=R2+l*l*m*m
assert S.factor(x*k-y2+(k**3+k*y2)/D2-m*m*(1-l*l*k/D2))==0
assert S.factor(D2-2*l*l*k-(1-l*l)*R2)==0
print('axis, centre IBP and two rim identities: exact zero residuals')
