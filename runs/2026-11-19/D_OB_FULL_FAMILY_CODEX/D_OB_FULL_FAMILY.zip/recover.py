"""Supplementary finite cover of unresolved core boxes."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import sys,subprocess
def job(f):
 p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
 with (Path(sys.argv[2])/f.name).open('w') as out:
  for line in f.read_text().splitlines():
   key,_,*v=line.split()
   if v[-1]!='open':continue
   b=tuple(map(int,v[:6]))
   queries=([('X',512,128),('X',1024,256)] if b[2]>0 else [])+[('H',1024,16),('H',2048,32),('H',2048,64)]
   for mode,n,k in queries:
    q=' '.join(map(str,(mode,*b,n,k)));p.stdin.write(q+'\n');p.stdin.flush()
    ans=p.stdout.readline().strip()
    if int(ans.split()[0])>0:break
   print(key,q,ans,'sign' if int(ans.split()[0])>0 else 'open',file=out)
 p.stdin.close();assert p.wait()==0
if __name__=='__main__':
 Path(sys.argv[2]).mkdir(exist_ok=False)
 with ProcessPoolExecutor(4) as pool:list(pool.map(job,sorted(Path('mixed').glob('*.tsv'))))
