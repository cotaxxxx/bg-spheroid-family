import sys,subprocess
p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
def sign(x):
 for n in [65536,262144,1048576,4194304]:
  p.stdin.write(f'{x} {x} {n}\n');p.stdin.flush();a,b,c,d=map(int,p.stdout.readline().split())
  print(x,n,a,b,c,d)
  if b<0:return -1
  if a>0:return 1
 return 0
a,b=5*(1<<17),692061
assert sign(a)==-1 and sign(b)==1
while b-a>16:
 m=(a+b)//2;s=sign(m)
 if s<0:a=m
 elif s>0:b=m
 else:
  if sign(m-4)<0 and sign(m+4)>0:a,b=m-4,m+4
  break
print('bracket',a,b,'denominator',1<<20)
p.stdin.close();assert p.wait()==0
