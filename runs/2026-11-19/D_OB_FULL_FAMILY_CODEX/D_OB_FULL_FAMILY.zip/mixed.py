"""Tail compact extension, mixed H and direct radial sign."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import sys,subprocess
U=2**20
def run(j):
 b0=(j*U//256,(j+1)*U//256,0,U,0,U)
 p=subprocess.Popen([sys.argv[1]],stdin=-1,stdout=-1,text=True)
 with (Path(sys.argv[2])/f'{j:02}H.tsv').open('w') as out:
  todo=[('x',b0)]
  while todo:
   key,b=todo.pop();depth=len(key)-1
   modes=['X','H'] if b[2]>=U//4 else ['H','X'] if b[2]>0 else ['H']
   for mode in modes:
    n,k=((32,16) if depth<6 else (64,32) if depth<10 else (128,64) if depth<14 else (256,128)) if mode=='X' else ((64,16) if depth<5 else (128,32) if depth<9 else (256,64) if depth<13 else (512,64))
    q=' '.join(map(str,(mode,*b,n,k)));p.stdin.write(q+'\n');p.stdin.flush();ans=p.stdout.readline().strip()
    if ans=='empty' or int(ans.split()[0])>0:break
   if ans=='empty':act='empty'
   elif int(ans.split()[0])>0:act='sign'
   elif depth>=14:act='open'
   else:
    axis=max((0,2,4),key=lambda i:(b[i+1]-b[i])*(8 if i==0 else 1))
    mid=(b[axis]+b[axis+1])//2;act='split'+str(axis)
    for side in (1,0):
     ch=list(b);ch[axis+1-side]=mid;todo.append((key+str(side),tuple(ch)))
   print(key,q,ans,act,file=out)
 p.stdin.close();assert p.wait()==0
if __name__=='__main__':
 Path(sys.argv[2]).mkdir(exist_ok=False)
 with ProcessPoolExecutor(4) as pool:list(pool.map(run,range(8,16)))
