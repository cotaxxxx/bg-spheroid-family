"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Explicit cap-bound outward evaluations."""
from flint import arb,fmpq as Q,ctx
from pathlib import Path
import json
ctx.prec=192
rows=[]
for XX,LL in [(1,128),(1,256),(4,4096),(16,65536)]:
    e=arb(Q(1,LL));X=arb(XX);c=arb(Q(15,16));h=1-c
    z=1-e*e*X;r=e*X.sqrt();d=z-c
    assert d>0 and r<h
    ss=(1-c*c).sqrt()
    QQ=e*e*(1+r)**2/(d*d);T=e*e/(ss*ss)
    K=(1-r/h)/(1+QQ)
    L=(1-r/h)/((1+QQ)*(1+T)).sqrt()
    G=e*((1+e*e*X/d)/ss+r/d)
    p=arb.pi()
    negative_upper=p*e*X/(z*(1+z))*(1+2*X/(3*arb(3).sqrt()))
    positive_lower=L/2*((2*p-3*G)*(1-ss)+(p-2*G)*K*c.asin())
    negative_lower_half=p/z*(1+r/2)
    lower=positive_lower-negative_lower_half-negative_upper
    rows.append({'X':XX,'Lambda_cap':LL,'cut':'15/16','lower_bound_Ez_over_epsilon':str(lower),'rational_lower':str(lower.lower().fmpq()),'greater_than_1_4':bool(lower>arb(Q(1,4))),'positive':bool(lower>0),'parts':{'positive_lower':str(positive_lower),'negative_mu_bound':str(negative_lower_half),'upper_cap_negative_bound':str(negative_upper)}})
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','precision_bits':ctx.prec,'rows':rows}
Path(__file__).with_name('POLE_BOUND_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
