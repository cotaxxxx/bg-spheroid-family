"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Ancillary rational inequalities, 192-bit Arb."""
from flint import arb,fmpq as Q,ctx
from pathlib import Path
import json
ctx.prec=192
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','G_second_upper':str(8+4*arb(2).log()),'G_second_less_than_11':bool(8+4*arb(2).log()<11),'small_S_coefficient_lower_div_pi':str(1-arb(Q(1,4096))-(11+arb(16).log())/64),'small_S_greater_than_three_quarters':bool(1-arb(Q(1,4096))-(11+arb(16).log())/64>arb(Q(3,4))),'large_S_log_margin':str(18*arb(2).log()-11),'large_S_margin_greater_than_one':bool(18*arb(2).log()-11>1),'Hessian_constant_3pi_plus_2':str(3*arb.pi()+2),'Hessian_constant_less_than_12':bool(3*arb.pi()+2<12)}
Path(__file__).with_name('TRANSFER_BOUND_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
