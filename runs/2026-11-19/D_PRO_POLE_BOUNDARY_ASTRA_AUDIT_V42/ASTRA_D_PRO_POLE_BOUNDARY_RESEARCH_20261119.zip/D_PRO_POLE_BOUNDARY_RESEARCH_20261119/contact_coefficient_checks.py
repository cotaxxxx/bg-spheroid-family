"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact differential and cap constants."""
import sympy as s,json
from pathlib import Path
d,l,u,c=s.symbols('d l u c',positive=True)
T=l*(d*s.log(d)-(d+l)*s.log(d+l))
checks={
 'T_d':s.simplify(s.diff(T,d)-l*s.log(d/(d+l)))==0,
 'T_dd':s.simplify(s.diff(T,d,2)-l*l/(d*(d+l)))==0,
 'T_dl':s.simplify(s.diff(T,d,l)-(s.log(d/(d+l))-l/(d+l)))==0,
 'T_ll':s.simplify(s.diff(T,l,2)+2*s.log(d+l)+2+l/(d+l))==0,
 'distance_decomposition':s.expand(1+u*u-2*u*c-(u-c)**2-(1-c*c))==0,
}
th=s.symbols('th',positive=True)
f=s.log(4*s.sin(th))+s.cot(th)*(s.pi/2-th)
checks['coefficient_monotonicity']=s.simplify(s.diff(f,th)+(s.pi/2-th)/s.sin(th)**2)==0
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','checks':checks,'all_exact':all(checks.values())}
Path(__file__).with_name('CONTACT_ALGEBRA_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
