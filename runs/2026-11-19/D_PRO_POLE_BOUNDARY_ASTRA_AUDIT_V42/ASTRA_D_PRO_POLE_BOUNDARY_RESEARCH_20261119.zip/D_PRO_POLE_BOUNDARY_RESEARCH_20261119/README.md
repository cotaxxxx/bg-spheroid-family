# D-PRO pole boundary research
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Main report: `ASTRA_D_PRO_POLE_BOUNDARY_REPORT_20261119.md`.

No global Lambda0 has been obtained. The number 256 applies only to the
shrinking polar region 1-z^2<=lambda^-2. The number 65536 controls the
two-term approximation, not the true global gradient.

Files:
- `pole_rational_check.py`: standard-library rational verification of the
  cap constant. Depends on the analytic kernel estimates proved in the report.
- `pole_lower_bound.py`: Arb evaluation of four predeclared cap constants;
  the insufficient lambda=128 bound is retained.
- `compact_constants.py`: scalar checks of explicit compact thresholds;
  does not independently verify the Cauchy majorant argument.
- `contact_coefficient_checks.py`, `transport_identity.py`: exact symbolic
  differential identities.
- `transfer_bounds.py`: auxiliary Arb constant inequalities.
- `pole_diagnostics.py`: 28 fixed primitive derivative evaluations, mpmath,
  nonrigorous; no sign selection or full-domain certification.
- `inputs/`: read-only source copies, including the user instruction.
- `SOURCE_CHECK.json`, `ENVIRONMENT.json`, result JSONs and numerical log.

Copy the sealed package to a new directory before re-running scripts, because
they write results in their own directory. Minimal standard-library check:

```bash
python pole_rational_check.py
```

Arb scripts require python-flint 0.8.0. Symbolic scripts require SymPy;
the diagnostic requires mpmath. Versions are in ENVIRONMENT.json.

No external PC operation or repository write was performed. No existing
evidence or earlier sealed package was modified. SHA256SUMS excludes itself;
the zip SHA-256 is supplied outside the zip.
