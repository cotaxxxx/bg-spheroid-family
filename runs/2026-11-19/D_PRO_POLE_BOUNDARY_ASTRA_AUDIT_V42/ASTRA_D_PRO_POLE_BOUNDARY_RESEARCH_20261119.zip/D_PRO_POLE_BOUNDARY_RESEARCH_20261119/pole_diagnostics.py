"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Primitive E_z, no interval claim."""
import mpmath as mp,json,time
from pathlib import Path
mp.mp.dps=40
def evaluate(lam,X,u,nm=32,np=64):
    lam,X,u=map(mp.mpf,(lam,X,u));ep=1/lam;z=mp.sqrt(1-X*ep*ep);r=u*ep*mp.sqrt(X)
    nodes,weights=mp.gauss_quadrature(nm,'legendre');pn,pw=mp.gauss_quadrature(np,'legendre')
    phis=[((v+1)*mp.pi/2,w*mp.pi/2) for v,w in zip(pn,pw)]
    cuts=[mp.mpf(-1),mp.mpf(1),z]
    for j in range(1,int(mp.ceil(2*mp.log10(lam)))+4):
        d=mp.mpf(10)**(-j)
        cuts.extend([-1+d,1-d,max(mp.mpf(-1),z-d),min(mp.mpf(1),z+d)])
    cuts=sorted(set(cuts));total=mp.mpf(0)
    for lo,hi in zip(cuts,cuts[1:]):
        mid=(lo+hi)/2;half=(hi-lo)/2
        for nd,ww in zip(nodes,weights):
            mu=mid+half*nd;s=mp.sqrt(1-mu*mu);B=s*s+ep*ep*mu*mu;v=mu-z
            for ph,wp in phis:
                k=1-z*mu-r*s*mp.cos(ph);A=s*s+r*r-2*r*s*mp.cos(ph)
                d2=v*v+ep*ep*A;gam=ep*k/mp.sqrt(d2*B)
                if gam<0 or gam>1:raise ArithmeticError('gamma outside geometry')
                angle=mp.acos(gam);F=mp.pi*mp.asin(gam)-mp.asin(gam)**2
                Fp=2 if gam==1 else 2*angle/mp.sqrt(1-gam*gam)
                kernel=mu*(F+gam*Fp)-k*gam*Fp*v/d2
                total+=half*ww*wp*kernel
    return total/(2*mp.pi),r,z
if __name__=='__main__':
    start=time.monotonic();rows=[];root=Path(__file__).parent
    cases=[(L,X,u,32,64) for L in [5,20,100] for X in ['0.25','1','4'] for u in ['0','0.5','0.9']]+[(20,'1','0.9',48,96)]
    for L,X,u,nm,np in cases:
        st=time.monotonic();ez,r,z=evaluate(L,X,u,nm,np)
        row={'lambda':L,'X':X,'u':u,'rho':mp.nstr(r,28),'z':mp.nstr(z,28),'grid':[nm,np],'Ez':mp.nstr(ez,28),'lambda_Ez':mp.nstr(L*ez,28),'seconds':time.monotonic()-st}
        rows.append(row);print(json.dumps(row),flush=True)
        out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','planned_cases':len(cases),'completed_cases':len(rows),'rows':rows}
        (root/'POLE_DIAGNOSTICS.json').write_text(json.dumps(out,indent=2)+'\n')
        if time.monotonic()-start>600:break
