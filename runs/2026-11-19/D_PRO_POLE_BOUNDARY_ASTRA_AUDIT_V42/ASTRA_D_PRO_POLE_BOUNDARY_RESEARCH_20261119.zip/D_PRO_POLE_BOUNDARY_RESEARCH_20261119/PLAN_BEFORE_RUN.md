# Pole boundary-layer calculation plan
2026-11-18 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Read-only inputs: user instruction, V41 audit, pinned upstream commit
7d9e921bd3d7e138ed3971e0c63116e280b17277, prior sealed needle report.

First experiment: evaluate the newly derived axial-gradient lower bound for
the entire shrinking cap 1-z^2 <= X/lambda^2, rho^2+z^2<=1, z>0.
Fixed rational cases (X,Lambda)=(1,128),(1,256),(4,4096),(16,65536).
Cut c=15/16, 192-bit Arb. Compare the rigorous lower endpoint against 1/4.
These inequalities concern E_z/epsilon, not H and not the entire ball.
No grid tuning, no sign-based point selection. Failure is preserved.

Second experiment, numerical only: direct primitive axial derivative at
lambda=5,20,100; X=1/4,1,4 and rho/sqrt(1-z^2)=0,1/2,9/10.
All points use z=sqrt(1-X/lambda^2). Fixed 40-decimal mpmath Gauss-Legendre
quadrature, 32 mu nodes per segment and 64 azimuth nodes. Split at mu=z and
decimal distances down to lambda^-2/100 and at both poles. One fixed
refinement lambda=20,X=1,u=9/10 with 48x96. Record derivatives and times,
not evidence. Maximum 600 seconds; retain partial output on timeout.

Analytic constants and mathematical exclusions will be distinguished from
these nonrigorous sample integrals.
