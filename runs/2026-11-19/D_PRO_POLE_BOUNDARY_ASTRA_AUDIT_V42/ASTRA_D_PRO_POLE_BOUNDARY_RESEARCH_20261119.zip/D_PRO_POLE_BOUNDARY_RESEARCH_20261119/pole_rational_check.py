"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Rational proof of the X=1 cap constant."""
from fractions import Fraction as Q
from pathlib import Path
import json
def atan_bounds(x,n=6):
    partial=sum((-1)**j*x**(2*j+1)/Q(2*j+1) for j in range(n))
    nxt=(-1)**n*x**(2*n+1)/Q(2*n+1)
    return min(partial,partial+nxt),max(partial,partial+nxt)
a,b=atan_bounds(Q(1,5));c,d=atan_bounds(Q(1,239));pi_lo=16*a-4*d;pi_hi=16*b-4*c
e=Q(1,256);r=e;z=Q(9999,10000);cut=Q(15,16);gap=z-cut
Qupper=e*e*(1+r)**2/gap**2
Tupper=e*e/Q(31,256)
Gupper=e*(3*(1+e*e/gap)+r/gap)
checks={'pi_lower':pi_lo>Q(157,50),'pi_upper':pi_hi<Q(22,7),'z_lower':1-e*e>z,'Q_upper':Qupper<Q(1,250),'T_upper':Tupper<Q(1,7000),'K_lower':Q(15,16)/Q(251,250)>Q(93,100),'L_lower':(Q(15,16)/Q(93,100))**2>Q(251,250)*Q(7001,7000),'G_upper':Gupper<Q(3,250),'s_ge_one_third':Q(31,256)>Q(1,9),'s_le_seven_twentieths':Q(31,256)<Q(49,400),'sqrt3_ge_five_thirds':Q(3)>Q(25,9),'asin_lower':Q(6,5)-Q(6,5)**3/6+Q(6,5)**5/120<cut}
positive=Q(93,200)*((2*Q(157,50)-3*Q(3,250))*Q(13,20)+(Q(157,50)-2*Q(3,250))*Q(93,100)*Q(6,5))
negative=Q(22,7)/z*(1+r/2)
cap=Q(22,7)*e/(z*(1+z))*Q(7,5)
lower=positive-negative-cap
checks['final_lower_gt_one_quarter']=lower>Q(1,4)
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','all_exact':all(checks.values()),'checks':checks,'rational_lower':str(lower),'display_lower':float(lower),'claim':'lambda >=256, 1-z^2<=lambda^-2, z>0: E_z>=1/(4lambda), subject to the analytic kernel proof.'}
Path(__file__).with_name('POLE_RATIONAL_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
