"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Checks explicit compact thresholds in log form."""
from flint import arb,fmpq as Q,ctx
from pathlib import Path
import json
ctx.prec=192;rows=[]
for m in [Q(1,2),Q(1,4),Q(1,8)]:
    C=Q(2**100)/m**40;B=Q(2**60)/m**14
    n=Q(2**80)/m**16;assert n.denominator==1
    logLambda=arb(n)*arb(10).log();root=arb(m).sqrt();p=arb.pi()
    req_h=5*(2/arb(m)).log()
    req_b=4*arb(B)/(p*root)
    req_R=5*(48*arb(C)/(p*root)).log()
    rows.append({'m':str(m),'C_m_exact':str(C),'B_m_exact':str(B),'Lambda_compact':'10^('+str(n)+')','decimal_exponent_exact':str(n),'conditions':{'h_le_m_over_2':bool(logLambda>req_h),'b_subdominant':bool(logLambda>req_b),'C2_remainder_subdominant':bool(logLambda>req_R)},'log_lambda':str(logLambda),'log_requirements':{'h':str(req_h),'b':str(req_b),'remainder':str(req_R)}})
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','conditional_scope':'Uses analytic Cauchy majorant lemma in report; NOT a global threshold.','precision_bits':ctx.prec,'rows':rows}
Path(__file__).with_name('COMPACT_CONSTANT_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
