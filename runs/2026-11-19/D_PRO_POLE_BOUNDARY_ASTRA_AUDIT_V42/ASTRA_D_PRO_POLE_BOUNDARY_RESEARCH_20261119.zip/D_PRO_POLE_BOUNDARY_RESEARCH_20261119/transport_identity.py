"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact transport identity, rational check."""
import sympy as s,json
from pathlib import Path
mu,z,r,e,c=s.symbols('mu z r e c',real=True)
ss=s.sqrt(1-mu*mu);chi=1-z*z
k=1-z*mu-r*ss*c;A=ss*ss+r*r-2*r*ss*c
d2=(mu-z)**2+e*e*A;B=ss*ss+e*e*mu*mu
Tk=chi*s.diff(k,z)+(1-mu*mu)*s.diff(k,mu)
Tloggamma=Tk/k-(chi*s.diff(d2,z)+(1-mu*mu)*s.diff(d2,mu))/(2*d2)-(1-mu*mu)*s.diff(B,mu)/(2*B)
claimed=-r*z*ss*c/k+e*e*(-z*A+mu*r*(ss*c-r))/d2+(1-e*e)*mu*(1-mu*mu)/B
checks={'Tk':s.simplify(Tk+(mu+z)*k+r*z*ss*c)==0,'Tloggamma':s.simplify(Tloggamma-claimed)==0}
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','checks':checks,'all_exact':all(checks.values())}
Path(__file__).with_name('TRANSPORT_IDENTITY_RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
