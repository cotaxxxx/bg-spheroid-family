"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Independent tree traversal and exact terminal replay."""
import concurrent.futures
import csv
from fractions import Fraction
import gzip
import json
from pathlib import Path
import subprocess
import sys
import time
U=1<<20
def verify(task):
    file,exe=task
    now=time.monotonic()
    label=file.name.split('.')[0];f=label[0];i=int(label[1:])
    with gzip.open(file,'rt') as stream: raw=list(csv.DictReader(stream,delimiter='\t'))
    data={row['path']:row for row in raw}
    assert len(data)==len(raw)
    lo=U+i*(U//4)
    rrange=(0,0) if f in 'CB' else (0,U//8) if f=='T' else (0,U)
    zrange=(0,U//4) if f=='Z' else (U//4,U) if f=='V' else (0,0)
    root=(lo,lo+U//4,*rrange,*zrange)
    todo=[('x',root)];term=[];seen=set();vol=Fraction()
    while todo:
        key,box=todo.pop()
        row=data[key];assert key not in seen;seen.add(key)
        assert tuple(map(int,[row[n] for n in ('l0','l1','r0','r1','z0','z1')]))==box
        action=row['action']
        if action.startswith('split'):
            j={'l':0,'r':2,'z':4}[action[-1]]
            mid,rem=divmod(box[j]+box[j+1],2)
            assert rem==0 and box[j]<mid<box[j+1]
            a=list(box);b=list(box);a[j+1]=b[j]=mid
            todo.extend([(key+'0',tuple(a)),(key+'1',tuple(b))])
            continue
        vol+=Fraction(1,2**(len(key)-1))
        mode=row['mode']
        if action=='empty':
            assert box[2]**2+box[4]**2>U**2
        else:
            al,ah,bl,bh=(int(row[k]) for k in ('alo','ahi','blo','bhi'))
            assert al<=ah and bl<=bh
            if f in 'VZ': assert mode==f and action=='positive' and al>0
            elif f=='B':
                assert mode=='B' and action=='H_positive' and al>0
            elif f=='E':
                assert mode=='E' and ((action=='H_positive' and al>0) or
                    (action=='radial_curvature_negative' and bh<0 and box[2]>0))
            else: raise AssertionError(f)
        query=' '.join(map(str,(mode,*box,row['n'],row['k'])))
        expect='empty' if action=='empty' else ' '.join(row[n] for n in ('alo','ahi','blo','bhi'))
        term.append((query,expect))
    assert len(seen)==len(raw) and vol==1
    term.reverse()
    res=subprocess.run([exe],input=''.join(q+'\n' for q,_ in term),text=True,capture_output=True,timeout=360,check=True)
    vals=[s.strip() for s in res.stdout.splitlines()]
    assert vals==[r for _,r in term] and not res.stderr
    return dict(root=label,nodes=len(raw),terminal_replayed=len(term),relative_volume=str(vol),
                seconds=round(time.monotonic()-now,5))
if __name__=='__main__':
    start=time.monotonic();files=sorted(Path(sys.argv[1]).glob('*.tsv.gz'))
    assert {f.name for f in files}=={f"{g}{i:02}.tsv.gz" for g in "VZEB" for i in range(4)}
    with concurrent.futures.ProcessPoolExecutor(8) as pool:
        for r in pool.map(verify,[(f,sys.argv[2]) for f in files]):print(json.dumps(r),flush=True)
    print(json.dumps(dict(wall_s=time.monotonic()-start)))
