#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
d=$(mktemp -d)
fp=(-std=c++20 -ffp-contract=off -fno-fast-math -frounding-math)
g++ "${fp[@]}" -O3 kernel.cpp -o "$d/k"
python3 cover.py "$d/k" VZ "$d/f"
python3 finalcover.py "$d/k" EB "$d/f"
for f in final/*.gz; do cmp <(gzip -dc "$f") <(gzip -dc "$d/f/${f##*/}"); done
g++ "${fp[@]}" -O2 -fsanitize=undefined -fno-sanitize-recover=all kernel.cpp -o "$d/c"
python3 checker.py "$d/f" "$d/c"
