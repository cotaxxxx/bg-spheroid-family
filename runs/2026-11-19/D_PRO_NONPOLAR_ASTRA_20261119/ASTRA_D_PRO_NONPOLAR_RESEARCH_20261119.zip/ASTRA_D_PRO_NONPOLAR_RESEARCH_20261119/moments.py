"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact algebra, Arb azimuth moments."""
from fractions import Fraction
from flint import arb,fmpq as Q,ctx
import math
ctx.prec=192

def iv(a,b):
 a,b=Q(a),Q(b)
 return arb((a+b)/2,(b-a)/2)
def sq(x):
 a,b=x.lower().fmpq(),x.upper().fmpq()
 return iv(0 if a<=0<=b else min(a*a,b*b),max(a*a,b*b))
def powq(x,p):
 if not x>0:raise ArithmeticError('nonpositive power base')
 return (x.log()*arb(p)).exp()
def add(a,b):
 c=[arb(0)]*max(len(a),len(b))
 for i,v in enumerate(a):c[i]+=v
 for i,v in enumerate(b):c[i]+=v
 return c
def mul(a,b):
 c=[arb(0)]*(len(a)+len(b)-1)
 for i,v in enumerate(a):
  for j,w in enumerate(b):c[i+j]+=v*w
 return c
def power(a,n):
 c=[arb(1)]
 for _ in range(n):c=mul(c,a)
 return c
def scaled(a,c):return [x*c for x in a]
def horner(a,x):
 out=arb(0)
 for c in reversed(a):out=out*x+c
 return out

def rational_coefficients(N=4):
 a=[Fraction(1)]
 for n in range(N+1):a.append(a[-1]*Fraction(2*n+2,2*n+3))
 fp_h=[2*x for x in a[:N+1]]+[4*a[N+1]]
 q_h=[a[n]*Fraction(2*n*n+10*n+10,2*n+3) for n in range(N+1)]
 def togamma(cs):
  out=[Fraction(0)]*len(cs)
  for n,c in enumerate(cs):
   for j in range(n+1):out[j]+=c*Fraction((-1)**j*math.comb(n,j),2**n)
  return [Q(v.numerator,v.denominator) for v in out]
 return togamma(fp_h),togamma(q_h)

FP,QQ=rational_coefficients()
def envelope_avg(lam,rho,z,mu):
 lam,rho,z,mu=[x if isinstance(x,arb) else arb(x) for x in [lam,rho,z,mu]]
 ss2=1-sq(mu);ss=ss2.sqrt();vv=mu-z
 a=ss2+sq(rho)+sq(lam)*sq(vv);b=2*rho*ss
 B=ss2+sq(mu)/sq(lam);k0=1-z*mu
 if rho==0:
  gam=k0/(a*B).sqrt()
  return (horner(FP,gam)*sq(k0)*(a-ss2/2)-horner(QQ,gam)*(ss2/2)*sq(a-k0))/(powq(a,Q(5,2))*B.sqrt())
 if not b>0:raise ArithmeticError('b includes zero: needs axis chart')
 gap=sq(ss-rho)+sq(lam)*sq(vv)
 if not gap>0:raise ArithmeticError('contact moment chart needs further cancellation')
 ratio=1/(1+gap/b);xx=sq(ratio)
 if not xx<1:raise ArithmeticError('hypergeometric parameter reaches singular endpoint')
 c=1-sq(rho)-sq(z)-(sq(lam)-1)*sq(vv)
 kk=[c/2,arb(Q(1,2))];dk=[-c/2,arb(Q(1,2))]
 yy=[ss2*(1-sq(a)/sq(b)),2*ss2*a/sq(b),-ss2/sq(b)]
 dy=add([arb(0),arb(1)],scaled(yy,-1))
 cache={}
 def moment(p):
  if p not in cache:
   cache[p]=powq(a,-p)*xx.hypgeom_2f1(arb(p/2),arb((p+1)/2),1)
   if not cache[p].is_finite():raise ArithmeticError('nonfinite moment')
  return cache[p]
 out=arb(0)
 for coefs,second in [(FP,False),(QQ,True)]:
  for j,cj in enumerate(coefs):
   if not cj:continue
   if second:poly=mul(mul(power(kk,j),yy),power(dk,2))
   else:poly=mul(power(kk,j+2),dy)
   p=Q(j+5,2);value=arb(0)
   for n,pn in enumerate(poly):
    if pn==0:continue
    value+=pn*moment(p-n)
   value*=arb(cj)/powq(B,Q(j+1,2))
   out+=-value if second else value
 if not out.is_finite():raise ArithmeticError('nonfinite azimuth envelope')
 return out
