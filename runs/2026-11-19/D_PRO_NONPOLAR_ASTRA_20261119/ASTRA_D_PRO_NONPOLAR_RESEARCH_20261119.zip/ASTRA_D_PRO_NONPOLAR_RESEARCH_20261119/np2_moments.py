"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed moment checks and widths."""
from moments import *
import numpy as np,json,time
from pathlib import Path
from scipy.special import roots_legendre
XREF,WREF=roots_legendre(2048)
def fq(x):return int(x.p)/int(x.q)

def reference(lam,r,z,mu):
 x,w=XREF,WREF;phi=(x+1)*np.pi/2;ss=np.sqrt(1-mu*mu)
 a=ss*ss+r*r+lam*lam*(mu-z)**2;b=2*r*ss;D2=a-b*np.cos(phi)
 yy=ss*ss*np.sin(phi)**2;B=ss*ss+mu*mu/lam**2;k=1-z*mu-r*ss*np.cos(phi)
 ga=k/np.sqrt(D2*B)
 fp=np.polynomial.polynomial.polyval(ga,[fq(c) for c in FP]);q=np.polynomial.polynomial.polyval(ga,[fq(c) for c in QQ])
 return float(np.sum(w*(fp*k*k*(D2-yy)-q*yy*(D2-k)**2)/(D2**2.5*np.sqrt(B)))/2)

if __name__=='__main__':
 cases=[(Q(5),Q(0),Q(0),Q(0)),(Q(5),Q(0),Q(0),Q(1,2)),(Q(5),Q(1,2),Q(1,2),Q(0)),(Q(5),Q(1,2),Q(1,2),Q(1,2)),(Q(5),Q(1,2),Q(1,2),Q(3,4)),(Q(10),Q(3,4),Q(1,4),Q(1,4)),(Q(5),Q(1,1024),Q(1,2),Q(1,2)),(Q(5),Q(3,5)-Q(1,1024),Q(4,5),Q(4,5))]
 rows=[];root=Path(__file__).parent
 for ca in cases:
  row={'parameters':[str(v) for v in ca]};st=time.monotonic()
  try:
   v=envelope_avg(*ca);ref=reference(*map(fq,ca));err=arb(Q(1,10**7))
   row.update(point_interval=str(v),point_lower=str(v.lower().fmpq()),point_upper=str(v.upper().fmpq()),reference=ref,reference_agrees=bool((v+arb(0,Q(1,10**7))).contains(arb(str(ref)))))
   if ca[1]:
    box=envelope_avg(*ca[:3],iv(ca[3]-Q(1,16384),ca[3]+Q(1,16384)))
    row.update(mu_box_interval=str(box),mu_box_width=str(box.upper().fmpq()-box.lower().fmpq()))
  except Exception as ex:row['error']=str(ex)
  row['seconds']=time.monotonic()-st;rows.append(row);print(json.dumps(row),flush=True)
  (root/'NP2_MOMENTS.json').write_text(json.dumps({'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','precision_bits':192,'rows':rows},indent=2)+'\n')
