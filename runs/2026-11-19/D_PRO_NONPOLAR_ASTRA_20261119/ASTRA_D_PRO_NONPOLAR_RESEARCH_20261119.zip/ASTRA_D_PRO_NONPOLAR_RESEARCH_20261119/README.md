# D-PRO nonpolar research, 2026-11-19

**DIAGNOSTIC_ONLY / NOT_EVIDENCE**

Read `ASTRA_D_PRO_NONPOLAR_REPORT_20261119.md` first. No global Lambda threshold
has been established. This package contains analytic derivations, a small
central interval cover, noninterval diagnostics, and preserved failed approaches.
No repository or external research PC was modified.

## Files

- `np1_hessian.py`: 96 fixed binary64 surface probes; not enclosures.
- `moments.py`, `np2_moments.py`: Arb azimuth moments; the naive interval
  form has large widths and is NOT recommended for production.
- `centre_interval.py`: 128 epsilon intervals covering lambda in [5,64]
  at q=0 only. Range integration with Arb128; four local worker processes.
- `check_new_results.py`: symbolic identities, rational constants, saved
  centre-cover structure, and noninterval mpmath density comparisons.
- `PLAN_NP*_BEFORE_RUN.md`: plans written before the corresponding runs.
- `NP*_*.json`, `*.jsonl`, `*.log`: outputs and retained failure records.
- `inputs/`: fixed upstream source copies. Their original bytes are preserved;
  inclusion is documentary and does not promote this package to evidence.

`NP1` uses the looser degree4 tail `2h^5/(1-h)`. `NP2` and `NP3` use
`4*a_5*h^5`. This distinction is intentional and documented in the report.

## Reproduction

Use a NEW directory, Python3.12, python-flint==0.8.0, numpy, scipy, sympy and
mpmath. Exact versions used locally are in `ENVIRONMENT.json`.
There is no Julia dependency. No global sign search is part of these commands.

```bash
python -m pip install -r requirements.txt
python centre_interval.py
python check_new_results.py
python np1_hessian.py
python np2_moments.py
```

Run these inside the extracted package. Each diagnostic writes its output in
that directory; therefore do not run inside the sealed original directory.
The central check does not independently reintegrate using a second kernel.

Single command for the small central cover plus checks, after dependencies:

```bash
python centre_interval.py && python check_new_results.py
```

All output is research material. The checker initially returned40/41 because
SymPy left a substitution unevaluated; the original source/output are retained.
See `NP4_CHECKER_NOTE.md`. NP2 runtime corrections and their traces are also
retained. No numerical threshold was relaxed to change a failed result.

## Integrity

`sha256sum -c SHA256SUMS` checks the package files. The manifest excludes itself.
The original ZIP has a separate `.sha256` file. Hash checks check identity,
not the validity of the mathematics.
