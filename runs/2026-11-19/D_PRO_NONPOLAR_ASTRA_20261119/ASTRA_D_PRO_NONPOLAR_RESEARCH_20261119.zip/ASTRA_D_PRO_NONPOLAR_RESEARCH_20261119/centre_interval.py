"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Only the central transverse Hessian."""
from flint import arb,fmpq as Q,ctx
from fractions import Fraction
from pathlib import Path
import json,time,multiprocessing as mp
ctx.prec=128
def iv(a,b):
 a,b=Q(a),Q(b)
 return arb((a+b)/2,(b-a)/2)
def sq(x):
 a,b=x.lower().fmpq(),x.upper().fmpq()
 return iv(0 if a<=0<=b else min(a*a,b*b),max(a*a,b*b))
def clip(x,lo,hi):return iv(max(Q(lo),x.lower().fmpq()),min(Q(hi),x.upper().fmpq()))
def poly(cs,x):
 v=arb(0)
 for c in reversed(cs):v=v*x+c
 return v
A=[Q(1)]
for n in range(5):A.append(A[-1]*Q(2*n+2,2*n+3))
FP=[2*x for x in A[:5]]+[4*A[5]]
QQ=[A[n]*Q(2*n*n+10*n+10,2*n+3) for n in range(5)]
GRID=None
def init():
 global GRID
 dt=arb.pi()/4096;rows=[]
 for j in range(2048):
  th=dt*iv(j,j+1);si=th.sin();co=th.cos()
  rows.append((sq(si),sq(co),co))
 GRID=(rows,dt)
def work(i):
 st=time.monotonic();elo=Q(1,64)+(Q(1,5)-Q(1,64))*Q(i,128);ehi=Q(1,64)+(Q(1,5)-Q(1,64))*Q(i+1,128)
 e=iv(elo,ehi);e2=sq(e);tot=arb(0);rows,dt=GRID
 for mu2,ss2,co in rows:
  D2=1+(1/e2-1)*mu2;B=ss2+e2*mu2
  ga=clip(1/(D2*B).sqrt(),0,1);h=clip((1-ga)/2,0,Q(1,2))
  aa=sq(ga)*(1-ss2/(2*D2));cc=ss2/(2*B)*sq(1-1/D2)
  val=B.sqrt()/D2.sqrt()*(poly(FP,h)*aa-poly(QQ,h)*cc)*co
  if not val.is_finite():raise ArithmeticError('nonfinite centre envelope')
  tot+=val
 out=tot*dt
 return {'index':i,'epsilon':[str(elo),str(ehi)],'upper_exact':str(out.upper().fmpq()),'lower_exact':str(out.lower().fmpq()),'upper_negative':bool(out<0),'seconds':time.monotonic()-st}
if __name__=='__main__':
 root=Path(__file__).parent;start=time.monotonic();rows=[]
 with (root/'NP3_CENTRE_COVER.jsonl').open('w') as f,mp.Pool(4,initializer=init) as pool:
  for row in pool.imap_unordered(work,range(128)):
   rows.append(row);f.write(json.dumps(row)+'\n');f.flush()
   if len(rows)%32==0:print(json.dumps({'completed':len(rows),'failed':sum(not r['upper_negative'] for r in rows)}),flush=True)
 out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','scope':'q=0,lambda in [5,64],not a global sign proof','precision_bits':128,'theta_cells':2048,'epsilon_boxes':128,'all_negative':all(r['upper_negative'] for r in rows),'max_upper_exact':str(max(Fraction(r['upper_exact']) for r in rows)),'seconds':time.monotonic()-start}
 (root/'NP3_CENTRE_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
