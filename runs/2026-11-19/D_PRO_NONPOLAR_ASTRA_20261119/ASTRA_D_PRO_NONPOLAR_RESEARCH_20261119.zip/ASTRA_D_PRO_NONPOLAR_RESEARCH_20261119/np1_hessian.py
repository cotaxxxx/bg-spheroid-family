"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed double-precision probes."""
import numpy as np
from pathlib import Path
import json,time

def coefs(n):
 a=[1.]
 for j in range(n):a.append(a[-1]*(2*j+2)/(2*j+3))
 a=np.array(a);j=np.arange(n+1)
 return 2*a,a*(2*j*j+10*j+10)/(2*j+3)

def nodes(lam,z,nm=32,np_=128):
 x,w=np.polynomial.legendre.leggauss(nm)
 pp,pw=np.polynomial.legendre.leggauss(np_)
 phi=(pp+1)*np.pi/2;pw=pw/4
 cuts=[-1.,1.,z]
 for delta in [1.,.1,.01,1/lam,1/(10*lam)]:
  cuts.extend([np.clip(z-delta,-1,1),np.clip(z+delta,-1,1)])
 for delta in [.1,.01,1/lam**2,1/(10*lam**2)]:cuts.extend([-1+delta,1-delta])
 cuts=sorted(set(cuts));mus=[];weights=[]
 for lo,hi in zip(cuts,cuts[1:]):
  mus.extend((lo+hi)/2+(hi-lo)/2*x);weights.extend((hi-lo)/2*w)
 return np.array(mus)[:,None],np.array(weights)[:,None]*pw[None,:],phi[None,:]

def evaluate(lam,z,u,nm=32,np_=128):
 rho=np.sqrt(1-z*z)*u;mu,weights,phi=nodes(lam,z,nm,np_);ss=np.sqrt(1-mu*mu)
 xi=ss*np.cos(phi);yy=ss*np.sin(phi);vx=xi-rho;vz=lam*(mu-z)
 D=np.sqrt(vx*vx+yy*yy+vz*vz);B=ss*ss+mu*mu/lam**2;bb=np.sqrt(B)
 k=1-z*mu-rho*xi;gam=np.clip(k/(D*bb),0,1);hh=(1-gam)/2
 fp,q=coefs(48);Fp=np.polynomial.polynomial.polyval(hh,fp);Q=np.polynomial.polynomial.polyval(hh,q)
 def parts(uv,nv):return gam**2*(1-uv*uv),(nv-gam*uv)**2
 aa,cc=parts(yy/D,yy/bb)
 factor=bb/D;density=factor*(Fp*aa-Q*cc)
 ax,cx=parts(vx/D,xi/bb)
 az,cz=parts(vz/D,mu/(lam*bb))
 alpha=np.arcsin(gam);F=alpha*(np.pi-alpha)
 Ez=mu*(F+gam*Fp)-k*gam*Fp*(mu-z)/(D*D/lam**2)
 # Positive series: Fp tail <=2*h^(N+1)/(1-h), Q truncated below.
 N=4;Fpup=np.polynomial.polynomial.polyval(hh,fp[:N+1])+2*hh**(N+1)/(1-hh)
 Qlo=np.polynomial.polynomial.polyval(hh,q[:N+1])
 vals={'H':np.sum(density*weights),'Exx':np.sum(factor*(Fp*ax-Q*cx)*weights),
 'Ezz':np.sum(lam*lam*factor*(Fp*az-Q*cz)*weights),'Ez':np.sum(Ez*weights),
 'H_upper_constant':np.sum(factor*(np.pi*aa-(10/3)*cc)*weights),
 'H_upper_degree4':np.sum(factor*(Fpup*aa-Qlo*cc)*weights)}
 return {k:float(v) for k,v in vals.items()}

if __name__=='__main__':
 root=Path(__file__).parent;rows=[];start=time.monotonic()
 for lam in [5,6,8,10,20,100]:
  for z in [0.,.5,.9,.99]:
   for u in [0.,.5,.9,.99]:
    st=time.monotonic();row={'lambda':lam,'z':z,'u':u,**evaluate(lam,z,u),'seconds':time.monotonic()-st}
    rows.append(row)
  print(json.dumps({'lambda':lam,'max_H':max(r['H'] for r in rows if r['lambda']==lam),'positive_H':sum(r['H']>=0 for r in rows if r['lambda']==lam),'constant_upper_positive':sum(r['H_upper_constant']>=0 for r in rows if r['lambda']==lam),'degree4_upper_positive':sum(r['H_upper_degree4']>=0 for r in rows if r['lambda']==lam)}),flush=True)
 out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','quadrature':'binary64 noninterval,32per panel x128azimuth','rows':rows,'seconds':time.monotonic()-start}
 (root/'NP1_HESSIAN.json').write_text(json.dumps(out,indent=2)+'\n')
