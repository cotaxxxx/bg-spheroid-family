"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Symbolic checks and a ledger check."""
from pathlib import Path
from fractions import Fraction as Q
import json, time, traceback, sys
import sympy as sp
import mpmath as mp

ROOT = Path(__file__).resolve().parent

def main():
    start = time.perf_counter()
    checks = []
    def record(name, condition, **details):
        checks.append(dict(name=name, ok=bool(condition), **details))

    # Exact density differentiation in a rotated orthonormal frame.
    vx, vy, vz, d = sp.symbols('vx vy vz d', real=True, positive=True)
    gamma, st = sp.symbols('gamma st', real=True)
    F = sp.Function('F')
    D = sp.sqrt(vx*vx+vy*vy+vz*vz)
    dot = gamma*vx+st*vy
    g = dot/D
    density = dot*F(g)
    fp = sp.diff(F(gamma), gamma)
    fpp = sp.diff(F(gamma), gamma, 2)
    expected = sp.diag(0, (-gamma**2*fp+(2*fp+gamma*fpp)*st**2)/d,
                       -gamma**2*fp/d)
    vv = [vx, vy, vz]
    for i in range(3):
        for j in range(i,3):
            result = sp.diff(density, vv[i], vv[j]).subs({vx:d,vy:0,vz:0})
            record(f'perspective_hessian_{i}{j}',
                   sp.simplify((result-expected[i,j]).doit()) == 0)

    n = sp.symbols('n', integer=True, nonnegative=True)
    record('Q_coefficient', sp.simplify(4+2*n-(n+1)*(2*n+2)/(2*n+3)
                         -(2*n*n+10*n+10)/(2*n+3)) == 0)
    record('Q_coefficient_below_n_plus_4',
           sp.expand((n+4)*(2*n+3)-(2*n*n+10*n+10)) == n+2)
    h = sp.symbols('h', real=True)
    record('unit_vector_factor', sp.expand(1-(1-2*h)**2-4*h*(1-h)) == 0)

    a, theta = sp.symbols('a theta', positive=True)
    dt = sp.sqrt(1+a*sp.sin(theta)**2)
    record('central_positive_integral_identity', sp.trigsimp(
        (1+a)/dt**3-dt-a*sp.diff(sp.sin(theta)*sp.cos(theta)/dt,theta)) == 0)
    mu, lam = sp.symbols('mu lam', positive=True)
    primitive = (1+2/lam**2)*sp.log(mu)-mu**2/2+1/(lam**2*mu**2)
    record('central_negative_antiderivative', sp.simplify(sp.diff(primitive,mu)
        -(1-mu**2)/mu*(1-2/(lam**2*mu**2))) == 0)
    record('central_negative_endpoint_integral', sp.simplify(
        primitive.subs(mu,1)-primitive.subs(mu,2/lam)
        -((1+2/lam**2)*sp.log(lam/2)-sp.Rational(3,4)+3/lam**2)) == 0)
    record('distance_factor_8_over_9', Q(4,5)>Q(64,81))
    tail_gap = Q(310,81)-Q(5049,1568)
    record('central_tail_margin', tail_gap>Q(1,2), gap_exact=str(tail_gap))
    x = sp.symbols('x', positive=True)
    record('log_lower_derivative', sp.simplify(sp.diff(sp.log(x)-2*(x-1)/(x+1),x)
                      -(x-1)**2/(x*(x+1)**2)) == 0)

    rows = [json.loads(s) for s in (ROOT/'NP3_CENTRE_COVER.jsonl').read_text().splitlines()]
    record('centre_cover_unique_128', len(rows)==128 and sorted(r['index'] for r in rows)==list(range(128)))
    width = Q(1,5)-Q(1,64)
    record('centre_cover_exact_endpoints', all(
        Q(r['epsilon'][0])==Q(1,64)+width*Q(r['index'],128) and
        Q(r['epsilon'][1])==Q(1,64)+width*Q(r['index']+1,128) for r in rows))
    record('centre_all_upper_negative', all(Q(r['upper_exact'])<0 for r in rows))
    record('centre_ledger_summary_agrees', str(max(Q(r['upper_exact']) for r in rows)) ==
           json.loads((ROOT/'NP3_CENTRE_SUMMARY.json').read_text())['max_upper_exact'])

    constants=[]
    for N in [4,12,16,20,24]:
        an=Q(1)
        for j in range(N+1): an*=Q(2*j+2,2*j+3)
        eta=(2*N+12)*an/2**(N+1)
        zeta=(4*N+20)*an/2**(N+1)
        constants.append(dict(N=N,eta_exact=str(eta),zeta_exact=str(zeta),
                              eta_approx=float(eta),zeta_approx=float(zeta),
                              error_5_to_10_upper_exact=str(5*zeta)))
    record('degree20_transverse_error_below_1_over_20000',
           5*Q(constants[3]['zeta_exact'])<Q(1,20000))
    # e^3>11 and e^(3/4)>2 imply log11<3, log2<3/4, T<25.
    def exp_lower(x,n):
        term=Q(1); total=term
        for k in range(1,n+1): term*=x/k; total+=term
        return total
    record('log11_below_3', exp_lower(Q(3),4)>11)
    record('log2_below_3_over_4', exp_lower(Q(3,4),3)>2)
    record('T_below_25_on_5_to_10', Q(3)+29*Q(3,4)<25)

    mp.mp.dps=70
    specs=[(5,Q(1,3),Q(1,4),[Q(2,3),Q(1,3),Q(2,3)]),
           (10,Q(0),Q(0),[Q(0),Q(3,5),Q(4,5)]),
           (64,Q(1,7),Q(4,5),[Q(12,13),Q(0),Q(5,13)])]
    def real(q):return mp.mpf(q.numerator)/q.denominator
    numeric=[]
    for case,(ell,rho,z,xis) in enumerate(specs):
        xi=list(map(real,xis));rho=real(rho);z=real(z); ell=mp.mpf(ell)
        p=[rho,mp.mpf(0),ell*z]; B=xi[0]**2+xi[1]**2+xi[2]**2/ell**2
        normal=[xi[0]/mp.sqrt(B),xi[1]/mp.sqrt(B),xi[2]/(ell*mp.sqrt(B))]
        def original(px,py,pz):
            v=[xi[0]-px,xi[1]-py,ell*xi[2]-pz]
            dist=mp.sqrt(sum(t*t for t in v));k=1-px*xi[0]-py*xi[1]-pz*xi[2]/ell
            g=k/(dist*mp.sqrt(B))
            return k*mp.acos(g)**2
        v=[xi[0]-p[0],xi[1]-p[1],ell*xi[2]-p[2]]
        dist=mp.sqrt(sum(t*t for t in v));u=[t/dist for t in v]
        g=sum(normal[i]*u[i] for i in range(3));w=[normal[i]-g*u[i] for i in range(3)]
        fp=2*mp.acos(g)/mp.sqrt(1-g*g)
        fpp=(g*fp-2)/(1-g*g); qq=2*fp+g*fpp
        for i in range(3):
            for j in range(i,3):
                orders=[0,0,0];orders[i]+=1;orders[j]+=1
                reference=mp.diff(original,tuple(p),tuple(orders))
                formula=mp.sqrt(B)/dist*(g*g*fp*((1 if i==j else 0)-u[i]*u[j])-qq*w[i]*w[j])
                err=abs(reference-formula)
                record(f'mpmath_original_density_case{case}_{i}{j}',err<mp.mpf('1e-50'))
                numeric.append(dict(case=case,entry=f'{i}{j}',absolute_error=mp.nstr(err,12)))

    out=dict(status='DIAGNOSTIC_ONLY / NOT_EVIDENCE',all_checks=all(c['ok'] for c in checks),
             checks=checks,constants=constants,numeric_density_checks=numeric,
             seconds=time.perf_counter()-start)
    (ROOT/'NP4_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(dict(status=out['status'],checks=len(checks),
                         true=sum(c['ok'] for c in checks),seconds=out['seconds']),indent=2))
    return 0 if out['all_checks'] else 1

if __name__=='__main__':
    try: sys.exit(main())
    except Exception:
        (ROOT/'NP4_EXCEPTION.txt').write_text('DIAGNOSTIC_ONLY / NOT_EVIDENCE\n'+traceback.format_exc())
        raise
