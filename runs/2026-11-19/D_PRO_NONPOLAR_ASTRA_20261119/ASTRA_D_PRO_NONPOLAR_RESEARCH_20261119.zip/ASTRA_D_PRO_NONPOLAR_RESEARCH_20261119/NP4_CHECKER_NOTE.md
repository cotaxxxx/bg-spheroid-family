# NP4 checker correction
DIAGNOSTIC_ONLY / NOT_EVIDENCE

The initial run returned 40/41. The 11-entry symbolic residual was an
unevaluated SymPy derivative/substitution expression; evaluating `.doit()`
reduces it exactly to zero. Neither the proposed identity, the numerical
inputs, nor a tolerance was changed. The initial source, JSON and log are
retained with `initial` / `INITIAL` names. The corrected run evaluates
the expression before its exact-zero comparison.
