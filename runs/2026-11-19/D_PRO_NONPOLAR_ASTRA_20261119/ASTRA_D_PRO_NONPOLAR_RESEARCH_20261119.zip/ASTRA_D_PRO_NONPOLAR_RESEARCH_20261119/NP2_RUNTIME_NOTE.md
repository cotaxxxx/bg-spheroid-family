# NP2 execution note
DIAGNOSTIC_ONLY / NOT_EVIDENCE

The first invocation with dpro_r3_env/bin/python stopped at import because
NumPy was not installed in that virtual environment. No case was evaluated.
Use the main Python3.12 interpreter with that environment's python-flint
site-packages on PYTHONPATH. The fixed2048point Gauss reference is generated
once with SciPy roots_legendre and cached. Points, criteria and precision are
unchanged; this is an implementation/runtime correction.

The next invocation exposed python-flint0.8.0 fmpq lacking float conversion. The nonrigorous reference now converts numerator/denominator explicitly. The eight error records are preserved as NP2_RUNTIME_ERRORS_R1.json. No numerical threshold or input case changed.

Width serialization was corrected to subtract the two exact fmpq endpoints, rather than converting a rounded Arb subtraction to fmpq. The preceding point results and formatting failures remain in NP2_FORMAT_ERRORS_R2.json.
