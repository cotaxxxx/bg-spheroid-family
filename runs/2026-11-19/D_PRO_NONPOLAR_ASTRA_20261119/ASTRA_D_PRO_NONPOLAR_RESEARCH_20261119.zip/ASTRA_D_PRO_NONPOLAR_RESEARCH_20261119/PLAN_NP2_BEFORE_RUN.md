# NP2 fixed azimuth moment comparison
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Use a degree4 positive-series lower bound for Q=2F'+gamma F'' and a degree5
polynomial upper bound for F'. Coefficients are exact rationals.
For fixed mu, integrate the polynomial envelope in azimuth by Gauss
hypergeometric moments of a-b cos(phi). Arb precision192bits.
Keep k=(D^2+c)/2 and y^2=s^2*(1-(a-D^2)^2/b^2) as polynomials in D^2.
The axis b=0 is handled directly. No interval containing b=0 is divided by b.

Cases (lambda,rho,z,mu):
(5,0,0,0),(5,0,0,1/2),(5,1/2,1/2,0),
(5,1/2,1/2,1/2),(5,1/2,1/2,3/4),(10,3/4,1/4,1/4),
(5,1/1024,1/2,1/2),(5,3/5-1/1024,4/5,4/5).
Compare with binary64 azimuth Gauss2048 (nonrigorous reference,1e-7 tolerance).
For every non-axis case also evaluate a mu interval of halfwidth1/16384;
record width, endpoints and elapsed time. This does not assert negativity of
the full surface integral. Stop an individual call if its denominator is not
strictly positive, it is nonfinite, or the special function fails.
