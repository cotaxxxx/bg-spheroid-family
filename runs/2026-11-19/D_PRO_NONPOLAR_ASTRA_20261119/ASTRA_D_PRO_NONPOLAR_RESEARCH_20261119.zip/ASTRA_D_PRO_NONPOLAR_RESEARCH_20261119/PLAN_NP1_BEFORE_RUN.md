# NP1 fixed noninterval diagnostic
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Questions: does the tangential-Hessian representation agree with the known
centre value, and do simple pointwise coefficient bounds retain the sign?
No global sign is inferred from this diagnostic.

Fix lambda in {5,6,8,10,20,100}, z in {0,1/2,9/10,99/100},
u=rho/sqrt(1-z^2) in {0,1/2,9/10,99/100}. Total96points.
Binary64 Gauss-Legendre32nodes on each fixed mu panel and128azimuth nodes.
Mu breakpoints: -1,1,z,z+-{1,1/10,1/100,1/lambda,1/(10lambda)},
plus +-1 with inward distances {1/10,1/100,1/lambda^2,1/(10lambda^2)}.
Clip and deduplicate. Gamma coefficients use48terms of a positive series.
Record true tangential H, radial E_xx, axial E_z, constant-coefficient
upper envelope, and a four-term coefficient upper envelope, plus elapsed time.
First-order agreement tests and higher-resolution checks require their own
declared settings. No parameter box or certification is being selected here.
