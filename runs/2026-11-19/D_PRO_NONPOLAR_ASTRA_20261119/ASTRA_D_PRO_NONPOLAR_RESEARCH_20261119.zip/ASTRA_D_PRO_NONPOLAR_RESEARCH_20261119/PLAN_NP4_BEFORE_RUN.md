# NP4: algebra, coverage and kernel checks
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

This is a separate check of the newly derived identities, not a global sign run.
No grid or bound in NP1--NP3 will be changed.

1. SymPy exact simplification: the physical Hessian of D gamma F(gamma),
   in the orthonormal frame with u=e1 and n=(gamma,sqrt(1-gamma^2),0);
   all six symmetric entries. Check the Q coefficient formula and the
   elementary central-tail antiderivatives.
2. Fractions: the 128 saved epsilon intervals must occur exactly once, join
   without gaps and cover [1/64,1/5]; every saved upper must be negative.
   This checks the ledger only; it is not an independent quadrature.
3. Fractions: compute eta_N and zeta_N for N=4,12,16,20,24; check the
   proposed rational tail margin and 5*zeta_20 < 1/20000.
4. mpmath, 70 decimal digits: compare the physical Hessian kernel against
   second derivatives of the ORIGINAL k*acos(gamma)^2 density, at three
   fixed (lambda,rho,z,xi) tuples:
   (5,1/3,1/4,(2/3,1/3,2/3));
   (10,0,0,(0,3/5,4/5));
   (64,1/7,4/5,(12/13,0,5/13)).
   Test all six symmetric Hessian entries; absolute tolerance 10^-50.
   These numerical checks are diagnostics, not interval enclosures.

Stop on an exception; retain a traceback. Record wall time using perf_counter.
