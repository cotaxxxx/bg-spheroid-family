# NP3 centre interval cover and analytic tail
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Question: is the degree4/degree5 polynomial upper envelope for E_yy(0)
strictly negative on all lambda in [5,64]?
Fix epsilon in [1/64,1/5],128equal parameter intervals; theta in [0,pi/2],
2048equal cells; Arb128bits,4local processes. Integrate by cell ranges,
not an approximate quadrature. The required result for every box is upper<0.
Keep every box and failure. This covers only q=0, not a neighborhood or
all nonpolar points. Lambda>=64 is to be treated by the separately derived
elementary inequality, not by sampling epsilon=0.

Use F' upper=2sum(n=0..4)a_n h^n+4a_5 h^5,
Q lower=sum(n=0..4)q_n h^n, h=(1-gamma)/2.
Do not tune the threshold after viewing results.
