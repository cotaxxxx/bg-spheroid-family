"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact index, endpoint and rational checks."""
from fractions import Fraction as Q
from pathlib import Path
import json
root=Path(__file__).parent
rows=[json.loads(x) for x in (root/'CAP_COVER_R2.jsonl').read_text().splitlines()]
expected={(i,j,k) for i in range(16) for j in range(8) for k in range(8)}
ids=[tuple(r['index']) for r in rows]
checks={'count':len(rows)==1024,'unique_indices':len(ids)==len(set(ids)),'full_index_set':set(ids)==expected,'correct_endpoints':True,'strict_rational_lower':True}
minimum=None
for row in rows:
    i,j,k=row['index'];box=[[Q(i,80),Q(i+1,80)],[Q(j,8),Q(j+1,8)],[Q(k,8),Q(k+1,8)]]
    checks['correct_endpoints'] &= [[Q(x) for x in a] for a in row['box']]==box
    lower=Q(row['lower_exact']);checks['strict_rational_lower'] &= lower>Q(1,4)
    if minimum is None or lower<minimum[0]:minimum=(lower,row['index'])
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','scope':'Checks cover and scalar results, not an independent reintegration or analytic proof audit.','checks':checks,'all_checks':all(checks.values()),'minimum_lower_exact':str(minimum[0]),'minimum_lower_display':float(minimum[0]),'index_of_minimum':minimum[1]}
(root/'CAP_COVER_CHECK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
