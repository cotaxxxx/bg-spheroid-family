"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed lower-envelope quadrature."""
import numpy as np,json,time
from pathlib import Path
from numpy.polynomial.legendre import leggauss
def envelope(e,w,u,n=96,m=128):
    c=.75;delta=1/64;lo=np.arccos(c);hi=np.pi-delta
    x,v=leggauss(n);p,wp=leggauss(m)
    th=(lo+hi)/2+(hi-lo)*x[:,None]/2;ph=np.pi*(p[None,:]+1)/2
    mu=np.cos(th);s=np.sin(th);z=np.sqrt(1-e*e*w*w);r=e*w*u
    k=1-z*mu-r*s*np.cos(ph);A=s*s+r*r-2*r*s*np.cos(ph)
    d2=(z-mu)**2+e*e*A;B=s*s+e*e*mu*mu
    gam=e*k/np.sqrt(d2*B);T=s/np.sqrt(B)
    a=mu*k;b=mu*k+k*k*(z-mu)/d2
    low=T/np.sqrt(d2)*(np.pi*(a+b)-gam*(np.maximum(a,0)+2*np.maximum(b,0)))
    integral=np.sum(low*v[:,None]*wp[None,:])*(hi-lo)/4/2
    south=np.pi*delta/z
    north=e*w*w*np.sqrt(1+w*w)/(1+z)
    return integral-south-north,integral,south,north
if __name__=='__main__':
    rows=[]
    for e in [.2,.1,.01,0.]:
        for w in [0.,.5,1.]:
            for u in [0.,.5,1.]:
                l,f,s,n=envelope(e,w,u)
                rows.append({'epsilon':e,'w':w,'u':u,'lower_envelope_diagnostic':float(l),'far_integral':float(f),'south_subtraction':float(s),'north_subtraction':float(n)})
    out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','rows':rows,'minimum':min(x['lower_envelope_diagnostic'] for x in rows)}
    Path(__file__).with_name('CAP_ENVELOPE_PROBE.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
