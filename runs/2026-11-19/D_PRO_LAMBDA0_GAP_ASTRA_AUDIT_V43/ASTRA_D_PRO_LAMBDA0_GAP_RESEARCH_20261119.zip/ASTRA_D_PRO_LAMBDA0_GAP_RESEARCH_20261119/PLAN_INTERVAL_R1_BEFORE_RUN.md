# Fixed interval pilot R1
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Analytic lower envelope from PLAN_BEFORE_RUN, c=3/4, delta=1/64.
128-bit Arb range integration (no unproved numerical quadrature rule).
Theta 96 equal cells, phi 48 equal cells on [0,pi], with exact reflection.
Four fixed parameter boxes:
epsilon [7/40,1/5], w,u each [3/4,1];
epsilon [0,1/40], w,u each [3/4,1];
epsilon [7/40,1/5], w [0,1/4], u [3/4,1];
epsilon [7/40,1/5], w [3/4,1], u [0,1/4].
Compare the exact lower endpoint with 1/4. Record failures, widths and time.
These four boxes are pilots, not a complete parameter cover.
