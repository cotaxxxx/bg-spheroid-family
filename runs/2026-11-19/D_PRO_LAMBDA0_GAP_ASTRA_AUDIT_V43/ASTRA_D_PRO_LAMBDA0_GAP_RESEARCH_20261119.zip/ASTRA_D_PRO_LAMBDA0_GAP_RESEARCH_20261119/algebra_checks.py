"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Symbolic identities only."""
import sympy as s
import json
from pathlib import Path
mu,z,r,ss,co,e=s.symbols('mu z rho s co epsilon', real=True)
k=1-z*mu-r*ss*co
ell=ss-r*co
A=ss**2+r**2-2*r*ss*co
v=mu-z;d2=v**2+e**2*A;B=ss**2+e**2*mu**2
def dm(f):return s.diff(f,mu)-mu/ss*s.diff(f,ss)
def T(f):return s.diff(f,z)+dm(f)
def zero(f):
    f=s.cancel(f).as_numer_denom()[0]
    return s.rem(s.Poly(s.expand(f),ss),s.Poly(ss**2+mu**2-1,ss)).as_expr().expand()==0
checks={
 'k_decomposition':zero(k-ss*ell-mu*v),
 'A_nonnegative_decomposition':zero(A-ell**2-r**2*(1-co**2)),
 'minus_Tk':zero(-T(k)-z-mu*ell/ss),
 'A_mu':zero(dm(A)+2*mu*ell/ss),
 'B_mu':zero(dm(B)+2*(1-e**2)*mu),
 'T_d_squared':zero(T(d2)-e**2*dm(A)),
 'gamma_z_log':zero(s.diff(e**2*k**2/(d2*B),z)/(2*e**2*k**2/(d2*B))+mu/k-v/d2),
 'gamma_transport_log':zero(T(e**2*k**2/(d2*B))/(2*e**2*k**2/(d2*B))-T(k)/k+e**2*dm(A)/(2*d2)+dm(B)/(2*B)),
 'C_after_B_bound':zero(2*z+2*mu*ell/ss-k*mu/ss**2-(2*z+mu*ell/ss-mu**2*v/ss**2)),
 'ell_term_split':zero(e**2*k*ell/(ss*d2)-e**2*ell**2/d2-e**2*mu*v*ell/(ss*d2))}
S=s.sqrt(1-z**2)
b=S+(2-z**2)*z*s.asin(z)+S**3*s.log(S)
checks['axis_b_derivative']=s.simplify(s.diff(b,z)-((2-3*z**2)*s.asin(z)-3*z*S*s.log(S)))==0
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','checks':checks,'all_checks':all(checks.values())}
Path(__file__).with_name('ALGEBRA_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
if not all(checks.values()):raise SystemExit(1)
