# Exact algebra and scalar inequalities

2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

These are checks of the analytic derivation, not a sign search. Fix before
running: s0=2^-12, the intermediate band half-width h=S^2/4,
transition condition S>=4 epsilon, c=15/16, and lambda>=65536.
For the full-ball conditional assembly, fix Lambda=2^13000,
L=log(2 lambda), delta=s0/(2^20 L), m=1/(2^46 L).
Use Python Fraction for all scalar inequalities and SymPy for algebra.
Do not infer the old analytic lemma P10 from these checks. Its explicit C2
bound remains an input to the full-ball theorem. The independent cap cover
lambda>=5 uses neither P10 nor this global threshold.

Analytic revision before the second scalar check: choose inner-layer epsilon0=1/4096 and bound its normalized north loss by1/100. This makes the fixed polar belt analytic for lambda>=4096. For5<=lambda<=4096 that same fixed belt lies in the independently covered cap S<=1/lambda. This is a change in a sufficient analytic constant, not a numerical mesh or sign-selection change. Preserve the first scalar result as EXACT_CHECKS_R1.json.
