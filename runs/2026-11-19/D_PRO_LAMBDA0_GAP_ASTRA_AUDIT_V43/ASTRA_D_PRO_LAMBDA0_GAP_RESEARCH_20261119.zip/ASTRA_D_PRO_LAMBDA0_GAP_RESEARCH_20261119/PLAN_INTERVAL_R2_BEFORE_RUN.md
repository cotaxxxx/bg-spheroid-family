# Fixed interval cover R2
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

The R1 pilot has two of four boxes below the target 1/4; preserve it unchanged.
R2 retains the formula, cutoff c=3/4, delta=1/64, precision128 and spatial
range grid96x48. Halve each outer parameter width: epsilon16 equal intervals
on [0,1/5], w8 and u8 on [0,1]. Exactly1024 Cartesian boxes. Uniform fixed
cover, no adaptive selection or sign-based omission. Four local processes.
Every exact lower endpoint must exceed1/4. All rows are written immediately;
the separate checker verifies the full index set and rational comparisons.
This establishes at most the cap lemma, never a full-ball sign theorem.
