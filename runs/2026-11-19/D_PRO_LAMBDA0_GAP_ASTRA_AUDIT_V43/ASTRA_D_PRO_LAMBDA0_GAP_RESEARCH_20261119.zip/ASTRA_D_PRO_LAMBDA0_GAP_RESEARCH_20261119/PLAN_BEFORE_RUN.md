# D-PRO gap research: fixed first comparison
2026-11-19 / DIAGNOSTIC_ONLY / NOT_EVIDENCE

Goal A: lower the polar-cap threshold to lambda>=5 on chi<=lambda^-2.
Use exact E_z kernel, integrate the retained region mu in [-cos(delta),3/4]
with delta=1/64, discard the nonnegative interval [3/4,z], and subtract
analytic upper bounds for the south cap and mu>z. Parameterization:
epsilon in [0,1/5], w in [0,1], u in [0,1], chi=epsilon^2*w^2,
rho=epsilon*w*u, z=sqrt(1-epsilon^2*w^2).

First numerical-only test: epsilon=1/5,1/10,1/100,0; w,u in {0,1/2,1}.
Gauss-Legendre 96 theta nodes,128 azimuth nodes, double precision.
Evaluate a rigorously derived quadratic lower envelope pointwise, but label
the quadrature values nonrigorous. Fixed c=3/4, delta=1/64, no threshold tuning.
If useful, run interval range quadrature with separately declared fixed mesh
and parameter boxes. Preserve failed lower bounds.

Goal B: an explicit moving polar region, using the improved negative-cap
bound epsilon*X*sqrt(X+1)/(1+z) for E_z/epsilon. Algebraic bounds and exact
rational comparisons must be separated from diagnostics.

Exploratory note before this plan: random samples suggested positivity of a
transported kernel on the upper hemisphere; a deliberately constructed small-z
point gave a negative value. No global pointwise-positive-kernel claim is made.
