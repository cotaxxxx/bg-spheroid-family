"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed full outer cover for polar cap."""
import json,time,multiprocessing as mp
from pathlib import Path
from flint import fmpq as Q
from cap_interval import geometry,record
G=None
def init():
    global G
    G=geometry(96,48)
def work(idx):
    i,j,k=idx
    box=[(Q(i,80),Q(i+1,80)),(Q(j,8),Q(j+1,8)),(Q(k,8),Q(k+1,8))]
    row=record(box,G);row['index']=[i,j,k]
    return row
if __name__=='__main__':
    root=Path(__file__).parent;start=time.monotonic();rows=[]
    ids=[(i,j,k) for i in range(16) for j in range(8) for k in range(8)]
    with (root/'CAP_COVER_R2.jsonl').open('w') as out,mp.Pool(4,initializer=init) as pool:
        for row in pool.imap_unordered(work,ids,chunksize=1):
            rows.append(row);out.write(json.dumps(row)+'\n');out.flush()
            if len(rows)%64==0:print(json.dumps({'completed':len(rows),'failures':sum(not r['gt_one_quarter'] for r in rows),'seconds':time.monotonic()-start}),flush=True)
    summary={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','precision_bits':128,'spatial_grid':[96,48],'parameter_grid':[16,8,8],'planned_boxes':1024,'completed':len(rows),'all_lower_gt_one_quarter':all(r['gt_one_quarter'] for r in rows),'seconds':time.monotonic()-start}
    (root/'CAP_COVER_R2_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
