# D-PRO Lambda0 gap research

2026-11-19 — **DIAGNOSTIC_ONLY / NOT_EVIDENCE**

This classification applies to every file in this package, including raw
JSONL rows, stdout logs, copied inputs, and hashes. Nothing here changes the
status of an existing certificate or running computation.

Read `ASTRA_D_PRO_LAMBDA0_GAP_REPORT_20261119.md` first. The new polar cap
calculation does not depend on the previous compact C2 remainder lemma P10.
The sufficient full-ball threshold `2^13000` explicitly does depend on P10;
the rational checker does not audit that lemma. A practical full-ball
threshold at or below10 has not been obtained.

The fixed interval cover uses python-flint0.8.0,128bit Arb,96x48 spatial
cells,16x8x8 outer boxes, and4local processes. There are no external-PC or
GitHub mutations in this research run. No GPU or global sign producer is used.

## Reproduction

Extract a copy into a new writable directory. Do not run in the sealed
original: scripts write their output files beside themselves.

```bash
python cap_cover_r2.py && python check_cover.py && python exact_checks.py && python algebra_checks.py
```

Requirements: Python3, python-flint==0.8.0, SymPy. NumPy is required only for
the separate nonrigorous36-point exploratory script. The exact scalar and
coverage checkers use Python's standard library only.

The coverage checker validates every index, endpoint, and rational lower
bound. It is not an independent producer or mathematical audit.

The first four-box interval pilot contains two failed lower bounds and is
preserved unchanged. `EXACT_CHECKS_R1.json` preserves the first, more
conservative analytic constant check. The subsequent analytic revision is
recorded in `PLAN_ANALYTIC_CHECKS_BEFORE_RUN.md`; the current exact checker
reproduces `EXACT_CHECKS.json`, not that earlier file.

`inputs/` contains unmodified source copies. The fixed-source manifest is
itself copied verbatim; it references an earlier ZIP that is not duplicated
in this package. `SOURCE_PIN_CHECK.json` states exactly which four input
files were matched against that manifest.

`SHA256SUMS` covers all packaged files except itself. The ZIP's own SHA-256
is recorded outside the ZIP. Hash consistency is not mathematical validity.
