"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Scalar checks, not an audit of P10."""
from fractions import Fraction as Q
from pathlib import Path
import json

checks={}
def test(name, condition):
    checks[name]=bool(condition)

def atan_bounds(x,n=8):
    a=sum((-1)**j*x**(2*j+1)/Q(2*j+1) for j in range(n))
    b=a+(-1)**n*x**(2*n+1)/Q(2*n+1)
    return min(a,b),max(a,b)
a,b=atan_bounds(Q(1,5));c,d=atan_bounds(Q(1,239))
test('pi_lower',16*a-4*d>Q(157,50))
test('pi_upper',16*b-4*c<Q(22,7))
cut=Q(15,16);sc2=1-cut*cut
test('sin_cap_lower',sc2>Q(1,9))
test('sin_cap_upper',sc2<Q(49,400))
test('asin_cut_lower',Q(6,5)-Q(6,5)**3/6+Q(6,5)**5/120<cut)
# log(2) = 2 sum_{j>=0} (1/3)^(2j+1)/(2j+1).
test('log2_lower_two_thirds',2*(Q(1,3)+Q(1,3)**3/3)>Q(2,3))
# Upper bound by the geometric series: log(2)<3/4<1.
test('log2_upper_one',2*Q(1,3)/(1-Q(1,9))<1)
s0=Q(1,4096);zlo=Q(9999,10000)
test('band_z_lower',1-s0*s0>zlo)
test('band_s_squared_lower',Q(1,2)-s0*s0/16>Q(1,3))
test('band_ell_lower',Q(3)<Q(7,4)**2)
test('band_minus_Tk_positive',Q(99,100)-Q(3,4)>0)
test('band_C_ell_positive',Q(49,50)-Q(3,4)-Q(7,32)==Q(9,800))
test('band_C_ell_negative',Q(99,50)-Q(3,4)-Q(3,4)==Q(12,25))
test('band_lower_k_bound',Q(3,2)<Q(5,4)**2)

def far_bounds(e0,r0,chi0,target_kl,target_g,prefix):
    gap=zlo-cut
    q=e0**2*(1+r0)**2/gap**2
    t=e0**2/sc2
    v=1-r0/(1-cut)
    g=e0*(3*(1+chi0/gap)+r0/gap)
    test(prefix+'_z_lower',1-chi0>zlo)
    test(prefix+'_K',v/(1+q)>target_kl)
    test(prefix+'_L',v**2>target_kl**2*(1+q)*(1+t))
    test(prefix+'_G',g<target_g)

far_bounds(s0/4,s0,s0**2,Q(99,100),Q(1,1000),'transition')
positive=Q(99,200)*((2*Q(157,50)-Q(3,1000))*Q(13,20)
 +(Q(157,50)-Q(2,1000))*Q(99,100)*Q(6,5))
transition=positive-Q(22,7)/zlo*(1+s0/2)-Q(153,2)*Q(22,7)*s0
test('transition_Ez_gt_half_epsilon',transition>Q(1,2))
e0=Q(1,4096);r0=4*e0
far_bounds(e0,r0,r0**2,Q(93,100),Q(3,250),'inner')
test('inner_rho_bound',r0<Q(1,256))
test('inner_sqrt17',Q(17)<25)
test('inner_north_loss',e0*16*5/(1+zlo)<Q(1,100))
positive=Q(93,200)*((2*Q(157,50)-Q(9,250))*Q(13,20)
 +(Q(157,50)-Q(6,250))*Q(93,100)*Q(6,5))
inner=positive-Q(22,7)/zlo*(1+Q(1,512))-Q(1,100)
test('inner_Ez_gt_quarter_epsilon',inner>Q(1,4))

# All following checks assume the analytic C2 estimate P10.
Llo=Q(13001)*Q(2,3)
test('L_upper_power_two',13001<2**14)
test('bulk_decreasing',Llo>205)
test('h_constraint_decreasing',Llo>5)
test('h_constraint_at_threshold',13000>235+5*14)
bulk=Q(6,2**86)
test('bulk_error',bulk<Q(1,8192))
transfer=Q(96,2**20)*(1+Q(29,13001))+Q(88)*Q(22,7)*s0/(2**20*Llo)
test('radial_transfer_error',transfer<Q(1,8192))
test('radial_shift_small',1/(2**20*Llo)<Q(1,4))
test('m_less_s0_squared_over_4',1/(2**22*Llo)<Q(1,4))
test('P15_large_S_margin',18*Q(2,3)-11>=1)
test('P15_small_S_margin',1-Q(1,4096)-Q(15,64)>Q(3,4))
test('H_strict_negative_margin',Q(3,64)-Q(1,4096)>Q(1,32))
test('axis_b_upper',Q(22,7)*(Q(22,7)+Q(3,2))<15)
axis_lower=Q(78000,4096)-15-Q(1,8192)
test('axis_positive_margin',axis_lower>1)
out={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE',
 'scope':'Exact scalar checks of the stated analytic implications. P10 is an un-reaudited input, not established by this script.',
 'checks':checks,'all_checks':all(checks.values()),
 'transition_lower_exact':str(transition),'inner_lower_exact':str(inner),
 'bulk_upper_exact':str(bulk),'transfer_upper_exact':str(transfer),
 'axis_lower_exact':str(axis_lower),'conditional_global_threshold':'2^13000'}
Path(__file__).with_name('EXACT_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
if not all(checks.values()):raise SystemExit(1)
