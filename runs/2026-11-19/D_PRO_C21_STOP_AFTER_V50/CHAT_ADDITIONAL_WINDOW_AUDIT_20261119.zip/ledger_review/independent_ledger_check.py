"""Independent structural and exact rational audit; no numerical kernels executed."""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter, defaultdict
import csv, gzip, json

BASE=Path('/workspace/scratch/2929c6ca3779/stationary_review/input/CODEX_D_PRO_WINDOW_STATIONARY_20261119')
OUT=Path(__file__).parent
U=2**20
KEYS='l0 l1 r0 r1 z0 z1'.split()

def rows(p):
    opener=gzip.open if p.suffix=='.gz' else open
    with opener(p,'rt') as stream:return list(csv.DictReader(stream,delimiter='\t'))

def coords(row):return tuple(int(row[k]) for k in KEYS)

def expected_root(f,i):
    ll,lh=(79*U//16,5*U) if f=='X' else (2*U+i*U//4,2*U+(i+1)*U//4)
    rr=(0,0) if f in 'CB' else (0,U//8) if f=='T' else (0,U)
    zz=(0,U//4) if f=='Z' else (U//4,U) if f=='V' else (0,U) if f in 'HX' else (0,0)
    return (ll,lh,*rr,*zz)

def measure(box,active):
    m=Q(1)
    for j in active:m*=Q(box[j+1]-box[j],U)
    return m

all_leaves={};stats={};total_nodes=0;root_results=[]
for folder,families in [('N3','VZECTB'),('N4','HDX')]:
    files=sorted((BASE/'ledgers'/folder).glob('*.tsv.gz'))
    expected={f+f'{i:02}' for f in families for i in range(1 if f=='X' else 12)}
    assert {p.name.split('.')[0] for p in files}==expected
    for p in files:
        tag=p.name.split('.')[0];f=tag[0];i=int(tag[1:]);rr=rows(p)
        idx={r['path']:r for r in rr};assert len(idx)==len(rr)
        root=expected_root(f,i);assert coords(idx['x'])==root
        active=[j for j in (0,2,4) if root[j+1]>root[j]]
        reached=set();todo=['x'];vol=Q(0);term=[]
        while todo:
            key=todo.pop();assert key not in reached;reached.add(key)
            a=idx[key];box=coords(a)
            assert all(box[j]<=box[j+1] for j in (0,2,4))
            assert all(root[j]<=box[j]<=box[j+1]<=root[j+1] for j in (0,2,4))
            if a['action'].startswith('split'):
                axis=2*'lrz'.index(a['action'][-1]);mid=Q(box[axis]+box[axis+1],2)
                assert mid.denominator==1 and box[axis]<mid<box[axis+1]
                lc,rc=list(box),list(box);lc[axis+1]=int(mid);rc[axis]=int(mid)
                assert coords(idx[key+'0'])==tuple(lc)
                assert coords(idx[key+'1'])==tuple(rc)
                todo += [key+'0',key+'1']
                continue
            assert key+'0' not in idx and key+'1' not in idx
            vol+=measure(box,active);term.append(a)
            action,mode=a['action'],a['mode']
            if action=='empty':
                assert box[2]**2+box[4]**2>U**2
                continue
            lo,hi,blo,bhi=[int(a[k]) for k in ('alo','ahi','blo','bhi')]
            assert lo<=hi and blo<=bhi
            if f in 'VZ':assert mode==f and action=='positive' and lo>0
            elif f=='C':assert mode=='C' and action=='lambda_decreasing' and bhi<0
            elif f=='B':
                assert mode=='B'
                assert (box[1]<=9*U//4 and action=='lambda_decreasing' and bhi<0) or (box[0]>=9*U//4 and action=='negative' and hi<0)
            elif f=='T':assert mode=='T' and action=='radial_decreasing' and hi<0
            elif f=='E':
                assert (mode=='T' and action=='radial_decreasing' and hi<0) or (mode=='E' and ((action=='H_positive' and lo>0) or (action=='H_negative' and hi<0) or (action=='radial_curvature_negative' and bhi<0)))
            elif f=='D':
                assert mode=='D' and ((action=='H_positive' and lo>0) or (action=='H_negative' and hi<0) or (action=='lambda_decreasing' and bhi<0))
            elif f=='X':assert mode=='H' and action=='H_negative' and hi<0
            elif f=='H':
                assert mode=='H' and ((action=='H_positive' and lo>0) or (action=='H_negative' and hi<0) or (action=='H_undetermined' and lo<=0<=hi))
                if action=='H_undetermined':assert box[1]-box[0]<=U//16 and box[3]-box[2]<=U//32 and box[5]-box[4]<=U//32
        assert reached==set(idx)
        assert vol==measure(root,active)
        total_nodes+=len(rr)
        all_leaves.setdefault(f,[]).extend(term)
        root_results.append({'root':tag,'nodes':len(rr),'leaves':len(term),'measure':str(vol),'measure_axes':['lambda','rho','z'][0:0]+[('lambda','rho','z')[j//2] for j in active]})

summary=json.loads((BASE/'tables/summary.json').read_text())
for f,ll in all_leaves.items():
    s={'leaves':len(ll),'counts':dict(Counter(r['action'] for r in ll))}
    assert summary['families'][f]['leaves']==s['leaves'] and summary['families'][f]['counts']==s['counts']
    pairs={'V':('uniform_lower','alo',min),'Z':('uniform_lower','alo',min),'C':('Hlambda_upper','bhi',max),'T':('T_upper','ahi',max),'X':('uniform_upper','ahi',max)}
    if f in pairs:
        field,col,fn=pairs[f];value=Q(fn(int(r[col]) for r in ll if r['action']!='empty'),2**36)
        assert value==Q(summary['families'][f][field]);s[field]=str(value)
    stats[f]=s

# Check correspondence of every heavy-slab anchor and every attempted grid.
anchors={r['path']:r for r in all_leaves['X']}
attempts=defaultdict(list);integer_rows=0
for p in sorted((BASE/'ledgers/N7').glob('*.gz')):
    for r in rows(p):attempts[r['anchor']].append(r);integer_rows+=1
assert set(attempts)==set(anchors)
terminal_counts=Counter();upper=Q(-128);refinements=0
for anchor,ar in attempts.items():
    src=anchors[anchor];b=coords(src);assert all(v%256==0 for v in b)
    assert len(ar)<=6
    for i,r in enumerate(ar):
        assert r['sub']=='x' # Independently check the report's "no extra spatial splitting" statement.
        assert coords(r)==tuple(v//256 for v in b)
        assert (int(r['nm']),int(r['na']))==(32*2**i,4*2**i)
        v=Q(int(r['upper_num']),int(r['upper_den']))
        if i<len(ar)-1:assert r['action']=='refine_grid' and v>=0;refinements+=1
        else:
            terminal_counts[r['action']]+=1
            if src['action']=='empty':
                assert r['action']=='empty' and coords(r)[2]**2+coords(r)[4]**2>4096**2
            else:
                assert r['action']=='negative' and -128<=v<0 and r['lower']=='-128'
                upper=max(upper,v)
assert upper==Q(summary['integer_check']['largest_upper'])
assert integer_rows==summary['integer_check']['all_evaluations']

# Reconstruct published brackets from their final separated rows, including every signed rational.
curves=[{k:Q(v) for k,v in r.items()} for r in rows(BASE/'tables/lambda_at_radius.tsv')]
slices=[{k:Q(v) for k,v in r.items()} for r in rows(BASE/'tables/radius_at_lambda.tsv')]
assert len(curves)==33 and len(slices)==7
quad_queries=0
for family,tt in [('N5',curves),('N6',slices)]:
    for i,t in enumerate(tt):
        name=f'curve_{i:02}.tsv' if family=='N5' else f'slice_{int(t["lambda"]*16):02}.tsv'
        rr=rows(BASE/'ledgers'/family/name);quad_queries+=len(rr)
        ends={}
        for side in ('lower','upper'):
            seq=[r for r in rr if r['side']==side]
            assert seq and all(r['status']=='refine' for r in seq[:-1]) and seq[-1]['status']=='separated'
            assert [int(r['n']) for r in seq]==[32*2**j for j in range(len(seq))]
            assert len({r['rho_num20'] for r in seq})==len({r['lambda_num28'] for r in seq})==1
            ends[side]=seq[-1]
        l,h=ends['lower'],ends['upper']
        assert int(l['H_lo'])>0 and int(h['H_hi'])<0
        if family=='N5':
            assert t['rho']==Q(i,32)==Q(int(l['rho_num20']),2**20)==Q(int(h['rho_num20']),2**20)
            assert t['lambda_lo']==Q(int(l['lambda_num28']),2**28) and t['lambda_hi']==Q(int(h['lambda_num28']),2**28)
            assert 2<t['lambda_lo']<t['lambda_hi']<5
        else:
            assert t['lambda']==Q(int(l['lambda_num28']),2**28)==Q(int(h['lambda_num28']),2**28)
            assert t['rho_lo']==Q(int(l['rho_num20']),2**20) and t['rho_hi']==Q(int(h['rho_num20']),2**20)
            assert 0<t['rho_lo']<t['rho_hi']<1 and t['rho_hi']-t['rho_lo']==Q(9,2**20)
        for row,prefix in [(l,'left'),(h,'right')]:
            for k in ('lo','hi'):assert t[f'{prefix}_H_{k}']==Q(int(row[f'H_{k}']),2**47)
for i in range(32):assert curves[i]['lambda_lo']>curves[i+1]['lambda_hi']
for t in (curves[0],curves[-1]):assert t['lambda_hi']-t['lambda_lo']==Q(9,2**24)
assert quad_queries==summary['N5_N6_simpson_queries']

# Exact piecewise sweep of all lookup transition points and open cells.
edges=sorted({2,5}|{t[k] for t in curves for k in ('lambda_lo','lambda_hi')})
queries=edges+[Q(a+b,2) for a,b in zip(edges,edges[1:])]
lookup_max=Q(0);outside_max=Q(0)
for lam in queries:
    lower=max([Q(0)]+[t['rho'] for t in curves if lam<=t['lambda_lo']])
    higher=min([Q(1)]+[t['rho'] for t in curves if lam>=t['lambda_hi']])
    assert lower<=higher
    width=higher-lower;lookup_max=max(lookup_max,width)
    assert width<=Q(1,16)
    if not any(t['lambda_lo']<lam<t['lambda_hi'] for t in curves):
        assert width<=Q(1,32);outside_max=max(outside_max,width)
for t in slices:
    lam=t['lambda'];lo=max([Q(0)]+[r['rho'] for r in curves if lam<=r['lambda_lo']]);hi=min([Q(1)]+[r['rho'] for r in curves if lam>=r['lambda_hi']])
    assert lo<=t['rho_lo']<t['rho_hi']<=hi

# Central local slope records must cover the threshold bracket and produce the quoted ratio.
sl=rows(BASE/'ledgers/N6/slope.tsv');assert len(sl)==2
for r in sl:
    assert Q(int(r['l0']),U)<=curves[0]['lambda_lo']<curves[0]['lambda_hi']<=Q(int(r['l1']),U)
    assert all(int(r[k])==0 for k in ['r0','r1','z0','z1'])
a,b=sl
derivs=[Q(int(a[k]),2**36) for k in ('blo','bhi')]
fourth=[Q(int(b[k]),2**36) for k in ('alo','ahi')]
assert derivs[0]<=derivs[1]<0 and fourth[0]<=fourth[1]<0
ratio=[6*x/y for x in derivs for y in fourth]
assert [str(min(ratio)),str(max(ratio))]==summary['center']['slope']
result={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','scope':'Independent exact-rational structural checks; no numerical kernel rerun or mathematical certification','roots':len(root_results),'total_tree_nodes':total_nodes,'families':stats,'N7_anchors':len(anchors),'N7_queries':integer_rows,'N7_refinements':refinements,'N7_terminal_counts':dict(terminal_counts),'N7_largest_upper':str(upper),'lambda_brackets':len(curves),'radius_brackets':len(slices),'quadrature_rows':quad_queries,'lookup_test_points':len(queries),'lookup_max_width':str(lookup_max),'lookup_max_width_outside_brackets':str(outside_max),'slope':summary['center']['slope'],'issues':[],'root_results':root_results}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='root_results'},ensure_ascii=False,indent=2))
