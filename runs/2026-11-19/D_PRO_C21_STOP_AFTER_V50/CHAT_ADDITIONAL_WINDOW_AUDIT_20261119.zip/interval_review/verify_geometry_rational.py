#!/usr/bin/env python3
"""Independent exact-rational checks of the supplied V49 geometry table.

No floating-point value is used in a mathematical check.  Intermediate intervals
are dyadic rationals rounded outward after every operation.  Pi is enclosed by
the Machin identity and alternating rational arctangent sums.  Sine/cosine are
enclosed by Taylor polynomials and the absolute Lagrange remainder on [0,2].

The cosine-moment recurrence is integration by parts.  Weighted moments use the
positive weight sin(theta)^2.  All seven reported quantities lie in [0,1]
(both variances in fact lie in [0,1/4]); intersecting that range is therefore
valid.  Exact endpoint identities handle 0 and pi/2.
"""
from dataclasses import dataclass
from fractions import Fraction as F
from functools import cache
from hashlib import sha256
from math import factorial
from pathlib import Path
import argparse
import json

if not __debug__:
    raise RuntimeError('Run without -O or PYTHONOPTIMIZE: assertions are checks.')

BITS = 256
D = 1 << BITS
ATAN_TERMS = 80
TAYLOR_INDEX = 48


def ceildiv(a, b):
    assert b > 0
    return -((-a) // b)


@dataclass(frozen=True)
class IV:
    lo: int
    hi: int

    def __post_init__(self):
        assert self.lo <= self.hi

    def __add__(self, b):
        return IV(self.lo + b.lo, self.hi + b.hi)

    def __sub__(self, b):
        return IV(self.lo - b.hi, self.hi - b.lo)

    def __mul__(self, b):
        products = (self.lo*b.lo, self.lo*b.hi,
                    self.hi*b.lo, self.hi*b.hi)
        return IV(min(products)//D, ceildiv(max(products), D))

    def __truediv__(self, b):
        assert b.lo > 0
        return self * IV(D*D//b.hi, ceildiv(D*D, b.lo))

    def square(self):
        low = 0 if self.lo <= 0 <= self.hi else min(self.lo**2, self.hi**2)
        return IV(low//D, ceildiv(max(self.lo**2, self.hi**2), D))

    def power(self, n):
        assert n >= 0
        result = ONE
        for _ in range(n):
            result = result * self
        return result

    def unit(self):
        return IV(max(0, self.lo), min(D, self.hi))


def rational(x):
    x = F(x)
    return IV(x.numerator*D//x.denominator,
              ceildiv(x.numerator*D, x.denominator))


ZERO, ONE = rational(0), rational(1)


def atan_bounds(n):
    partial = sum((F((-1)**j, (2*j+1)*n**(2*j+1))
                   for j in range(ATAN_TERMS)), F(0))
    next_term = F((-1)**ATAN_TERMS,
                  (2*ATAN_TERMS+1)*n**(2*ATAN_TERMS+1))
    return min(partial, partial+next_term), max(partial, partial+next_term)


a5, b5 = atan_bounds(5)
a239, b239 = atan_bounds(239)
PI_LO, PI_HI = 16*a5-4*b239, 16*b5-4*a239
PI = IV(rational(PI_LO).lo, rational(PI_HI).hi)
assert 3*D < PI.lo <= PI.hi < 4*D


@cache
def sine_cosine(multiple):
    """Return sin(pi*multiple), cos(pi*multiple), 0 <= multiple <= 1/2."""
    assert F(0) <= multiple <= F(1, 2)
    if multiple == 0:
        return ZERO, ONE
    if multiple == F(1, 2):
        return ONE, ZERO
    x = PI*rational(multiple)
    assert 0 <= x.lo <= x.hi < 2*D
    xx = x.square()
    result = []
    for odd in (1, 0):
        p = rational(F((-1)**TAYLOR_INDEX,
                       factorial(2*TAYLOR_INDEX+odd)))
        for j in range(TAYLOR_INDEX-1, -1, -1):
            p = p*xx + rational(F((-1)**j, factorial(2*j+odd)))
        if odd:
            p = x*p
        # For degree d, |R| <= 2^(d+1)/(d+1)!, since |sin|,|cos| <= 1.
        order = 2*TAYLOR_INDEX+odd+1
        error = rational(F(1 << order, factorial(order))).hi
        result.append(IV(p.lo-error, p.hi+error).unit())
    return tuple(result)


def angle_quantities(n, i):
    sa, ca = sine_cosine(F(i, 2*n))
    sb, cb = sine_cosine(F(i+1, 2*n))
    width = PI*rational(F(1, 2*n))
    moments = [ONE, (sb-sa)/width]
    for k in (2, 3, 4):
        boundary = sb*cb.power(k-1) - sa*ca.power(k-1)
        moments.append(boundary/(rational(k)*width)
                       + rational(F(k-1, k))*moments[k-2])
    mean = moments[1]
    variance = moments[2]-mean.square()
    mass = ONE-moments[2]
    assert mass.lo > 0
    weighted_mean = (mean-moments[3])/mass
    weighted_variance = (moments[2]-moments[4])/mass-weighted_mean.square()
    return [v.unit() for v in
            (IV(cb.lo, ca.hi), IV(sa.square().lo, sb.square().hi),
             mean, variance, mass, weighted_mean, weighted_variance)]


def verify(table):
    raw = table.read_bytes()
    rows = raw.decode().splitlines()
    assert rows[0] == '# DIAGNOSTIC_ONLY / NOT_EVIDENCE'
    q, g = map(int, rows[1].split())
    assert (q, g) == (1 << 24, 2048)
    assert len(rows) == 2+(g+1)+255
    aa = [F(1)]
    for k in range(17):
        aa.append(aa[-1]*F(2*k+2, 2*k+3))
    qq = [(4+2*k)*aa[k]-(k+1)*aa[k+1] for k in range(17)]
    for i in range(g+1):
        pbound, qbound = map(int, rows[2+i].split())
        h = F(g-i, 2*g)
        pupper = 2*sum(aa[k]*h**k for k in range(17))+4*h**17
        qlower = sum(qq[k]*h**k for k in range(17))
        assert F(pbound, q) >= pupper, ('P upper', i)
        assert F(qbound, q) <= qlower, ('Q lower', i)
    cursor = g+3
    margins = []
    nonstrict = []
    scalar_width = 0
    for n in (1, 2, 4, 8, 16, 32, 64, 128):
        for i in range(n):
            record = list(map(int, rows[cursor].split()))
            cursor += 1
            assert record[:2] == [n, i] and len(record) == 16
            for j, enclosed in enumerate(angle_quantities(n, i)):
                lo, hi = record[2+2*j:4+2*j]
                # Compare integer-scaled rationals without floating point.
                left = enclosed.lo*q-lo*D
                right = hi*D-enclosed.hi*q
                assert left >= 0 and right >= 0, (n, i, j, left, right)
                for side, margin in (('lower', left), ('upper', right)):
                    if margin:
                        margins.append(margin)
                    else:
                        nonstrict.append([n, i, j, side])
                if j >= 2:
                    scalar_width = max(scalar_width, enclosed.hi-enclosed.lo)
    assert cursor == len(rows)
    smallest_margin = F(min(margins), D*q)
    width_upper_power = scalar_width.bit_length()-BITS
    margin_lower_power = (smallest_margin.numerator.bit_length()-1
                          -(smallest_margin.denominator.bit_length()-1))
    return {
        'status': 'PASS', 'arithmetic': 'exact integers and rational outward intervals',
        'table': str(table.resolve()), 'table_sha256': sha256(raw).hexdigest(),
        'checker_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'interval_fractional_bits': BITS, 'arctangent_terms': ATAN_TERMS,
        'sine_degree': 2*TAYLOR_INDEX+1, 'cosine_degree': 2*TAYLOR_INDEX,
        'p_q_rows_checked_exactly': g+1, 'angle_rows_checked_exactly': 255,
        'angle_intervals_checked_exactly': 255*7,
        'angle_bounds_checked_exactly': 255*7*2,
        'max_scalar_interval_width': str(F(scalar_width, D)),
        'max_scalar_interval_width_strictly_below_power_of_two': width_upper_power,
        'smallest_positive_angle_bound_margin': str(smallest_margin),
        'positive_angle_bound_margins_at_least_power_of_two': margin_lower_power,
        'angle_quantity_order': ['cos_range', 'sin_squared_range', 'cos_mean',
                                 'cos_variance', 'sin_squared_mean',
                                 'weighted_cos_mean', 'weighted_cos_variance'],
        'exact_boundary_equality_count': len(nonstrict),
        'exact_boundary_equalities': nonstrict,
        'pi_enclosure': {'lower': str(F(PI.lo, D)), 'upper': str(F(PI.hi, D))},
        'scope': 'Supplied P/Q bounds and all angular moments; not the research conclusion.'
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('table', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.table), ensure_ascii=False, indent=2))
