# D-PRO window stationary structure

DIAGNOSTIC_ONLY / NOT_EVIDENCE　2026-11-19

研究報告は同じディレクトリの CODEX_D_PRO_WINDOW_STATIONARY_20261119.md。七つの指定断面と一般の有理パラメータを照合する例は次のとおり。

    python3 src/lookup.py 3
    python3 src/lookup.py 37/10

## 内容

| パス | 内容 |
|---|---|
| plans/ | 実行前の計画と当時のコード・入力の SHA-256。PLAN_INDEX.tsv に計画ごとのハッシュ一覧 |
| src/ | 区間コード、被覆、再演算、位置照合、集計と図の作成 |
| ledgers/N3/ | V 縦微分、Z 縦 Hessian、E 赤道、C 中心、B 赤道端、T 中央の四階微分 |
| ledgers/N4/ | H 全窓の符号、X 重い板、D 赤道零点でのパラメータ微分 |
| ledgers/N5/、ledgers/N6/ | 各二端の Simpson 和と剰余、および中心の局所分岐係数 |
| ledgers/N7/ | V49 整数実装の全葉・全格子試行。anchor は N4/X00 内の path に対応 |
| logs/ | 数値診断、本走、別ビルドでの再演算、時間と環境 |
| tables/、figures/ | 有理数の全位置包囲、符号の集計、枝の図 |
| v49/、SOURCE_PINS.json | 参照コード、係数表、3 箇所の変更を示す差分、上流資料の内容ハッシュ |

N3/N4 の座標列の分母は 2^20、値の分母は 2^36。N5/N6 の半径分母は 2^20、lambda は 2^28、区間値は 2^47。N6 の slope.tsv は N3 と同じ書式。N7 の座標分母は 4096、上端の分母は各行に記載される。split 行は両子を持ち、空葉の区間値には意味を与えない。N3/N4 の表は各根の箱を球と交差させる前の六端点を保持する。H_undetermined は H の符号だけが未分離の箱である。

## 再現

Linux、IEEE binary64 の丸めモードを尊重する g++、Python 3、NumPy、SymPy を使う。収録表で整数検算を行える。V49 の上流表を一から作り直す場合のみ python-flint が必要。図の再作成には matplotlib を使う。

    bash reproduce.sh replay

これは展開物のハッシュを検証し、別コンパイルで全終端と求積記録を再演算する。全計画の主計算から繰り返す場合は次のコマンドを使う。

    bash reproduce.sh full

全計算は新しい一時ディレクトリで行う。生産台帳は gzip のヘッダ時刻を除く全行を元のパッケージと比較する。計算結果の上下端は整数の完全一致を要求する。実時間はマシンや同時実行状況に依存する。N2 の実行前ハッシュにある src/kernel.cpp はコンパイル前の旧版で、plans/N2_kernel.cpp にそのバイト列を収録した。
