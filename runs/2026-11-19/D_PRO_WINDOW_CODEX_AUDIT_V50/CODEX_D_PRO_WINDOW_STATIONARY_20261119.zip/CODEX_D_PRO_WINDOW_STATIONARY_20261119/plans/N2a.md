# N2a calibration
DIAGNOSTIC_ONLY / NOT_EVIDENCE. N2 ended at compilation: local fourth-derivative variable shadowed the enum Q2. Qualify ::Q2; N2_kernel.cpp retains the old bytes. All N2 grids, decisions, cutoff and time limit remain the same. No evaluation took place under N2.
