#!/usr/bin/env bash
# DIAGNOSTIC_ONLY / NOT_EVIDENCE. Run from an extracted complete package.
set -euo pipefail
mode="${1:-replay}"
if [[ "$mode" != "replay" && "$mode" != "full" ]]; then
  echo 'Usage: bash reproduce.sh [replay|full]' >&2
  exit 2
fi
package_dir="$(cd "$(dirname "$0")" && pwd)"
cd "$package_dir"
sha256sum --quiet -c SHA256SUMS
python3 src/verify_plans.py
run_dir="$(mktemp -d)"
mkdir "$run_dir/work" "$run_dir/bin" "$run_dir/logs"
cp -R src v49 plans ledgers "$run_dir/work"
cd "$run_dir/work"
export OPENBLAS_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
fp=(-std=c++20 -ffp-contract=off -fno-fast-math -frounding-math)
check=(-O1 -fsanitize=undefined -fno-sanitize-recover=all)
b="$run_dir/bin"
if [[ "$mode" == "full" ]]; then
  g++ "${fp[@]}" -O3 src/kernel.cpp -o "$b/kernel"
  g++ "${fp[@]}" -O3 src/map.cpp -o "$b/map"
  g++ "${fp[@]}" -O3 src/quadrature.cpp -o "$b/quad"
  g++ -std=c++20 -O3 v49/chord_window.cpp -o "$b/integer"
  python3 src/cover.py "$b/kernel" VZECTB ledgers/N3 > "$run_dir/logs/N3.jsonl"
  python3 src/map_cover.py "$b/map" ledgers/N4 > "$run_dir/logs/N4.jsonl"
  python3 src/curve.py "$b/quad" ledgers/N5 > "$run_dir/logs/N5.jsonl"
  python3 src/locations.py "$b/quad" "$b/kernel" ledgers/N6 > "$run_dir/logs/N6.jsonl"
  python3 src/integer_check.py run "$b/integer" > "$run_dir/logs/N7.jsonl"
  python3 - "$package_dir/ledgers" <<'PY'
import gzip,sys
from pathlib import Path
a=Path(sys.argv[1])
for p in sorted(a.rglob('*')):
    if not p.is_file():continue
    q=Path('ledgers')/p.relative_to(a)
    read=(lambda f:gzip.decompress(f.read_bytes())) if p.suffix=='.gz' else (lambda f:f.read_bytes())
    assert read(p)==read(q),p
print('All uncompressed producer ledgers match the package.')
PY
fi
g++ "${fp[@]}" "${check[@]}" src/kernel.cpp -o "$b/kernelcheck"
g++ "${fp[@]}" "${check[@]}" src/map.cpp -o "$b/mapcheck"
g++ "${fp[@]}" "${check[@]}" src/quadrature.cpp -o "$b/quadcheck"
g++ -std=c++20 "${check[@]}" v49/chord_window.cpp -o "$b/integercheck"
python3 src/recheck.py ledgers/N3 "$b/kernelcheck" > "$run_dir/logs/N3R.jsonl"
python3 src/extra_recheck.py "$b/mapcheck" "$b/quadcheck" "$b/kernelcheck" > "$run_dir/logs/R46.jsonl"
python3 src/integer_check.py check "$b/integercheck" > "$run_dir/logs/N7R.jsonl"
python3 src/independent.py > "$run_dir/logs/N8.jsonl"
echo "Terminal and quadrature replays agree. Output in $run_dir/logs"
