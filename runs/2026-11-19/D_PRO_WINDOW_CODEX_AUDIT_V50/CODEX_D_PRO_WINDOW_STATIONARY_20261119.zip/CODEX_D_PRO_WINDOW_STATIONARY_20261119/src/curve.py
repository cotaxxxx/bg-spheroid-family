"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Floating candidate selection, then rational sign enclosures."""
import concurrent.futures,csv,json,math,os,subprocess,sys,time
from pathlib import Path
import numpy as np
from numpy.polynomial.legendre import leggauss
P28=1<<28
R20=1<<20
PTS=32
x,w=leggauss(80)
t=((1+x)/2)[:,None]
wt=w[:,None]/2
c2=((1+np.cos(np.pi*(1+x)/2))/2)[None,:]
ww=wt*(w/2)
coef=[1.]
for n in range(49):coef.append(coef[-1]*(2*n+2)/(2*n+3))
pv=np.array([2*k for k in coef[:49]])
qv=np.array([(4+2*n)*coef[n]-(n+1)*coef[n+1] for n in range(49)])
def trial(l,r):
    if r==0: m2=t*t;j=(1-m2)/2;d=1;v=0
    else: m2=(1-t*t)*c2;j=(1-t*t)*(1-c2);d=np.sqrt(1-r*r*(1-t*t));v=r*t
    ci=1/(1+(l*l-1)*m2)
    ans=0.
    for sig in (1,-1):
        e=d-sig*v;T=np.sqrt(ci/(1-(1-l**-2)*e*e*m2));g=np.clip(d*T,0,1)
        fp=np.polynomial.polynomial.polyval((1-g)/2,pv)
        q=np.polynomial.polynomial.polyval((1-g)/2,qv)
        vals=.5*(1-sig*v/d)*T*(fp*d*d*ci*(1-j*ci)-q*j*(e-d*ci)**2)
        ans+=np.sum((wt if r==0 else ww)*vals)
    return float(ans)
def sample(i):
    r=i/PTS;lo=2.;hi=5.
    assert trial(lo,r)>0 and trial(hi,r)<0
    for _ in range(34):
        mid=(lo+hi)/2
        if trial(mid,r)>0:lo=mid
        else:hi=mid
    seed=(lo+hi)/2
    b,pad=(24,4) if i in (0,PTS) else (13,2)
    return seed,(math.floor(seed*2**b)-pad)<<(28-b),(math.ceil(seed*2**b)+pad)<<(28-b)
def work(tk):
    i,exe,out=tk;start=time.monotonic();seed,low,high=sample(i)
    pro=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    checks=0;ok=True;fout=Path(out)/('curve_%02d.tsv'%i)
    with open(fout,'w',newline='')as fs:
        wr=csv.writer(fs,delimiter='\t',lineterminator='\n')
        wr.writerow('rho_num20 lambda_num28 side n k H_lo H_hi sim_lo sim_hi err_lo err_hi status'.split())
        for side,ell in [('lower',low),('upper',high)]:
            resolved=False
            for n in (32,64,128,256,512,1024):
                if time.monotonic()-start>240: raise RuntimeError('curve time cap')
                k=1 if i==0 else n//2
                req=(ell,i*(R20//PTS),n,k)
                pro.stdin.write(' '.join(map(str,req))+'\n');pro.stdin.flush()
                ans=tuple(map(int,pro.stdout.readline().split()))
                if len(ans)!=6: raise RuntimeError('quadrature failed '+str(req))
                resolved=ans[0]>0 if side=='lower' else ans[1]<0
                checks+=1
                wr.writerow((req[1],ell,side,n,k,*ans,'separated' if resolved else 'refine'))
                if resolved:break
            ok=ok and resolved
    pro.stdin.close();assert pro.wait()==0
    return dict(index=i,rho=rational(i,PTS),seed=seed,lambda_lower_num28=low,lambda_upper_num28=high,
                both_signs_separated=ok,queries=checks,seconds=time.monotonic()-start)
def rational(a,b):return f'{a}/{b}'
if __name__=='__main__':
    t0=time.monotonic();Path(sys.argv[2]).mkdir(parents=True,exist_ok=True)
    with concurrent.futures.ProcessPoolExecutor(6) as pool:
        for t in pool.map(work,[(i,sys.argv[1],sys.argv[2])for i in range(PTS+1)]):
            print(json.dumps(t),flush=True)
    print(json.dumps(dict(wall_s=time.monotonic()-t0)))
