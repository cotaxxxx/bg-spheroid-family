"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Fixed workload for N2."""
from fractions import Fraction as F
import subprocess,sys,time
u=2**20
cases=[]
for l in (2,3.5,4.875):
    for r,z in ((0,0),(.5,0),(.9375,0),(0,.1875),(.75,.1875),(.9375,.1875)):
        for w in (0,1/32):
            cases.append(('Z',l,l+4*w,r,r+w,z,z+w,64,32))
    for r,z in ((.25,.25),(.875,.25),(.5,.5),(.25,.75),(0,.9375)):
        for w in (0,1/32):
            cases.append(('V',l,l+4*w,r,r+w,z,z+w,128,32))
    for r in (0,.25,.5,.75,.9375):
        cases.append(('E',l,l+.125,r,r+.03125,0,0,64,32))
    for r in (0,.125,.25,.375):
        cases.append(('T',l,l+.125,r,r+.03125,0,0,128,32))
for l in (2,2.0625,2.125,4.5,4.75,5):
    for mode in 'BC': cases.append((mode,l,l,0,0,0,0,512,256))
start=time.perf_counter()
proc=subprocess.Popen([sys.argv[1]],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
print('mode\tl0\tl1\tr0\tr1\tz0\tz1\tn\tk\tlo\thi\tlo2\thi2\telapsed_s')
for row in cases:
    m,*args,n,k=row
    line=' '.join(map(str,[m,*[int(F(v)*u) for v in args],n,k]))
    proc.stdin.write(line+'\n');proc.stdin.flush()
    output=proc.stdout.readline()
    if not output: raise RuntimeError('terminated '+line)
    vals=list(map(int,output.split()))
    print(*row,*[v/2**36 for v in vals],round(time.perf_counter()-start,5),sep='\t',flush=True)
proc.stdin.close()
if proc.wait()!=0: raise RuntimeError('kernel failed')
