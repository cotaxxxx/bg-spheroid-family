"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Independent rational checks of trees, brackets and replay."""
import concurrent.futures,csv,gzip,json,subprocess,sys,time
from fractions import Fraction as F
from pathlib import Path
U=2**20
def call(exe,requests,answers):
    p=subprocess.run([exe],input=''.join(' '.join(map(str,x))+'\n'for x in requests[::-1]),capture_output=True,text=True,timeout=480,check=True)
    assert not p.stderr and [l.split()for l in p.stdout.splitlines()]==[list(map(str,x))for x in answers[::-1]]
def check_map(arg):
    file,exe=arg;t0=time.monotonic()
    tag=file.name[:3];f=tag[0];i=int(tag[1:]);l=2*U+i*U//4
    box=(79*U//16,5*U,0,U,0,U)if f=='X'else(l,l+U//4,0,U,0,0 if f=='D'else U)
    with gzip.open(file,'rt')as stream:rows=list(csv.DictReader(stream,delimiter='\t'))
    tab={r['path']:r for r in rows};assert len(tab)==len(rows)
    todo=[('x',box)];seen=set();volume=F(0);req=[];ans=[]
    while todo:
        key,b=todo.pop();item=tab[key];assert key not in seen;seen.add(key)
        actual=tuple(int(item[k])for k in 'l0 l1 r0 r1 z0 z1'.split())
        assert b==actual
        a=item['action'];m=item['mode'];assert m==('D'if f=='D'else'H')
        if a.startswith('split'):
            j=2*'lrz'.index(a[-1]);mid,rem=divmod(b[j]+b[j+1],2);assert rem==0 and b[j]<mid<b[j+1]
            left=list(b);right=list(b);left[j+1]=right[j]=mid
            todo.extend([(key+'0',tuple(left)),(key+'1',tuple(right))]);continue
        volume+=F(1,2**(len(key)-1))
        if a=='empty':assert b[2]**2+b[4]**2>U**2;v=['empty']
        else:
            v=[int(item[k])for k in 'alo ahi blo bhi'.split()];x,y,u,w=v;assert x<=y and u<=w
            if a=='H_positive':assert x>0 and f!='X'
            elif a=='H_negative':assert y<0
            elif a=='lambda_decreasing':assert w<0 and f=='D'
            elif a=='H_undetermined':
                assert f=='H' and x<=0<=y and b[1]-b[0]<=U//16 and max(b[3]-b[2],b[5]-b[4])<=U//32
            else:raise AssertionError(a)
        req.append((m,*b,item['n'],item['k']));ans.append(v)
    assert len(seen)==len(rows) and volume==1
    call(exe,req,ans)
    return dict(root=tag,relative_volume=str(volume),nodes=len(rows),replayed=len(req),seconds=time.monotonic()-t0)
def check_quad(arg):
    file,exe=arg;t0=time.monotonic();rows=list(csv.DictReader(file.open(),delimiter='\t'))
    req=[];ans=[];last={}
    for r in rows:
        v=[int(r[k])for k in 'H_lo H_hi sim_lo sim_hi err_lo err_hi'.split()]
        assert v[0]<=v[1] and v[2]<=v[3] and v[4]<=v[5]
        side=r['side'];assert side in ('lower','upper')
        assert (r['status']=='separated')==(v[0]>0 if side=='lower'else v[1]<0)
        if side in last:assert last[side]['status']=='refine' and int(r['n'])==2*int(last[side]['n'])
        else:assert int(r['n'])==32
        last[side]=r
        req.append([r[k]for k in 'lambda_num28 rho_num20 n k'.split()]);ans.append(v)
    assert set(last)=={'lower','upper'} and all(x['status']=='separated'for x in last.values())
    if file.name.startswith('curve'):
        assert int(last['lower']['lambda_num28'])<int(last['upper']['lambda_num28'])
        assert int(last['lower']['rho_num20'])==int(last['upper']['rho_num20'])==int(file.stem[-2:])*U//32
    else:
        assert int(last['lower']['rho_num20'])<int(last['upper']['rho_num20'])
        assert int(last['lower']['lambda_num28'])==int(last['upper']['lambda_num28'])==int(file.stem.split('_')[1])*(1<<24)
    call(exe,req,ans)
    return dict(bracket=file.stem,replayed=len(req),seconds=time.monotonic()-t0)
def main():
    ex1,ex2,ex3=sys.argv[1:];t0=time.monotonic()
    f=sorted(Path('ledgers/N4').glob('*.tsv.gz'));assert len(f)==25
    q=sorted(Path('ledgers/N5').glob('*.tsv'))+sorted(Path('ledgers/N6').glob('slice*.tsv'));assert len(q)==40
    with concurrent.futures.ProcessPoolExecutor(8)as pool:
        for a in pool.map(check_map,[(p,ex1)for p in f]):print(json.dumps(a),flush=True)
        for a in pool.map(check_quad,[(p,ex2)for p in q]):print(json.dumps(a),flush=True)
    rows=list(csv.DictReader(open('ledgers/N6/slope.tsv'),delimiter='\t'))
    call(ex3,[[r[k]for k in 'mode l0 l1 r0 r1 z0 z1 n k'.split()]for r in rows],
         [[r[k]for k in 'alo ahi blo bhi'.split()]for r in rows])
    assert len(rows)==2 and int(rows[0]['bhi'])<0 and int(rows[1]['ahi'])<0
    roots=[]
    for p in sorted(Path('ledgers/N5').glob('*.tsv')):
        a=list(csv.DictReader(p.open(),delimiter='\t'));roots.append((int(a[0]['lambda_num28']),int(a[-1]['lambda_num28'])))
    assert all(roots[j][0]>roots[j+1][1] for j in range(32))
    print(json.dumps(dict(slope_replayed=2,disjoint_ordered_crossings=33,wall_s=time.monotonic()-t0)))
if __name__=='__main__':main()
