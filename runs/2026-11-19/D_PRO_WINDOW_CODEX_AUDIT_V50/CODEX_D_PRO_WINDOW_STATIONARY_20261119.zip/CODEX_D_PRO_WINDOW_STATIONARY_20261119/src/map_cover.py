"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Global H atlas, heavy slab and equatorial crossing orientation."""
from cover import U,COLS,halves
import concurrent.futures,csv,gzip,json,subprocess,sys,time
from pathlib import Path

def root(f,i):
    lo=79*U//16 if f=='X' else 2*U+i*(U//4)
    hi=5*U if f=='X' else lo+U//4
    return (lo,hi,0,U,0,0 if f=='D' else U)
def job(args):
    f,i,exe,dest=args
    mode='D' if f=='D' else 'H'
    pro=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    start=time.monotonic();stats={};todo=[('x',root(f,i))];tag=f+str(i).zfill(2)
    with gzip.open(Path(dest)/(tag+'.tsv.gz'),'wt',newline='') as fs:
        wr=csv.writer(fs,delimiter='\t',lineterminator='\n');wr.writerow(COLS)
        while todo:
            key,box=todo.pop();l,h,r,s,z,y=box
            if time.monotonic()-start>480 or sum(stats.values())>350000:raise RuntimeError('time/node cap '+tag)
            ratios=((h-l)/4/U,(s-r)/U,(y-z)/U);w=max(ratios)
            if f=='D':
                n,k=(64,32) if w>1/16 else (128,64) if w>1/64 else (256,128) if w>1/256 else (512,256)
            elif f=='X':
                n,k=64,16
                if w<=1/8:n,k=128,32
                if w<=1/32:n,k=256,32
                if w<=1/128:n,k=512,64
                if w<=1/512:n,k=1024,128
            else:
                n,k=(32,16) if w>1/8 else (64,32) if w>1/32 else (128,32)
            pro.stdin.write(' '.join(map(str,(mode,*box,n,k)))+'\n');pro.stdin.flush()
            out=pro.stdout.readline().strip()
            if not out:raise RuntimeError('kernel exit '+tag+key)
            if out=='empty':ans=('--',)*4;action='empty'
            else:
                ans=tuple(map(int,out.split()));a,b,c,d=ans
                if a>0:action='H_positive'
                elif b<0:action='H_negative'
                elif f=='D' and d<0:action='lambda_decreasing'
                elif f=='H' and h-l<=U//16 and s-r<=U//32 and y-z<=U//32:action='H_undetermined'
                elif len(key)>36:action='open'
                else:
                    coeff=(1,4,4) if f!='H' else (1,2,2)
                    axis=2*max(range(3),key=lambda j:coeff[j]*(box[2*j+1]-box[2*j]))
                    action='split'+'lrz'[axis//2]
                    a1,b1=halves(box,axis);todo.extend([(key+'1',b1),(key+'0',a1)])
            wr.writerow((key,*box,mode,n,k,*ans,action))
            stats[action]=stats.get(action,0)+1
    pro.stdin.close();assert pro.wait()==0
    return dict(root=tag,counts=stats,nodes=sum(stats.values()),wall_s=time.monotonic()-start)
if __name__=='__main__':
    out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
    todo=[(f,i,sys.argv[1],out) for f in 'XDH' for i in range(1 if f=='X' else 12)]
    start=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(8) as pool:
        for res in concurrent.futures.as_completed([pool.submit(job,t) for t in todo]):
            print(json.dumps(res.result()),flush=True)
    print(json.dumps(dict(wall_s=time.monotonic()-start)),flush=True)
