"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact lookup for the interior circle in reference coordinates."""
import argparse
import csv
from fractions import Fraction as F
from pathlib import Path

def load_table(name):
    with (Path(__file__).resolve().parents[1]/'tables'/name).open() as stream:
        return [{k:F(v) for k,v in row.items()} for row in csv.DictReader(stream,delimiter='\t')]

def region(value):
    if not 2<=value<=5: raise ValueError('lambda must belong to [2,5]')
    grid=load_table('lambda_at_radius.tsv')
    edge=grid[-1];center=grid[0]
    if value<=edge['lambda_lo']:return 'Center only, strict local minimum.'
    if value>=center['lambda_hi']:return 'Center only, nondegenerate saddle.'
    low=max([F(0)]+[r['rho']for r in grid if value<=r['lambda_lo']])
    high=min([F(1)]+[r['rho']for r in grid if value>=r['lambda_hi']])
    if value<edge['lambda_hi']:
        return f'Inside boundary-threshold bracket. Center is a strict minimum. An interior circle exists exactly when lambda > lambda_b. If present, rho lies in [{low}, {high}].'
    if value>center['lambda_lo']:
        return f'Inside center-threshold bracket. Circle exists exactly when lambda < lambda_c. If present, rho lies in [{low}, {high}]. Center is a minimum below, a degenerate saddle at, and a nondegenerate saddle above lambda_c.'
    for row in load_table('radius_at_lambda.tsv'):
        if value==row['lambda']:low,high=row['rho_lo'],row['rho_hi'];break
    return f'Center is a strict minimum. One saddle circle at z=0, rho in [{low}, {high}].'
if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('lambda_value',type=F);v=a.parse_args()
    print('DIAGNOSTIC_ONLY / NOT_EVIDENCE')
    print(region(v.lambda_value))
