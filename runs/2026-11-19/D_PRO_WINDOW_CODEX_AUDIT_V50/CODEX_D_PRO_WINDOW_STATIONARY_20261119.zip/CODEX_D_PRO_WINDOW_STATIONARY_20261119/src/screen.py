"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Floating point chord diagnostic."""
import time
import numpy as np
from numpy.polynomial.legendre import leggauss

def rule(n):
    u,w=leggauss(n)
    return (u+1)/2,w/2

def run():
    m,wm=rule(64)
    phi,wp=rule(96)
    m=m[:,None]
    weights=wm[:,None]*wp
    s=np.sqrt(1-m*m)
    ex=s*np.cos(np.pi*phi)
    j=(s*np.sin(np.pi*phi))**2
    a=[1.]
    for n in range(17):
        a.append(a[-1]*(2*n+2)/(2*n+3))
    print('lambda\trho\tz\tH\tEzz\tEz')
    for lam in (2,2.5,3,3.5,4,4.5,5):
        C=1+(lam*lam-1)*m*m
        for z in (0,.125,.5,.75,.875,.9375,1.):
            for frac in (0,.25,.5,.75,1.):
                if z==1 and frac: continue
                r=frac*np.sqrt(1-z*z)
                v=r*ex+z*m
                d=np.sqrt(np.maximum(0,1-z*z-r*r)+v*v)
                H=Ezz=Ez=0.
                for sig in (-1,1):
                    ell=d-sig*v
                    w=.5*ell/d
                    mu=z+sig*ell*m
                    B=1-(1-1/lam**2)*mu*mu
                    g=np.minimum(1,d/np.sqrt(B*C))
                    h=(1-g)/2
                    alpha=np.arccos(g)
                    den=np.maximum(1e-30,1-g*g)
                    fp=2*alpha/np.sqrt(den)
                    q=2*fp+g*(g*fp-2)/den
                    fseries=np.polynomial.polynomial.polyval(h,[2*t for t in a[:17]])
                    qseries=np.polynomial.polynomial.polyval(h,[(4+2*n)*a[n]-(n+1)*a[n+1] for n in range(17)])
                    fp=np.where(h<1/32,fseries,fp)
                    q=np.where(h<1/32,qseries,q)
                    common=weights*w/np.sqrt(C*B)
                    H+=np.sum(common*(fp*d*d/C*(1-j/C)-q*j*(ell-d/C)**2))
                    Ezz+=np.sum(common*(fp*d*d/C*lam**2*(1-lam**2*m*m/C)-q*(mu-sig*d*m*lam**2/C)**2))
                    Ez+=np.sum(weights*w*ell*(-mu*alpha**2+g*fp*(mu-sig*d*m*lam**2/C)))
                print(lam,r,z,H,Ezz,Ez,sep='\t')
if __name__=='__main__': run()
