// DIAGNOSTIC_ONLY / NOT_EVIDENCE. Composite Simpson with interval fourth-derivative remainders.
#include "interval.hpp"
#include <iostream>
#include <map>
#include <memory>
struct Jet{
 std::array<I,5> c{};
 Jet()=default;
 Jet(double x){c[0]=x;}
 Jet(I x){c[0]=x;}
};
inline Jet operator+(const Jet&a,const Jet&b){Jet q;for(int k=0;k<5;k++)q.c[k]=a.c[k]+b.c[k];return q;}
inline Jet operator-(const Jet&a,const Jet&b){Jet q;for(int k=0;k<5;k++)q.c[k]=a.c[k]-b.c[k];return q;}
inline Jet operator*(const Jet&a,const Jet&b){
 Jet q;
 for(int k=0;k<5;k++){I v=a.c[0]*b.c[k];for(int j=1;j<=k;j++)v=v+a.c[j]*b.c[k-j];q.c[k]=v;}
 return q;
}
inline Jet rec(const Jet&a){
 Jet q;q.c[0]=inv(a.c[0]);
 for(int k=1;k<5;k++){I v=a.c[1]*q.c[k-1];for(int j=2;j<=k;j++)v=v+a.c[j]*q.c[k-j];q.c[k]=-q.c[0]*v;}
 return q;
}
inline Jet rt(const Jet&a){
 Jet q;q.c[0]=root(a.c[0]);I c=.5*inv(q.c[0]);
 for(int k=1;k<5;k++){I v=a.c[k];for(int j=1;j<k;j++)v=v-q.c[j]*q.c[k-j];q.c[k]=v*c;}
 return q;
}
inline I rec(I a){return inv(a);} inline I rt(I a){return root(a);}
inline I& base(I& a){return a;} inline I& base(Jet& a){return a.c[0];}
inline I plus_sq(I a){return sq(a);}
inline Jet plus_sq(const Jet& a){Jet b=a*a;b.c[0]=sq(a.c[0]);return b;}
constexpr int size_tab=4096,deg=96,K=6;
struct Coefs{
 std::array<std::array<std::array<I,size_tab+1>,K+1>,2> tab;
 Coefs(){
  I a[deg+2],q[deg+1];a[0]=1;
  for(int n=0;n<=deg;n++){
   a[n+1]=a[n]*(2*n+2)/I(2*n+3);
   q[n]=(4+2*n)*a[n]-(n+1)*a[n+1];
  }
  for(int k=0;k<=K;k++){
   double comb=1;I pc[deg+1],qc[deg+1];
   for(int n=k;n<=deg;n++){
    if(n>k)comb=std::round(comb*n/(n-k)); // exact integer below 2^53 (see report)
    I factor=std::ldexp(comb,-k);
    pc[n]=factor*2*a[n];qc[n]=factor*q[n];
   }
   for(int i=0;i<=size_tab;i++){
    I h=(1.-double(i)/size_tab)*.5,p=pc[deg],v=qc[deg];
    for(int n=deg-1;n>=k;n--){p=p*h+pc[n];v=v*h+qc[n];}
    tab[0][k][i]=p+I(0,0x1p-52);tab[1][k][i]=v+I(0,0x1p-52);
   }
  }
 }
 I av(int which,int k,I g)const{
  int a=int(g.l*size_tab),b=int(std::ceil(g.h*size_tab));
  return {tab[which][k][b].l,tab[which][k][a].h};
 }
 I value_at(int f,double x)const{
  int i=int(x*size_tab);
  if(i==size_tab)return tab[f][0][i];
  I h=I(x)-double(i)/size_tab;
  I last{tab[f][2][i+1].l,tab[f][2][i].h};
  return tab[f][0][i]-h*tab[f][1][i]+sq(h)*last;
 }
 I eval(int f,I g)const{
  g=bound01(g);
  return {value_at(f,g.h).l,value_at(f,g.l).h};
 }
 Jet eval(int f,Jet g)const{
  g.c[0]=bound01(g.c[0]);I b=g.c[0];g.c[0]=0;
  Jet v(av(f,4,b));
  for(int k=3;k>=0;k--)v=v*g+Jet(k%2?-av(f,k,b):av(f,k,b));
  return v;
 }
};
std::unique_ptr<Coefs> cf;
struct Lambda{I l2,ep,ecc;};
template<class A>A density(const Lambda& L,double r,A t,A a){
 A t2=plus_sq(t),s2=A(1)-t2,m2,j;
 if(r==0){
  m2=t2;j=A(.5)*s2;
 }else{
  m2=s2*a;j=s2*(A(1)-a);
 }
 A ci=rec(A(1)+A(L.l2-1)*m2);
 if(r==0||r==1){
  A d=r==0?A(1):t;
  A zz=r==0?t2:A(4)*t2*m2;
  A B=A(1)-A(L.ecc)*zz;base(B)=meet(base(B),{L.ep.l,1});
  A T=rt(ci*rec(B)),g=d*T;
  A P=cf->eval(0,g),Q=cf->eval(1,g);
  return T*plus_sq(d)*(P*ci*(A(1)-j*ci)-Q*j*plus_sq(A(r==0?1:2)-ci));
 }
 A d2=A(1)-A(r*r)*s2;
 base(d2)=meet(base(d2),{1-r*r,1});
 A d=rt(d2),v=A(r)*t,w=(A(1)-v*rec(d))*A(.5);
 base(w)=bound01(base(w));
 A out(0);
 for(int sig:{-1,1}){
  A ell=d-A(sig)*v, zz=plus_sq(ell)*m2;
  A B=A(1)-A(L.ecc)*zz;base(B)=meet(base(B),{L.ep.l,1});
  A T=rt(ci*rec(B)),g=d*T;
  A P=cf->eval(0,g),Q=cf->eval(1,g);
  A h=T*(P*d2*ci*(A(1)-j*ci)-Q*j*plus_sq(ell-d*ci));
  out=out+(sig==1?w:A(1)-w)*h;
 }
 return out;
}
struct Angular{
 std::vector<I> pts,centers,cosrange,sinrange;
};
const Angular& angular_q(int n){
 static std::map<int,Angular> lookup;
 auto& g=lookup[n];if(!g.pts.empty())return g;
 int M=2*n;auto arcs=angular(M);
 auto node=[&](int j)->I{
  if(j<0)j=-j;
  if(j==0)return 1;
  if(j==M)return -1;
  return {arcs[j-1].c.l,arcs[j].c.h};
 };
 for(int j=0;j<=M;j++)g.pts.push_back(bound01((1+node(j))*.5));
 for(int j=0;j<n;j++){
  g.cosrange.push_back({node(2*j+2).l,node(2*j).h});
  I a=node(n-2*j),b=node(n-(2*j+2));
  g.sinrange.push_back({std::min(a.l,b.l),(2*j<=n&&n<=2*j+2)?1.:std::max(a.h,b.h)});
  g.centers.push_back(bound01((1+g.cosrange.back())*.5));
 }
 return g;
}
inline int weight(int i,int n){return (i==0||i==2*n)?1:(i%2?4:2);}
std::array<I,3> integrate(double lam,double r,int n,int k){
 Lambda L;L.l2=sq(I(lam));L.ep=inv(L.l2);L.ecc=1-L.ep;
 I pi{0x1.921fb54442d18p+1,0x1.921fb54442d19p+1},p2=sq(pi);
 const auto& g=angular_q(k);
 I val=0,err=0;
 for(int i=0;i<=2*n;i++){
  I t=double(i)/(2*n),row=0;
  if(r==0)row=density<I>(L,r,t,0);
  else {
   for(int j=0;j<=2*k;j++)row=row+weight(j,k)*density<I>(L,r,t,g.pts[j]);
   row=row/I(6*k);
  }
  val=val+weight(i,n)*row;
 }
 val=val/I(6*n);
 I ht4=std::pow(1./n,4),hu4=std::pow(1./k,4); // dyadic powers; also verified below
 if(ht4.l!=std::ldexp(1.,-4*std::countr_zero((unsigned)n))||
    hu4.l!=std::ldexp(1.,-4*std::countr_zero((unsigned)k)))throw std::runtime_error("grid scale");
 for(int i=0;i<n;i++){
  I tx{double(i)/n,double(i+1)/n};Jet t(tx);t.c[1]=1;
  I row=0;
  if(r==0)row=-density<Jet>(L,r,t,Jet(0)).c[4]*ht4;
  else {
   for(int j=0;j<k;j++){
    Jet u(g.centers[j]);u.c[1]=-pi*g.sinrange[j]*.5;
    u.c[2]=-p2*g.cosrange[j]*.25;u.c[3]=p2*pi*g.sinrange[j]/I(12);
    u.c[4]=sq(p2)*g.cosrange[j]/I(48);
    I rt4=density<Jet>(L,r,t,Jet(u.c[0])).c[4];
    I ru4=density<Jet>(L,r,Jet(tx),u).c[4];
    row=row-(rt4*ht4+ru4*hu4);
   }
   row=row/I(k);
  }
  err=err+row;
 }
 err=err/I(120*n);
 return {val+err,val,err};
}
int main(){
 try {
  setup();cf=std::make_unique<Coefs>();
  long long ell,rr;int n,k;
  while(std::cin>>ell>>rr>>n>>k){
   if(ell<2LL*(1LL<<28)||ell>5LL*(1LL<<28)||rr<0||rr>(1LL<<20)||n<1||k<1||n>2048||k>2048||
       (n&(n-1))||(k&(k-1)))throw std::runtime_error("unsupported endpoint grid");
   auto v=integrate(std::ldexp(double(ell),-28),std::ldexp(double(rr),-20),n,k);
   for(I s:v){
    if(!std::isfinite(s.l)||!std::isfinite(s.h)||s.l>s.h||std::max(s.h,-s.l)>10000)throw std::runtime_error("quad range");
    std::cout<<(long long)std::floor(s.l*0x1p47)<<' '<<(long long)std::ceil(s.h*0x1p47)<<' ';
   }
   std::cout<<std::endl;
  }
  return std::cin.eof()?0:2;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 3;}
}
