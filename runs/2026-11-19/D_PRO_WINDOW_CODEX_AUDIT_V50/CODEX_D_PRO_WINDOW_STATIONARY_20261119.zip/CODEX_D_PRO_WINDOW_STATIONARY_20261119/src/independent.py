"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Exact algebra/constant checks and direct energy differences."""
from fractions import Fraction as F
from math import comb,factorial
from pathlib import Path
import csv,gzip,json,time
import numpy as np
import sympy as s
from numpy.polynomial.legendre import leggauss
def exact():
    g,n,b,A,Q,Q1,Q2=s.symbols('g n b A Q Q1 Q2');p=1-n*n
    def op(f):
        return (b*(f.diff(g)+g*Q*f.diff(A)+Q1*f.diff(Q)+Q2*f.diff(Q1))
                +p*f.diff(n)-(n*b+g*p)*f.diff(b))
    G2=A*p-Q*b*b;G3=op(G2)-n*G2;G4=op(G3)-2*n*G3
    formula=(-3*(A+g*g*Q)*p**2+12*A*n*n*p-24*n*b*g*Q*p+
             (6*(Q+g*Q1)*p-12*n*n*Q)*b*b+8*n*b*Q1*b*b-Q2*b**4)
    assert s.expand(G4-formula)==0
    t=s.symbols('t');moment=s.integrate(t*(t-1)*(t-s.Rational(1,2))**2,(t,0,1))
    assert moment==-s.Rational(1,120)
    def atan(n):
        v=sum(F((-1)**j,(2*j+1)*n**(2*j+1)) for j in range(25))
        return v-F(1,51*n**51),v
    l,u=atan(5);v,w=atan(239);lo=16*l-4*w;hi=16*u-4*v
    assert F(float.fromhex('0x1.921fb54442d18p+1'))<lo<hi<F(float.fromhex('0x1.921fb54442d19p+1'))
    tails=[]
    for N,K,raw,bits in [(60,2,True,38),(96,6,False,52)]:
        upper=0
        for k in range(K+1):
            n0=N+1
            f=F((4+2*n0)*comb(n0,k),1<<n0)*(factorial(k)if raw else 1)
            ratio=F((6+2*n0)*(n0+1),2*(4+2*n0)*(n0+1-k))
            upper=max(upper,f/(1-ratio))
        assert upper<F(1,1<<bits);tails.append(str(upper))
    return dict(fourth_residual='0',simpson_signed_moment=str(moment),pi='enclosed',series_tail_upper=tails)
def values(l,r,z):
    x,w=leggauss(144);mu=x[:,None];si=np.sqrt(1-mu*mu)
    u=np.pi*(1+x)/2;xx=si*np.cos(u);yy=si*np.sin(u)
    weight=w[:,None]*w[None,:]/4
    nx,ny,nz=xx,yy,mu/l
    def energy(a,b,c):
        vx,vy,vz=xx-a,yy-b,l*(mu-c)
        cross=np.sqrt((vy*nz-vz*ny)**2+(vz*nx-vx*nz)**2+(vx*ny-vy*nx)**2)
        k=1-a*xx-b*yy-c*mu
        return np.sum(weight*k*np.arctan2(cross,k)**2)
    points=list(range(-4,5));h=1/128
    def fd(axis,d):
        weights=s.finite_diff_weights(d,points,0)[d][-1]
        return sum(float(w0)*energy(r+(h*j if axis==0 else 0),h*j if axis==1 else 0,
                                   z+(h*j if axis==2 else 0)) for w0,j in zip(weights,points))/h**d
    return dict(H=fd(1,2),Ez=fd(2,1),Ezz=fd(2,2),Exx=fd(0,2),T=fd(1,4))
def run():
    start=time.monotonic();print(json.dumps(exact()),flush=True);cache={}
    pts=[(2.,0.,0.),(2.5,.5,.25),(3.,.75,0.),(3.5,.5,.5),(4.,.25,.75),
         (4.5,.25,0.),(4.75,0.,0.),(5.,.25,.1875),(5.,0.,.875)]
    for l,r,z in pts:
        vals=values(l,r,z);comp={}
        for where,f in [('ledgers/N4','H'),('ledgers/N3','Z' if z<=.25 else 'V')]+([('ledgers/N3','E')]if z==0 else []):
            key=(where,f,min(11,int((l-2)*4)))
            if key not in cache:
                p=Path(where)/(f+str(key[2]).zfill(2)+'.tsv.gz')
                cache[key]=[t for t in csv.DictReader(gzip.open(p,'rt'),delimiter='\t')if not t['action'].startswith('split') and t['action']!='empty']
            u=2**20
            covers=[t for t in cache[key] if all(int(t[a])<=v*u<=int(t[b]) for a,b,v in [('l0','l1',l),('r0','r1',r),('z0','z1',z)])]
            assert covers
            for t in covers:
                mode=t['mode']
                for what,a,b in {'H':[('H','alo','ahi')],'V':[('Ez','alo','ahi')],'Z':[('Ezz','alo','ahi')],
                                 'E':[('H','alo','ahi'),('Exx','blo','bhi')],'T':[('T','alo','ahi')]}[mode]:
                    low=int(t[a])/2**36;high=int(t[b])/2**36
                    assert low-2e-5<vals[what]<high+2e-5
                    comp[what]=comp.get(what,0)+1
        print(json.dumps(dict(lam=l,rho=r,z=z,energy_differences=vals,comparisons=comp)),flush=True)
    print(json.dumps(dict(wall_s=time.monotonic()-start)))
if __name__=='__main__':run()
