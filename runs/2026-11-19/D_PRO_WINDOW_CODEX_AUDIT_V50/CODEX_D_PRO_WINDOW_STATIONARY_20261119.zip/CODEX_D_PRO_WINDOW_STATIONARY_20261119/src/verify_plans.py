"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Validate frozen-file hashes, including historical N2."""
from pathlib import Path
import hashlib
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run():
    total=0
    for freeze in sorted(Path('plans').glob('*.sha256')):
        for line in freeze.read_text().splitlines():
            expected,name=line.split(None,1)
            path=Path('plans/N2_kernel.cpp') if freeze.name=='N2.sha256' and name=='src/kernel.cpp' else Path(name)
            assert digest(path)==expected,(freeze,path)
            total+=1
    print(f'{total} frozen input hashes agree.')
if __name__=='__main__':run()
