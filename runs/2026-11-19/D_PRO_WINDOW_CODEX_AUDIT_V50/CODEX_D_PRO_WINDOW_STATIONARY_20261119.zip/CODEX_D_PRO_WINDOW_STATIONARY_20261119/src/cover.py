"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Predeclared dyadic cover of the window."""
import argparse
import concurrent.futures
import csv
import gzip
import json
from pathlib import Path
import subprocess
import time

U=2**20
D=2**36
FAMILIES='ZVECTB'
COLS='path l0 l1 r0 r1 z0 z1 mode n k alo ahi blo bhi action'.split()
def root_box(f,i):
    box=(2*U+i*U//4,2*U+(i+1)*U//4,0,U,0,0)
    if f=='Z': return (*box[:4],0,U//4)
    if f=='V': return (*box[:4],U//4,U)
    if f in 'CB': return (*box[:2],0,0,0,0)
    if f=='T': return (*box[:2],0,U//8,0,0)
    return box
def cut(f,box):
    sizes=[box[i+1]-box[i] for i in (0,2,4)]
    coeff={'V':(1,6,12),'Z':(1,5,8),'E':(1,5,0),'T':(1,6,0),
           'B':(1,0,0),'C':(1,0,0)}[f]
    return 2*max(range(3),key=lambda j:sizes[j]*coeff[j])
def halves(box,j):
    lo=list(box);hi=list(box);m=(box[j]+box[j+1])//2
    if not box[j]<m<box[j+1]:raise RuntimeError('cannot bisect')
    lo[j+1]=m;hi[j]=m
    return tuple(lo),tuple(hi)
def queries(f,box):
    l,h,r,s,z,y=box
    w=max((h-l)/4,s-r,y-z)/U
    if f=='V': return [('V',64,16)] if w>1/8 else [('V',128,32)] if w>1/32 else [('V',256,64)]
    if f=='Z': return [('Z',32,16)] if w>1/8 else [('Z',64,32)] if w>1/32 else [('Z',128,64)]
    if f=='C':return [('C',1024,2)]
    if f=='B':return [('B',256,128)] if h-l>U//32 else [('B',512,256)]
    if f=='T':return [('T',128,64)]
    if s<=U//2:
        return [('T',128,64),('E',128,64)] if w<=1/16 else [('E',64,32),('T',64,32)]
    return [('E',64,32)] if w>1/16 else [('E',128,64)] if w>1/64 else [('E',256,128)]
def decide(f,mode,a,b,c,d,box):
    if f in 'VZ': return 'positive' if a>0 else ''
    if f=='C':return 'lambda_decreasing' if d<0 else ''
    if f=='B':
        if box[0]<9*U//4: return 'lambda_decreasing' if d<0 else ''
        return 'negative' if b<0 else ''
    if mode=='T':return 'radial_decreasing' if b<0 else ''
    if a>0:return 'H_positive'
    if b<0:return 'H_negative'
    if d<0:return 'radial_curvature_negative'
    return ''
def name(f,i):return f+str(i).zfill(2)
def work(task):
    f,i,exe,out=task
    stem=name(f,i); dest=Path(out)/(stem+'.tsv.gz')
    started=time.monotonic(); nodes=0
    proc=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    todo=[('x',root_box(f,i))];stats={}
    with gzip.open(dest,'wt',newline='') as stream:
        w=csv.writer(stream,delimiter='\t',lineterminator='\n')
        w.writerow(COLS)
        while todo:
            key,box=todo.pop();nodes+=1
            if nodes>600000 or time.monotonic()-started>360:raise RuntimeError('cap '+stem)
            action=''
            for mode,n,k in queries(f,box):
                q=' '.join(map(str,(mode,*box,n,k)))
                proc.stdin.write(q+'\n');proc.stdin.flush();reply=proc.stdout.readline().strip()
                if reply=='empty':
                    ans=('--',)*4;action='empty';break
                if not reply:raise RuntimeError(f'{stem}: no response {q}')
                ans=tuple(map(int,reply.split()))
                action=decide(f,mode,*ans,box)
                if action: break
            if not action:
                if len(key)>36: action='open'
                else:
                    j=cut(f,box);a,b=halves(box,j);action='split'+'lrz'[j//2]
                    todo.extend([(key+'1',b),(key+'0',a)])
            w.writerow((key,*box,mode,n,k,*ans,action))
            stats[action]=stats.get(action,0)+1
    proc.stdin.close()
    if proc.wait()!=0:raise RuntimeError('kernel exit')
    return dict(root=stem,counts=stats,nodes=nodes,wall_s=round(time.monotonic()-started,5))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('exe');p.add_argument('families');p.add_argument('out')
    p.add_argument('--workers',type=int,default=8);a=p.parse_args()
    Path(a.out).mkdir(parents=True,exist_ok=True)
    tasks=[(f,i,a.exe,a.out) for f in a.families for i in range(12)]
    start=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(a.workers) as pool:
        for job in concurrent.futures.as_completed([pool.submit(work,t) for t in tasks]):
            print(json.dumps(job.result()),flush=True)
    print(json.dumps(dict(total_elapsed_s=time.monotonic()-start)),flush=True)
