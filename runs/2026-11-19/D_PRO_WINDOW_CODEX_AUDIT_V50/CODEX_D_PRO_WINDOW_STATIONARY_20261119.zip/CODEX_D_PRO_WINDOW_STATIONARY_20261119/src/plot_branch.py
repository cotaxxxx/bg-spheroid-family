"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Plot only boxes derived from the exact location tables."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
from matplotlib.lines import Line2D
from lookup import load_table
base=Path(__file__).resolve().parents[1]
g=load_table('lambda_at_radius.tsv')
fig,ax=plt.subplots(figsize=(7.8,4.4),layout='constrained')
for low,hi in zip(g,g[1:]):
    x0=float(hi['lambda_lo']);x1=float(low['lambda_hi'])
    y0=float(low['rho']);y1=float(hi['rho'])
    ax.add_patch(Rectangle((x0,y0),x1-x0,y1-y0,edgecolor='#448582',facecolor='#b5dcd7',lw=.55,zorder=2))
for t in load_table('radius_at_lambda.tsv'):
    x=float(t['lambda']);a=float(t['rho_lo']);b=float(t['rho_hi'])
    ax.vlines(x,a,b,color='#153c54',lw=3,zorder=4)
    ax.scatter([x],[(a+b)/2],color='#153c54',s=17,zorder=4)
edge,center=g[-1],g[0]
for row,y,label,xy in [(edge,1,r'$\lambda_b$',(6,2)),(center,0,r'$\lambda_c$',(6,8))]:
    x=float((row['lambda_lo']+row['lambda_hi'])/2)
    ax.scatter([x],[y],facecolors='white',edgecolors='#153c54',s=34,zorder=5)
    ax.annotate(label,(x,y),xytext=xy,textcoords='offset points',fontsize=11)
ax.set(xlim=(1.96,5.02),ylim=(-.035,1.065),xlabel=r'Aspect ratio $\lambda$',ylabel=r'Circle radius $\rho$ in the reference ball')
ax.set_title('Equatorial stationary circle',loc='left',weight='bold',fontsize=14,pad=10)
ax.set_axisbelow(True);ax.grid(color='#d8dddf',lw=.55)
ax.spines[['right','top']].set_visible(False)
ax.legend(handles=[Patch(facecolor='#b5dcd7',edgecolor='#448582',label='Rigorous branch enclosure'),
                   Line2D([],[],marker='o',linestyle='',color='#153c54',markersize=4,label='Seven enclosed radii')],
          loc='lower left',frameon=False,fontsize=9)
dest=base/'figures';dest.mkdir(exist_ok=True)
fig.savefig(dest/'branch.png',dpi=180)
