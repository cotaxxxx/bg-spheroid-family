"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Radius bounds for seven parameter sections and center slope."""
from curve import trial,R20,P28
from pathlib import Path
import concurrent.futures,csv,math,json,subprocess,sys,time
def work(args):
    lam,exe,folder=args
    start=time.monotonic()
    lo=0.;hi=1.
    assert trial(lam,lo)>0>trial(lam,hi)
    for _ in range(34):
        mid=(lo+hi)/2
        if trial(lam,mid)>0:lo=mid
        else:hi=mid
    seed=(lo+hi)/2;lower=math.floor(seed*R20)-4;upper=math.ceil(seed*R20)+4
    p=subprocess.Popen([exe],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    ok=True
    with open(folder/('slice_'+str(int(lam*16))+'.tsv'),'w',newline='') as stream:
        w=csv.writer(stream,delimiter='\t',lineterminator='\n')
        w.writerow('rho_num20 lambda_num28 side n k H_lo H_hi sim_lo sim_hi err_lo err_hi status'.split())
        for side,r in [('lower',lower),('upper',upper)]:
            for n in (32,64,128,256,512,1024):
                if time.monotonic()-start>240:raise RuntimeError('N6 time cap')
                k=n//2;ell=int(lam*P28)
                p.stdin.write(f'{ell} {r} {n} {k}\n');p.stdin.flush()
                vals=tuple(map(int,p.stdout.readline().split()));assert len(vals)==6
                sep=vals[0]>0 if side=='lower' else vals[1]<0
                w.writerow((r,ell,side,n,k,*vals,'separated' if sep else 'refine'))
                if sep:break
            ok=ok and sep
    p.stdin.close();assert p.wait()==0
    return dict(lam=lam,rho_lo_num20=lower,rho_hi_num20=upper,seed=seed,both_signs_separated=ok,seconds=time.monotonic()-start)
if __name__=='__main__':
    folder=Path(sys.argv[3]);folder.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    with concurrent.futures.ProcessPoolExecutor(5)as pool:
        for t in pool.map(work,[(l,sys.argv[1],folder)for l in (17/8,5/2,3,7/2,4,9/2,75/16)]):print(json.dumps(t),flush=True)
    rows=list(csv.DictReader(open('ledgers/N5/curve_00.tsv'),delimiter='\t'))
    a=min(int(r['lambda_num28'])for r in rows)//256
    b=(max(int(r['lambda_num28'])for r in rows)+255)//256
    req=[('C',a,b,0,0,0,0,8192,2),('T',a,b,0,0,0,0,2048,512)]
    data=subprocess.run([sys.argv[2]],input=''.join(' '.join(map(str,r))+'\n'for r in req),text=True,capture_output=True,timeout=90,check=True)
    assert not data.stderr
    with open(folder/'slope.tsv','w',newline='')as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow('mode l0 l1 r0 r1 z0 z1 n k alo ahi blo bhi'.split())
        for r,ans in zip(req,data.stdout.splitlines(),strict=True):w.writerow((*r,*ans.split()))
    print(json.dumps(dict(wall_s=time.monotonic()-start)))
