"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Derive exact summaries and lookup tables from ledgers."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import csv,gzip,json
def records(p):
    op=gzip.open if str(p).endswith('.gz') else open
    with op(p,'rt')as f:return list(csv.DictReader(f,delimiter='\t'))
def jsonl(n):return [json.loads(s)for s in (Path('logs')/(n+'.jsonl')).read_text().splitlines()]
def best(rows,k,flag=max):return str(F(flag(int(r[k])for r in rows),2**36))
def main():
    dest=Path('tables');dest.mkdir(exist_ok=True)
    data={'status':'DIAGNOSTIC_ONLY / NOT_EVIDENCE','families':{}}
    for name,ff in [('N3','VZECTB'),('N4','HDX')]:
        for f in ff:
            allrows=[];atlas=[]
            for file in sorted((Path('ledgers')/name).glob(f+'*.tsv.gz')):
                a=[r for r in records(file) if not r['action'].startswith('split')];allrows+=a
                if f=='H':
                    z=[r for r in a if r['action']=='H_undetermined'];c=Counter(r['action'] for r in a)
                    i=int(file.name[1:3]);at=[str(2+F(i,4)),str(2+F(i+1,4))]+[c[k]for k in ('H_positive','H_negative','H_undetermined','empty')]
                    if z:at+=[str(F(func(int(r[k])for r in z),2**20))for k,func in [('r0',min),('r1',max),('z0',min),('z1',max)]]
                    atlas.append(at)
            counts=dict(Counter(r['action']for r in allrows));rec={'leaves':len(allrows),'counts':counts}
            if f in 'VZ':rec['uniform_lower']=best([r for r in allrows if r['action']=='positive'],'alo',min)
            if f=='X':rec['uniform_upper']=best([r for r in allrows if r['action']=='H_negative'],'ahi')
            if f=='C':rec['Hlambda_upper']=best(allrows,'bhi')
            if f=='B':
                rec['Hlambda_upper_low_band']=best([r for r in allrows if r['action']=='lambda_decreasing'],'bhi')
                rec['H_upper_high_band']=best([r for r in allrows if r['action']=='negative'],'ahi')
            if f=='T':rec['T_upper']=best(allrows,'ahi')
            data['families'][f]=rec
            if f=='H':
                with (dest/'H_atlas_by_lambda.tsv').open('w')as s:
                    w=csv.writer(s,delimiter='\t',lineterminator='\n');w.writerow('lambda0 lambda1 H_positive H_negative H_undetermined empty undec_r_min undec_r_max undec_z_min undec_z_max'.split());w.writerows(atlas)
    for name in ('N3','N3R','N4','N5','N6','R46','N7','N7R','N8'):
        data.setdefault('timings',{})[name]=jsonl(name)[-1]
    with (dest/'lambda_at_radius.tsv').open('w')as fs:
        w=csv.writer(fs,delimiter='\t',lineterminator='\n')
        w.writerow('rho lambda_lo lambda_hi left_H_lo left_H_hi right_H_lo right_H_hi'.split())
        for p in sorted(Path('ledgers/N5').glob('*.tsv')):
            a=[r for r in records(p)if r['status']=='separated'];assert len(a)==2
            w.writerow([F(int(a[0]['rho_num20']),2**20)]+[F(int(r['lambda_num28']),2**28)for r in a]+[F(int(r[k]),2**47)for r in a for k in ('H_lo','H_hi')])
    with (dest/'radius_at_lambda.tsv').open('w')as fs:
        w=csv.writer(fs,delimiter='\t',lineterminator='\n');w.writerow('lambda rho_lo rho_hi left_H_lo left_H_hi right_H_lo right_H_hi'.split())
        for p in sorted(Path('ledgers/N6').glob('slice*'),key=lambda x:int(x.stem.split('_')[1])):
            a=[r for r in records(p)if r['status']=='separated'];assert len(a)==2
            w.writerow([F(int(a[0]['lambda_num28']),2**28)]+[F(int(r['rho_num20']),2**20)for r in a]+[F(int(r[k]),2**47)for r in a for k in ('H_lo','H_hi')])
    a=records('ledgers/N6/slope.tsv')
    mu=[F(int(a[0][k]),2**36)for k in ('blo','bhi')];T=[F(int(a[1][k]),2**36)for k in ('alo','ahi')]
    ratio=[6*x/y for x in mu for y in T]
    data['center']={'Hlambda':[str(v)for v in mu],'Eyyyy':[str(v)for v in T],'slope':[str(min(ratio)),str(max(ratio))]}
    n7=jsonl('N7R')[:-1];data['integer_check']={'terminal':sum(r['terminal']for r in n7),'all_evaluations':sum(r['all_queries_replayed']for r in n7),'largest_upper':str(max(F(r['largest_upper'])for r in n7))}
    data['N3_terminals']=sum(r['terminal_replayed']for r in jsonl('N3R')[:-1])
    data['N4_terminals']=sum(r['replayed']for r in jsonl('R46') if 'root'in r)
    data['N5_N6_simpson_queries']=sum(r['replayed']for r in jsonl('R46') if 'bracket'in r)
    for family in ('N5','N6'):
        subset=[r for r in jsonl('R46')if r.get('bracket','').startswith('curve'if family=='N5'else'slice')]
        data[family+'_simpson_queries']=sum(r['replayed']for r in subset)
    (dest/'summary.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
if __name__=='__main__':main()
