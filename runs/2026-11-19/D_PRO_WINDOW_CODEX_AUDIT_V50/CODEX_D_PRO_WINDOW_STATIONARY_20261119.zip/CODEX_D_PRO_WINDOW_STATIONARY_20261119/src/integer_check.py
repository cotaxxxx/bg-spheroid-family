"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Independent V49 rational-moment upper on the heavy slab."""
import concurrent.futures,csv,gzip,json,subprocess,sys,time
from fractions import Fraction
from pathlib import Path
COLUMNS='anchor sub l0 l1 r0 r1 z0 z1 nm na lower upper_num upper_den action'.split()
BOX='l0 l1 r0 r1 z0 z1'.split()
def anchors():
    with gzip.open('ledgers/N4/X00.tsv.gz','rt') as f:
        rows=[r for r in csv.DictReader(f,delimiter='\t') if not r['action'].startswith('split')]
    return [(r['path'],tuple(int(r[j])//256 for j in BOX)) for r in rows if all(int(r[j])%256==0 for j in BOX)]
def divide(b,j):
    mid,rem=divmod(b[j]+b[j+1],2);assert rem==0 and b[j]<mid<b[j+1]
    a,c=list(b),list(b);a[j+1]=c[j]=mid
    return tuple(a),tuple(c)
def run(args):
    i,aa,exe,folder=args;start=time.monotonic()
    p=subprocess.Popen([exe,'v49/geometry.tbl'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
    def query(b,n,k):
        p.stdin.write(' '.join(map(str,(*b,n,k)))+'\n');p.stdin.flush()
        typ,x,y=p.stdout.readline().split();return typ,int(x),int(y)
    count=empty=neg=0
    with gzip.open(folder/f'part{i}.tsv.gz','wt',newline='')as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(COLUMNS)
        for label,b in aa:
            todo=[('x',b)]
            while todo:
                sub,box=todo.pop()
                for n,k in ((32,4),(64,8),(128,16),(256,32),(512,64),(1024,128)):
                    if time.monotonic()-start>480:raise RuntimeError('N7 time cap')
                    typ,x,y=query(box,n,k);count+=1
                    if typ=='empty':action='empty';empty+=1
                    elif x<0:action='negative';neg+=1
                    elif n!=1024:action='refine_grid'
                    elif len(sub)>=8:action='open'
                    else:
                        available=[j for j in (0,2,4)if box[j+1]-box[j]>=2]
                        if not available:action='open'
                        else:
                            j=max(available,key=lambda u:(box[u+1]-box[u])*(1 if u==0 else 4))
                            a,b1=divide(box,j);action='split'+'lrz'[j//2];todo.extend([(sub+'1',b1),(sub+'0',a)])
                    w.writerow((label,sub,*box,n,k,'--'if typ=='empty'else'-128',x,y,action))
                    if action!='refine_grid':break
    p.stdin.close();assert p.wait()==0
    return dict(part=i,anchors=len(aa),queries=count,negative=neg,empty=empty,seconds=time.monotonic()-start)
def check(args):
    i,aa,exe,folder=args;t0=time.monotonic()
    with gzip.open(folder/f'part{i}.tsv.gz','rt')as f:rows=list(csv.DictReader(f,delimiter='\t'))
    grouped={}
    for t in rows:grouped.setdefault((t['anchor'],t['sub']),[]).append(t)
    totalq=[];outputs=[];seen=set();worst=Fraction(-128);term=0
    for label,box in aa:
        todo=[('x',box)];vol=Fraction()
        while todo:
            sub,b=todo.pop();key=(label,sub);assert key not in seen;seen.add(key)
            attempts=grouped[key]
            for j,t in enumerate(attempts):
                assert b==tuple(map(int,(t[k]for k in BOX)))
                nm=32*2**j;na=4*2**j;assert(int(t['nm']),int(t['na']))==(nm,na)
                a=t['action'];x=int(t['upper_num']);y=int(t['upper_den']);v=Fraction(x,y);assert y>0
                totalq.append((*b,nm,na));outputs.append(('empty' if a=='empty'else 'upper',x,y))
                if a!='empty':assert t['lower']=='-128' and v>=-128
                if j+1<len(attempts):assert a=='refine_grid' and x>=0
            a=attempts[-1]['action']
            if a.startswith('split'):
                assert x>=0 and len(attempts)==6
                j=2*'lrz'.index(a[-1]);a1,b1=divide(b,j);todo.extend([(sub+'0',a1),(sub+'1',b1)])
            else:
                if a=='empty':assert b[2]**2+b[4]**2>4096**2
                else:assert a=='negative' and x<0;worst=max(worst,v)
                vol+=Fraction(1,2**(len(sub)-1));term+=1
        assert vol==1
    assert len(seen)==len(grouped)
    p=subprocess.run([exe,'v49/geometry.tbl'],input=''.join(' '.join(map(str,r))+'\n'for r in totalq[::-1]),text=True,capture_output=True,timeout=480,check=True)
    assert not p.stderr and [r.split()for r in p.stdout.splitlines()]==[list(map(str,r))for r in outputs[::-1]]
    return dict(part=i,terminal=term,all_queries_replayed=len(totalq),largest_upper=str(worst),seconds=time.monotonic()-t0)
if __name__=='__main__':
    mode=sys.argv[1];aa=anchors();assert len(aa)==3656 and len({t[0]for t in aa})==3656
    dest=Path('ledgers/N7');dest.mkdir(exist_ok=True);start=time.monotonic()
    tasks=[(i,aa[i::8],sys.argv[2],dest)for i in range(8)]
    with concurrent.futures.ProcessPoolExecutor(8)as pool:
        for r in pool.map(run if mode=='run' else check,tasks):print(json.dumps(r),flush=True)
    print(json.dumps(dict(wall_s=time.monotonic()-start)))
