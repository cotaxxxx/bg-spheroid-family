// DIAGNOSTIC_ONLY / NOT_EVIDENCE. General H sign and lambda crossing orientation.
#define main base_program_main
#include "kernel.cpp"
#undef main
I cos_at(int i,int n){
 i=(i%(2*n)+2*n)%(2*n);
 if(i>n)i=2*n-i;
 if(i==0)return 1;
 if(i==n)return -1;
 const auto& a=arcs(n);
 return {a[i-1].c.l,a[i].c.h};
}
I pi_bound(){return {0x1.921fb54442d18p+1,0x1.921fb54442d19p+1};}
const std::vector<I>& mean_sin2(int n){
 static std::map<int,std::vector<I>> cache;
 auto& v=cache[n];
 if(!v.empty())return v;
 I sinc=cos_at(n/2-1,n)*n/pi_bound();
 for(int j=0;j<n;j++)v.push_back(bound01((1-cos_at(2*j+1,n)*sinc)*.5));
 return v;
}
I general_H(const Outer& p,int nm,int na){
 I sum=0;const auto& ang=arcs(na);const auto& moment=mean_sin2(na);
 for(int i=0;i<nm;i++){
  I m{double(i)/nm,double(i+1)/nm},m2=sq(m),s2=1-m2,s=root(s2);
  I C=1+(p.l2-1)*m2,ci=inv(C),c=inv(root(C)),u=1-ci;
  I z0=p.z*m,v1=p.r*s;
  for(int ja=0;ja<na;ja++){
   const auto& a=ang[ja];
   I ex=s*a.c,v=symclip(z0+v1*a.c), d2=bound01(p.delta+sq(v));
   d2=meet(d2,1-sq(p.r*m*a.c-p.z*s)-sq(p.r)*a.ss);
   I d=root(d2),w=bound01((1-ratio_unit(v,d))*.5);
   I Ap[2],Am[2],raw[2],j=s2*a.ss;
   for(int k=0;k<2;k++){
    int sig=k?1:-1;
    I ell=meet(d-pm(v,sig),{0,2*d.h});
    I mu=symclip(p.z+pm(ell*m,sig)),x=symclip(p.r+pm(ell*ex,sig));
    I hor=bound01(sq(x)+sq(ell)*j),B=accurate_B(sq(mu),hor,p.eps,p.ecc);
    I T=c*inv(root(B)),g=bound01(d*T);
    Ap[k]=T*tb->get(FP,g)*d2*ci;
    I n=T*tb->get(QV,g)*sq(d*u-pm(v,sig));
    Am[k]=Ap[k]*ci+n;
    raw[k]=Ap[k]*(1-j*ci)-n*j;
   }
   I av=blend(Ap[1],Ap[0],w)-s2*moment[ja]*blend(Am[1],Am[0],w);
   sum=sum+meet(av,blend(raw[1],raw[0],w));
  }
 }
 return sum/(double(nm)*na);
}
// Radial chord directions t=e_x, d and all endpoint positions are lambda-independent.
Result equator_lambda(const Outer& p,int nm,int na){
 I sh=0,sd=0,rr=sq(p.r);
 for(int i=0;i<nm;i++){
  I t{double(i)/nm,double(i+1)/nm},t2=sq(t),a2=1-t2;
  I v=p.r*t,d2=bound01(meet(1-rr*a2,1-rr+sq(v))),d=root(d2);
  I w=bound01((1-ratio_unit(v,d))*.5),ell[2],xx2[2];
  for(int k=0;k<2;k++){
   int sig=k?1:-1;ell[k]=meet(d-pm(v,sig),{0,2*d.h});
   xx2[k]=sq(symclip(p.r*a2+pm(t*d,sig)));
  }
  for(const auto& a:arcs(na)){
   I m2=a2*a.cs,j=a2*a.ss,C=1+(p.l2-1)*m2,ci=inv(C),c=inv(root(C)),u=1-ci;
   I fc=d2*ci*(1-j*ci),cip=-2*p.l*m2*sq(ci);
   I vh[2],vd[2];
   for(int k=0;k<2;k++){
    int sig=k?1:-1;
    I mu2=bound01(meet(sq(ell[k])*m2,(1-xx2[k])*a.cs));
    I B=accurate_B(mu2,xx2[k]+(1-xx2[k])*a.ss,p.eps,p.ecc),T=c*inv(root(B));
    I g=bound01(d*T),P=tb->get(FP,g),Q=tb->get(QV,g),ds=d*u-pm(v,sig);
    I qc=j*sq(ds),A=P*fc-Q*qc,R=mu2*p.eps/(p.l*B)-p.l*m2*ci;
    vh[k]=T*A;
    vd[k]=T*(R*(A+g*(-tb->get(NEGFP1,g)*fc+tb->get(NEGQ1,g)*qc))
                 +cip*(P*d2*(1-2*j*ci)+2*Q*j*d*ds));
   }
   sh=sh+blend(vh[1],vh[0],w);sd=sd+blend(vd[1],vd[0],w);
  }
 }
 I n=double(nm)*na;return {sh/n,sd/n};
}
int main(){
 try {
  setup();tb=std::make_unique<Tables>();
  string mode;int a,b,r,s,z,y,n,k;
  while(std::cin>>mode>>a>>b>>r>>s>>z>>y>>n>>k){
   if(!(2*SCALE<=a&&a<=b&&b<=5*SCALE&&0<=r&&r<=s&&s<=SCALE&&0<=z&&z<=y&&y<=SCALE
      &&n>=2&&n<=1048576&&!(n&(n-1))&&k>=2&&k<=65536&&!(k&(k-1))))
     throw std::runtime_error("map input");
   if(int64_t(r)*r+int64_t(z)*z>int64_t(SCALE)*int64_t(SCALE)){std::cout<<"empty"<<std::endl;continue;}
   I l{a/SCALE,b/SCALE},R{r/SCALE,s/SCALE},Z{z/SCALE,y/SCALE};
   R.h=std::min(R.h,root(1-sq(I(Z.l))).h);Z.h=std::min(Z.h,root(1-sq(I(R.l))).h);
   I L=sq(l),ep=inv(L);Outer p{l,R,Z,L,ep,1-ep,bound01(1-sq(R)-sq(Z))};
   Result out;
   if(mode=="H")out={general_H(p,n,k),0};
   else if(mode=="D"&&z==0&&y==0)out=equator_lambda(p,n,k);
   else throw std::runtime_error("map mode");
   for(I v:{out.first,out.second}){
    if(!std::isfinite(v.l)||!std::isfinite(v.h)||v.l>v.h||v.h>1e7||v.l< -1e7)
      throw std::runtime_error("map output");
    std::cout<<(long long)std::floor(v.l*0x1p36)<<' '<<(long long)std::ceil(v.h*0x1p36)<<' ';
   }
   std::cout<<std::endl;
  }
  return std::cin.eof()?0:2;
 }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 3;}
}
