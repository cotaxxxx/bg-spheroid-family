#!/usr/bin/env bash
set -euo pipefail
base="$(cd -- "$(dirname -- "$0")" && pwd)"
cd -- "$base"
sha256sum --quiet -c SHA256SUMS
sha256sum --quiet -c PLAN_AND_CODE.sha256
if [[ $# -gt 1 ]]; then
    echo "Usage: ./reproduce.sh [new-output-directory]" >&2
    exit 2
fi
if [[ $# == 1 ]]; then
    out="$(realpath -m -- "$1")"
    mkdir -- "$out"
else
    out="$(mktemp -d)"
fi
python3 check_exact.py > "$out/exact.json"
cmp verification/exact.json "$out/exact.json"
python3 diagnostics.py "$out"
python3 compare_replay.py verification "$out"
echo "Reproduction files: $out"

