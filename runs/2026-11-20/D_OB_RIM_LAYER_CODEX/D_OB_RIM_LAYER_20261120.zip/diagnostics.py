"""Independent floating-point checks using angle integration on the source sphere."""
import csv
from fractions import Fraction
import json
import math
from pathlib import Path
import sys
import numpy as np
from numpy.polynomial.legendre import leggauss

HERE = Path(__file__).resolve().parent
PLAN = json.loads((HERE / "verification_plan.json").read_text())


def composite(nodes, order):
    base, weights = leggauss(order)
    points = []
    mass = []
    knots = sorted(set(nodes))
    for lo, hi in zip(knots, knots[1:]):
        if hi - lo <= 2e-15:
            continue
        half = (hi - lo) / 2
        points.extend((hi + lo) / 2 + base * half)
        mass.extend(weights * half)
    return np.array(points), np.array(mass)


def grid(lam, rho, z, order):
    halfpi = math.pi/2
    contact = math.acos(rho)
    lat_knots = {-halfpi, 0.0, halfpi}
    for center in (0.0, -contact, contact, math.asin(z)):
        for span in (0.0, lam**2, lam, 4*lam, math.sqrt(lam), 0.25):
            for sign in (-1, 1):
                lat_knots.add(min(halfpi, max(-halfpi, center+sign*span)))
    az_knots = [0.0, lam**2, lam/4, lam, 4*lam, math.sqrt(lam), 0.25, 1.0, math.pi]
    t, wt = composite(lat_knots, order)
    phi, wphi = composite(az_knots, order)
    return t, wt, phi, wphi


def integrals(lam, rho, z, order, fixed_grid=None):
    t, wt, phi, wp = grid(lam,rho,z,order) if fixed_grid is None else fixed_grid
    mu = np.sin(t)[:,None]
    sh = np.cos(t)[:,None]
    x = sh*np.cos(phi)
    y = sh*np.sin(phi)
    dx = x-rho
    v = mu-z
    r2 = dx*dx+y*y
    d = np.sqrt(r2+lam**2*v*v)
    beta = 1-lam**2
    S = np.sqrt(lam**2+beta*mu**2)/lam
    k = (1-rho*rho-z*z+r2+v*v)/2
    raw_g = k/(S*d)
    if raw_g.min() < -1e-10 or raw_g.max() > 1+1e-10:
        raise ValueError("source angle outside its geometrical range")
    g = np.clip(raw_g,0.0,1.0)
    theta = np.arccos(g)
    angP = 2/np.sinc(theta/np.pi)
    dp = -2/3-4*theta**2/15
    wide = theta > 0.002
    tw = theta[wide]
    dp[wide] = 2*(tw*np.cos(tw)-np.sin(tw))/np.sin(tw)**3
    angQ = 2*angP+g*dp
    angF = (np.pi/2+theta)*np.arcsin(g)
    weight = (sh*wt[:,None])*wp/(2*np.pi)

    def avg(value):
        return float(np.sum(weight*value))

    grad = angF+g*angP
    rho_der = avg(x*grad-S*dx/d*g**2*angP)
    z_der = avg(mu*grad-lam**2*S*v/d*g**2*angP)
    pos = avg(angP*lam**2*k**2*r2/(S*d**5))
    neg = avg(angQ*(mu-lam**2*k*v/d**2)**2/(S*d))
    result = {"energy_shifted":avg(-k*angF), "er":rho_der, "ez":z_der,
              "ezz":pos-neg, "p_plus":pos, "n_minus":neg}
    if z == 0 and rho > 0:
        a = rho/beta
        numer = (1-rho*rho)*y*y+mu**2*(beta*((x-a)**2+y*y)-(beta/rho-rho)*(x-a))
        result["h_equator"] = avg(angP*numer/(S*d**3))
        result["odd"] = avg(angP*mu**2*(x-a)/(S*d**3))
    return result


def main(path):
    path.mkdir(parents=True,exist_ok=True)
    rows = []
    for label, ls, rs, zs in PLAN["cases"]:
        lf, rf, zf = (Fraction(v) for v in (ls,rs,zs))
        if rf**2+zf**2>1:
            raise ValueError(label)
        lam,rho,z = map(float,(lf,rf,zf))
        for order in PLAN["orders"]:
            val = integrals(lam,rho,z,order)
            row = {"case":label, "lambda":ls, "rho":rs, "z":zs, "order":order,
                   "E_rho/lambda":val["er"]/lam, "E_zz/lambda":val["ezz"]/lam,
                   "P_plus/lambda^2":val["p_plus"]/lam**2,
                   "N/lambda":val["n_minus"]/lam,
                   "E_z/(z*lambda)":val["ez"]/(z*lam) if z else None,
                   "H_from_gradient/lambda":val["er"]/(rho*lam) if z==0 else None,
                   "H_from_azimuth/lambda":val.get("h_equator",0)/lam if z==0 else None,
                   "odd/lambda":val.get("odd",0)/lam if z==0 else None}
            rows.append(row)
    with (path/"diagnostics.tsv").open("w",newline="") as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]),delimiter="\t",lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k:(format(v,".12g") if isinstance(v,float) else v) for k,v in row.items()})
    f = PLAN["finite_difference"]
    lam,rho,z,h = [float(Fraction(f[k])) for k in ("lambda","rho","z","h")]
    order = max(PLAN["orders"])
    frozen = grid(lam,rho,z,order)
    val = integrals(lam,rho,z,order,frozen)

    def shifted(dr,dz):
        return integrals(lam,rho+dr,z+dz,order,frozen)["energy_shifted"]

    er_fd = (shifted(h,0)-shifted(-h,0))/(2*h)
    ez_fd = (shifted(0,h)-shifted(0,-h))/(2*h)
    ezz_fd = (shifted(0,h)-2*val["energy_shifted"]+shifted(0,-h))/h**2
    fine = [r for r in rows if r["order"]==order]
    eq = [r for r in fine if r["z"]=="0"]
    off = [r for r in fine if r["z"]!="0"]
    summary = {"scope":"noninterval, finite points only","cases":len(fine),
               "minimum_equatorial_H_over_lambda":min(r["H_from_gradient/lambda"] for r in eq),
               "largest_off_plane_Ez_over_zlambda":max(r["E_z/(z*lambda)"] for r in off),
               "largest_Ezz_over_lambda":max(r["E_zz/lambda"] for r in fine),
               "max_equatorial_formula_discrepancy_over_lambda":
                   max(abs(r["H_from_gradient/lambda"]-r["H_from_azimuth/lambda"]) for r in eq),
               "max_Ezz_two_order_discrepancy_over_lambda":
                   max(abs(rows[i]["E_zz/lambda"]-rows[i+1]["E_zz/lambda"]) for i in range(0,len(rows),2)),
               "direct_energy_finite_difference_absolute_error":
                   {"E_rho":abs(er_fd-val["er"]), "E_z":abs(ez_fd-val["ez"]),
                    "E_zz":abs(ezz_fd-val["ezz"])}}
    (path/"diagnostic_summary.json").write_text(json.dumps(summary,indent=2)+"\n")


if __name__=="__main__":
    main(Path(sys.argv[1]))
