"""Compare the two finite diagnostic runs, allowing floating-point variation."""
import csv
import json
import math
from pathlib import Path
import sys


def rows(folder):
    with (folder/"diagnostics.tsv").open(newline="") as src:
        return list(csv.DictReader(src,delimiter="\t"))


def near(a,b):
    return math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=5e-7,abs_tol=5e-7)


def main(reference, actual):
    old,new = rows(reference),rows(actual)
    if len(old)!=len(new) or not old:
        raise ValueError("diagnostic row count")
    labels = {"case","lambda","rho","z","order"}
    for expected,got in zip(old,new):
        if set(expected)!=set(got):
            raise ValueError("diagnostic columns")
        for name,value in expected.items():
            if name in labels or not value:
                good = got[name]==value
            else:
                good = near(float(value),float(got[name]))
            if not good:
                raise ValueError((expected["case"],name,value,got[name]))
    f=json.loads((actual/"diagnostic_summary.json").read_text())
    errors=f["direct_energy_finite_difference_absolute_error"]
    if not all(math.isfinite(v) and v<5e-5 for v in errors.values()):
        raise ValueError(("energy finite differences",errors))
    print(f"Exact identities matched. Replayed {len(new)} noninterval quadrature rows and the scalar-energy difference check.")


if __name__=="__main__":
    main(Path(sys.argv[1]),Path(sys.argv[2]))

