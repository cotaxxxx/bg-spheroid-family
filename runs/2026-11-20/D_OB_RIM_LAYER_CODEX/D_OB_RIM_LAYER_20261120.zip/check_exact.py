"""Replay exact polynomial identities and rational bounds used in the report."""
from fractions import Fraction as F
import json
import sympy as sp


def main():
    checks = []

    def zero(name, expr):
        numerator = sp.factor(sp.together(expr).as_numer_denom()[0])
        if numerator != 0:
            raise ArithmeticError(f"{name}: residual {numerator}")
        checks.append(name)

    def check(name, condition):
        if not condition:
            raise ArithmeticError(name)
        checks.append(name)

    b, r, x, y, m = sp.symbols("beta rho x y m")
    ysq = 1 - m**2 - x**2
    dsq = 1 + r**2 - 2*r*x - b*m**2
    k = 1-r*x
    delta = 1-r**2
    raw = -ysq*dsq+ysq*k+x*k*dsq/r-(x-r)*k**2/r
    n = delta*ysq+m**2*(1+b*(1-m**2)-(r+b/r)*x)
    zero("equator azimuthal integration-by-parts numerator", raw-n)

    a = r/b
    d = 1-r**2/b
    s = sp.symbols("s")
    u = sp.symbols("t")
    for sign, label in ((1, "right"), (-1, "left")):
        xx = a+sign*u
        m2 = 1-xx**2-y**2
        l2 = 1-b
        radial2 = u**2+y**2
        w2 = l2+b*m2
        dd = (xx-r)**2+y**2+l2*m2
        zero(f"projected distance {label}", dd-((1-b)*d+b*radial2))
        zero(f"normal length {label}", w2-(d-b*radial2-sign*2*r*u))
        zero(f"angle numerator {label}", 2*(1-r*xx)-(w2+d+b*radial2))
    shifted = b*((x-a)**2+y**2)-(b/r-r)*(x-a)
    zero("even and odd parts of equator kernel",
         shifted-(1+b*(x**2+y**2)-(r+b/r)*x))
    wl, wr, c = sp.symbols("w_left w_right c", nonzero=True)
    zero("angle order after reflection", wl+c/wl-wr-c/wr-(wl-wr)*(1-c/(wl*wr)))
    zero("outer collar factorization", 1+b*s**2-(r+b/r)*s-(1-r*s)*(1-b*s/r))
    zero("horizontal moments", delta/3+b*(sp.Rational(2,15)+a**2/3)
         -(sp.Rational(1,3)+2*b/15+r**2*(1/b-1)/3))
    check("sphere moments", F(1,3)-F(1,5)==F(2,15))

    L, S, R, v, mu, K = sp.symbols("lambda S R v mu k", positive=True)
    D = sp.sqrt(R**2+L**2*v**2)
    g = K/(S*D)
    def dz(expr):
        return -sp.diff(expr,v)-mu*sp.diff(expr,K)
    h = L**2*K*v/D**2
    zero("angle derivative at fixed source", dz(g)+(mu-h)/(S*D))
    zero("axial unit component derivative", dz(v/D)+R**2/D**3)
    pfun = sp.Function("P")
    jfun = sp.Function("J")
    pp = pfun(g)
    gprime = dz(g)
    # J' = Q, (g^2 P)' = g Q. Differentiate the two gradient terms.
    Q = 2*pp+g*sp.diff(pfun(s),s).subs(s,g)
    lhs = mu*Q*gprime-L**2*S*(dz(v/D)*g**2*pp+v/D*g*Q*gprime)
    rhs = L**2*K**2*R**2*pp/(S*D**5)-Q*(mu-h)**2/(S*D)
    zero("axial Hessian decomposition", lhs-rhs)

    t = sp.symbols("t", positive=True)
    zero("positive-kernel envelope", (1+t**2)**2-4*t**2-(1-t**2)**2)
    zero("Q integrand derivative",sp.diff((2*c+s)/(c+s)**2,s)+(3*c+s)/(c+s)**3)
    zero("P-prime endpoint integral",sp.integrate((1-t**2)/2,(t,0,1))-sp.Rational(1,3))
    check("positive-term constant", F(22,7)**2+4*F(22,7)<24)
    check("normal factor", 1+F(1,64)<F(33,32)**2)
    check("axial directional error", F(96,1024)==F(3,32)<F(1,10))
    check("projected area", F(15,16)-F(1,16)==F(7,8))
    check("projected second moment", F(15,16)*(1+F(15,32)+F(1,256))<F(3,2))
    check("reciprocal-distance average", F(3,2)/F(7,8)==F(12,7)<F(4,3)**2)
    nbound = F(10,3)*F(9,10)**2*F(32,33)*F(3,4)*F(7,16)
    check("axial negative lower bound", nbound==F(189,220))
    check("net axial curvature margin", nbound-F(24,32)==F(6,55))

    # Geometric second derivative and scalar Lipschitz envelopes in Appendix A.
    U, Y, D0 = sp.symbols("U Y D", positive=True)
    G = 2*U**2/D0-4*K*U*Y/D0**3+K**2*(-1/D0**3+3*Y**2/D0**5)
    tt = sp.symbols("displacement")
    varied = (K-tt*U)**2 / sp.sqrt(D0**2-2*tt*Y+tt**2)
    zero("fixed-source horizontal second derivative", sp.diff(varied,tt,2).subs(tt,0)-G)
    check("small-belt geometry constants", (20+56+2*60+302,2*302)==(498,604))
    check("small-belt angular remainder", 24+36+64==124)
    check("geometric error integral", 2*498+604==1600)
    check("far projection product bound", 130+2*3*18+27*4==346)
    check("explicit remainder constant",
          700*4*8**7+248*2**4+1600*4*2**6+70*4*(3+16)*2**5 < 10**10)
    print(json.dumps({"kind":"exact_algebra_and_constant_checks",
                      "count":len(checks),"identities_and_inequalities":checks},
                     ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
