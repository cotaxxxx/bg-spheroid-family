# 入力と再現環境

2026年11月20日 ／ DIAGNOSTIC_ONLY / NOT_EVIDENCE

## 定義、依頼、既採用の範囲

原本のバイト列の SHA-256 を示す。括弧付きの名前は添付された表示名である。元のファイルは再現計算の実行時には不要である。

| 入力 | SHA-256 |
|---|---|
| CODEX_INSTRUCTION_D_OB_RIM_LAYER_20261120.md | `52607d13639c124a9d1c82fae662de4e31615733786d51e10ccc5e40b47db544` |
| CHAT_AUDIT_D_OB_FULL_FAMILY_CODEX_V53(1).md | `8a5e3b4c5567a4f0e8590330146cf4e2c1fa04cd5d9272d1c4764c7fde678f2e` |
| JUDGE_RULING_D_OB_FULL_FAMILY_ADOPT_20261120(1).md | `49a3f18f0a7e5a659089759f92fc24a73cf98b59d22699bab8e82235038cae01` |
| D_OB_FULL_FAMILY.md（V53の監査対象） | `86aab5f29194b95613bd2e9ac01f7c407f97c38223f5896a8ed94f907ee73d8e` |
| D_OB_FULL_FAMILY.zip（同じ前報の束） | `4ef5785bbde4787f5ddc110517439bdd569e8f514a90f29b2a82353096ab03aa` |

前報§1、§4、§5、§7から、参照球のエネルギー、円板極限係数、境界トレース、任意使用の Hessian ノルム評価を参照した。[前報の固定コミット](https://github.com/cotaxxxx/bg-spheroid-family/commit/6f22a41f56e8439c63c4731d5bd6e39a10ced86f)

## 関連する別報告と今回の差分

- 別報告 `CODEX_D_OB_FULL_FAMILY_20261119.md` の§3.4、§3.5は軸方向 Hessian の分解、射影積分 \(\langle1/R\rangle=\pi/2\)、小さい尾 \(\lambda\le1/256\) の軸方向凹性、赤道の外縁 \(\rho\ge1-\lambda^2\) の評価を与えている。今回の報告では必要な出発式を導き直した。[別報告](https://chatgpt.com/library?file_id=libfile_1275d1ebfacc81918f28dd0b41afd18c&account_id=personal)
- `D_OB_FULL_FAMILY_REVIEW_20261120.md` §5は、固定した \(\rho\) の漸近を動く層に移せない点と、\((1/256,1/32)\) にも証明が要る点を整理している。[比較報告](https://chatgpt.com/library?file_id=libfile_cfdd23359df08191b61e861728730efd&account_id=personal)
- 今回追加した解析は、距離が同じになる直線での鏡映と角度重みの順序、射影円板の面積と二次モーメントを用いる軸方向凹性の \(1/32\) への拡張、固定尺度の明示的な二側剰余である。いずれの定数も現在の本文内で検証できる。

## 再現

通常の Linux 環境で Python 3.12.14、SymPy 1.14.0、NumPy 2.3.5、bash、GNU sha256sum を用いた。データ通信は不要である。

展開先で `bash reproduce.sh` を実行する。出力先を指定するときは `bash reproduce.sh /absolute/new-directory` とする。入力ハッシュ、代数検算、全14組×2次数の求積、スカラーエネルギーの差分照合を順に行う。数値照合には実装間の丸め差を許容する。厳密な不等式の根拠は本文の積分評価である。
