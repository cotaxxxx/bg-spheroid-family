#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
base=$PWD
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir "$tmp/code" "$tmp/out"
cp code/{long.cpp,hb.cpp,axis.cpp,interval.hpp,iv_cross.hpp,axcover.py,long_end.py,long_axis.py} "$tmp/code/"
export JOBS="${JOBS:-6}" OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
cd "$tmp"
for unit in axis long; do
  g++ -std=c++17 -O3 -fPIC -shared -fno-fast-math -ffp-contract=off "code/$unit.cpp" -o "code/$unit.so"
done
python3 code/long_end.py
python3 code/long_axis.py
cd "$base"
sha256sum --quiet -c LONG_SCIENCE.sha256
cmp out/long_end.csv "$tmp/out/long_end.csv"
cmp out/long_axis.csv "$tmp/out/long_axis.csv"
python3 code/check_long.py
echo 'Long-axis ledgers reproduced byte for byte.'
