#include "axis.cpp"
// mode 0 gradient/r, 1 Tii-Tjj (used only for s=1,i=0,j=1), 2 kappa'.
extern "C" void profile(int mode,int axis,const int* ends,int n,double *out){
 I a[3];for(int i=0;i<3;i++)a[i]=I(rat(ends[2*i],5242880).l,rat(ends[2*i+1],5242880).h);
 I s=a[0],t=a[1],r=a[2],U1=axis==0?sq(s):inv(sq(s)),U2=axis==0?sq(s*t):sq(t),total=0;
 const auto& g=cells(n);
 for(const auto& w:g){
  I U=blend(w.w,U1,U2),V=blend(w.w,inv(U1),inv(U2)),row=0;
  for(const auto& c:g){
   I B=blend(c.v,1,V),S=root(B),v=c.mu-r,k=clip(1-r*c.mu,0,2);
   I dd=sq(v)+c.v*U;
   if(dd.l<=0){
    if(mode==2)std::abort();
    row=row+(mode==1?I(-16,16):I(-8,8)*(1+S));continue;
   }
   I d=root(dd),gamma=unit(k/(d*S)),P=angle(gamma,1),u=clip(v/d,-1,1);
   I eg=c.mu*(gamma*P-angle(gamma,0))-u*S*sq(gamma)*P;
   I val=eg;
   if(mode==1){
    I y2=c.v*(1-w.w);
    I un=clip(sq(u)-clip(y2*U1/dd,0,1),-1,1);
    I nn=clip((c.m2-y2/U1)/B,-1,1);
    val=k*P*gamma*(un-nn);
   }else if(mode==2){
    I Q=2*P-gamma*angle(gamma,2),z=c.mu-gamma*S*u;
    I H=(P*sq(gamma)*B*clip(c.v*U/dd,0,1)-Q*sq(z))/(d*S);
    val=(H-eg/r)/r;
   }
   row=row+val;
  }total=total+row;
 }
 total=total/I(n*n);if(mode==0)total=total/r;
 out[0]=total.l;out[1]=total.h;
}
