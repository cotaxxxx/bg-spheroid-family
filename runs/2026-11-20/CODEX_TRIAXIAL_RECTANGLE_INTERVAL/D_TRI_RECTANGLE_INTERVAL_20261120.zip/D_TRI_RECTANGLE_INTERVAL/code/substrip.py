from bridge import calc
from axcover import *
def job(arg):
 i,j=arg;c=2*D+j*D//32;d=c+D//32;tic=time.process_time();rows=[]
 # A t band must use the same criterion on the entire central radial segment.
 def low(c,d,dep):
  for n in [96,256,512,1024]:
   vs=[calc(0,i,(D,D+1,c,d,k*D//64,(k+1)*D//64),n) for k in range(16)]
   if min(x[2] for x in vs)>0:st='Hpos'
   elif max(x[3] for x in vs)<0:st='Hneg'
   elif max(x[1] for x in vs)<0:st='fourth'
   else:st='open'
   if st!='open':break
  if st=='open' and dep<2:
   mid=(c+d)//2;low(c,mid,dep+1);low(mid,d,dep+1);return
  for k,v in enumerate(vs):rows.append([i+1,0,D,D+1,c,d,k*D//64,(k+1)*D//64,dep,n,*v,st])
 low(c,d,0)
 for k in range(8,32):
  todo=[((D,D+1,c,d,k*D//32,(k+1)*D//32),0)]
  while todo:
   b,dep=todo.pop()
   for n in ([64,128,256] if dep<2 else [256,512,1024]):
    v=calc(1,i,b,n)
    st='slope' if v[1]<0 else 'Upos' if v[2]>0 else 'Uneg' if v[3]<0 else 'open'
    if st!='open':break
   if st=='open' and dep<5:
    a0,a1,t0,t1,r0,r1=b
    if dep%3==2:
     m=(t0+t1)//2;children=[(a0,a1,t0,m,r0,r1),(a0,a1,m,t1,r0,r1)]
    else:
     m=(r0+r1)//2;children=[(a0,a1,t0,t1,r0,m),(a0,a1,t0,t1,m,r1)]
    todo.extend((v,dep+1) for v in children);continue
   rows.append([i+1,1,*b,dep,n,*v,st])
 return rows,time.process_time()-tic
def run():
 args=[(i,j) for i in range(2) for j in range(48)]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','7'))) as pool,(BASE/'out/substrip.csv').open('w') as f,(BASE/'out/substrip_time.csv').open('w') as g:
  w=csv.writer(f);w.writerow('axis mode s0 s1 t0 t1 r0 r1 depth N lower upper altlo althi result'.split());z=csv.writer(g);z.writerow('axis0 j leaves cpu_s'.split())
  for p,(rows,t) in zip(args,pool.map(job,args)):w.writerows(rows);z.writerow([*p,len(rows),t]);f.flush();g.flush()
if __name__=='__main__':run()
