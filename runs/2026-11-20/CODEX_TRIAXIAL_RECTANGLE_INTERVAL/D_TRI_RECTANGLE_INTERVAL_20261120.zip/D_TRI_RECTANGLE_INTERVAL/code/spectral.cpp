// Validated nodal integration for the central eigenvalues.
#include "axis.cpp"
struct Rule{std::vector<I> sin2,cos2,weight;};
static std::map<int,Rule> rules1,rules2;
inline I sin_half(int m,int n){
 if(m==0)return 0;if(m==n)return 1;
 return unit(sinreg(pi*rat(m,2*n)));
}
inline I cospi(int m,int n){
 m=m%(2*n);if(m>n)m=2*n-m;
 if(2*m==n)return 0;
 return 2*m<n? sin_half(n-2*m,n):-sin_half(2*m-n,n);
}
inline const Rule& rule(int n,bool polar){
 auto &map=polar?rules1:rules2;if(map.count(n))return map[n];auto &r=map[n];
 std::vector<I> cg;for(int j=0;j<=2*n;j++)cg.push_back(cospi(j,n));
 for(int j=0;j<=n;j++){
  r.sin2.push_back(unit(sq(sin_half(j,n))));r.cos2.push_back(unit(sq(sin_half(n-j,n))));
  I v=1;
  if(polar)for(int k=1;k<=n;k++)v=v-rat(k==n?1:2,4*k*k-1)*cg[(k*j)%(2*n)];
  r.weight.push_back(v*rat(j==0||j==n?1:2,2*n));
 }
 return r;
}
inline I tight(I g,int j){
 auto at=[j](double x){
  int k=int(x*K);I h=I(x)-I(double(k)/K);
  if(k==K)return tab[j][k];
  I rem=j==2?I(0,24):I(0,8); // |P'''|<=6*pi<24; |P''|<=2*pi<8.
  return tab[j][k]-tab[j+1][k]*h+0.5*rem*sq(h);
 };
 return {at(g.h).l,at(g.l).h};
}
extern "C" void spectral_node(int i,int j,double* out){
 I s=(I(21)+11*cospi(i,96))/10,t=(I(7)+5*cospi(j,128))/2;
 I A[3]={1,sq(s),sq(s*t)},invA[3]={1,inv(A[1]),inv(A[2])};
 int n=16*int(std::ceil(40*(s*t).h/16)),m=n/2;
 auto& theta=rule(n,true);auto& phi=rule(m,false);
 I total[3]={};
 for(int l=0;l<=n;l++){
  I row[3]={},z2=theta.cos2[l],horiz=theta.sin2[l];
  for(int k=0;k<=m;k++){
   I w[]={horiz*phi.cos2[k],horiz*phi.sin2[k],z2};
   I d=w[0]+A[1]*w[1]+A[2]*w[2],B=w[0]+invA[1]*w[1]+invA[2]*w[2];
   I gam=unit(inv(root(d*B))),P=tight(gam,1),Q=2*P-gam*tight(gam,2);
   I weight=phi.weight[k]*gam;
   for(int a=0;a<3;a++){
    I ratio=A[a]/d;
    row[a]=row[a]+weight*(P*ratio*(1-ratio*w[a])-Q*w[a]*sq(1-ratio));
   }
  }
  for(int a=0;a<3;a++)total[a]=total[a]+theta.weight[l]*row[a];
 }
 for(int a=0;a<3;a++){I v=total[a]+I(-1e-13,1e-13);out[2*a]=v.l;out[2*a+1]=v.h;}
}
extern "C" void costable(int n,double* result){
 for(int k=0;k<=n;k++)for(int j=0;j<=n;j++){I v=cospi(j*k,n);int pos=2*(k*(n+1)+j);result[pos]=v.l;result[pos+1]=v.h;}
}
