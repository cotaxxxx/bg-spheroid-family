#include "iv_cross.hpp"
#include <array>
#include <vector>
// Univariate jet: actual first and second derivatives, not divided by factorials.
struct J{I v,d,h; J(double x=0):v(x){} J(I a,I b=0,I c=0):v(a),d(b),h(c){}};
inline J operator+(J a,J b){return {a.v+b.v,a.d+b.d,a.h+b.h};}
inline J operator-(J a,J b){return {a.v-b.v,a.d-b.d,a.h-b.h};}
inline J operator*(J a,J b){return {a.v*b.v,a.v*b.d+a.d*b.v,a.h*b.v+2*a.d*b.d+a.v*b.h};}
inline J chain(J a,I v,I d,I h){return {v,d*a.d,d*a.h+h*sq(a.d)};}
inline J invj(J a){I u=inv(a.v);return chain(a,u,-sq(u),2*sq(u)*u);}
inline J operator/(J a,J b){return a*invj(b);}
inline J sqrtj(J a){I u=root(a.v);return chain(a,u,0.5/u,-I(.25)/(u*a.v));}
inline J square(J a){return {sq(a.v),2*a.v*a.d,2*(sq(a.d)+a.v*a.h)};}
inline J sinunit(J a){a.v=unit(a.v);return a;}
inline J cap(J a,double l,double h){a.v=clip(a.v,l,h);return a;}
inline I aval(I g,int j){
 // Monotone endpoints, with an affine enclosure from the adjacent table entry.
 auto at=[j](double x){
  int k=int(x*K); I v=tab[j][k];
  if(k<K && j<4){
   I slope=-I(tab[j+1][k+1].l,tab[j+1][k].h);
   v=v+slope*(I(x)-I(double(k)/K));
  }return v;
 };
 if(j>=4)return angle(g,j);
 return {at(g.h).l,at(g.l).h};
}
inline J funP(J g){return chain(g,aval(g.v,1),-aval(g.v,2),aval(g.v,3));}
inline J funF(J g){return chain(g,aval(g.v,0),-aval(g.v,1),aval(g.v,2));}
inline J funQ(J g){
 I p=aval(g.v,1),d=-aval(g.v,2),h=aval(g.v,3),u=-aval(g.v,4);
 return chain(g,2*p+g.v*d,3*d+g.v*h,4*h+g.v*u);
}
struct Node{J s,c,den;};
inline Node trig(J v){J v2=square(v),den=1+v2;return {sinunit(2*v/den),sinunit((1-v2)/den),den};}
using Ax=std::array<J,3>;
inline J kernel(int mode,int axis,J s,J t,Node y,Node w){
 // y=tan(theta/4), w=tan(phi/2); polar axis is the differentiated axis.
 Ax A={1,square(s),square(s*t)};
 int j=(axis+1)%3,k=(axis+2)%3;
 J cw=square(w.c),sw=square(w.s),su=square(y.s),cu=square(y.c);
 J mu=1-2*su,mu2=square(mu),sin2=4*su*cu;
 J U=A[j]*cw+A[k]*sw,V=cw/A[j]+sw/A[k];
 J B=mu2/A[axis]+sin2*V;
 B=cap(B,inv(A[2].v).l,1.00000000000001);
 J D2=mode==0? A[axis]*mu2+U*sin2:A[axis]*su+U*cu;
 D2=cap(D2,0.99999999999999,A[2].v.h);
 J invprod=invj(sqrtj(D2*B)),g=sinunit(mode==0?invprod:y.s*invprod);
 J P=funP(g),f;
 if(mode==0){
  J z=mu*(1-A[axis]/D2);
  f=(P*A[axis]*U*sin2/square(D2)-funQ(g)*square(z))*invprod;
 }else{
  f=mu*(g*P-funF(g))+A[axis]*y.s*sqrtj(B/D2)*square(g)*P;
 }
 return f*16*y.s*y.c/(J(pi)*y.den*w.den);
}
extern "C" void initcross(){init_tables();}
extern "C" void cross_eval(int mode,int axis,const int* ends,int n,int which,double* out){
 // 0: point/box integral with second derivative midpoint correction;
 // 1,2: ranges of the integrand shape derivative over angular cells.
 J s(I(rat(ends[0],1000000).l,rat(ends[1],1000000).h),which==1);
 J t(I(rat(ends[2],1000000).l,rat(ends[3],1000000).h),which==2);
 I total=0;double delta=1./n;
 std::vector<Node> md,cl,jet;
 for(int i=0;i<n;i++){
  I z(i*delta,(i+1)*delta);
  md.push_back(trig(J((i+.5)*delta)));cl.push_back(trig(J(z)));jet.push_back(trig(J(z,1)));
 }
 for(int i=0;i<n;i++){
  I sub=0;
  for(int j=0;j<n;j++){
   I val;
   if(which){
    val=kernel(mode,axis,s,t,cl[i],cl[j]).d;
   }else{
    I mid=kernel(mode,axis,s,t,md[i],md[j]).v;
    I yy=kernel(mode,axis,s,t,jet[i],cl[j]).h;
    I ww=kernel(mode,axis,s,t,md[i],jet[j]).h;
    val=mid+(yy+ww)*rat(1,24)*I(delta*delta);
   }
   sub=sub+val;
  }total=total+sub;
 }
 total=total/I(double(n)*n);out[0]=total.l;out[1]=total.h;
}
