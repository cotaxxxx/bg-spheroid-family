"""Independent exact-rational reconstruction of both Krawczyk enclosures."""
import csv
from pathlib import Path
from fractions import Fraction as Q
ROOT=Path(__file__).resolve().parents[1]/'out'
def load(name):
 with (ROOT/name).open() as f:return list(csv.DictReader(f))
def interval(r):
 return tuple(Q(float(r[k])) for k in ('lower','upper'))
def add(a,b):
 return a[0]+b[0],a[1]+b[1]
def multiply(a,b):
 p=[x*y for x in a for y in b];return min(p),max(p)
def dot(a,b):
 return add(multiply(a[0],b[0]),multiply(a[1],b[1]))
def run():
 c=load('cross.csv');e=load('endpoints.csv');m=[Q(x,10**6) for x in (1566969,2296586)]
 n=max(int(x['N']) for x in c if x['derivative']=='0')
 coarse={int(x['mode']):interval(x) for x in c if x['derivative']=='0' and int(x['N'])==n}
 fine={int(x['mode']):interval(x) for x in e if x['s0']=='1566969'}
 columns=[{int(r['mode']):interval(r) for r in c if int(r['derivative'])==d and r['N']=='1024'} for d in (1,2)]
 y=[[(Q(v,100),)*2 for v in row] for row in ((164,-189),(26,480))]
 mat=[[add((Q(i==j),)*2,dot(y[i],columns[j])) for j in range(2)] for i in range(2)]
 outer=[(-Q(1,1000),Q(1,1000))]*2
 original=[list(map(Q,r.split())) for r in (ROOT/'kraw.txt').read_text().splitlines()]
 for i in range(2):
  shift=dot(y[i],coarse);norm=sum(max(map(abs,z)) for z in mat[i])
  assert original[i]==[m[i]+shift[0]-norm/1000,m[i]+shift[1]+norm/1000,norm]
 for _ in range(32):
  proposed=[add(dot(y[i],fine),dot(mat[i],outer)) for i in range(2)]
  outer=[(max(x[0],z[0]),min(x[1],z[1])) for x,z in zip(outer,proposed)]
 for i,r in enumerate(load('cross_refined.csv')):
  lo,hi=add((m[i],m[i]),outer[i]);den=int(r['denominator'])
  assert int(r['lo_integer'])==(lo*den).__floor__() and int(r['hi_integer'])==(hi*den).__ceil__()
 for mode,low,high in [(0,5917000,5919000),(1,2275000,2277000)]:
  for t,side in ((low,1),(high,-1)):
   fits=[r for r in e if r['s0']==r['s1']=='3200000' and int(r['mode'])==mode and r['axis']=='2' and int(r['t0'])==int(r['t1'])==t]
   assert any((interval(r)[0]>0 if side==1 else interval(r)[1]<0) for r in fits)
if __name__=='__main__':run()
