import runpy
from axcover import BASE,D,ProcessPoolExecutor,os,csv
calc=runpy.run_path(str(BASE/'code/hb.py'))['calc']
def job(p):
 i,b=p;stack=[(b,0)];rows=[]
 while stack:
  b,dep=stack.pop()
  for n in [256,512,1024,2048]:
   v=calc(0,i,b,n)
   if v[1]<0:break
  if v[1]>=0 and dep<2:
   m=(b[-2]+b[-1])//2;stack+= [(b[:-1]+(m,),dep+1),(b[:-2]+(m,b[-1]),dep+1)];continue
  rows.append(['tile',i+1,0,*b,dep,n,*v,'negative' if v[1]<0 else 'open'])
 return rows
def run():
 s=round(1.02*D);b=(s-16,s+16,3*D-16,3*D+16)
 args=[(i,b+(j*D//256,(j+1)*D//256)) for i in range(2) for j in range(64,84)]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','7'))) as pool,(BASE/'out/bridge.csv').open('w') as f:
  w=csv.writer(f);w.writerow('kind axis mode s0 s1 t0 t1 r0 r1 depth N lower upper altlo althi result'.split())
  for r in pool.map(job,args):w.writerows(r)
if __name__=='__main__':run()
