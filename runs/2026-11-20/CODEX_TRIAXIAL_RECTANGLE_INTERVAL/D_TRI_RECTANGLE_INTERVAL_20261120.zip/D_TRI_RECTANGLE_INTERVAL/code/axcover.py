from pathlib import Path
import ctypes as ct, os, csv, time
from concurrent.futures import ProcessPoolExecutor
BASE=Path(__file__).resolve().parents[1]; D=5242880
lib=ct.CDLL(str(BASE/'code/axis.so'));lib.axis_setup()
lib.axis_bound.argtypes=[ct.c_int,ct.c_int,ct.POINTER(ct.c_int),ct.c_int,ct.c_int,ct.POINTER(ct.c_double)]
def bound(mode,axis,box,n,der):
 ret=(ct.c_double*4)();lib.axis_bound(mode,axis,(ct.c_int*4)(*box),n,der,ret);return list(ret)
def initial():
 for surf in ['R','bottom','top']:
  for i in range(4):
   for j in (range(8) if surf=='R' else [0]):
    s0=D+i*(11*D//20);t0=D+j*(5*D//8)
    box=(s0,s0+11*D//20,t0 if surf=='R' else D if surf=='bottom' else 6*D,t0+5*D//8 if surf=='R' else D if surf=='bottom' else 6*D)
    for mode,axis in [(0,0),(0,1),(0,2),(1,0),(1,1)]:
     if surf!='R' and axis==2:continue
     yield surf,mode,axis,box
def job(p):
 surf,mode,axis,box=p;der=1 if surf=='bottom' else 2
 leaves=[];tim=0;pending=[(box,0)]
 while pending:
  box,dep=pending.pop(0)
  n=16 if dep<3 else 48 if dep<6 else 96
  tic=time.process_time();v=bound(mode,axis,box,n,der);tim+=time.process_time()-tic
  if v[0]>0:status='positive'
  elif v[1]<0:status='negative'
  elif v[3]<0 and ((surf=='R' and axis<2) or (surf=='bottom' and axis==0)):status='down'
  else:status='open'
  # Deterministic initial cap per root: keep all terminal boxes, including unresolved.
  if status=='open' and dep<7:
   a,b,c,d=box
   if (b-a)*50 >= (d-c)*22:
    m=(a+b)//2;children=[(a,m,c,d),(m,b,c,d)]
   else:
    m=(c+d)//2;children=[(a,b,c,m),(a,b,m,d)]
   pending.extend((x,dep+1) for x in children);continue
  leaves.append([surf,mode,axis+1,*box,dep,n,der,*v,status])
 return leaves,tim
def run():
 rows=[];times=[]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','6'))) as pool:
  args=list(initial())
  for p,(ret,t) in zip(args,pool.map(job,args)):
   rows+=ret;times.append([*p[:3],*p[3],len(ret),t])
 with (BASE/'out/axis_cover.csv').open('w') as f:
  w=csv.writer(f);w.writerow('surface mode axis s0 s1 t0 t1 depth N deriv lower upper dlo dhi result'.split());w.writerows(rows)
 with (BASE/'out/axis_time.csv').open('w') as f:
  w=csv.writer(f);w.writerow('surface mode axis0 s0 s1 t0 t1 leaves cpu_s'.split());w.writerows(times)
if __name__=='__main__':run()
