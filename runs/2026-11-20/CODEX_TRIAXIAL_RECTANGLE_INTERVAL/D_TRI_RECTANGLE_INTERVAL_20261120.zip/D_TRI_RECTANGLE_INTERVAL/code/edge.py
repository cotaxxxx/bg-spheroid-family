from axcover import BASE,D,ct,ProcessPoolExecutor,os,csv,time
lib=ct.CDLL(str(BASE/'code/profiles.so'));lib.axis_setup()
lib.profile.argtypes=[ct.c_int,ct.c_int,ct.POINTER(ct.c_int),ct.c_int,ct.POINTER(ct.c_double)]
def bound(mode,axis,box,n):
 ret=(ct.c_double*2)();lib.profile(mode,axis,(ct.c_int*6)(*box),n,ret);return list(ret)
def initial():
 for j in range(60): # 17/8 through 4; all bands have width 1/32
  t0=17*D//8+j*D//32;t1=t0+D//32
  r0=9*D//16 if t0<7*D//2 else 6*D//16
  yield ('floor',0,0,(D,D,t0,t1,r0,r0))
  for r in range(r0,D,D//16):
   yield ('strip',1,0,(D,D,t0,t1,r,r+D//16))
 # Nonaxisymmetric closed shape box; distinct signed end radii in each axis.
 for axis,(a,b) in enumerate([(75,85),(78,88)]):
  s0=round(1.02*D)-16;s1=round(1.02*D)+16;t0=3*D-16;t1=3*D+16
  for side,r in [('plus',a),('minus',b)]:
   yield (side,0,axis,(s0,s1,t0,t1,r*D//100,r*D//100))
  for r in range(a,b):
   yield ('slope',2,axis,(s0,s1,t0,t1,r*D//100,(r+1)*D//100))
def job(req):
 typ,mode,axis,box=req;tic=time.process_time();leaves=[];stack=[(box,0)]
 while stack:
  end,dep=stack.pop();sign=-1 if typ in ['minus','slope'] else 1
  for n in [48,128,256,512]:
   v=bound(mode,axis,end,n);status='positive' if v[0]>0 else 'negative' if v[1]<0 else 'open'
   if (sign>0 and v[0]>0) or (sign<0 and v[1]<0):break
   if n>=128 and dep<2 and typ=='strip':break
  if status=='open' and dep<3 and typ=='strip':
   s0,s1,t0,t1,r0,r1=end
   mid=(r0+r1)//2
   stack.extend([((s0,s1,t0,t1,r0,mid),dep+1),((s0,s1,t0,t1,mid,r1),dep+1)])
   continue
  leaves.append([typ,mode,axis+1,*end,dep,n,*v,status])
 return leaves,time.process_time()-tic
def run():
 rows=[];tim=[]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','6'))) as pool:
  for p,(v,t) in zip(initial(),pool.map(job,initial())):rows.extend(v);tim.append([*p[:3],*p[3],len(v),t])
 head='kind mode axis s0 s1 t0 t1 r0 r1'.split()
 for nm,h,v in [('edge',head+['depth','N','lower','upper','result'],rows),('edge_time',head+['leaves','cpu_s'],tim)]:
  with (BASE/'out'/(nm+'.csv')).open('w') as f:
   w=csv.writer(f);w.writerow(h);w.writerows(v)
if __name__=='__main__':run()
