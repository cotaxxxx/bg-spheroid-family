"""Plot V55 floating sections on the rectangle; mark the enclosed crossing."""
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
ROOT=Path(__file__).resolve().parents[1]
with (ROOT/'inputs/v55_sections.csv').open() as f: records=list(csv.DictReader(f))
with (ROOT/'inputs/v55_special.csv').open() as f: markers=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(8.2,5.3),layout='constrained')
for axis,color in [(1,'#23558f'),(2,'#ad4b0f')]:
 for mode,style in [('h','-'),('b','--')]:
  points=[(float(v['s']),float(v['t'])) for v in records if v['n']=='96' and int(v['axis'])==axis and v['mode']==mode and float(v['s'])<=3.2 and float(v['t'])<=6]
  if axis==1:
   points.append((next(float(v['s']) for v in markers if v['event']=='ob_'+mode+'1' and v['n']=='96'),1))
  xs,ys=zip(*sorted(points))
  ax.plot(xs,ys,style,color=color,lw=2.2,label=('$Z_' if mode=='h' else '$B_')+str(axis)+'$')
  ax.scatter(xs,ys,color=color,s=10)
ax.scatter([1.566969],[2.296586],marker='o',s=37,color='#171717',zorder=8)
ax.annotate('$Z_1 \\cap B_2$',xy=(1.566969,2.296586),xytext=(1.8,2.85),arrowprops={'arrowstyle':'-','color':'#444'},size=11)
ax.set(xlim=(1,3.2),ylim=(1,6),xlabel='$s = a_2/a_1$',ylabel='$t = a_3/a_2$',
       title='Centre and axial boundary zeros on the shape rectangle')
ax.xaxis.set_minor_locator(MultipleLocator(.1));ax.yaxis.set_minor_locator(MultipleLocator(.25))
ax.grid(alpha=.2);ax.legend(loc='center right',ncol=2)
fig.savefig(ROOT/'RECTANGLE_MAP.png',dpi=175)
