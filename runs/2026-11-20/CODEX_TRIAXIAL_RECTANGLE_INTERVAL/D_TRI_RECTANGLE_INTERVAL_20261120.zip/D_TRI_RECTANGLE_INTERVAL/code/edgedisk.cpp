#include "profiles.cpp"
// Analytic radial second derivative of T11-T22 for s=1.
extern "C" void shear2(const int* ends,int n,double* out){
 I a[2];for(int i=0;i<2;i++)a[i]=I(rat(ends[2*i],5242880).l,rat(ends[2*i+1],5242880).h);
 I T=sq(a[0]),r=a[1],total=0;
 const auto& g=cells(n);
 for(const auto &w:g){
  I U=blend(w.w,1,T),V=blend(w.w,1,inv(T)),row=0;
  for(const auto &c:g){
   I mu=c.mu,m=mu-r,d=sq(m)+c.v*U,k=1-r*mu,B=blend(c.v,1,V);
   I H=inv(root(d*B)),gamma=unit(k*H),P=angle(gamma,1),Pd=-angle(gamma,2),Pdd=angle(gamma,3);
   I l=gamma*P,l1=P+gamma*Pd,l2=2*Pd+gamma*Pdd;
   I h=m/d,ratio=clip(sq(m)/d,0,1);
   I dg=H*(-mu+k*h),ddg=H*(-2*mu*h+k*(3*ratio-1)/d);
   I A=k*l,Ad=-mu*l+k*l1*dg,Add=-2*mu*l1*dg+k*(l2*sq(dg)+l1*ddg);
   I Y=c.v*(1-w.w),coef=c.v*blend(w.w,2,T)/d;
   I diff=clip((sq(m)-Y)/d,-1,1)-clip((c.m2-Y)/B,-1,1);
   I Vd=-2*h*coef,Vdd=2*coef*(1-4*ratio)/d;
   row=row+Add*diff+2*Ad*Vd+A*Vdd;
  }total=total+row;
 }
 total=total/I(n*n);out[0]=total.l;out[1]=total.h;
}
