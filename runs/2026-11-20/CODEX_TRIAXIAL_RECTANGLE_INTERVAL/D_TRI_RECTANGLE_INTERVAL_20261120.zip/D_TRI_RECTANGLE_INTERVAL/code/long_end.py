from axcover import BASE,D,bound,csv,ProcessPoolExecutor,os
def job(start):
 stack=[(start,0)];rows=[]
 while stack:
  box,depth=stack.pop()
  for n in [32,96,256]:
   lo,hi,*_=bound(1,2,box,n,0)
   if lo>0:break
  if lo<=0 and depth<7:
   a,b,c,d=box
   if (b-a)*50>=(d-c)*22:
    m=(a+b)//2;parts=[(a,m,c,d),(m,b,c,d)]
   else:
    m=(c+d)//2;parts=[(a,b,c,m),(a,b,m,d)]
   stack.extend((p,depth+1) for p in parts)
  else:rows.append([*box,3,n,depth,lo,hi,'positive' if lo>0 else 'open'])
 return rows
def run():
 boxes=[(D+i*11*D//20,D+(i+1)*11*D//20,D+j*5*D//8,D+(j+1)*5*D//8) for i in range(4) for j in range(8)]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','6'))) as pool,(BASE/'out/long_end.csv').open('w') as f:
  w=csv.writer(f);w.writerow('s0 s1 t0 t1 axis N depth lower upper result'.split())
  for data in pool.map(job,boxes):w.writerows(data);f.flush()
if __name__=='__main__':run()
