from axcover import *
lib=ct.CDLL(str(BASE/'code/rim.so'));lib.axis_setup()
lib.rim.argtypes=[ct.POINTER(ct.c_int),ct.c_int,ct.POINTER(ct.c_double)]
def calculate(box,n):
 res=(ct.c_double*6)();lib.rim((ct.c_int*4)(*box),n,res);return list(res)
def run():
 rows=[]
 for mode,(a,b,c,d) in [('pro',(100,100,206,207)),('ob',(155,156,100,100))]:
  # Outer rounding of decimal input to the common grid; pin exact symmetry edges.
  box=[a*D//100,(b*D+99)//100,c*D//100,(d*D+99)//100]
  for n in [32,64,128,256]:
   res=calculate(box,n);ok=res[1]<0 and res[4]>0 and (mode=='pro' or res[2]>0)
   rows.append([mode,*box,n,*res,'sign' if ok else 'open'])
   if ok:break
 with (BASE/'out/rim.csv').open('w') as f:
  w=csv.writer(f);w.writerow('mode s0 s1 t0 t1 N H11lo H11hi H22lo H22hi H33lo H33hi result'.split());w.writerows(rows)
if __name__=='__main__':run()
