from axcover import BASE,D,ct,time,csv,ProcessPoolExecutor,os
lib=ct.CDLL(str(BASE/'code/hb.so'));lib.hbsetup()
lib.hbval.argtypes=[ct.c_int,ct.c_int,ct.POINTER(ct.c_int),ct.c_int,ct.POINTER(ct.c_double)]
def calc(mode,i,box,n):
 ret=(ct.c_double*4)();lib.hbval(mode,i,(ct.c_int*6)(*box),n,ret);return list(ret)
def job(p):
 kind,i,box,mode=p;tic=time.process_time();stack=[(box,0)];rows=[]
 while stack:
  b,dep=stack.pop()
  for n in ([64,256] if dep==0 else [256,512,1024]):
   v=calc(mode,i,b,n)
   if v[1]<0:break
  if kind=='tile' and v[1]>=0 and dep<5:
   m=(b[-2]+b[-1])//2
   stack.extend([(b[:-1]+(m,),dep+1),(b[:-2]+(m,b[-1]),dep+1)]);continue
  rows.append([kind,i+1,mode,*b,dep,n,*v,'negative' if v[1]<0 else 'open'])
 return rows,time.process_time()-tic
def run():
 s=round(1.02*D);tile=(s-16,s+16,3*D-16,3*D+16)
 args=[('tile',i,tile+(j*D//32,(j+1)*D//32),int(j>=8)) for i in (0,1) for j in range(32)]
 for si in range(4):
  for ti in range(8):
   width=11*D//20;high=5*D//8;s=D+si*width+width//2;t=D+ti*high+high//2
   shape=(s-width//128,s+width//128,t-high//128,t+high//128)
   for i in (0,1):
    for a,b in [(0,D//1024),(D//2-D//1024,D//2+D//1024),(D-D//1024,D)]:
     args.append(('probe',i,shape+(a,b),int(a>0)))
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','7'))) as pool,(BASE/'out/hb.csv').open('w') as f,(BASE/'out/hb_time.csv').open('w') as g:
  w=csv.writer(f);z=csv.writer(g);w.writerow('kind axis mode s0 s1 t0 t1 r0 r1 depth N lower upper altlo althi result'.split());z.writerow('kind axis0 s0 s1 t0 t1 r0 r1 leaves cpu_s'.split())
  for p,(rows,t) in zip(args,pool.map(job,args)):w.writerows(rows);z.writerow([p[0],p[1],*p[2],len(rows),t]);f.flush();g.flush()
if __name__=='__main__':run()
