from pathlib import Path
import sys,csv
sys.path.insert(0,str(Path(__file__).resolve().parent/'atlas'))
from refine import ax,S,T
rows=[]
for s in S:
 for t in T:
  for i in (0,1):
   for r in (.025,.1,.25,.5,.75,.95,.99):
    u,h=ax(s,t,i,r,64)
    rows.append((s,t,i+1,r,u,(h[i]-u)/r))
with open('out/hb_scout.csv','w') as f:
 w=csv.writer(f);w.writerow(['s','t','axis','r','kappa','d_kappa_dr']);w.writerows(rows)
print(sorted(rows,key=lambda x:-x[-1])[:8])
