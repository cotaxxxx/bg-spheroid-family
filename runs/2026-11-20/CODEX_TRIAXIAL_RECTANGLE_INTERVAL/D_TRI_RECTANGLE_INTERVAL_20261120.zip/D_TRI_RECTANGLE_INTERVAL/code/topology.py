from polycover import *
from collections import Counter
from fractions import Fraction as F
def bfun(i,box,n,der): return bound(1,i,box,n,der)
def mul(x,y):
 g=[F(a)*F(b) for a in x for b in y];return min(g),max(g)
def lowerfloat(x):return np.nextafter(float(x),-np.inf)
def upperfloat(x):return np.nextafter(float(x),np.inf)
def det(h,ds,dt):return lowerfloat(mul(h[2:4],dt)[0]-mul(h[4:6],ds)[1])
def run():
 errs,_=prep(False)
 with (BASE/'out/axis_cover.csv').open() as f:old=list(csv.DictReader(f))
 with (BASE/'out/bfinish.csv').open() as f:old+=list(csv.DictReader(f))
 rows=[]
 for kind,idx in [('cross',2),('b2_h2',2),('b1_h1',1),('b1_b2',1),('centre_gap',0)]:
  if idx:
   boxes=[tuple(int(x[k]) for k in 's0 s1 t0 t1'.split()) for x in old if x['surface']=='R' and int(x['mode'])==1 and int(x['axis'])==idx and x['result']=='down']
  else:boxes=[(D,16*D//5,D,6*D)]
  for start in boxes:
   todo=[(start,0)]
   while todo:
    box,dep=todo.pop();s0,s1,t0,t1=box;st='open';v=0.;n=0
    if kind=='centre_gap':
     h1=enclosure(0,box,errs);h2=enclosure(1,box,errs);s=F(s1,D)
     v=lowerfloat(F(h2[0])-F(h1[1])-(s-1/s)/32)
     if v>0:st='gap'
     else:
      wide=(D,s1,t0,t1);h1=enclosure(0,wide,errs);h2=enclosure(1,wide,errs)
      v=lowerfloat(F(h2[2])-F(h1[3])-F(1,16))
      if v>0:st='gap_from_edge'
    else:
     h=enclosure(int(kind=='b2_h2'),box,errs)
     if kind!='b1_b2' and (h[0]>0 or (kind=='cross' and h[1]<0)):
      v=h[0] if h[0]>0 else -h[1];st='positive_h' if h[0]>0 else 'negative_h'
     else:
      for n in ([48,128] if dep<2 else [96,256,512]):
       b=bfun(idx-1,box,n,2)
       if b[0]>0 or b[1]<0:v=max(b[0],-b[1]);st='b_nonzero';break
       if kind=='cross':
        bs=bfun(1,box,n,1)
        v=det(h,bs[2:],b[2:])
        if v>0:st='positive_det';break
       elif kind=='b1_b2':
        b2=bfun(1,box,n,2)
        if b2[0]>0:v=b2[0];st='b2_positive';break
        if s1<=2*D:
         wide=(D,s1,t0,t1);u=bfun(0,wide,n,1);w=bfun(1,wide,n,1)
         v=lowerfloat(F(w[2])-F(u[3]))
         if v>0:st='ordered_from_edge';break
    if st=='open' and dep<14:
     todo.extend((x,dep+1) for x in split(box));continue
    rows.append([kind,*start,*box,dep,n,v,st])
 with (BASE/'out/topology.csv').open('w') as f:
  w=csv.writer(f);w.writerow('mode parent_s0 parent_s1 parent_t0 parent_t1 s0 s1 t0 t1 depth N margin result'.split());w.writerows(rows)
 print(Counter((x[0],x[-1]) for x in rows))
if __name__=='__main__':run()
