#include "axis.cpp"
extern "C" void rim(const int* ends,int n,double* out){
 I s(rat(ends[0],5242880).l,rat(ends[1],5242880).h),t(rat(ends[2],5242880).l,rat(ends[3],5242880).h);
 I A=sq(s),C=sq(s*t),total[3]={};const auto& grid=cells(n);
 for(auto &w:grid){
  I U=blend(w.w,A,C),V=blend(w.w,inv(A),inv(C)),row[3]={};
  for(int i=0;i<n;i++){
   I f(rat(i,n).l,rat(i+1,n).h),f2=unit(sq(f)),c2=unit(1-f2),mu=1-2*f2,v=unit(4*f2*c2);
   I d=blend(f2,U,1),B=blend(v,1,V),H=inv(root(d*B)),gam=unit(f*H),P=angle(gam,1),Q=2*P-gam*angle(gam,2);
   I u2=f2/d,z=mu+u2;
   row[0]=row[0]+(P*sq(gam)*B*clip(1-u2,0,1)-Q*sq(z))*H;
   for(int l=1;l<=2;l++){
    I wj=l==1?1-w.w:w.w,aa=l==1?A:C;
    I proj=aa*clip(1-aa*c2*wj/d,0,1);
    I zz=v*wj*sq(1-aa/(2*d));
    row[l]=row[l]+(P*sq(gam)*B*proj-Q*zz)*H;
   }
  }for(int l=0;l<3;l++)total[l]=total[l]+row[l];
 }for(int l=0;l<3;l++){I val=total[l]/I(n*n);out[2*l]=val.l;out[2*l+1]=val.h;}
}
