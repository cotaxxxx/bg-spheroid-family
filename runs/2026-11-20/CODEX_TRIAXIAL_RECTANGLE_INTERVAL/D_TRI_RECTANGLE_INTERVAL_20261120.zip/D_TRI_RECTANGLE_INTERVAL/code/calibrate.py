import ctypes as ct,csv,os,time
from fractions import Fraction as F
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
BASE=Path(__file__).resolve().parents[1]
D=5242880
lib=ct.CDLL(str(BASE/'code'/'bound.so'))
lib.setup()
IP=ct.POINTER(ct.c_int);DP=ct.POINTER(ct.c_double)
lib.enclosure.argtypes=[ct.c_int,IP,ct.c_int,DP]
def call(mode,ends,n):
 b=(ct.c_double*2)()
 lib.enclosure(mode,(ct.c_int*10)(*ends),n,b)
 return tuple(b)
patches=[('oct',1,(F(1,4),F(1,4),F(1,2))),('face13',1,(F(1,4),0,F(1,2))),('face23',1,(0,F(1,4),F(1,2))),
 ('plane-H33',3,(F(1,4),F(1,4),0)),('rim13',1,(F(3,5),0,F(4,5))),
 ('disk',2,(F(1,2),F(1,2),0)),('rim12',2,(F(3,5),F(4,5),0)),('disk2',2,(F(1,4),F(1,2),0))]
def job(arg):
 i,j,stage,p=arg;name,mode,q=patches[p]
 a,b=F(1)+i*F(11,20),F(1)+j*F(5,8)
 spans=[(a,a+F(11,20)),(b,b+F(5,8))]
 if stage:
  spans=[((x+y)/2-(y-x)/128,(x+y)/2+(y-x)/128) for x,y in spans]
 for k,x in enumerate(q):
  w=F(1,1024) if x or (mode==3 and k==2) else 0
  spans.append((max(0,x-w),x+w))
 ends=[int(v*D) for span in spans for v in span]
 assert all(v*D==z for v,z in zip([v for span in spans for v in span],ends))
 n=[16,64,256][stage];tic=time.process_time();low,high=call(mode,ends,n)
 return [i,j,stage,name,mode,*ends,n,low,high,'positive' if low>0 else 'open'],time.process_time()-tic
def run():
 header='sidx tidx stage patch mode s0 s1 t0 t1 q10 q11 q20 q21 q30 q31 N lower upper result'.split()
 results=[]; timing=[]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','6'))) as pool:
  for stage in range(3):
   if stage<2: args=[(i,j,stage,p) for i in range(4) for j in range(8) for p in range(8)]
   else:
    # One fine trial per layer and tile: prioritize open octant and interior disk.
    args=[]
    for i in range(4):
     for j in range(8):
      for indices in [[0,1,2,3,4],[5,6,7]]:
       for p in indices:
        if any(x[:4]==[i,j,1,patches[p][0]] and x[-1]=='open' for x in results):
         args.append((i,j,2,p));break
   for row,sec in pool.map(job,args):
    results.append(row);timing.append([*row[:5],sec])
 with (BASE/'out/cal.csv').open('w') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(results)
 with (BASE/'out/cal_time.csv').open('w') as f:
  w=csv.writer(f);w.writerow(header[:5]+['cpu_s']);w.writerows(timing)
if __name__=='__main__':run()
