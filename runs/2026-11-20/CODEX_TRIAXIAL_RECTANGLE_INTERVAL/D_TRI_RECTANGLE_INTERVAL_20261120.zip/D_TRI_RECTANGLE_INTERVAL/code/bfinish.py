from axcover import *
def item(arg):
 row=arg;root=tuple(map(int,(row[k] for k in 's0 s1 t0 t1'.split())))
 todo=[(root,0)];leaves=[];tic=time.process_time()
 while todo:
  box,dep=todo.pop()
  for n in (256,512):
   v=bound(1,0,box,n,2)
   if v[0]>0 or v[1]<0 or v[3]<0:break
  if v[0]>0:st='positive'
  elif v[1]<0:st='negative'
  elif v[3]<0:st='down'
  else:st='open'
  if st=='open' and dep<4:
   a,b,c,d=box
   if (b-a)*50>=(d-c)*22:
    mid=(a+b)//2;xs=[(a,mid,c,d),(mid,b,c,d)]
   else:
    mid=(c+d)//2;xs=[(a,b,c,mid),(a,b,mid,d)]
   todo.extend((x,dep+1) for x in xs);continue
  leaves.append(['R',1,1,*box,dep+7,n,2,*v,st])
 return leaves,time.process_time()-tic
def run():
 with (BASE/'out/axis_cover.csv').open() as f:
  data=list(csv.DictReader(f));head=list(data[0])
 targets=[x for x in data if x['surface']=='R' and x['mode']=='1' and x['axis']=='1' and x['result']=='open']
 rows=[];times=[]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','6'))) as pool:
  for orig,(v,t) in zip(targets,pool.map(item,targets)):
   rows+=v;times.append([*[orig[k] for k in 's0 s1 t0 t1'.split()],len(v),t])
 for nm,h,v in [('bfinish',head,rows),('bfinish_time','s0 s1 t0 t1 leaves cpu_s'.split(),times)]:
  with (BASE/'out'/(nm+'.csv')).open('w') as f:
   w=csv.writer(f);w.writerow(h);w.writerows(v)
if __name__=='__main__':run()
