from edge import *
import ctypes as ct
sh=ct.CDLL(str(BASE/'code/disk.so'));sh.axis_setup()
sh.shear2.argtypes=[ct.POINTER(ct.c_int),ct.c_int,ct.POINTER(ct.c_double)]
def calc(b,n,small):
 if not small:return bound(1,0,(D,D,*b),n)
 ret=(ct.c_double*2)();sh.shear2((ct.c_int*4)(*b),n,ret);return list(ret)
def job(args):
 box,small=args;tic=time.process_time();stack=[(box,0)];rows=[]
 while stack:
  b,dep=stack.pop()
  for n in ([32,96] if dep<2 else [128,256,512]):
   v=calc(b,n,small)
   if v[0]>0:break
  if v[0]<=0 and dep<4:
   a,c,r,l=b
   if dep%3==2:
    m=(a+c)//2;kids=[(a,m,r,l),(m,c,r,l)]
   else:
    m=(r+l)//2;kids=[(a,c,r,m),(a,c,m,l)]
   stack.extend((x,dep+1) for x in kids);continue
  rows.append(['tau2' if small else 'tau',*b,dep,n,*v,'positive' if v[0]>0 else 'open'])
 return rows,time.process_time()-tic
def run():
 args=[((2*D+j*D//8,2*D+(j+1)*D//8,i*D//32,(i+1)*D//32),i<12) for j in range(24) for i in range(32)]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','7'))) as pool,(BASE/'out/disk.csv').open('w') as f,(BASE/'out/disk_time.csv').open('w') as t:
  w=csv.writer(f);w.writerow('mode t0 t1 r0 r1 depth N lower upper result'.split());z=csv.writer(t);z.writerow('t0 t1 r0 r1 leaves cpu_s'.split())
  for (b,_),(rows,sec) in zip(args,pool.map(job,args)):w.writerows(rows);z.writerow([*b,len(rows),sec]);f.flush();t.flush()
if __name__=='__main__':run()
