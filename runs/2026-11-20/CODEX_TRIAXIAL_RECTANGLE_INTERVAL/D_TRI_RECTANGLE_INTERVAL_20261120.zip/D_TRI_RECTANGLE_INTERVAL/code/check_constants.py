"""Rational checks for the analytic estimates used in the two proof appendices."""
from fractions import Fraction as Q
from math import factorial

def exp_upper(x, n=15):
    last=x**(n+1)/factorial(n+1)
    return sum(x**i/factorial(i) for i in range(n+1))+last/(1-x/(n+2))

def verify():
    pi=Q(22,7)
    tail=Q(101*100*99,2**100)/(1-Q(102,198))
    assert tail<Q(1,2**75)
    k=Q(96,5);a=Q(13,20)
    sinh_upper=(exp_upper(a)-1/exp_upper(a))/2
    assert sinh_upper<Q(7,10)
    decay=(1+Q(52,2048))**(-2048)
    assert 8*200000*decay*(1+k/(2*a))<Q(1,10**13)
    alpha=Q(339,1000);beta=Q(374,1000)
    for c,v,r,angle in [(Q(21,10),Q(11,10),Q(33,20),alpha),(Q(7,2),Q(5,2),Q(7,5),beta)]:
        A=v*(r+1/r)/2;B=v*(r-1/r)/2
        assert B**2<angle**2*(c*c-A*A)
    tangent=(alpha+beta)/(1-alpha*beta)
    assert (1-tangent**2)/(1+tangent**2)>Q(1,8)
    assert 2*(pi*800*4+4*pi*(2+6+3*800))<200000
    assert 8*(pi*18432*9+10*pi*(2+16*18432))<10**8
    for k,bound in [(2,2500),(6,50000)]:
        assert k*pi*(14*k*k+16*(1+k)**2+30*k*(1+k))<bound
    e=exp_upper(Q(1,32));sqrt2=Q(99,70)
    assert sqrt2**2>2
    assert e-1+6*sqrt2*e/256<Q(7,100) and e-1<Q(32,1000)
    assert (1+Q(13,100))**2*(1-Q(15,100))*(1-Q(7,100))>1
    assert Q(13,100)+Q(113,100)*6*sqrt2/256<Q(18,100)
    assert 1+sqrt2/256<Q(101,100)
    assert Q(101,100)*4*Q(12,10)*2*Q(12,10)**2<20
    assert e-1+6*e/31<Q(233,1000)
    assert (1+Q(233,1000))**2-1<Q(521,1000)
    assert (1+Q(32,1000))**2-1<Q(66,1000)
    assert Q(3,2)**2*(1-Q(521,1000))*(1-Q(66,1000))>1
    assert Q(1,2)+Q(3,2)*6/31<Q(8,10)
    assert (1+Q(2,32))*Q(181,100)*17<40
    eps=Q(1,2**39)
    assert Q(3341881,2**36)-50000*eps>0
    assert Q(18,100000)-20*32*256**2*eps>Q(1,10000)
    assert Q(1,24)-Q(2500,100000)>0
if __name__=='__main__':verify()
