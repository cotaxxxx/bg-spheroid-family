from axcover import BASE,D,ct,ProcessPoolExecutor,os,csv
lib=ct.CDLL(str(BASE/'code/long.so'));lib.hbsetup()
lib.long_value.argtypes=[ct.c_int,ct.POINTER(ct.c_int),ct.c_int,ct.POINTER(ct.c_double)]
def job(seed):
 queue=[(seed,0)];rows=[];visits=0;mode=int(seed[4]>=D//4)
 while queue:
  box,depth=queue.pop(0);visits+=1
  for n in ([32,96,256] if depth<3 else [128,256,512]):
   val=(ct.c_double*2)();lib.long_value(mode,(ct.c_int*6)(*box),n,val)
   if val[0]>0:break
  if val[0]<=0 and depth<6 and visits+len(queue)+2<=15:
   # normalize widths by the original seed in each dimension, preferring radius on ties
   pairs=[(box[2*j+1]-box[2*j])/(seed[2*j+1]-seed[2*j]) for j in range(3)]
   j=max(range(3),key=lambda j:(pairs[j],j));k=2*j;mid=(box[k]+box[k+1])//2
   queue.extend([(box[:k+1]+(mid,)+box[k+2:],depth+1),(box[:k]+(mid,)+box[k+1:],depth+1)])
  else:rows.append([*box,mode,n,depth,*val,'positive' if val[0]>0 else 'open'])
 return rows
def run():
 seeds=[(D+i*11*D//20,D+(i+1)*11*D//20,D+j*5*D//8,D+(j+1)*5*D//8,k*D//16,(k+1)*D//16) for i in range(4) for j in range(8) for k in range(16)]
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','5'))) as pool,(BASE/'out/long_axis.csv').open('w') as f:
  w=csv.writer(f);w.writerow('s0 s1 t0 t1 r0 r1 mode N depth lower upper result'.split())
  for data in pool.map(job,seeds):w.writerows(data);f.flush()
if __name__=='__main__':run()
