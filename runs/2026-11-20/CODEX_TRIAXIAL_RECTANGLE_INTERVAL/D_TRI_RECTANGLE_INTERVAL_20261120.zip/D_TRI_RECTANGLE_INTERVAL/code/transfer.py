"""Replay the rational stability test on the accepted V50 E partition."""
import csv,gzip
from fractions import Fraction as F
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
S=2**20
V=2**36
EPS=F(1,2**39)
def run():
 rows=[]
 for f in sorted((BASE/'inputs/v50').glob('E*.tsv.gz')):
  with gzip.open(f,'rt') as src:
   for x in csv.DictReader(src,delimiter='\t'):
    st=x['action']
    if st.startswith('split'):continue
    l,h,a,b=map(int,(x[k] for k in ('l0','l1','r0','r1')))
    if st=='H_positive':parts=[(a,b,'kappa_positive',F(int(x['alo']),V),50000*EPS)]
    elif st=='radial_curvature_negative':parts=[(a,b,'Hii_negative',-F(int(x['bhi']),V),50000*EPS)]
    else:
     assert st=='radial_decreasing'
     margin=-F(int(x['ahi']),3*V);parts=[]
     if a<S//32:parts.append((a,min(b,S//32),'centre_slope',margin,40*32*24*32**4*EPS/3))
     if b>S//32:
      lo=max(a,S//32)
      parts.append((lo,b,'outer_slope',margin,100000*EPS/F(lo,S)**2))
    for lo,hi,m,margin,err in parts:
     assert margin>err
     rows.append([f.name,x['path'],l,h,lo,hi,S,m,str(margin),str(err),str(margin-err)])
 with (BASE/'out/transfer.csv').open('w') as out:
  w=csv.writer(out);w.writerow('source path t0 t1 r0 r1 denominator mode edge_margin error remaining'.split());w.writerows(rows)
if __name__=='__main__':run()
