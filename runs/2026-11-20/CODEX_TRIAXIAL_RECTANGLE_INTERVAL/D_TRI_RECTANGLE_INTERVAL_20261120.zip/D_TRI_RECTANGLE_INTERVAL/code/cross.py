import ctypes as ct,csv,time,os
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from fractions import Fraction as F
BASE=Path(__file__).resolve().parents[1]; lib=ct.CDLL(str(BASE/'code/cross.so'))
lib.initcross();lib.cross_eval.argtypes=[ct.c_int,ct.c_int,ct.POINTER(ct.c_int),ct.c_int,ct.c_int,ct.POINTER(ct.c_double)]
def evaluate(job):
 mode,ax,box,n,d=job
 ret=(ct.c_double*2)();tic=time.process_time()
 lib.cross_eval(mode,ax,(ct.c_int*4)(*box),n,d,ret)
 return [mode,ax+1,*box,n,d,*ret],time.process_time()-tic
M=(1566969,2296586);Y=[[F(-164,100),F(189,100)],[F(-26,100),F(-480,100)]]
def imul(a,v):return (min(a*v[0],a*v[1]),max(a*v[0],a*v[1]))
def ii(row):return tuple(map(F,row[-2:]))
def ibound(v):return max(map(abs,v))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def kraw(points,jac):
 d=F(1,1000);out=[]
 for i in range(2):
  shift=add(imul(-Y[i][0],ii(points[0])),imul(-Y[i][1],ii(points[1])))
  norm=F(0)
  for j in range(2):
   col=add(imul(-Y[i][0],ii(jac[j])),imul(-Y[i][1],ii(jac[2+j])))
   norm+=ibound(add(col,(F(i==j),F(i==j))))
  mid=F(M[i],10**6);out.append((mid+shift[0]-d*norm,mid+shift[1]+d*norm,norm))
 return out
def run():
 rows=[];times=[];pbox=(M[0],M[0],M[1],M[1]);box=(M[0]-1000,M[0]+1000,M[1]-1000,M[1]+1000)
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','6'))) as pool:
  def batch(jobs):
   v=[]
   for row,sec in pool.map(evaluate,jobs):
    rows.append(row);times.append([*row[:8],sec]);v.append(row)
   return v
  for n in [64,128,256,512,1024,2048]:
   pts=batch([(m,m,pbox,n,0) for m in [0,1]])
   if all(ibound(ii(x))<F(7,100000) for x in pts):break
  for n in [64,128,256,512,1024]:
   jac=batch([(m,m,box,n,d) for m in [0,1] for d in [1,2]])
   bounds=kraw(pts,jac)
   if max(x[2] for x in bounds)<F(3,5):break
 hdr=['mode','axis','s0','s1','t0','t1','N','derivative']
 for name,head,data in [('cross',hdr+['lower','upper'],rows),('cross_time',hdr+['cpu_s'],times)]:
  with (BASE/'out'/(name+'.csv')).open('w') as f:
   w=csv.writer(f);w.writerow(head);w.writerows(data)
 with (BASE/'out/kraw.txt').open('w') as f:
  for a,b,L in bounds: f.write(f'{a} {b} {L}\n')
 print([[float(y) for y in x] for x in bounds],flush=True)
if __name__=='__main__':run()
