#include "iv_cross.hpp"
#include <vector>
#include <map>
inline I cosval(I x){
 I term=1,sum=1;for(int j=1;j<=12;j++){term=-term*sq(x)/I(2*j*(2*j-1));sum=sum+term;}
 // alternating series, first omitted term bounded by (pi/2)^26/26! < 4e-22
 return unit(sum+I(-1e-20,1e-20));
}
struct HC{I f,f2,mu,v,w;};static std::map<int,std::vector<HC>> cache;
inline auto& nodes(int n){
 if(cache.count(n))return cache[n];
 auto& a=cache[n];
 for(int i=0;i<n;i++){I left=rat(i,n),right=rat(i+1,n);I f=unit(I(left.l,right.h)),f2=unit(sq(f));
  I w=unit(I(sq(cosval(pi*right*.5)).l,sq(cosval(pi*left*.5)).h));
  a.push_back({f,f2,1-2*f2,unit(4*f2*(1-f2)),w});
 }return a;
}
inline I mix2(I w,I a,I b){
 auto p=[&](double x,double y){return I(x)+w*(I(y)-x);};return {p(a.l,b.l).l,p(a.h,b.h).h};
}
extern "C" void hbsetup(){init_tables();}
extern "C" void hbval(int mode,int axis,const int* end,int n,double* out){
 I arg[3];for(int i=0;i<3;i++)arg[i]={rat(end[2*i],5242880).l,rat(end[2*i+1],5242880).h};
 I s=arg[0],t=arg[1],r=arg[2],a=axis==0?sq(s):inv(sq(s)),b=axis==0?sq(s*t):sq(t);
 I amin=axis==0?I(1):inv(s);I total=0,etotal=0;
 const auto& grid=nodes(n);
 for(auto &p:grid){
  I U=mix2(p.w,a,b),V=mix2(p.w,inv(a),inv(b)),row=0,erow=0;
  for(auto &c:grid){
   I m=c.mu-r,d=sq(m)+c.v*U,k=clip(1-r*c.mu,0,2),B=mix2(c.v,1,V),S=root(B);
   I gam,u,fD,den;
   if(d.l>0){
    den=root(d);gam=unit(k/(den*S));u=clip(m/den,-1,1);fD=2*c.f/den;
    if(r.l>0)fD=clip(fD,0,inv(amin*root(r)).h);
   }else{
    if(mode==0||r.l<=0)std::abort();
    gam=I(0,1);u=I(-1,1);fD=I(0,inv(amin*root(r)).h);
   }
   I P=angle(gam,1),P1=-angle(gam,2),z=c.mu-gam*S*u,v;
   I Eg2f=2*c.f*(c.mu*(gam*P-angle(gam,0))-u*S*sq(gam)*P);
   if(mode==0){
    I H=inv(den*S),di=inv(d),h1=m*di,h2=(3*sq(u)-1)*di;
    I h3=h1*di*(15*sq(u)-9),h4=sq(di)*(105*sq(sq(u))-90*sq(u)+9);
    I d1=-H*z,d2=H*(k*h2-2*c.mu*h1),d3=H*(k*h3-3*c.mu*h2),d4=H*(k*h4-4*c.mu*h3);
    I F1=-P,F2=-P1,F3=-angle(gam,3),F4=angle(gam,4);
    I comp3=F3*d1*sq(d1)+3*F2*d1*d2+F1*d3;
    I comp4=F4*sq(sq(d1))+6*F3*sq(d1)*d2+3*F2*sq(d2)+4*F2*d1*d3+F1*d4;
    v=2*c.f*(k*comp4-4*c.mu*comp3);
    // For root exclusion at small r return Hii in secondary column.
    erow=erow+fD/S*(P*sq(gam)*B*clip(1-sq(u),0,1)-(2*P+gam*P1)*sq(z));
   }else{
    I hh=fD/S*(P*sq(gam)*B*clip(1-sq(u),0,1)-(2*P+gam*P1)*sq(z));
    v=(hh-Eg2f/r)/sq(r);erow=erow+Eg2f/r;
   }row=row+v;
  }total=total+row;etotal=etotal+erow;
 }
 total=total/I(n*n);etotal=etotal/I(n*n);
 out[0]=total.l;out[1]=total.h;out[2]=etotal.l;out[3]=etotal.h;
}
