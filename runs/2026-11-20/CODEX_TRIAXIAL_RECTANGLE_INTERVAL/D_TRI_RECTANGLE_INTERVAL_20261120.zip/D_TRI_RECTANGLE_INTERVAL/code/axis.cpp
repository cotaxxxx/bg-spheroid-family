// F and a shape derivative in a chart normalized by the length of the tested axis.
#include "interval.hpp"
#include <vector>
#include <map>
struct D{I v,d; D(double x=0):v(x){} D(I a,I b=0):v(a),d(b){}};
inline D operator+(D a,D b){return {a.v+b.v,a.d+b.d};}
inline D operator-(D a,D b){return {a.v-b.v,a.d-b.d};}
inline D operator*(D a,D b){return {a.v*b.v,a.d*b.v+a.v*b.d};}
inline D invd(D a){I v=inv(a.v);return {v,-sq(v)*a.d};}
inline D operator/(D a,D b){return a*invd(b);}
inline D sqd(D a){return {sq(a.v),2*a.v*a.d};}
inline D sqrtd(D a){I v=root(a.v);return {v,a.d/(2*v)};}
inline I blend(I w,I a,I b){
 I x=a.l+I(w.l)*(I(b.l)-a.l),y=a.l+I(w.h)*(I(b.l)-a.l);
 I z=a.h+I(w.l)*(I(b.h)-a.h),v=a.h+I(w.h)*(I(b.h)-a.h);
 return {std::min(x.l,y.l),std::max(z.h,v.h)};
}
inline D mix(I u,D a,D b){return {blend(u,a.v,b.v),blend(u,a.d,b.d)};}
inline I sinreg(I x){ // 0<=x<=pi/2; endpoint Taylor polynomial with Lagrange remainder
 I sum=x,term=x;
 for(int i=1;i<=12;i++){term=-term*sq(x)/I(2*i*(2*i+1));sum=sum+term;}
 return sum+I(-1e-20,1e-20); // (pi/2)^27 / 27! < 2e-23
}
struct Cell{I mu,v,m2,u,f,w;};
static std::map<int,std::vector<Cell>> grid;
inline const std::vector<Cell>& cells(int n){
 if(grid.count(n))return grid[n];
 auto &list=grid[n];
 for(int i=0;i<n;i++){
  I a=rat(i,n),b=rat(i+1,n);
  I mu=1-2*I(a.l,b.h),m2=unit(sq(mu)),u=unit(I(a.l,b.h));
  I w=unit(I(sq(sinreg(pi*a*.5)).l,sq(sinreg(pi*b*.5)).h));
  list.push_back({mu,unit(1-m2),m2,u,root(u),w});
 }return list;
}
extern "C" void axis_setup(){init_tables();}
extern "C" void axis_bound(int mode,int axis,const int* ends,int n,int der,double* out){
 D s(I(rat(ends[0],5242880).l,rat(ends[1],5242880).h),der==1);
 D t(I(rat(ends[2],5242880).l,rat(ends[3],5242880).h),der==2);
 D u,z;
 if(axis==0){u=sqd(s);z=sqd(s*t);}else if(axis==1){u=invd(sqd(s));z=sqd(t);}else{u=invd(sqd(s*t));z=invd(sqd(t));}
 D iu=invd(u),iz=invd(z);I total=0,dt=0;
 const auto& g=cells(n);
 for(const auto &w:g){
  D U=mix(w.w,u,z),V=mix(w.w,iu,iz);
  I row=0,drow=0;
  for(const auto &v:g){
   D B=mix(v.v,D(1),V),D2=mode==0?mix(v.v,D(1),U):mix(v.u,U,D(1));
   D H=invd(sqrtd(D2*B)),gam=mode==0?H:D(v.f)*H;gam.v=unit(gam.v);
   I pv=angle(gam.v,1),p1=-angle(gam.v,2);
   D P(pv,p1*gam.d),f;
   if(mode==0){
    D Q(2*pv+gam.v*p1,(3*p1+gam.v*angle(gam.v,3))*gam.d);
    D norm=(U-1)*D(v.v)/D2;
    f=(P*U*D(v.v)/sqd(D2)-Q*D(v.m2)*sqd(norm))*H;
   }else{
    D F(angle(gam.v,0),-pv*gam.d);
    f=D(v.mu)*(gam*P-F)+D(v.f)*sqrtd(B/D2)*sqd(gam)*P;
   }
   row=row+f.v;drow=drow+f.d;
  }
  total=total+row;dt=dt+drow;
 }
 total=total/I(n*n);dt=dt/I(n*n);
 out[0]=total.l;out[1]=total.h;out[2]=dt.l;out[3]=dt.h;
}
