from axcover import BASE,D,bound,csv
def run():
 rows=[]
 for mode,t,sign in ((1,17*D//8,-1),(0,9*D//2,1),(1,2*D,1),(0,5*D,-1)):
  for axis in (0,1):
   for n in (128,256,512,1024,2048):
    box=(D,D+1,t,t);lo,hi,*_=bound(mode,axis,box,n,0)
    rows.append((mode,axis+1,*box,n,lo,hi,sign))
    if (lo>0 if sign==1 else hi<0):break
   else:raise RuntimeError((mode,t,axis))
 with (BASE/'out/census.csv').open('w') as f:
  w=csv.writer(f);w.writerow('mode axis s0 s1 t0 t1 N lower upper expected_sign'.split());w.writerows(rows)
if __name__=='__main__':run()
