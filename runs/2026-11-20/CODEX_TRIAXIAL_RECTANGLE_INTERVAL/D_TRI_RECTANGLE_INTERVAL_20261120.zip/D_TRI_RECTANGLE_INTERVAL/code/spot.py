from pathlib import Path
import csv
import numpy as np
from scipy.special import roots_legendre
BASE=Path(__file__).resolve().parents[1]
def kernels(g):
 g=np.clip(g,0,1);h=1-g;sin=np.sqrt(h*(1+g));alpha=np.arctan2(sin,g)
 p=np.divide(2*alpha,sin,out=np.full_like(g,2.),where=sin>0)
 pd=np.divide(g*p-2,sin**2,out=np.zeros_like(g),where=sin>0)
 pd=np.where(h<1e-5,-2/3-(8/15)*h-(12/35)*h**2,pd)
 return alpha**2,p,pd
def integrate(s,t,axis,r,order):
 u,w=roots_legendre(order);u=(u+1)/2;w=w/2
 theta=u[:,None]*np.pi/2;phi=u[None,:]*np.pi/2
 a=np.array([1.,s*s,(s*t)**2])
 j,k=(axis+1)%3,(axis+2)%3
 if r:
  # f=sin(theta_full/2), signed mu integrates both hemispheres.
  f=u[:,None];mu=1-2*f*f;sin2=4*f*f*(1-f*f);weight=w[:,None]*w[None,:]*2*f
 else:
  mu=np.cos(theta);sin2=np.sin(theta)**2;weight=w[:,None]*w[None,:]*np.sin(theta)*np.pi/2
 y=sin2*np.cos(phi)**2;z=sin2*np.sin(phi)**2
 d=a[axis]*(mu-r)**2+a[j]*y+a[k]*z;B=mu**2/a[axis]+y/a[j]+z/a[k]
 h=1/np.sqrt(d*B);kb=(2*f*f if r else 1);g=kb*h
 F,P,Pd=kernels(g)
 l=a[axis]*(mu-r)/d
 d1=h*(-mu+kb*l)
 if r:integrand=-mu*F-kb*P*d1
 else:
  d2=h*(-2*mu*l+kb*(3*l*l-a[axis]/d))
  integrand=2*mu*P*d1-kb*(Pd*d1*d1+P*d2)
 return float(np.sum(integrand*weight))
def run():
 nodes={(int(q['i']),int(q['j'])):q for q in csv.DictReader((BASE/'out/nodes.csv').open())}
 endpoints=list(csv.DictReader((BASE/'out/endpoints.csv').open()))
 cases=[]
 for i in [0,48,96]:
  for j in [0,64,128]:
   s=(21+11*np.cos(i*np.pi/96))/10;t=(7+5*np.cos(j*np.pi/128))/2
   for a in range(3):
    v=nodes[i,j];cases.append(('node',s,t,a,0,float(v[f'h{a+1}lo']),float(v[f'h{a+1}hi'])))
 for mode,ts in [(0,[5917000,5919000]),(1,[2275000,2277000])]:
  for tn in ts:
   v=max([q for q in endpoints if q['s0']=='3200000' and int(q['mode'])==mode and int(q['t0'])==tn],key=lambda q:int(q['N']))
   cases.append(('right',3.2,tn/1e6,1,mode,float(v['lower']),float(v['upper'])))
 with (BASE/'out/spot.csv').open('w') as file:
  w=csv.writer(file);w.writerow('kind s t axis r N192 N384 lower upper inside'.split())
  for kind,s,t,a,r,lo,hi in cases:
   v192=integrate(s,t,a,r,192);v384=integrate(s,t,a,r,384)
   w.writerow([kind,s,t,a+1,r,v192,v384,lo,hi,int(lo<=v384<=hi)])
if __name__=='__main__':run()
