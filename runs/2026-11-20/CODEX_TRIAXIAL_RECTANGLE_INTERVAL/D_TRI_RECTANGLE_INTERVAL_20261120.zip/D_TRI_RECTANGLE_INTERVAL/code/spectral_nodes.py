from axcover import BASE,ct,csv,os,time,ProcessPoolExecutor
from itertools import product
lib=ct.CDLL(str(BASE/'code/spec.so'));lib.axis_setup()
lib.spectral_node.argtypes=[ct.c_int,ct.c_int,ct.POINTER(ct.c_double)]
def line(i):
 tic=time.process_time();rs=[]
 for j in range(129):
  v=(ct.c_double*6)();lib.spectral_node(i,j,v);rs.append([i,j,*v])
 return rs,time.process_time()-tic
def run():
 with (BASE/'out/nodes.csv').open('w') as f,(BASE/'out/nodes_time.csv').open('w') as g,ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','7'))) as pool:
  w=csv.writer(f);w.writerow('i j h1lo h1hi h2lo h2hi h3lo h3hi'.split());tw=csv.writer(g);tw.writerow(['i','cpu_s'])
  for i,(rows,t) in enumerate(pool.map(line,range(97))):w.writerows(rows);tw.writerow([i,t]);f.flush();g.flush()
if __name__=='__main__':run()
