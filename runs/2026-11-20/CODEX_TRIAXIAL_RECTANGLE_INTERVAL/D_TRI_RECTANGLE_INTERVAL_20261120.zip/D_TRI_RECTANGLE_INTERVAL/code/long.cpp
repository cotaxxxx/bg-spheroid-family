#include "hb.cpp"
// Long axis, normalized to length one. Positive H33 near the centre or E3/r elsewhere.
extern "C" void long_value(int mode,const int *ends,int n,double *out){
 I p[3];
 for(int i=0;i<3;i++)p[i]=I(rat(ends[2*i],5242880).l,rat(ends[2*i+1],5242880).h);
 I s=p[0],t=p[1],r=p[2],a=inv(sq(s*t)),b=inv(sq(t));
 I total=0; const auto &grid=nodes(n);
 for(auto &angle_cell:grid){
  I U=mix2(angle_cell.w,a,b),V=mix2(angle_cell.w,inv(a),inv(b)),row=0;
  for(auto &c:grid){
   I B=mix2(c.v,1,V),S=root(B),m=c.mu-r,d=sq(m)+c.v*U,k=clip(1-r*c.mu,0,2);
   if(d.l<=0){
    if(mode==0)std::abort();
    row=row+2*c.f*I(-1,1)*(8+4*S);continue;
   }
   I den=root(d),g=unit(k/(den*S)),u=clip(m/den,-1,1);
   I z=c.mu-g*S*u,z2=c.v*(r+c.mu*(U-1))/d;
   z=clip(z,z2.l,z2.h);I P=angle(g,1);
   if(mode==0){
    I proj=clip(c.v*U/d,0,1);
    I Q=2*P-g*angle(g,2);
    row=row+2*c.f*(P*sq(g)*B*proj-Q*sq(z))/(den*S);
   }else{
    row=row+2*c.f*(g*P*z-c.mu*angle(g,0));
   }
  }total=total+row;
 }
 total=total/I(n*n);if(mode==1)total=total/r;
 out[0]=total.l;out[1]=total.h;
}
