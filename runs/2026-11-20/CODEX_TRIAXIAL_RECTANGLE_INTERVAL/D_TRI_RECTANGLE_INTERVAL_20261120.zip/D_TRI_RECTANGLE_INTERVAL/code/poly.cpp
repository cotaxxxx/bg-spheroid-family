#include "spectral.cpp"
constexpr int nx=96,ny=128;
struct Term {int i,j;I v;};
static std::vector<Term> terms[3][3];
extern "C" void setpoly(const double* arr){
 for(int a=0;a<3;a++){
  I deriv[2][nx+1][ny+1]={};
  for(int i=0;i<=nx;i++)for(int j=0;j<=ny;j++){
   double v=arr[(a*(nx+1)+i)*(ny+1)+j];if(v==0)continue;
   terms[a][0].push_back({i,j,I(v)});
   for(int m=i-1;m>=0;m-=2)deriv[0][m][j]=deriv[0][m][j]+I(m?2*i:i)*v;
   for(int m=j-1;m>=0;m-=2)deriv[1][i][m]=deriv[1][i][m]+I(m?2*j:j)*v;
  }
  for(int d=0;d<2;d++)for(int i=0;i<=nx;i++)for(int j=0;j<=ny;j++){
   I v=deriv[d][i][j];if(v.l||v.h)terms[a][d+1].push_back({i,j,v});
  }
 }
}
extern "C" void nodecheck(const double* nod,double* out){
 std::vector<std::vector<I>> X(nx+1),Y(ny+1);
 for(int i=0;i<=nx;i++)for(int k=0;k<=nx;k++)X[i].push_back(cospi(i*k,nx));
 for(int j=0;j<=ny;j++)for(int k=0;k<=ny;k++)Y[j].push_back(cospi(j*k,ny));
 for(int a=0;a<3;a++){
  double maxerr=0;
  for(int i=0;i<=nx;i++)for(int j=0;j<=ny;j++){
   I v=0;for(auto c:terms[a][0])v=v+X[i][c.i]*Y[j][c.j]*c.v;
   int ix=2*((i*(ny+1)+j)*3+a);
   I e=v-I(nod[ix],nod[ix+1]);maxerr=std::max(maxerr,std::max(std::abs(e.l),std::abs(e.h)));
  }out[a]=maxerr;
 }
}
inline void basis(I x,I* table,int n){
 table[0]=1;table[1]=clip(x,-1,1);
 for(int k=2;k<=n;k++){
  int i=k/2;I v=(k%2)?2*table[i]*table[i+1]-x:2*sq(table[i])-1;
  table[k]=clip(v,-1,1);
 }
}
extern "C" void polyrange(int a,const int* box,const double* err,double* out){
 I x=(10*I(rat(box[0],5242880).l,rat(box[1],5242880).h)-21)/11;
 I y=(2*I(rat(box[2],5242880).l,rat(box[3],5242880).h)-7)/5;
 I X[nx+1],Y[ny+1];basis(x,X,nx);basis(y,Y,ny);
 for(int d=0;d<3;d++){
  I v=0;for(auto c:terms[a][d])v=v+c.v*X[c.i]*Y[c.j];
  v=v+I(-err[d],err[d]);
  if(d==1)v=v*rat(10,11);if(d==2)v=v*rat(2,5);
  out[2*d]=v.l;out[2*d+1]=v.h;
 }
}
