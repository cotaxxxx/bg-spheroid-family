from edge import *
def work(b):
 for n in (1024,2048):
  v=bound(0,0,b,n)
  if v[0]>0:break
 return ['floor',0,1,*b,0,n,*v,'positive' if v[0]>0 else 'open']
def run():
 with (BASE/'out/edge.csv').open() as f:
  data=list(csv.DictReader(f));head=list(data[0])
 args=[]
 for r in data:
  if r['kind']=='floor' and r['result']=='open':
   a,b,c,d,e,f=map(int,[r[k] for k in 's0 s1 t0 t1 r0 r1'.split()])
   args.extend((a,b,c+(d-c)*j//8,c+(d-c)*(j+1)//8,e,f) for j in range(8))
 with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','5'))) as pool:
  rows=list(pool.map(work,args))
 with (BASE/'out/floors.csv').open('w') as f:
  w=csv.writer(f);w.writerow(head);w.writerows(rows)
if __name__=='__main__':run()
