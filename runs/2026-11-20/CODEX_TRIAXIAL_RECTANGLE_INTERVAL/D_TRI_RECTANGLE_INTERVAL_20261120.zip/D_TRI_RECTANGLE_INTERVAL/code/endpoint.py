import runpy,csv
from pathlib import Path
from fractions import Fraction as F
from concurrent.futures import ProcessPoolExecutor
BASE=Path(__file__).resolve().parents[1]
mod=runpy.run_path(str(BASE/'code/cross.py'));evaluate=mod['evaluate']
def run():
 m,n=mod['M'];box=(m,m,n,n);rows=[]
 with ProcessPoolExecutor(max_workers=6) as pool:
  pts=[v for v,t in pool.map(evaluate,[(k,k,box,2048,0) for k in [0,1]])]
  rows+=pts
  for mode,ts in [(0,[5917000,5919000]),(1,[2275000,2277000])]:
   for it,t in enumerate(ts):
    b=(3200000,3200000,t,t)
    for N in [256,512,1024]:
     v,_=evaluate((mode,1,b,N,0));rows.append(v)
     if (v[-2]>0 if it==0 else v[-1]<0):break
 with (BASE/'out/endpoints.csv').open('w') as f:
  w=csv.writer(f);w.writerow('mode axis s0 s1 t0 t1 N derivative lower upper'.split());w.writerows(rows)
 with (BASE/'out/cross.csv').open() as f:
  j=[r for r in csv.DictReader(f) if r['derivative']!='0' and r['N']=='1024']
 Y=mod['Y'];plus=mod['add'];times=mod['imul']
 def product(a,b):
  v=[x*y for x in a for y in b];return min(v),max(v)
 def dec(x):return F(float(x))
 mid=[F(m,10**6),F(n,10**6)];R=[(-F(1,1000),F(1,1000))]*2
 shifts=[plus(times(-Y[i][0],mod['ii'](pts[0])),times(-Y[i][1],mod['ii'](pts[1]))) for i in range(2)]
 def cell(k):return dec(j[k]['lower']),dec(j[k]['upper'])
 E=[[plus((F(i==k),)*2,plus(times(-Y[i][0],cell(k)),times(-Y[i][1],cell(2+k)))) for k in range(2)] for i in range(2)]
 for _ in range(32):
  W=[plus(shifts[i],plus(product(E[i][0],R[0]),product(E[i][1],R[1]))) for i in range(2)]
  R=[(max(a,c),min(b,d)) for (a,b),(c,d) in zip(W,R)]
 def outer(z):return z.numerator//z.denominator
 with (BASE/'out/cross_refined.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['parameter','lo_integer','hi_integer','denominator'])
  for i in range(2):
   a,b=R[i];w.writerow(['st'[i],outer((a+mid[i])*10**12),-outer(-(b+mid[i])*10**12),10**12])
if __name__=='__main__':run()
