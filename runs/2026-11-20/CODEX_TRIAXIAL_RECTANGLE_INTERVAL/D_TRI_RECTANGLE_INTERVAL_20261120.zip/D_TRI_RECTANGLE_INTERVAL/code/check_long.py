"""Exact coverage of the long-axis tests and arithmetic behind the pole/centre estimates."""
import csv,runpy
from fractions import Fraction as Q
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
def run():
 m=runpy.run_path(str(BASE/'checker.py'));cover=m['cover'];coords=m['coords'];D=m['D'];R=m['R']
 ends=m['rows']('long_end');cover(R,[coords(x) for x in ends])
 assert all(x['axis']=='3' and float(x['lower'])>0.0000222 for x in ends)
 axis=m['rows']('long_axis')
 for row in axis:
  assert R[0]<=int(row['s0'])<int(row['s1'])<=R[1] and 0<=int(row['r0'])<int(row['r1'])<=D
  assert (row['result']=='positive')==(float(row['lower'])>0)
  assert (row['mode']=='0')==(int(row['r1'])<=D//4)
  if int(row['r1'])>11*D//16:assert int(row['r0'])>=11*D//16 and float(row['lower'])>0.0002149
 cuts=sorted({R[0],R[1]}|{int(x[k]) for x in axis for k in ('s0','s1')})
 for a,b in zip(cuts,cuts[1:]):
  cover((D,6*D,0,D),[coords(x,['t0','t1','r0','r1']) for x in axis if int(x['s0'])<=a<b<=int(x['s1'])])
 assert 20*Q(22,7)*(400+3*21**2)<110000
 assert Q(11,16)*Q(2149,10**7)-Q(110000,2**30)>0
 # Centre: analytic H33 along an arbitrary real direction.
 pi=Q(22,7);K=Q(96,5)
 a=K/128
 assert Q(122,100)**2*(1-2*a-a*a)>1
 assert Q(22,100)+Q(122,100)/128<Q(23,100)
 assert (1+a)*Q(122,100)<Q(141,100)
 assert pi/Q(77,100)<Q(41,10) and pi/Q(77,100)**2<Q(54,10)
 bb=28;gab=Q(123,100);p=Q(41,10);dp=Q(54,10)
 assert Q(122,100)*(p*gab**2*(400+bb**2)+(2*p+gab*dp)*(1+gab*bb)**2)<40000
 x=Q(128,2**16);assert Q(6714,10000)-40000*x*x/(1-x*x)>Q(51,100)
 # Centre: two-coordinate Cauchy bound for T12/(q1 q2) on the equator.
 a=K*Q(99,70)/128
 assert a<Q(213,1000) and Q(138,100)**2*(1-2*a-a*a)>1
 assert Q(38,100)+Q(138,100)*Q(99,70)/128<Q(4,10)
 assert (1+a)*Q(138,100)<Q(168,100)
 assert (1+Q(99,70)/128)*(pi/Q(6,10))*Q(14,10)*(Q(168,100)**2+1)<30
 x=Q(128,2**20);err=30*128**2*((1-x*x)**(-2)-1)
 assert Q(1,32)-err>Q(16,1000)
if __name__=='__main__':run()
