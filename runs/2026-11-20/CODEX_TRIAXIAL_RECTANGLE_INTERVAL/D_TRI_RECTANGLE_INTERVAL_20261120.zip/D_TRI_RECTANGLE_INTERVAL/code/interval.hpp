// DIAGNOSTIC_ONLY / NOT_EVIDENCE. Binary64 outward symmetric inflation.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <limits>
struct I {double l,h; I(double x=0):l(x),h(x){} I(double a,double b):l(a),h(b){}};
inline double pad(double x){return 0x1p-51*std::abs(x)+0x1p-1022;}
inline I wide(double a,double b){return {a-pad(a),b+pad(b)};}
inline I operator+(I a,I b){return wide(a.l+b.l,a.h+b.h);}
inline I operator-(I a,I b){return wide(a.l-b.h,a.h-b.l);}
inline I operator-(I a){return {-a.h,-a.l};}
inline I operator*(I a,I b){
 double p=a.l*b.l,q=a.l*b.h,r=a.h*b.l,s=a.h*b.h;
 return wide(std::min(std::min(p,q),std::min(r,s)),std::max(std::max(p,q),std::max(r,s)));
}
inline I inv(I a){if(!(a.l>0))std::abort();return wide(1/a.h,1/a.l);}
inline I operator/(I a,I b){return a*inv(b);}
inline I sq(I a){double x=a.l*a.l,y=a.h*a.h;return wide(a.l*a.h<=0?0:std::min(x,y),std::max(x,y));}
inline I root(I a){return wide(std::sqrt(std::max(0.,a.l)),std::sqrt(std::max(0.,a.h)));}
inline I clip(I a,double l,double h){a={std::max(l,a.l),std::min(h,a.h)};if(!(a.l<=a.h))std::abort();return a;}
constexpr int K=16384;
// Downward/upward values at the dyadic arguments, for F and |P^(m)| (m=0,1,2).
static I tab[4][K+1];
extern "C" inline void not_used(){}
inline void init_tables(){
 I p[101];p[0]=2;
 for(int j=1;j<=100;j++)p[j]=p[j-1]*I(j)/I(2*j+1);
 for(int k=0;k<=K;k++){
  I d=1.-double(k)/K;
  I f=0,a=0,b=0,c=0;
  for(int j=100;j>=0;j--){
   f=f*d+p[j]/I(j+1);a=a*d+p[j];
   if(j>=1)b=b*d+p[j]*I(j);
   if(j>=2)c=c*d+p[j]*I(j*(j-1));
  }
  I tail(0,0x1p-75);
  tab[0][k]=f*d+tail;tab[1][k]=a+tail;tab[2][k]=b+tail;tab[3][k]=c+tail;
 }
}
inline I angle(I g,int j){
 int i=int(std::floor(g.l*K)),k=int(std::ceil(g.h*K));
 return {tab[j][k].l,tab[j][i].h};
}
inline I unit(I g){return clip(g,0,1);}
static const I pi(0x1.921fb54442d17p+1,0x1.921fb54442d19p+1);
inline I rat(int a,int b){return I(a)/I(b);}
