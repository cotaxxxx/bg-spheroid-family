from axcover import BASE,D,ct,csv,time,os,bound
from pathlib import Path
import numpy as np
from fractions import Fraction as F
from scipy.fft import dctn
import math
lib=ct.CDLL(str(BASE/'code/poly.so'))
arrtype=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
lib.setpoly.argtypes=[arrtype];lib.nodecheck.argtypes=[arrtype,arrtype]
lib.polyrange.argtypes=[ct.c_int,ct.POINTER(ct.c_int),arrtype,arrtype]
NX,NY=96,128
def moments(z,n):
 k=n+1;b=1-z
 return z**k/b,z**k*(k*k/b+2*k*z/b**2+z*(1+z)/b**3)
def prep(make):
 d=np.loadtxt(BASE/'out/nodes.csv',delimiter=',',skiprows=1).reshape(97,129,8)
 ii,jj=np.indices((97,129));assert (ii==d[:,:,0]).all() and (jj==d[:,:,1]).all()
 data=np.ascontiguousarray(d[:,:,2:].reshape(97,129,3,2))
 assert np.isfinite(data).all() and np.all(data[:,:,:,0]<=data[:,:,:,1])
 pth=BASE/'out/polycoef.csv'
 p=np.zeros((3,97,129))
 if make:
  with pth.open('w') as f:
   w=csv.writer(f);w.writerow(['axis','i','j','coefficient_hex'])
   for a in range(3):
    c=dctn(data[:,:,a,:].mean(2),type=1)/(NX*NY)
    c[[0,-1],:]*=.5;c[:,[0,-1]]*=.5;c[abs(c)<2e-13]=0;p[a]=c
    for i,j in zip(*np.nonzero(c)):w.writerow([a+1,i,j,float(c[i,j]).hex()])
 else:
  with pth.open() as f:
   for v in csv.DictReader(f):p[int(v['axis'])-1,int(v['i']),int(v['j'])]=float.fromhex(v['coefficient_hex'])
 lib.setpoly(p);deltas=np.empty(3);lib.nodecheck(data,deltas)
 xl,x2=moments(F(20,33),NX);yl,y2=moments(F(5,7),NY)
 xs,xx=moments(F(20,33),-1);ys,yy=moments(F(5,7),-1)
 M=10**8
 tails=[8*M*(xl*ys+xs*yl),8*M*(x2*ys+xx*yl),8*M*(xl*yy+xs*y2)]
 errs=np.zeros((3,3))
 for a in range(3):
  for j,mark in enumerate([1,NX**2,NY**2]):
   val=tails[j]+224*mark*F(deltas[a])
   errs[a,j]=np.nextafter(float(val),np.inf)
 return errs,deltas
def enclosure(a,box,errs):
 r=np.empty(6);lib.polyrange(a,(ct.c_int*4)(*box),errs[a],r);return list(r)
def split(box):
 a,b,c,d=box
 if (b-a)*50>=(d-c)*22:
  m=(a+b)//2;return (a,m,c,d),(m,b,c,d)
 m=(c+d)//2;return (a,b,c,m),(a,b,m,d)
def cover(errs):
 rows=[]
 for surface in ['R','top','bottom','left','right']:
  for ax in ([0,1,2] if surface=='R' else [0,1]):
   # Right-side traces may have roots in t; same downward criterion as interior.
   root={'R':(D,16*D//5,D,6*D),'top':(D,16*D//5,6*D,6*D),'bottom':(D,16*D//5,D,D),'left':(D,D,D,6*D),'right':(16*D//5,16*D//5,D,6*D)}[surface]
   stack=[(root,0)]
   while stack:
    box,dep=stack.pop();lo,hi,ds0,ds1,dt0,dt1=enclosure(ax,box,errs)
    if lo>0:st='positive'
    elif hi<0:st='negative'
    elif surface in ('R','left','right') and ax<2 and dt1<0:st='down_t'
    elif surface=='bottom' and ax==0 and ds1<0:st='down_s'
    else:st='open'
    if st=='open' and dep<22:
     stack.extend((v,dep+1) for v in split(box));continue
    rows.append([surface,ax+1,*box,dep,lo,hi,ds0,ds1,dt0,dt1,st])
 return rows
def run():
 errs,d=prep(True)
 with (BASE/'out/poly_errors.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['axis','max_node_resid','value_error','dx_error','dy_error'])
  for a in range(3):w.writerow([a+1,d[a],*errs[a]])
 rows=cover(errs)
 with (BASE/'out/central.csv').open('w') as f:
  w=csv.writer(f);w.writerow('surface axis s0 s1 t0 t1 depth lower upper dslo dshi dtlo dthi result'.split());w.writerows(rows)
if __name__=='__main__':run()
