#include "interval.hpp"
#include <array>
#include <vector>
using V=std::array<I,3>;
extern "C" void setup(){init_tables();}
const int DEN=5242880;
struct Dir {I sn,cs,d;};
inline Dir direction(int j,int n){
 I x(double(j)/n,double(j+1)/n); // n power of two
 I den=1+sq(x);return {unit(2*x/den),unit((1-sq(x))/den),den};
}
extern "C" void enclosure(int mode,const int* ends,int n,double* answer){
 I arg[5];
 for(int i=0;i<5;i++)arg[i]={rat(ends[2*i],DEN).l,rat(ends[2*i+1],DEN).h};
 I s=arg[0],t=arg[1];V a={1,s,s*t},q={arg[2],arg[3],arg[4]};
 V A={1,sq(a[1]),sq(a[2])},invA={1,inv(A[1]),inv(A[2])};
 std::vector<Dir> dirs;for(int j=0;j<n;j++)dirs.push_back(direction(j,n));
 I total=0;
 for(auto y:dirs){
  I subtotal=0;
  for(auto w:dirs){
   V dir={y.sn*w.cs,y.sn*w.sn,y.cs};
   I B=clip(sq(dir[0])+sq(dir[1])*invA[1]+sq(dir[2])*invA[2],invA[2].l,1.);
   I S=root(B),sum=0;I weight=y.sn/(pi*y.d*w.d);
   for(int sig=0;sig<8;sig++){
    V xi,v;I k=1,D2=0;
    for(int j=0;j<3;j++){xi[j]=(sig&(1<<j))?-dir[j]:dir[j];v[j]=xi[j]-q[j];D2=D2+A[j]*sq(v[j]);k=k-q[j]*xi[j];}
    k=clip(k,0,2);I F;
    if(D2.l<=0){
      if(mode==1){F=I(-12,12)*a[2]+I(-8,8);}
      else if(mode==2){F=I(-16,16);}
      else std::abort();
    }else{
      I D=root(D2),g=unit(k/(D*S)),P=angle(g,1);
      if(mode==2){
       I u1=clip(v[0]/D,-1,1),u2=clip(a[1]*v[1]/D,-1,1);
       I n1=clip(xi[0]/S,-1,1),n2=clip(xi[1]/(a[1]*S),-1,1);
       F=k*P*g*(u1*u2-n1*n2);
      }else{
       I u=clip(a[2]*v[2]/D,-1,1),b=a[2]*u;
       if(mode==1)F=xi[2]*(g*P-angle(g,0))-b*S*sq(g)*P;
       else{
        I Q=2*P-g*angle(g,2),z=xi[2]-g*S*b;
        // The two expressions for the projection are identical.
        I proj=A[2]*clip(1-sq(u),0,1);
        I alt=A[2]*(sq(v[0])+A[1]*sq(v[1]))/D2;
        proj=clip(proj,alt.l,alt.h);
        F=(P*sq(g)*B*proj-Q*sq(z))/(D*S);
       }
      }
    }
    sum=sum+F;
   }
   subtotal=subtotal+weight*sum;
  }
  total=total+subtotal;
 }
 total=total/I(n*n);
 if(mode==1)total=total/q[2];
 if(mode==2)total=total/(q[0]*q[1]);
 answer[0]=total.l;answer[1]=total.h;
}
