"""Structural checker of sign claims and exact rectangular partitions. No third-party imports."""
import csv
import hashlib
import math
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
D = 5242880
R = (D, 16*D//5, D, 6*D)
SURF = dict(R=R, bottom=(*R[:2],D,D), top=(*R[:2],6*D,6*D),
            left=(D,D,*R[2:]), right=(R[1],R[1],*R[2:]))

def rows(name):
    with (ROOT / 'out' / (name+'.csv')).open() as stream:
        return list(csv.DictReader(stream))

def coords(row, names=('s0','s1','t0','t1')):
    return tuple(int(row[k]) for k in names)

def groups(data, keys):
    result = defaultdict(list)
    for row in data:
        result[tuple(row[k] for k in keys)].append(row)
    return result

def cover(region, pieces):
    """Each open slab must be covered exactly once. Closed leaves include their shared faces."""
    assert pieces
    lo,hi,b,t = region
    for a,c,d,e in pieces:
        assert lo<=a<=c<=hi and b<=d<=e<=t
        assert (a<c)==(lo<hi) and (d<e)==(b<t)
    xs = sorted({lo,hi} | {x for p in pieces for x in p[:2]})
    for left,right in list(zip(xs,xs[1:])) or [(lo,hi)]:
        intervals = sorted((d,e) for a,c,d,e in pieces if a<=left and right<=c)
        assert intervals and intervals[0][0]==b and intervals[-1][1]==t
        assert all(p[1]==q[0] for p,q in zip(intervals,intervals[1:]))
        if b==t: assert len(intervals)==1

def signs(data):
    for row in data:
        lo,hi=map(float,(row['lower'],row['upper']))
        assert math.isfinite(lo) and math.isfinite(hi) and lo<=hi
        st=row['result']
        if st=='positive': assert lo>0
        elif st=='negative': assert hi<0
        elif st in ('down','down_t','down_s'):
            k={'down':'dhi','down_t':'dthi','down_s':'dshi'}[st]
            assert float(row[k])<0
        else: raise ValueError(st)

def main():
    for line in (ROOT/'SCIENCE.sha256').read_text().splitlines():
        digest,p=line.split(None,1)
        assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==digest
    h=rows('central')
    signs(h)
    cent=groups(h,['surface','axis'])
    for surface,box in SURF.items():
        for i in ('1','2','3') if surface=='R' else ('1','2'):
            cover(box,[coords(x) for x in cent[surface,i]])
    assert min(float(x['lower']) for x in cent['R','3'])>0.6714
    b=[x for x in rows('axis_cover') if x['mode']=='1' and x['result']!='open']+rows('bfinish')
    signs(b)
    bs=groups(b,['surface','axis'])
    for surface in ('R','top','bottom'):
        for i in ('1','2'): cover(SURF[surface],[coords(x) for x in bs[surface,i]])
    for data in (bs,cent):
        for i in ('1','2'): assert all(x['result']=='negative' for x in data['top',i])
        assert all(x['result']=='positive' for x in data['bottom','2'])
    topo=groups(rows('topology'),['mode'])
    for kind,axis in [('cross','2'),('b2_h2','2'),('b1_h1','1'),('b1_b2','1'),('centre_gap',None)]:
        data=topo[kind,]
        allowed={'cross':{'negative_h','positive_h','b_nonzero','positive_det'},
                 'b2_h2':{'positive_h','b_nonzero'},'b1_h1':{'positive_h','b_nonzero'},
                 'b1_b2':{'b2_positive','b_nonzero','ordered_from_edge'},
                 'centre_gap':{'gap','gap_from_edge'}}[kind]
        assert all(x['result'] in allowed and float(x['margin'])>0 for x in data)
        parents={coords(x) for x in bs['R',axis] if x['result']=='down'} if axis else {R}
        children=defaultdict(list)
        for x in data:children[coords(x,['parent_'+k for k in ('s0','s1','t0','t1')])].append(coords(x))
        assert parents==children.keys()
        for p in parents:cover(p,children[p])
    for i,line in enumerate((ROOT/'out/kraw.txt').read_text().splitlines()):
        l,h,n=map(Fraction,line.split());m=Fraction([1566969,2296586][i],1000000)
        assert n<Fraction(3,5) and m-Fraction(1,1000)<l<h<m+Fraction(1,1000)
    d=rows('disk');signs(d)
    for kind,lo,hi,threshold in [('tau2',0,3*D//8,.0012),('tau',3*D//8,D,.00018)]:
        xs=[x for x in d if x['mode']==kind]
        cover((2*D,5*D,lo,hi),[coords(x,['t0','t1','r0','r1']) for x in xs])
        assert all(float(x['lower'])>threshold for x in xs)
    for axis in ('1','2'):
        xs=[x for x in rows('substrip') if x['axis']==axis]
        assert all(coords(x,['s0','s1'])==(D,D+1) for x in xs)
        cover((2*D,7*D//2,0,D),[coords(x,['t0','t1','r0','r1']) for x in xs])
        centband=groups([x for x in xs if x['mode']=='0'],['t0','t1'])
        for band in centband.values():assert len({x['result'] for x in band})==1
        for x in xs:
            st=x['result']
            if st in ('Hpos','Upos'): assert float(x['altlo'])>0
            elif st in ('Hneg','Uneg'):assert float(x['althi'])<0
            elif st in ('fourth','slope'):assert float(x['upper'])<0
            else: raise ValueError(st)
        tile=[x for x in rows('hb')+rows('bridge') if x['axis']==axis and x['kind']=='tile']
        for mode,lo,hi in [('0',0,21*D//64),('1',21*D//64,D)]:
            intervals=[(max(int(x['r0']),lo),min(int(x['r1']),hi)) for x in tile if x['mode']==mode and float(x['upper'])<0]
            cover((0,0,lo,hi),[(0,0,a,b) for a,b in intervals if a<b])
    census=groups(rows('census'),['mode','axis','t0'])
    for axis in ('1','2'):
        for m,t,sign in [(1,17*D//8,-1),(0,9*D//2,1),(1,2*D,1),(0,5*D,-1)]:
            data=census[str(m),axis,str(t)]
            assert all(coords(r,['s0','s1','t0','t1'])==(D,D+1,t,t) for r in data)
            assert any((float(r['lower'])>0 if sign==1 else float(r['upper'])<0) for r in data)
    transfer=rows('transfer')
    cover((2*2**20,5*2**20,0,2**20),[coords(x,['t0','t1','r0','r1']) for x in transfer])
    assert all(Fraction(x['edge_margin'])-Fraction(x['error'])==Fraction(x['remaining'])>0 for x in transfer)
    grid=rows('nodes')
    assert len(grid)==97*129 and len({coords(x,['i','j']) for x in grid})==len(grid)
    assert all(float(x[f'h{i}lo'])<=float(x[f'h{i}hi']) for x in grid for i in (1,2,3))
    for p in ('oct','disk'):
        assert len({coords(x,['sidx','tidx']) for x in rows('cal') if x['patch']==p and x['result']=='positive' and float(x['lower'])>0})==32
    import runpy
    runpy.run_path(str(ROOT/'code/check_constants.py'))['verify']()
    runpy.run_path(str(ROOT/'code/check_cross.py'))['run']()
    print('Exact tilings, endpoint orderings, sign margins and science hashes checked.')

if __name__=='__main__':
    if not __debug__: raise RuntimeError('Use ordinary Python, without -O')
    main()
