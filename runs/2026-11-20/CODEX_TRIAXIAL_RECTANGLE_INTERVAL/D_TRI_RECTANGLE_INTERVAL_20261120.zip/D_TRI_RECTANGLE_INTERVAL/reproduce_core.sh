#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export JOBS="${JOBS:-7}"
if [[ "${1:-}" == "--check" ]]; then exec python3 checker.py; fi
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
cp -r code "$tmp/code"
mkdir -p "$tmp/inputs"
cp -r inputs/v50 "$tmp/inputs/v50"
cp inputs/v55_*.csv "$tmp/inputs/"
find "$tmp/code" -name '*.so' -delete
mkdir "$tmp/out"
base=$PWD
cd "$tmp"
opts=(-O3 -std=c++17 -shared -fPIC -fno-fast-math -ffp-contract=off)
for pair in cal:bound axis:axis cross:cross profiles:profiles edgedisk:disk rim:rim hb:hb spectral:spec poly:poly; do
 g++ "${opts[@]}" "code/${pair%:*}.cpp" -o "code/${pair#*:}.so"
done
gcc -O3 -fPIC -shared code/atlas/kernel.c -lm -o code/atlas/kernel.so
for script in scout calibrate axcover bfinish cross edge floors disk rim hb bridge spectral_nodes polycover topology substrip endpoint_r2 transfer census; do
 echo "Computing $script"
 python3 "code/$script.py"
done
cd "$base"
python3 checker.py
while read -r checksum name; do
 old="${name#out/}"
 [[ -f "$tmp/out/$old" ]]
 cmp -- "$name" "$tmp/out/$old"
done < SCIENCE.sha256
python3 "$tmp/code/spot.py"
cmp out/spot.csv "$tmp/out/spot.csv"
python3 "$tmp/code/figure.py"
cmp RECTANGLE_MAP.png "$tmp/RECTANGLE_MAP.png"
echo 'Scientific ledgers and figure reproduced byte for byte.'
