#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "${1:-}" == "--check" ]]; then
    ./reproduce_core.sh --check
    sha256sum --quiet -c LONG_SCIENCE.sha256
    exec python3 code/check_long.py
fi
./reproduce_core.sh
./reproduce_long.sh
