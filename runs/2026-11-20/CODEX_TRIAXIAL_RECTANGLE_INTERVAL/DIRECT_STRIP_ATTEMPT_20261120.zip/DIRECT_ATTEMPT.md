# 直接法による全幅の試行

2026-11-20　DIAGNOSTIC_ONLY / NOT_EVIDENCE

初期計画 STRIP_PLAN.md を完走した生の記録。形は 1≤s≤1+1/5242880、2≤t≤5。両軸、全半径を含む192組の形状帯を計算した。最終葉は29178件、open は13376件。合計14456.7 CPU秒。各軸について整数座標で領域をちょうど覆うこと、帯別の葉数の総和を別に検査した。open は包囲幅のため符号を確定していない行である。

この台帳は主報告に先に記載した高次数の試行の全出力を補う。広い形状帯の全域に根の一意性を主張する資料の用途はない。主報告の狭い明示帯全体に対する根数は V50 の194移送箱、2≤t≤7/2 の広い方の帯の軸上根数は6050箱の別台帳に基づく。

元の証明 ZIP の code/strip.py と STRIP_PLAN.md を用いる。下のコマンドは元ZIPを展開した D_TRI_RECTANGLE_INTERVAL ディレクトリで実行する。出力は out/strip.csv、out/strip_time.csv。計時値は再現比較から外す。

```sh
g++ -std=c++17 -O3 -fPIC -shared -fno-fast-math -ffp-contract=off code/axis.cpp -o code/axis.so
g++ -std=c++17 -O3 -fPIC -shared -fno-fast-math -ffp-contract=off code/hb.cpp -o code/hb.so
OPENBLAS_NUM_THREADS=1 JOBS=7 python3 code/strip.py
```

処理別件数

- Hpos　2080
- Uneg　90
- Upos　4310
- open　13376
- slope　9322
