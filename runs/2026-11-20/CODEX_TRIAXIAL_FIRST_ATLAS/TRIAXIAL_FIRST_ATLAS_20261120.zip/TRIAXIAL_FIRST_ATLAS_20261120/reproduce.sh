#!/usr/bin/env bash
set -euo pipefail
base=$(cd -- "$(dirname -- "$0")" && pwd)
dest=$(mktemp -d "${TMPDIR:-/tmp}/triaxial-replay.XXXXXX")
echo "Replay directory: $dest"
cd "$base"
if test -f MANIFEST.sha256; then sha256sum --quiet -c MANIFEST.sha256; fi
for pin in PLAN*.sha256 *_CODE.sha256; do sha256sum --quiet -c "$pin"; done
mkdir -p "$dest/code" "$dest/out"
cp code/*.py code/kernel.c "$dest/code/"
cd "$dest"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLBACKEND=Agg
gcc -std=c99 -O3 -shared -fPIC code/kernel.c -lm -o code/kernel.so
for step in map mixed refine checks torque reversal ring_interval moving_boundary normal figure; do
  start=$SECONDS
  python3 "code/$step.py"
  echo "$step $((SECONDS-start)) seconds"
done
for expected in "$base"/out/*.csv; do
  cmp "$expected" "out/$(basename "$expected")"
done
echo "All reference CSV bytes reproduced on this host. Figure: $dest/out/TRIAXIAL_MAP.png"
