// DIAGNOSTIC_ONLY / NOT_EVIDENCE. Coordinates and derivatives in reference ball.
// nodes[] are the base sphere nodes in a frame with north pole q/|q|.
#include <math.h>
#include <stddef.h>
void evaluate(int count,const double *nodes,const double *weight,const double *q,
              const double *a,int with_h,double *out){
    double r=hypot(hypot(q[0],q[1]),q[2]);
    double north[3]={0,0,1}, east[3]={1,0,0}, side[3]={0,1,0};
    if(r>0){
        for(int j=0;j<3;j++) north[j]=q[j]/r;
        double rho=hypot(north[0],north[1]);
        if(rho>0){
            east[0]=-north[1]/rho; east[1]=north[0]/rho;
        }
        for(int j=0;j<3;j++) side[j]=north[(j+1)%3]*east[(j+2)%3]-north[(j+2)%3]*east[(j+1)%3];
    }
    for(int j=0;j<13;j++) out[j]=0;
    for(int m=0;m<count;m++){
        const double *node=nodes+3*m;
        double xi[3],v[3],b[3],z[3],D2=0,S2=0;
        for(int j=0;j<3;j++){
            xi[j]=east[j]*node[0]+side[j]*node[1]+north[j]*node[2];
            v[j]=a[j]*(xi[j]-q[j]);
            D2+=v[j]*v[j]; S2+=(xi[j]/a[j])*(xi[j]/a[j]);
        }
        double D=sqrt(D2),S=sqrt(S2), k=(1-r)+r*(1-node[2]);
        double g=fmin(1.,fmax(0.,k/(D*S))), ang=acos(g), d=1-g;
        double P,Q;
        if(d<1e-5){
            P=2+d*(2./3+d*(4./15+d*4./35));
            Q=2*P-g*(2./3+d*(8./15+d*12./35));
        }else{
            double sine2=(1-g)*(1+g);
            P=2*ang/sqrt(sine2);
            Q=2*P+g*(g*P-2)/sine2;
        }
        double w=weight[m], J=g*P-ang*ang;
        out[0]+=w*k*ang*ang;
        for(int j=0;j<3;j++){
            b[j]=a[j]*v[j]/D;
            z[j]=xi[j]-g*S*b[j];
            out[j+1]+=w*(xi[j]*J-b[j]*S*g*g*P);
        }
        if(with_h){
            for(int j=0;j<3;j++) for(int l=j;l<3;l++){
                double h=(P*g*g*S*S*((j==l?a[j]*a[j]:0)-b[j]*b[l])-Q*z[j]*z[l])/(D*S);
                out[4+3*j+l]+=w*h;
            }
        }
    }
    for(int j=0;j<3;j++) for(int l=0;l<j;l++) out[4+3*j+l]=out[4+3*l+j];
}
