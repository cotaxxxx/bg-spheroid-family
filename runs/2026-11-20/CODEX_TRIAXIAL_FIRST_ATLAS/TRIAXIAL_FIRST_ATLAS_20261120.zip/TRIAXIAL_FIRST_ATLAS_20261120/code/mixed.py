from common import *
import itertools
from concurrent.futures import ProcessPoolExecutor
from scipy.optimize import least_squares
from functools import lru_cache
import os
strata=[(0,1),(0,2),(1,2),(0,1,2)]
def point(y,ids,bound):
    r=1 if bound else y[0]
    ang=y if bound else y[1:]
    c,d=np.cos(ang[0]),np.sin(ang[0])
    if len(ids)==2:
        u=np.array([c,d]); directions=[np.array([-d,c])]
    else:
        e,f=np.cos(ang[1]),np.sin(ang[1])
        u=np.array([c*e,c*f,d]); directions=[np.array([-d*e,-d*f,c]),np.array([-c*f,c*e,0.])]
    q=np.zeros(3); q[list(ids)]=r*u
    return q,np.column_stack(([] if bound else [u])+[r*v for v in directions])
def solve(s,t,ids,bound,y,n=20):
    ids=list(ids)
    @lru_cache(maxsize=1)
    def fun(yt):
        q,dy=point(yt,ids,bound)
        _,g,H=ev(s,t,q,n)
        u=q[ids]; G=g[ids]/u
        jac=((H[np.ix_(ids,ids)]-np.diag(G))/u[:,None])@dy
        return G,jac
    lo=([.01] if not bound else [])+[.012]*(len(ids)-1)
    hi=([.99998] if not bound else [])+[np.pi/2-.012]*(len(ids)-1)
    res=least_squares(lambda y:fun(tuple(y))[0],y,jac=lambda y:fun(tuple(y))[1],bounds=(lo,hi),
                      max_nfev=22,gtol=1e-9,ftol=1e-10,xtol=1e-10)
    q,_=point(res.x,ids,bound)
    err=max(abs(res.fun))
    check=max(abs(ev(s,t,q,40)[1][ids]/q[ids])) if err<1e-3 else np.nan
    return [*q,err,check,res.status,res.nfev]
def task(arg):
    s,t,bound=arg; rows=[]
    for ids in strata:
        for r in ([1.] if bound else [.35,.75,.94]):
            for i,(ang,beta) in enumerate([(.43,.82),(1.05,.44)]):
                seed=([] if bound else [r])+[ang]+([beta] if len(ids)==3 else [])
                rows.append([s,t,int(bound),''.join(str(j+1) for j in ids),r,i,*solve(s,t,ids,bound,seed)])
    return rows
def run():
    args=[(s,t,False) for s in S[1:] for t in T[1:]]
    args.extend((s,t,True) for s,t in itertools.product([1.02,1.25,1.65,2.45,3.2],[1.02,2.15,3,4.72,6]))
    cr=np.genfromtxt(OUT/'curves.csv',delimiter=',',names=True,dtype=None,encoding='utf8')
    args.extend((float(v['s']),float(v['t']),True) for v in cr if v['fixed']=='s' and v['mode']=='b' and v['s'] in [1.02,1.25,1.65,2.45] and np.isfinite(v['t']))
    with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','5'))) as pool:
        rows=list(itertools.chain.from_iterable(pool.map(task,args)))
    write('mixed','s t boundary stratum seed_radius seed_direction q1 q2 q3 max_G20 max_G40_if_small solver_status nfev',rows)
if __name__=='__main__':run()
