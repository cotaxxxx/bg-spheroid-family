from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
def run():
    curves=pd.read_csv(OUT/'sections.csv').query('n==96')
    extra=pd.read_csv(OUT/'special.csv').query('n==96')
    a=pd.read_csv(OUT/'shape_refined.csv').query('n==64 & s>1 & t>1')
    branches=pd.read_csv(OUT/'axis_refined.csv').query('n==64 & t==3')
    plt.rcParams.update({'font.family':['DejaVu Sans'],'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(12.6,6.2),layout='constrained')
    grid=fig.add_gridspec(2,2,width_ratios=[1.6,1])
    phase=fig.add_subplot(grid[:,0]); tail=fig.add_subplot(grid[0,1]); split=fig.add_subplot(grid[1,1])
    palette={1:'#165a90',2:'#b55422'}
    markers=['.','o','s','D']
    for mask,label in enumerate(['Centre only','Short pair','Middle pair','Both pairs']):
        m=((a.h1>0)&(a.b1<0)).astype(int)+2*((a.h2>0)&(a.b2<0)).astype(int)
        sel=a[m==mask]
        phase.scatter(sel.s,sel.t,s=19,c='#737e85',marker=markers[mask],alpha=.72,label=label)
    for (i,mode),df in curves.groupby(['axis','mode']):
        x=list(df.s);y=list(df.t)
        if i==1:
            x.append(float(extra.loc[extra.event=='ob_'+mode+'1','s'].iloc[0])); y.append(1.)
        line='-' if mode=='h' else '--'
        phase.plot(x,y,line,c=palette[i],lw=2.2,label=('Short' if i==1 else 'Middle')+(' centre' if mode=='h' else ' boundary'))
        if i==2:tail.plot(x,y,line,c=palette[i],lw=2,marker='.',ms=4)
    c=extra[extra.event=='h1_b2'].iloc[0]
    phase.scatter(c.s,c.t,facecolors='white',edgecolors='#232b33',s=65,marker='o',zorder=5)
    phase.annotate('centre / boundary crossing',(c.s,c.t),xytext=(1.84,3.25),fontsize=9,arrowprops={'arrowstyle':'->','color':'#485962'})
    phase.legend(loc='upper center',bbox_to_anchor=(.5,-.12),ncol=4,fontsize=8,frameon=False,columnspacing=1)
    phase.set(xlabel='s = middle / short',ylabel='t = long / middle',xlim=(.98,3.25),ylim=(.94,6.15),title='Critical curves and sampled interior axis pairs')
    tail.set(xscale='log',xlabel='s  (log scale)',ylabel='critical t',title='Middle-axis thresholds at larger s',xticks=[1,2,4,8,16,32],xticklabels=['1','2','4','8','16','32'])
    for i,df in branches.groupby('axis'):
        split.plot(df.s,df.r96,color=palette[i],marker='o',ms=4,label='Short' if i==1 else 'Middle')
    split.scatter([1],[branches.r96.iloc[0]],marker='o',color='#262b2d',zorder=5)
    split.set(xlabel='s = middle / short',ylabel='radius r',ylim=(0,1),title='Stationary radii along t = 3')
    split.legend(frameon=False,fontsize=8)
    for ax in [phase,tail,split]:ax.grid(alpha=.17)
    fig.suptitle('Volume-preserving triaxial ellipsoids  |  First numerical atlas',weight='bold')
    fig.savefig(OUT/'TRIAXIAL_MAP.png',dpi=175)
if __name__=='__main__':run()
