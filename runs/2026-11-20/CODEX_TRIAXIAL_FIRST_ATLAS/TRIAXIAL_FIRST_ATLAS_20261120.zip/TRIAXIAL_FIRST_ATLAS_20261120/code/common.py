"""DIAGNOSTIC_ONLY / NOT_EVIDENCE."""
import ctypes as ct
from functools import lru_cache
from pathlib import Path
import csv
import numpy as np
from scipy.special import roots_legendre
from scipy.optimize import brentq
HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'out'
LIB=ct.CDLL(str(HERE/'kernel.so'))
p=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
LIB.evaluate.argtypes=[ct.c_int,p,p,p,p,ct.c_int,p]
LIB.evaluate.restype=None
S=[1,1.02,1.1,1.25,1.45,1.55,1.65,1.85,2.05,2.3,2.45,2.6,3.2]
T=[1,1.02,1.25,1.6,2,2.065,2.15,2.5,3,3.8,4.5,4.72,4.9,5.5,6]
R=[0,.12,.25,.4,.55,.7,.82,.91,.97,.99,1]
I=np.eye(3)
@lru_cache(None)
def nodes(n):
    x,w=roots_legendre(n)
    x=(1+x)/2
    phi=(np.arange(4*n)+.5)*2*np.pi/(4*n)
    mu=1-2*x*x
    sin=2*x*np.sqrt(1-x*x)
    xyz=np.stack(np.broadcast_arrays(sin[:,None]*np.cos(phi),sin[:,None]*np.sin(phi),mu[:,None]),axis=-1)
    return np.ascontiguousarray(xyz.reshape(-1,3)),np.repeat(x*w/(4*n),4*n)
def ev(s,t,q,n=40,h=True):
    pts,w=nodes(n)
    out=np.empty(13)
    LIB.evaluate(len(w),pts,w,np.ascontiguousarray(q,dtype=float),np.array([1.,s,s*t]),h,out)
    return out[0],out[1:4],out[4:].reshape(3,3)
def axis(s,t,i,r,n=40):
    if r==0: return ev(s,t,[0,0,0],n)[2][i,i]
    return ev(s,t,I[i]*r,n,False)[1][i]/r
def write(name,header,rows):
    with (OUT/(name+'.csv')).open('w') as f:
        w=csv.writer(f,lineterminator='\n')
        w.writerow(header.split()); w.writerows(rows)
