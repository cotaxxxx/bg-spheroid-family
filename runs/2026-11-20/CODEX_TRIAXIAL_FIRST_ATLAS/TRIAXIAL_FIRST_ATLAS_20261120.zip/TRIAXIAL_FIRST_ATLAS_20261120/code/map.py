from common import *
from itertools import pairwise
def run():
    shape=[]; roots=[]; scan=[]; records={}
    for s in S:
        for t in T:
            central=np.diag(ev(s,t,[0,0,0])[2])
            bound=[axis(s,t,i,1) for i in range(3)]
            records[s,t]=[*central,*bound]
            shape.append([s,t,*central,*bound])
            for i in range(3):
                vals=[central[i],*[axis(s,t,i,r) for r in R[1:-1]],bound[i]]
                scan.extend([s,t,i+1,r,v] for r,v in zip(R,vals))
                for j,(a,b) in enumerate(pairwise(R)):
                    if vals[j]*vals[j+1]>=0: continue
                    r=brentq(lambda x:axis(s,t,i,x),a,b,xtol=1e-12)
                    h=np.diag(ev(s,t,r*I[i])[2])
                    roots.append([s,t,i+1,r,*h,sum(h < -1e-6),axis(s,t,i,r,80)])
    write('shape','s t h1 h2 h3 b1 b2 b3',shape)
    write('axis','s t axis r H11 H22 H33 index_tol1e-6 G_at80',roots)
    write('radial_samples','s t axis r G',scan)
    curves=[]
    for fixed,grid,fgrid in [('s',T,S),('t',S,T)]:
        for f in fgrid:
            def st(v): return (f,v) if fixed=='s' else (v,f)
            for a,b in pairwise(grid):
                for j in range(6):
                    if records[st(a)][j]*records[st(b)][j]>=0:continue
                    fn=lambda v,n:axis(*st(v),j%3,int(j>=3),n)
                    # 40-node brackets from map; 80-node refinement only when still bracketed.
                    v=brentq(lambda v:fn(v,40),a,b)
                    v2=brentq(lambda v:fn(v,80),a,b) if fn(a,80)*fn(b,80)<0 else np.nan
                    curves.append([fixed,f,'bh'[j<3],j%3+1,a,b,v,v2,*st(v2)])
    write('curves','fixed fixed_value mode axis bracket_lo bracket_hi root40 root80 s t',curves)
if __name__=='__main__':run()
