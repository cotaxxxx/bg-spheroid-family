from mixed import *
from itertools import product,chain
def slice_search(arg):
    fixed,value=arg; rows=[]
    upper=6 if fixed=='s' else 3.2
    for ids in strata:
        for seed in np.linspace(1.02,upper,5):
            for ia,(a,b) in enumerate([(.43,.82),(1.05,.44)]):
                angles=[a]+([b] if len(ids)==3 else [])
                def evaluate(y,n):
                    s,t=(value,y[0]) if fixed=='s' else (y[0],value)
                    q=point(y[1:],ids,True)[0]
                    return ev(s,t,q,n,False)[1][list(ids)]/q[list(ids)],q,s,t
                sol=least_squares(lambda y:evaluate(y,40)[0],[seed,*angles],
                                  bounds=([1.02]+[.012]*len(angles),[upper]+[np.pi/2-.012]*len(angles)),max_nfev=40,
                                  gtol=1e-10,ftol=1e-10,xtol=1e-10)
                G,q,s,t=evaluate(sol.x,40); err=max(abs(G))
                check=max(abs(evaluate(sol.x,80)[0])) if err<.001 else np.nan
                rows.append([fixed,value,''.join(str(i+1) for i in ids),seed,ia,s,t,*q,err,check,sol.status,sol.nfev])
    return rows
def run():
    args=[('s',v) for v in S[1:]]+[('t',v) for v in T[1:]]
    with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','5'))) as pool:
        rows=list(chain.from_iterable(pool.map(slice_search,args)))
    write('moving_boundary','fixed value stratum seed_shape seed_angle s t q1 q2 q3 max_G40 recheck80_if_small solver_status nfev',rows)
if __name__=='__main__':run()
