from torque import *
def run():
    rows=[]
    for n in [160,320,480]:
        for r in [.93,.97,.99,.999,1.]:
            q=r*np.array([1.,2.,3.])/np.sqrt(14)
            G=ev(1.25,32,q,n,False)[1]/q
            v=next(evaluate(1.25,32,q,n))
            rows.append([1.25,32,r,*q,n,*G,*v[2:]])
        nodes.cache_clear()
    write('reversal','s t r q1 q2 q3 n G1 G2 G3 G2m1 torque12',rows)
if __name__=='__main__':run()
