from mixed import *
from itertools import product
import pandas as pd
def chord(s,t,q,n):
    """Independent formula in reference-chord directions. Average endpoints by symmetry."""
    e,w=nodes(n); a=np.array([1.,s,s*t]); A=a*a
    v=e@q; d=np.sqrt(1-q@q+v*v); ell=d-v
    xi=q+ell[:,None]*e; C=np.sum(A*e*e,axis=1)
    B=np.sum((xi/a)**2,axis=1)
    g=np.minimum(1,d/np.sqrt(C*B)); theta=np.arccos(g)
    # P via sinc; Q analytic limit near 1
    P=2/np.sinc(theta/np.pi)
    Q=2*P+g*(g*P-2)/np.maximum(1-g*g,1e-15)
    close=g>.99999
    Q[close]=2*P[close]-g[close]*(2/3+8/15*(1-g[close])+12/35*(1-g[close])**2)
    b=e*A/np.sqrt(C[:,None]); z=xi-(d/np.sqrt(C))[:,None]*b
    scale=ell/(d*np.sqrt(C*B))*w
    pos=scale*P*g*g*B
    return np.diag(A*sum(pos))-(b.T*pos)@b-(z.T*(Q*scale))@z
def run():
    m=pd.read_csv(OUT/'mixed.csv',dtype={'stratum':str})
    best=m.loc[m.groupby(['s','t','boundary','stratum']).max_G20.idxmin()]
    rows=[]
    for rec in best.itertuples():
        ids=[int(i)-1 for i in rec.stratum]
        q=np.array([rec.q1,rec.q2,rec.q3]); x=q[ids]; r=np.linalg.norm(x)
        ang=[np.arctan2(x[1],x[0])] if len(ids)==2 else [np.arcsin(x[2]/r),np.arctan2(x[1],x[0])]
        y=([] if rec.boundary else [np.clip(r,.01,.99998)])+list(np.clip(ang,.012,np.pi/2-.012))
        rows.append([rec.s,rec.t,rec.boundary,rec.stratum,*solve(rec.s,rec.t,ids,rec.boundary,y,n=40)])
    write('mixed_recheck','s t boundary stratum q1 q2 q3 max_G40 fine_if_small solver_status nfev',rows)
    rows=[]
    for s,t in product(S[1:],T[1:]):
        for ids in strata:
            for v in ([[1,1]] if len(ids)==2 else [[1,2,3],[3,2,1]]):
                unit=np.zeros(3);unit[list(ids)]=v;unit/=np.linalg.norm(unit)
                for r in [.25,.65,.93,1]:
                    q=r*unit; g=ev(s,t,q,40,False)[1]
                    G=np.full(3,np.nan); G[list(ids)]=g[list(ids)]/q[list(ids)]
                    rows.append([s,t,r,''.join(str(i+1) for i in ids),*q,*G,G[1]-G[0],G[2]-G[0],G[2]-G[1]])
    write('ordering','s t r stratum q1 q2 q3 G1 G2 G3 G2m1 G3m1 G3m2',rows)
    checks=[]
    for s,t,q in [(1,1,[.2,.1,.3]),(1.25,3,[.2,.3,.4]),(2.6,2,[.5,.2,.1]),(1.1,3,[0,.7,0])]:
        q=np.array(q); d=1e-5; _,g,H=ev(s,t,q,96)
        gf=[]; Hf=[]
        for e in I:
            vp,gp,_=ev(s,t,q+d*e,96); vm,gm,_=ev(s,t,q-d*e,96)
            gf.append((vp-vm)/(2*d));Hf.append((gp-gm)/(2*d))
        checks.append([s,t,*q,max(abs(g-gf)),np.max(abs(H-Hf)),np.max(abs(H-chord(s,t,q,120)))])
    write('derivative_check','s t q1 q2 q3 grad_vs_fd Hess_vs_fd Hess_vs_chord',checks)
if __name__=='__main__':run()
