from common import *
from itertools import combinations
def evaluate(s,t,q,n):
    # Reference area in a fixed frame, deliberately independent of the contact-aligned code.
    e,w=nodes(n); A=np.array([1.,s*s,(s*t)**2])
    v=e-q; D2=(v*v)@A; B=(e*e)@(1/A); k=1-e@q
    g=np.clip(k/np.sqrt(D2*B),0,1); P=2/np.sinc(np.arccos(g)/np.pi)
    G=ev(s,t,q,n,False)[1]/q
    for i,j in combinations(range(3),2):
        val=(A[j]-A[i])*np.dot(w*k*P*g,v[:,i]*v[:,j]/D2-e[:,i]*e[:,j]/(A[i]*A[j]*B))/(q[i]*q[j])
        yield [i+1,j+1,G[j]-G[i],val]
def run():
    rows=[]
    for s,t in [(1.02,3),(1.25,2.5),(2.45,1.02),(2,16),(1.25,32),(16,1.5),(32,3)]:
        for d in [[1.,2,3],[3.,2,1]]:
            for r in [.4,.93,1.]:
                q=r*np.array(d)/np.linalg.norm(d)
                for n in [80,160]:
                    rows.extend([s,t,r,*q,n,*v] for v in evaluate(s,t,q,n))
    write('torque','s t r q1 q2 q3 n i j Gdiff torque',rows)
if __name__=='__main__':run()
