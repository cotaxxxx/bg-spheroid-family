from common import *
from itertools import pairwise,product
from scipy.optimize import root, minimize_scalar
from concurrent.futures import ProcessPoolExecutor
import os
@lru_cache(None)
def quadrant(n):
    z,w=roots_legendre(n); y=(1+z)/2; w=w/2
    cut=2**-.5
    x=np.r_[cut*y,cut+(1-cut)*y]
    wx=2*x*np.r_[cut*w,(1-cut)*w]
    phi=y*np.pi/2; sin=2*x*np.sqrt(1-x*x)
    pts=np.stack(np.broadcast_arrays(sin[:,None]*np.cos(phi),sin[:,None]*np.sin(phi),(1-2*x*x)[:,None]),axis=-1)
    return np.ascontiguousarray(pts.reshape(-1,3)),np.outer(wx,w).ravel()
def ax(s,t,i,r,n):
    pts,w=quadrant(n); perm=[(i+1)%3,(i+2)%3,i]; a=np.array([1.,s,s*t])[perm]
    out=np.empty(13)
    LIB.evaluate(len(w),pts,w,np.array([0.,0.,r]),a,1,out)
    diag=np.diag(out[4:].reshape(3,3))[np.argsort(perm)]
    return (out[3]/r if r else diag[i]),diag
def f(s,t,j,n):
    return ax(s,t,j%3,float(j>=3),n)[0]
def findroot(s,t,i,a,b,n):
    return brentq(lambda r:ax(s,t,i,r,n)[0],a,b,xtol=3e-13)
def shape(st):
    s,t=st; rows=[]; axisrows=[]
    for n in [32,64]:
        vals=[f(s,t,j,n) for j in range(6)]
        rows.append([s,t,n,*vals])
        for i in range(3):
            v=[vals[i],*[ax(s,t,i,r,n)[0] for r in R[1:-1]],vals[3+i]]
            for j,(a,b) in enumerate(pairwise(R)):
                if v[j]*v[j+1]>=0: continue
                r=findroot(s,t,i,a,b,n)
                rr=findroot(s,t,i,a,b,96) if n==64 else np.nan
                _,h=ax(s,t,i,r,n)
                axisrows.append([s,t,n,i+1,r,rr,*h,sum(h< -1e-7),sum(abs(h)<1e-7)])
    return rows,axisrows
def section(s):
    rows=[]
    for j in range(6):
        for n in [48,96]:
            grid=T+[8,10,12]; vals=[f(s,t,j,n) for t in grid]
            for k,(a,b) in enumerate(pairwise(grid)):
                if vals[k]*vals[k+1]<0:
                    rt=brentq(lambda t:f(s,t,j,n),a,b)
                    rows.append([s,'hb'[j>=3],j%3+1,n,rt])
    return rows
def run():
    with ProcessPoolExecutor(max_workers=int(os.getenv('JOBS','5'))) as pool:
        records=list(pool.map(shape,product(S,T)))
        curves=list(pool.map(section,S+[4,6,8,12,16,24,32]))
    write('shape_refined','s t n h1 h2 h3 b1 b2 b3',[x for rows,_ in records for x in rows])
    write('axis_refined','s t n axis r r96 H11 H22 H33 index nullity_tol',[x for _,rows in records for x in rows])
    write('sections','s mode axis n t',[x for rows in curves for x in rows])
    special=[]
    for n in [48,96]:
        sol=root(lambda st:[f(*st,0,n),f(*st,4,n)],[1.56,2.30],tol=1e-11)
        special.append(['h1_b2',n,*sol.x,*sol.fun])
        for j in [1,4]:
            def threshold(s):return brentq(lambda t:f(s,t,j,n),1,8)
            res=minimize_scalar(lambda s:-threshold(s),bounds=(1.5,5),method='bounded',options={'xatol':1e-8})
            special.append(['max_'+'hb'[j>=3]+'2',n,res.x,-res.fun,f(res.x,-res.fun,j,n),np.nan])
        for j in [0,3]:
            s=brentq(lambda s:f(s,1,j,n),1,3)
            special.append(['ob_'+'hb'[j>=3]+'1',n,s,1,f(s,1,j,n),np.nan])
    write('special','event n s t residual1 residual2',special)
    tails=[]
    for x in [8,16,32]:
        for s,t in [(s,x) for s in [1,1.25,2]]+[(x,t) for t in [1,1.5,3]]:
            for n in [64,128,256]: tails.append([s,t,n,*[f(s,t,j,n) for j in range(6)]])
    write('rays','s t n h1 h2 h3 b1 b2 b3',tails)
    split=[]
    for ds in [0,.0001,.001,.005,.01,.02]:
        for i in [0,1]:
            r=findroot(1+ds,3,i,.65,.95,96); _,h=ax(1+ds,3,i,r,96)
            split.append([1+ds,3,i+1,r,*h])
    write('split','s t axis r H11 H22 H33',split)
if __name__=='__main__':run()
