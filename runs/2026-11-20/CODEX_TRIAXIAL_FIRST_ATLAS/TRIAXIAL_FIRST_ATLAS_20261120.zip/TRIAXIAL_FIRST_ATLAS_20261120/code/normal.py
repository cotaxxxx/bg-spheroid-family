from refine import *
import pandas as pd
def run():
    records=[]
    for v in pd.read_csv(OUT/'sections.csv').query('n==96 & s<=3.2').itertuples():
        records.append(('t',v.s,v.t,v.mode,v.axis-1))
    for v in pd.read_csv(OUT/'special.csv').query('n==96').itertuples():
        if v.event.startswith('ob'):records.append(('s',v.s,v.t,v.event[3],0))
    rows=[]
    for free,s,t,mode,i in records:
        r=int(mode=='b')
        def vary(step):return ax(s+(step if free=='s' else 0),t+(step if free=='t' else 0),i,r,96)[0]
        ds=[(vary(d)-vary(-d))/(2*d) for d in [.0002,.0001]]
        val,H=ax(s,t,i,r,96)
        if mode=='h':
            vals=[(ax(s,t,i,x,96)[0]-val)/(x*x) for x in [.025,.0125,.00625]]
            local=[(4*y-x)/3 for x,y in pairwise(vals)]
        else:local=[ax(s,t,i,r,n)[1][i] for n in [64,96]]
        rows.append([free,s,t,mode,i+1,*ds,*local,*H])
    write('normal','free s t mode axis dshape1 dshape2 cubic_or_Bslope1 cubic_or_Bslope2 H11 H22 H33',rows)
if __name__=='__main__':run()
