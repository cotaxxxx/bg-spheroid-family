"""DIAGNOSTIC_ONLY / NOT_EVIDENCE. Directed cell ranges for one perturbation coefficient.
IEEE binary64 with normal round-to-nearest primitive operations, correctly rounded square root;
each primitive result widened by nextafter. No platform transcendental functions.
"""
from pathlib import Path
from functools import lru_cache
import csv, math
import numpy as np
OUT=Path(__file__).resolve().parents[1]/'out'
def lo(x): return np.nextafter(x,-np.inf)
def hi(x): return np.nextafter(x,np.inf)
class Box:
    __array_priority__=1000
    def __init__(self,a,b=None):
        self.a=np.asarray(a,dtype=np.float64);self.b=self.a if b is None else np.asarray(b,dtype=np.float64)
    def __add__(self,o):
        o=box(o);return Box(lo(self.a+o.a),hi(self.b+o.b))
    __radd__=__add__
    def __neg__(self):return Box(-self.b,-self.a)
    def __sub__(self,o):return self+-box(o)
    def __rsub__(self,o):return box(o)+-self
    def __mul__(self,o):
        o=box(o)
        a,b,c,d=self.a*o.a,self.a*o.b,self.b*o.a,self.b*o.b
        return Box(lo(np.minimum(np.minimum(a,b),np.minimum(c,d))),hi(np.maximum(np.maximum(a,b),np.maximum(c,d))))
    __rmul__=__mul__
    def __truediv__(self,o):
        o=box(o); assert np.all(o.a>0)
        return self*Box(lo(1/o.b),hi(1/o.a))
    def sq(self):
        a,b=self.a**2,self.b**2
        return Box(np.where((self.a<=0)&(self.b>=0),0,lo(np.minimum(a,b))),hi(np.maximum(a,b)))
    def sqrt(self):
        return Box(lo(np.sqrt(np.maximum(0,self.a))),hi(np.sqrt(self.b)))
    def cut(self,a,b):
        x,y=np.maximum(self.a,a),np.minimum(self.b,b)
        assert np.all(x<=y)
        return Box(x,y)
def box(x):return x if isinstance(x,Box) else Box(x)
def psum(x,up):
    # entries of an equal-volume block; balanced signed sum, each level outward
    x=x.ravel(); assert len(x)&(len(x)-1)==0
    widen=hi if up else lo
    while len(x)>1: x=widen(x[::2]+x[1::2])
    return x[0]
N=16384
@lru_cache(None)
def table():
    g=np.arange(N+1)/N; z=Box((1-g)/2)
    v=Box(0)
    for j in range(54,-1,-1):
        # Form the exactly rational coefficient via nearest-even Python integer division,
        # then widen by one ULP on both sides.
        c=math.comb(2*j,j)/(4**j*(2*j+1))
        v=Box(lo(c),hi(c))+z*v
    v=v+Box(0.,2.**-54) # sum_{j>=55} (1/2)^j <= 2^-54
    return 2*v/(1-z).sqrt(),4*z*v.sq()
def angles(g):
    lower=np.floor(g.a*N).astype(int); upper=np.ceil(g.b*N).astype(int)
    return tuple(Box(v.a[upper],v.b[lower]) for v in table())
def integral(r,M,mode):
    W=M//2
    w=Box(np.arange(W)/W,np.arange(1,W+1)/W)
    den=1+w.sq(); sy=(1-w.sq())/den; sz=2*w/den
    # Probabilistic phi density after folding four quadrants: 4/pi/(1+w^2)
    weight=Box(4)/Box(333/106-1e-14,355/113+1e-14)/den
    sums=[]
    for i in range(0,M,32):
        z=np.arange(i,i+32)[:,None]
        mu=Box(-1+2*z/M,-1+2*(z+1)/M)
        m2=mu.sq(); left=(1-m2).cut(0,1)
        y2=left*sy.sq(); z2=left*sz.sq()
        v=mu-r; k=1-mu*r
        D2=(v.sq()+left+8*z2).cut(lo((1-r.b)**2),np.inf)
        B=(1-Box(8)/9*z2).cut(lo(1/9),1)
        D=D2.sqrt(); S=B.sqrt()
        g=(k/(D*S)).cut(0,1); P,alpha2=angles(g)
        if mode=='g':
            val=mu*(g*P-alpha2)-(v/D)*S*g.sq()*P
        else:
            val=.5*k*P*g*((m2-y2)/B-(v.sq()-y2)/D2)
        val=weight*val
        sums.append((psum(val.a,False),psum(val.b,True)))
    ar=np.asarray(sums)
    return Box(psum(ar[:,0],False),psum(ar[:,1],True))/(M*W)
def run():
    cases=[('g',13/16,13/16,1),('g',27/32,27/32,-1)]
    # From outset use all eight r subintervals to avoid parameter wrapping.
    cuts=np.linspace(13/16,27/32,9)
    cases.extend(('c',a,b,-1) for a,b in zip(cuts[:-1],cuts[1:]))
    with (OUT/'ring_boxes.csv').open('w') as file:
        writer=csv.writer(file,lineterminator='\n')
        writer.writerow('mode rlo_x256 rhi_x256 mu_lo mu_hi w_lo w_hi nmu nw lower upper result'.split())
        for mode,a,b,sign in cases:
            for M in [256,512,1024,2048,4096]:
                enclosure=integral(Box(a,b),M,mode)
                good=enclosure.a>0 if sign==1 else enclosure.b<0
                writer.writerow([mode,round(a*256),round(b*256),-1,1,0,1,M,M//2,float(enclosure.a),float(enclosure.b),'sign' if good else 'refine'])
                file.flush()
                if good: break
if __name__=='__main__':run()
