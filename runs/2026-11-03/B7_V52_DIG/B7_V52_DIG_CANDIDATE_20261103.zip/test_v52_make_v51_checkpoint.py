#!/usr/bin/env python3
"""Produce synthetic V5.1 eight-leaf checkpoint only; interrupt after durable write.

This test makes NO change to the production V5.1 jobs or checkpoints.
"""
import importlib
import os
import sys
from pathlib import Path
from fractions import Fraction as Q

work=Path('/home/daybreak/B7_work/b7_v51')
sys.path.insert(0,str(work))
w=importlib.import_module('v6_b7_unified_outerrem_v51')
cells=[]
for yi in range(2):
    y=(Q(56+yi,100),Q(57+yi,100))
    for ti in range(2):
        for ui in range(2):
            cells.append((y,(Q(1,1000),Q(11,10000)),
                          (Q(ti,2),Q(ti+1,2)),(Q(ui,2),Q(ui+1,2))))
assert len(cells)==8
w.inner_grid_v2=lambda:iter(cells)
w.grid_count=lambda:8
original=w.atomic
def hook(path,obj,as_json=False):
    original(path,obj,as_json)
    if path.suffix=='.checkpoint' and obj['state']['initialized']:
        print('SYNTHETIC_V51_ATOMIC_CHECKPOINT_CREATED',path,flush=True)
        os._exit(42)
w.atomic=hook
out=Path('/home/daybreak/B7_work/b7_v52/diagnostics/synthetic_8_v51_checkpoint')
out.mkdir(parents=True,exist_ok=True)
assert not any(out.iterdir()),'refusing nonempty test directory'
job=('L0_T3_D1',dict(w.boxes())['L0_T3_D1'],'full',8,8,str(out),2,w.fingerprint(),(1,1,1),1,1,1,False)
w.worker(job)
raise RuntimeError('expected test-only abrupt interruption')
