#!/usr/bin/env python3
"""Diagnostic-only read-only V5.2 ASTRA3 stratified K-floor sample.

This is not a certificate; no production files are altered.
"""
from pathlib import Path
from fractions import Fraction as Q
import sys
import pickle
import hashlib
import random
import time
import json

ROOT=Path('/home/daybreak/B7_work/b7_v52')
sys.path.insert(0,str(ROOT))
from b7_astra3_v52 import astra3_floor_raw
S=1<<128
rng_seed=20261103
d=Path('/home/daybreak/B7_work/b7_v51/full_v51')
rows=[]
for name in ('L0_T0_D1','L0_T1_D1','L0_T2_D1','L0_T3_D1','L1_T0_D1','L1_T1_D1'):
    path=d/(name+'_full.checkpoint')
    if not path.exists():
        print('NO_CHECKPOINT',name,flush=True);continue
    t0=time.monotonic()
    with path.open('rb') as f:
        obj=pickle.load(f)
    cfg=obj['config']
    outer=tuple(tuple(Q(x) for x in ab) for ab in cfg['outer'])
    all_k=[x for x in obj['state']['active'].values() if x['bound_source']=='K_FLOOR']
    eligible=[x for x in all_k if x['cell'][1][1]<=Q(1,100)]
    rs=random.Random(rng_seed+len(name))
    selected=rs.sample(eligible,min(256,len(eligible)))
    oldraw=0;newraw=0;strict=0;positive=0
    for leaf in selected:
        old=leaf['total_lo_selected']
        cand=astra3_floor_raw(outer,leaf['cell'])
        new=max(old,cand)
        oldraw+=old;newraw+=new
        strict+=new>old
        positive+=cand==0
    result={'key':name,'leaves':len(obj['state']['active']),
        'total_k_floor':len(all_k),'small_p_k_floor':len(eligible),
        'samples':len(selected),'strict_improvements':strict,'astra3_zero_candidates':positive,
        'sample_old_negative_J':float(Q(oldraw,S)),
        'sample_new_negative_J':float(Q(newraw,S)),
        'fraction_of_sample_K_floor_loss_removed':float(Q(newraw-oldraw,-oldraw)) if oldraw<0 else None,
        'runtime_seconds':round(time.monotonic()-t0,2)}
    print('SAMPLE',json.dumps(result,sort_keys=True),flush=True)
    rows.append(result)
out=ROOT/'V52_ASTRA3_256_SAMPLE_D1_20261103.json'
out.write_text(json.dumps({'date':'2026-11-03','method':'sampling current checkpoint 256 random K-floor small-p leaves per box; read-only','not_proof':True,'results':rows},indent=2,sort_keys=True)+'\n')
print('WRITTEN',out,flush=True)
