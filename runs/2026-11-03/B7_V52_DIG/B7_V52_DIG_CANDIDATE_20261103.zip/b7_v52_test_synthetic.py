#!/usr/bin/env python3
"""Read-only V5.1-vs-V5.2 synthetic whole-leaf regression (NOT a B7 certificate).

Test starts 8 inner leaves in difficult D1 p~1e-3 and freezes at 8 leaves.
Only the generator and its count are monkeypatched IN MEMORY.
No production checkpoint is used or modified.
"""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys
from fractions import Fraction as Q

ap=argparse.ArgumentParser()
ap.add_argument('--version',choices=('v51','v52'),required=True)
ap.add_argument('--out',required=True)
args=ap.parse_args()
root=Path('/home/daybreak/B7_work')
work=root/('b7_v51' if args.version=='v51' else 'b7_v52')
sys.path.insert(0,str(work))
os.chdir(work)
w=importlib.import_module('v6_b7_unified_outerrem_'+args.version)
cells=[]
for yi in range(2):
    y=(Q(56+yi,100),Q(57+yi,100))
    for ti in range(2):
        for ui in range(2):
            cells.append((y,(Q(1,1000),Q(11,10000)),
                          (Q(ti,2),Q(ti+1,2)),(Q(ui,2),Q(ui+1,2))))
assert len(cells)==8
w.inner_grid_v2=lambda:iter(cells)
w.grid_count=lambda:len(cells)
out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
if any(out.iterdir()):raise RuntimeError('requires empty diagnostic directory')
key='L0_T3_D1'
job=(key,dict(w.boxes())[key],'full',8,8,str(out),2,w.fingerprint(),
     (1,1,1),1,1,1,False)
print('START',args.version,'fp',w.fingerprint(),'source',
      hashlib.sha256((work/('v6_b7_unified_outerrem_'+args.version+'.py')).read_bytes()).hexdigest(),flush=True)
w.worker(job)
res=json.loads((out/(key+'_full.json')).read_text())
leaves=json.loads((out/(key+'_full.leaves.json')).read_text())['leaves']
assert res['leaves']==8 and res['initial_cells']==8
print('COMPLETE',args.version,'J',res['total_lower'],'status',res['status'],
      'chosen',{src:sum(x['bound_source']==src for x in leaves) for src in ('K_FLOOR','MIDPOINT','ZEROTH','ASTRA3')},
      'raw_selected',[x['selected_lower_raw'] for x in leaves],flush=True)
